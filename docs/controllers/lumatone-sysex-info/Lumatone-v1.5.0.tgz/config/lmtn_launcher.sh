#!/bin/sh
#NOTE: no "set -e" here. A failed firmware update must never stop the Lumatone application from starting,
#otherwise the octave boards stay in rainbow mode on every boot.

#directory
User_dir=/home/debian
App_dir=/home/debian/LumatoneController

#free space if the storage is nearly full: settings files cannot be written then and the application fails to start.
#old units fill up with system logs (see lmtn_unpack.sh)
Log_dir=/var/log
used="$(df -P / | awk 'NR==2 {print $5}' | tr -d '%')"
if [ -n "$used" ] && [ "$used" -ge 90 ]; then
    echo "storage ${used}% full, clearing large log files"
    find "$Log_dir" -type f -size +10M -exec truncate -s 0 {} +
fi

#check for a new firmware update package, only in the home directory itself
#(an extracted package can leave config/Lumatone-v*.tgz behind, which must not be picked up)
FW_File="$(find "$User_dir" -maxdepth 1 -type f -name "Lumatone-v*.tgz" | sort -rV | head -n 1)"

if [ -n "$FW_File" ]; then
    echo "fw update package present"
    update_installed=false

    #start from a clean config folder
    rm -rf "${User_dir}/config"

    echo "unpacking $FW_File"
    #extract tgz file. quoted, as the file name may contain spaces
    if tar -xvzf "$FW_File" -C "$User_dir" --warning=no-timestamp; then
        echo "launch unpacking script"
        #launch unpack script to update relevant BBB internal files for application
        if "${User_dir}/config/lmtn_unpack.sh"; then
            update_installed=true
        else
            echo "ERROR: unpacking script failed"
        fi
    else
        echo "ERROR: could not extract $FW_File"
    fi

    if [ "$update_installed" = true ]; then
        #launch picberry application to update submodules CA-004
        echo "launch ICSP..."
        "${App_dir}/picberry" -o 0 -w "${App_dir}/LMTN-01_OctaveBoard.hex" || echo "ERROR: octave board programming failed"
    fi

    #remove firmware update related files and folders, including a package that failed,
    #so that it is not retried on every boot
    echo "cleaning temp folder"
    rm -rf "${User_dir}/config"

    echo "removing tgz file(s)"
    find "$User_dir" -maxdepth 1 -type f -name "*.tgz" -delete

    if [ "$update_installed" = true ]; then
        echo "rebooting BBB to apply kernel changes"
        sudo reboot
        exit 0
    fi
    echo "fw update not installed, launching current application"
else
    #remove any other tgz files that are not firmware packages
    find "$User_dir" -maxdepth 1 -type f -name "*.tgz" -delete
    echo "no new fw package"
fi

#launch lumatone-BBB application. An older firmware package (1.4.1 and earlier) installs its program as
#TerpstraController; newer packages remove that file, so if it exists an older version was installed last.
App=LumatoneController
if [ -x ${App_dir}/TerpstraController ]; then App=TerpstraController; fi
while :; do sudo ${App_dir}/$App ; done

exit 0
