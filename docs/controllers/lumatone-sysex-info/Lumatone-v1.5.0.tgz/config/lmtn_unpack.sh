#!/bin/sh -e

#directory
App_dir=/home/debian/LumatoneController
config_dir=/home/debian/config
#folder and program name used by firmware 1.4.1 and earlier
Legacy_dir=/home/debian/TerpstraController
Legacy_app=TerpstraController

#move an existing installation to the new folder, keeping presets, calibration and fw_rev.txt
if [ -d $Legacy_dir ] && [ ! -L $Legacy_dir ]; then
    if [ ! -e $App_dir ]; then
        echo "Moving $Legacy_dir to $App_dir"
        mv $Legacy_dir $App_dir
    else
        #replace it with the link below, otherwise the launcher of the installed (older) firmware
        #would program the octave boards from a folder this update did not write to
        echo "WARNING: both $Legacy_dir and $App_dir exist, keeping $App_dir, moving $Legacy_dir to ${Legacy_dir}_old"
        rm -rf ${Legacy_dir}_old
        mv $Legacy_dir ${Legacy_dir}_old
    fi
fi

#create_dir () {
if [ ! -e $App_dir ]; then
    echo "Creating dir $App_dir"
    mkdir $App_dir
fi
#}

#keep the old path working: the launcher of the installed (older) firmware runs this script and then
#programs the octave boards from the old path, and older firmware packages install into it
if [ ! -e $Legacy_dir ]; then
    ln -s $App_dir $Legacy_dir
fi

#install the launcher on every update, not only the first, so fixes to it reach existing units.
#the launcher running this script is reading that file, so copy alongside and rename over it:
#the running shell keeps the old file open instead of reading a half-written new one.
echo "Copying Lumatone Installer shell script ..."
cp ${config_dir}/lmtn_launcher.sh ${App_dir}/lmtn_launcher.sh.new
chmod +x ${App_dir}/lmtn_launcher.sh.new
mv -f ${App_dir}/lmtn_launcher.sh.new ${App_dir}/lmtn_launcher.sh

#NOTE: shell script must be unixified prior to upload to beaglebone as unixify function does not exist on beaglebones
#if unixify is not done, shell script will not execute and fail

echo "Copying executables to proper locations..."
#configure application files to executables
cd /home/debian/config

cp LumatoneController $App_dir
#remove the program file of older firmware; the launcher runs it only if an older package puts it back (rollback)
rm -f $App_dir/$Legacy_app
cp picberry $App_dir                   
cp CA004_Test $App_dir             
cp LMTN-01_OctaveBoard.X.production.hex $App_dir/LMTN-01_OctaveBoard.hex
chmod +x ${App_dir}/LumatoneController
chmod +x ${App_dir}/picberry
chmod +x ${App_dir}/CA004_Test

echo "Copy default presets"
tar xzf defaults.tgz -C $App_dir

echo "Copying uEnv boot file..."
#replace uEnv file
sudo cp uEnv.txt /boot/

echo "Copying tree overlay files..."
#create the dtbo file from dts file and move to appropriate location
#if this fails, the overlay already in /lib/firmware stays in use
{ cpp -nostdinc -I include -I arch  -undef -x assembler-with-cpp LMTN-GPIO-00A0.dts LMTN-GPIO-00A0.dts.preprocessed &&
  dtc -O dtb -o LMTN-GPIO-00A0.dtbo -b 0 -@ LMTN-GPIO-00A0.dts.preprocessed &&
  sudo mv LMTN-GPIO-00A0.dtbo /lib/firmware/ ; } || echo "WARNING: could not rebuild tree overlay, keeping existing one"

echo "Copying systemd files..."
#launch the autoscript set up
sudo cp lmtn_gpiosetup.service /lib/systemd/system
sudo systemctl enable lmtn_gpiosetup.service

echo "Copying usb config settings..."
#replace usb set up script with custom and replace dependent usb config files
sudo cp am335x_evm.sh /opt/scripts/boot/
sudo cp bb-boot /etc/default/

echo "limiting system logs..."
#the BBB has no clock battery and starts in 2016 on every boot, so date-based log rotation never runs and
#/var/log/syslog and daemon.log grow until the storage is full. A full storage makes settings files come out
#empty and stops the Lumatone application from starting. The journal (journalctl) still works and is kept in memory.
sudo systemctl mask --now syslog.socket rsyslog.service || echo "WARNING: could not disable rsyslog"
sudo find /var/log -type f -size +10M -exec truncate -s 0 {} + || echo "WARNING: could not trim log files"
sudo mkdir -p /etc/systemd/journald.conf.d &&
printf '[Journal]\nSystemMaxUse=20M\nRuntimeMaxUse=20M\n' | sudo tee /etc/systemd/journald.conf.d/lumatone.conf > /dev/null ||
    echo "WARNING: could not limit the journal size"

echo "disable bonescript services..."
#disable bonescript if currently enabled in systemd
#fails if any of these units is not installed, which must not stop the update
sudo systemctl disable bonescript.service bonescript.socket bonescript-autorun.service || echo "WARNING: could not disable bonescript services"

if [ -e ${App_dir}/files ]; then
	echo "files folder generated, check fw version..."
	if [ -e ${App_dir}/fw_rev.txt ]; then
		curr_fw=`cat ${App_dir}/fw_rev.txt`
		echo "current fw version: ${curr_fw}"

		package_fw=`cat ${config_dir}/fw_rev.txt`
		echo "package fw version: ${package_fw}"

		#optional changes can be made here
		#application will update files accordingly upon initial startup on next execute

	else
		echo "fw_rev.txt not found, fw_rev < 1.0.8"
		if [ -e ${App_dir}/files/GlobalSettings ]; then 
			echo "removing GlobalSettings file..."
			sudo rm ${App_dir}/files/GlobalSettings
		fi

		echo "generating revision 1.0.7 fw_rev.txt..."
		touch ${App_dir}/fw_rev.txt
		echo "1.0.7" > ${App_dir}/fw_rev.txt
	fi
else
	echo "files folder not generated by app, first time unpacking"
	cp fw_rev.txt $App_dir
fi

