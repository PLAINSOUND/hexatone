#!/bin/sh -e

#directory
User_dir=/home/debian
Terpstra_dir=/home/debian/TerpstraController

#check for any new firmware update packages.
if find $User_dir -type f -name "*.tgz" -print -quit | grep -q '^'; then
    echo "tgz file(s) detected"
    if find $User_dir -type f -name "Lumatone-v*" -print -quit | grep -q '^'; then
        echo "fw update package present"
        FW_File="$(find $User_dir -name "Lumatone-v*" -print0 | xargs -r -0 ls -1rv | head -1)"

        echo "unpacking $FW_File"
        #extract tgz file
        tar -xvzf $FW_File -C ${User_dir} --warning=no-timestamp

        echo "launch unpacking script"
        #launch unpack script to update relevant BBB internal files for application
        ${User_dir}/config/lmtn_unpack.sh
    
        #launch picberry application to update submodules CA-004
        echo "launch ICSP..."
        ${Terpstra_dir}/picberry -o 0 -w ${Terpstra_dir}/LMTN-01_OctaveBoard.hex

        #remove firmware update related files and folders
        echo "cleaning temp folder"
        rm -r ${User_dir}/config

	echo "removing tgz file(s)"
	find ${User_dr} -name "*.tgz" -type f -delete
	
	echo "rebooting BBB to apply kernel changes"
	sudo reboot
    else
        echo "fw update package was not found in tgz files"
	echo "removing tgz file(s)"
	find ${User_dir} -name "*.tgz" -type f -delete
    fi
else
    echo "no new fw package"
fi

#launch lumatone-BBB application
while :; do sudo ${Terpstra_dir}/TerpstraController ; done

exit 0
