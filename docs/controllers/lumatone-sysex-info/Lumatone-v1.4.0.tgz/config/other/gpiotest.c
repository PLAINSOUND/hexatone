#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <iobb.h>

#define GPIO_PORT	9
#define GPIO_PIN	20

int main(void){
	int x=0;
	(void) iolib_init();
	iolib_setdir(GPIO_PORT, GPIO_PIN, DigitalOut);	//CTS1, GPIO2_2	

	do{
		(x==1)? pin_high(GPIO_PORT, GPIO_PIN): pin_low(GPIO_PORT, GPIO_PIN);		
		printf("enter number. if 2, exit program\n");
		scanf("%d", &x);
	}while(x>=0);
   
	iolib_free();

   return 0;
}