#include <linux/soundcard.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int main(void) {
	int x=1;
   char* device =  "/dev/snd/midiC0D0" ;
   unsigned char data[3] = {0x90, 60, 127};

   // step 1: open the OSS device for writing
   int fd = open(device, O_WRONLY, 0);
   if (fd < 0) {
      printf("Error: cannot open %s\n", device);
      exit(1);
   }

   do{
	printf("enter number. if 0, exit program\n");
	scanf("%d", &x);
	
   // step 2: write the MIDI information to the OSS device
	if(x!=0) write(fd, data, sizeof(data));
   }while(x!=0);
   
   // step 3: (optional) close the OSS device
   close(fd);

   return 0;
}
