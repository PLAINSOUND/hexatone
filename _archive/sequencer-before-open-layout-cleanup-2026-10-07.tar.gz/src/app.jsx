/**
 * src/app.jsx
 *
 * Main application shell for PLAINSOUND HEXATONE.
 *
 * This file composes the major runtime layers: persisted settings, tuning
 * normalization, keyboard/synth wiring, controller integration, manual/help
 * surfaces, and the two primary workspaces (Hexatone and Sequencer). It is the
 * orchestration boundary where domain modules are combined into the running app.
 */
import { Suspense, lazy } from "preact/compat";
import { useState, useEffect, useLayoutEffect, useMemo, useCallback, useRef } from "preact/hooks";

import Keyboard from "./keyboard";
import { sendLumatoneBlankLayout } from "./keyboard/keys-controller-leds.js";
import { primeSharedSampleAudio } from "./sample_synth/prime-shared-audio.js";
import { bringPaletteToFront } from "./ui/palette-stacking.js";
import { normalizeColors, normalizeStructural } from "./settings/normalize-settings.js";
import { instruments } from "./sample_synth/instruments";
import { createScaleWorkspace, normalizeWorkspaceForKeys } from "./tuning/workspace.js";
import { restoreIOOnReload } from "./persistence/io-reload-policy.js";
import {
  createHarmonicFrame,
  deriveActiveHejiFrame,
  deriveCurrentFundamentalForHistory,
  deriveCurrentFundamentalSummary,
  deriveDegreeColorsForFrame,
  deriveHejiLabelsForFrame,
  deriveModulationPaletteTitles,
  deriveModulationSummaryText,
  hasActiveModulationHistory,
  modulationHistoryKey,
  modulationEntryDisplayText,
  modulationRouteLabelPair,
  presetModulationSnapshot,
  replayModulationHistoryForFrame,
  snapshotModulationState,
  spellWorkspaceForFrame,
} from "./tuning/modulation-frame-runtime.js";
import { parseExactInterval } from "./tuning/interval.js";

import useSynthWiring from "./hooks/use-synth-wiring.js";
import { createTransportClock } from "./sequencer/transport-clock.js";
import useAudioRecovery from "./hooks/use-audio-recovery.js";
import { useMidiGuardian } from "./hooks/use-midi-guardian.js";
import useDeferredModulationHistory from "./tuning/use-deferred-modulation-history.js";
import {
  useQuery,
  ExtractInt,
  ExtractString,
  ExtractFloat,
  ExtractBool,
  ExtractJoinedString,
} from "./hooks/use-query";
import usePresets, { SCALE_KEYS_TO_CLEAR } from "./hooks/use-presets.js";
import {
  buildQuerySpec,
  buildRegistryDefaults,
  PRESET_SKIP_KEYS,
} from "./persistence/settings-registry.js";
import { settingsImpactKey, settingsImpactSnapshot } from "./settings/settings-impact-registry.js";
import useImport from "./hooks/use-import.js";
import useSettingsChange from "./hooks/use-settings-change.js";
import sessionDefaults from "./settings/session-defaults.js";
import {
  controllerRequiresMpeInput,
  detectController,
  getControllerById,
  getControllerMpeInputPolicy,
} from "./controllers/registry.js";
import Credits from "./credits";
import LoadingIcon from "./loading-icon.jsx";
import ManualSidebar from "./manual/manual-sidebar.jsx";
import {
  addBarsBeforeSnapshots,
  addSequenceBarMarker,
  addSequenceRepeatMarker,
  addSequenceTempoMarker,
  moveSequenceBarMarker,
  updateSequenceBarMarker,
  updateSequenceRepeatMarker,
  updateSequenceTempoMarker,
} from "./sequencer/structure-editing.js";
import {
  SEQUENCE_WORKSPACE_STORAGE_KEY,
  loadSequenceWorkspaceFromSession,
  createSequenceWorkspaceSessionWriter,
} from "./sequencer/session-persistence.js";
import { CALCULATOR_WORKSPACE_STORAGE_KEY } from "./calculator/session-persistence.js";
import {
  buildLoadedSequenceWorkspace,
  buildRestoredSequenceWorkspace,
  defaultSequenceBars,
  defaultSequenceTempi,
} from "./sequencer/workspace-runtime.js";
import { sequenceWorkspaceTransition } from "./sequencer/workspace-transition.js";
import { presentSnapshotPalette } from "./sequencer/snapshot-palette-presenter.js";
import {
  effectiveManualSnapshotArticulation,
  normalizeManualArpeggiation,
} from "./sequencer/manual-snapshot-arpeggiation.js";
import {
  planManualSnapshotFormation,
  planManualSnapshotRelease,
} from "./sequencer/manual-snapshot-gesture-planner.js";
import { createManualSnapshotGestureRuntime } from "./sequencer/manual-snapshot-gesture-runtime.js";
import {
  appendSnapshotToWorkspace,
  buildClearedSequenceWorkspaceState,
  deleteSnapshotRangeFromWorkspace,
  deleteSnapshotFromWorkspace,
  duplicateSnapshotInWorkspace,
  insertSnapshotCopyBlock,
  moveSnapshotRangeInWorkspace,
  moveSnapshotInWorkspace,
  resetSnapshotRangeNoteOffsetsInWorkspace,
  resetSnapshotDescriptionInWorkspace,
  restoreSnapshotsInWorkspace,
  setSnapshotRangeArticulationInWorkspace,
  updateSnapshotInWorkspace,
} from "./sequencer/snapshot-workspace-runtime.js";
import { captureSequencePitchFrame } from "./sequencer/pitch-frame.js";
import {
  appendPersistedTimedTransportDiagnostic,
  isTimedTransportDiagnosticsEnabled,
} from "./debug/timed-transport-diagnostics.js";
import {
  appendPersistedSequenceRuntimeDiagnostic,
  isSequenceRuntimeDiagnosticsEnabled,
} from "./debug/sequence-runtime-diagnostics.js";
import {
  appendPersistedSequencerCrashDiagnostic,
  createSequencerDiagnosticTransactionId,
  getActiveSequencerDiagnosticTransaction,
  isSequencerCrashDiagnosticsEnabled,
  loadPersistedSequencerCrashDiagnostics,
  readSequencerDiagnosticMemory,
} from "./debug/sequencer-crash-diagnostics.js";
import { buildSnapshotDisplayDescription } from "./sequencer/labels.js";
import { deriveSequenceLegatoFlags, normalizeSequenceLegatoMode } from "./sequencer/legato.js";
import ChordSnapControls from "./sequencer/chord-snap-controls.jsx";
import { DEFAULT_CHORD_DRIFT } from "./sequencer/chord-snap.js";
import { createChordSnapScheduler, chordPrefetchIndices } from "./sequencer/chord-snap-scheduler.js";
import { noteIdentity as sequenceNoteIdentity } from "./sequencer/value-runtime.js";
import {
  remapSequenceSnapshotsToRuntime,
  resolveLiveSequencePitch,
  resolveSequenceSnapRuntime,
  withSequenceSnapGroup,
  prepareSequenceChord,
} from "./sequencer/runtime-pitch-map.js";
import { createSequenceRuntimeModelBuilder } from "./sequencer/runtime-model.js";
import { buildCueExpandedSnapshotIdsAt } from "./sequencer/view-runtime.js";
import { clearPendingTransportSelection } from "./sequencer/transport-selection.js";
import {
  buildCommittedSequencePlaybackState,
  buildStoppedSequenceTransportState,
  buildTimedPlaybackUiResetState,
  resolveManualPlaybackStopTransportState,
  resolvePendingCueTransportState,
  resolvePendingSnapshotTransportState,
  resolveWorkspaceMutationTransportState,
} from "./sequencer/transport-intent-runtime.js";
import {
  applyPlaybackPitchOffsetToNotes,
  applySequenceTimbreModWheelToNotes,
  clampSequenceTimbreModWheel,
  clampSequencePlaybackPitchCents,
  clampSequencePlaybackSpeed,
  NEUTRAL_SEQUENCE_TIMBRE_MOD_WHEEL,
} from "./sequencer/playback-modifiers-runtime.js";
import { advanceCueIndexWithRepeats } from "./sequencer/repeat-playback-runtime.js";
import { buildDependencyToken } from "./sequencer/dependency-token.js";
import { reuseEquivalentDisplaySnapshots } from "./sequencer/display-snapshot-stability.js";
import {
  applySequenceTimbreModWheelToActiveSnapshotHexes,
  retuneActiveSnapshotHexes,
  remapActiveSnapshotHexes,
  retuneSnapshotHexes,
} from "./sequencer/snapshots.js";

const Settings = lazy(() => import("./settings/index.jsx"));
const IOSettings = lazy(() => import("./settings/io-settings.jsx"));
const CalculatorTab = lazy(() => import("./calculator/tab.jsx"));
const Sequencer = lazy(() => import("./sequencer/sequencer.jsx"));
// Lazy controller imports keep optional hardware paths out of the initial app
// shell until the relevant controller/runtime actually needs them.
const loadExquisLEDs = (() => {
  let promise = null;
  return () => (promise ??= import("./controllers/exquis-leds.js"));
})();
const loadLumatoneLEDs = (() => {
  let promise = null;
  return () => (promise ??= import("./controllers/lumatone-leds.js"));
})();
const loadLinnstrumentUserFirmware = (() => {
  let promise = null;
  return () => (promise ??= import("./controllers/linnstrument-user-firmware.js"));
})();
const loadHakenController = (() => {
  let promise = null;
  return () => (promise ??= import("./controllers/hakenaudio.js"));
})();

export function applyReloadPersistencePolicy({
  navigationType = performance.getEntriesByType("navigation")[0]?.type,
  shouldPersist = localStorage.getItem("hexatone_persist_on_reload") === "true",
} = {}) {
  if (navigationType !== "reload" || shouldPersist) return;

  // SCALE_KEYS_TO_CLEAR covers all scale/preset keys.
  // Clear musical workspace state only. MIDI access and auto-send intent are
  // governed independently by the I/O reload policy before defaults are read.
  const extraKeysToClear = [
    "hexatone_preset_source",
    "hexatone_preset_name",
    SEQUENCE_WORKSPACE_STORAGE_KEY,
    CALCULATOR_WORKSPACE_STORAGE_KEY,
  ];
  [...SCALE_KEYS_TO_CLEAR, ...extraKeysToClear].forEach((key) => sessionStorage.removeItem(key));

  if (window.location.search.length > 0) {
    const url = new URL(window.location.toString());
    url.search = "";
    history.replaceState({}, "Hexatone WebApp", url);
  }
}

export const RELOAD_WORKSPACE_TAB_KEY = "hexatone_reload_workspace_tab";
const RELOADABLE_WORKSPACE_TABS = new Set(["sequencer", "calculator", "io"]);

export function loadReloadWorkspaceTab(storage = globalThis.sessionStorage) {
  try {
    const storedTab = storage?.getItem(RELOAD_WORKSPACE_TAB_KEY);
    if (storedTab === "io" && !restoreIOOnReload()) return "hexatone";
    return RELOADABLE_WORKSPACE_TABS.has(storedTab) ? storedTab : "hexatone";
  } catch {
    return "hexatone";
  }
}

export function saveReloadWorkspaceTab(workspaceTab, storage = globalThis.sessionStorage) {
  try {
    if (RELOADABLE_WORKSPACE_TABS.has(workspaceTab)) {
      storage?.setItem(RELOAD_WORKSPACE_TAB_KEY, workspaceTab);
    } else {
      storage?.removeItem(RELOAD_WORKSPACE_TAB_KEY);
    }
  } catch {
    // Navigation state is optional when browser storage is unavailable.
  }
}

// On browser refresh (not initial load), clear scale/preset sessionStorage unless
// the user has opted into "Restore last preset on page reload".
applyReloadPersistencePolicy();

export const Loading = () => <LoadingIcon />;

function SidebarLoadingFallback() {
  return (
    <div className="app-shell__sidebar-loading">
      <LoadingIcon />
    </div>
  );
}

function buildLumatoneAutoSyncKey({
  lumatoneInId,
  lumatoneOutId,
  name,
  referenceDegree,
  fundamental,
  noteColors,
  keyLabels,
  scale,
  equivInterval,
  centerDegree,
  rSteps,
  drSteps,
  anchorNote,
  anchorChannel,
}) {
  return [
    lumatoneInId ?? "no-in",
    lumatoneOutId ?? "no-out",
    name ?? "",
    referenceDegree ?? "",
    fundamental ?? "",
    noteColors ?? "",
    keyLabels ?? "",
    scale ?? "",
    equivInterval ?? "",
    centerDegree ?? "",
    rSteps ?? "",
    drSteps ?? "",
    anchorNote ?? "",
    anchorChannel ?? "",
  ].join("|");
}

function modulo(value, modulus) {
  if (!modulus) return value;
  return ((value % modulus) + modulus) % modulus;
}

function formatCommittedCents(cents) {
  return Number.isFinite(cents) ? Number(cents).toFixed(6) : "";
}

function formatCommittedRatio(ratio) {
  if (!ratio?.toFraction) return null;
  const text = ratio.toFraction();
  return text.includes("/") ? text : `${text}/1`;
}

function modulationSnapshotKey(snapshot) {
  if (!snapshot) return "";
  const currentRoute = snapshot.currentRoute;
  const lastDecision = snapshot.lastDecision;
  return [
    snapshot.mode ?? "",
    snapshot.sourceDegree ?? "",
    snapshot.targetDegree ?? "",
    snapshot.strategy ?? "",
    snapshot.geometryMode ?? "",
    snapshot.historyIndex ?? 0,
    modulationHistoryKey(snapshot.history ?? []),
    currentRoute
      ? [
          currentRoute.sourceDegree ?? "",
          currentRoute.targetDegree ?? "",
          currentRoute.count ?? 0,
          currentRoute.transpositionDeltaCents ?? "",
        ].join(":")
      : "",
    lastDecision
      ? [lastDecision.type ?? "", lastDecision.reason ?? "", lastDecision.articulation ?? ""].join(
          ":",
        )
      : "",
  ].join("|");
}

function committedScaleTextForSlot(slot, frame, workspace) {
  const equaveRatio = workspace?.baseScale?.equaveInterval?.ratio ?? null;
  const equaveCents = workspace?.baseScale?.equaveCents ?? 1200;
  const slotRatio = slot?.committedIdentity?.ratio ?? null;
  const slotCents = slot?.committedIdentity?.cents ?? slot?.cents ?? null;
  const anchorRatio = frame?.anchorInterval?.ratio ?? null;
  const anchorCents = frame?.anchorInterval?.cents ?? 0;
  const normalizedCents = modulo((slot?.cents ?? 0) - anchorCents, equaveCents);

  if (
    slotRatio &&
    anchorRatio &&
    equaveRatio &&
    Number.isFinite(slotCents) &&
    Number.isFinite(anchorCents) &&
    Number.isFinite(equaveCents) &&
    Math.abs(equaveCents) > 0.000001
  ) {
    let ratio = slotRatio.div(anchorRatio);
    const rawDeltaCents = slotCents - anchorCents;
    const equavePower = Math.round((normalizedCents - rawDeltaCents) / equaveCents);
    ratio =
      equavePower >= 0
        ? ratio.mul(equaveRatio.pow(equavePower))
        : ratio.div(equaveRatio.pow(Math.abs(equavePower)));
    return formatCommittedRatio(ratio);
  }

  return formatCommittedCents(normalizedCents);
}

export function commitModulationHistoryToPreset(
  settings,
  tuningWorkspace,
  history = [],
  options = {},
) {
  const activeHistory = Array.isArray(history)
    ? history.filter((entry) => {
        const count = Number.isFinite(entry?.count) ? Math.trunc(entry.count) : 0;
        return count !== 0;
      })
    : [];
  if (!tuningWorkspace || activeHistory.length === 0) return null;

  const baseFrame = createHarmonicFrame(tuningWorkspace, {
    anchorDegree: settings.reference_degree ?? 0,
    anchorLabel: options.hejiAnchorLabel ?? "A",
    anchorRatioText: options.hejiAnchorRatio ?? "1/1",
    anchorInterval: parseExactInterval(String(options.hejiAnchorRatio || "1/1")),
    referenceDegree: settings.reference_degree ?? 0,
    strategy: "anchor_substitution",
    generation: 0,
  });
  const frame = replayModulationHistoryForFrame(tuningWorkspace, baseFrame, activeHistory, {
    suppressDeviation: true,
    temperedOnly: options.hejiTemperedOnly === true,
    forceShowZeroDeviation: false,
  });
  const spelled = spellWorkspaceForFrame(tuningWorkspace, frame, {
    suppressDeviation: true,
    temperedOnly: options.hejiTemperedOnly === true,
    forceShowZeroDeviation: false,
  });
  const derivedColors = deriveDegreeColorsForFrame(tuningWorkspace, frame, {
    baseColors: Array.isArray(settings.note_colors) ? settings.note_colors : [],
  });
  const currentFundamental = deriveCurrentFundamentalForHistory(tuningWorkspace, activeHistory, {
    fundamental: settings.fundamental,
  });
  const equaveCents = tuningWorkspace.baseScale.equaveCents ?? 1200;
  const anchorCents =
    frame?.anchorInterval?.cents ??
    tuningWorkspace.lookup?.byDegree?.get(frame?.anchorDegree)?.cents ??
    0;

  const labelsByDegree =
    settings.key_labels === "heji"
      ? spelled.labelsByDegree
      : Array.isArray(settings.note_names)
        ? settings.note_names
        : [];

  const orderedSlots = (tuningWorkspace.slots ?? [])
    .map((slot) => ({
      slot,
      degree: slot.degree,
      centsFromAnchor: modulo((slot.cents ?? 0) - anchorCents, equaveCents),
      scaleText: committedScaleTextForSlot(slot, frame, tuningWorkspace),
      label: labelsByDegree?.[slot.degree] ?? "",
      color: derivedColors?.[slot.degree] ?? settings.note_colors?.[slot.degree] ?? null,
    }))
    .sort((a, b) => {
      if (a.centsFromAnchor !== b.centsFromAnchor) return a.centsFromAnchor - b.centsFromAnchor;
      if (a.degree === frame.anchorDegree) return -1;
      if (b.degree === frame.anchorDegree) return 1;
      return a.degree - b.degree;
    });

  return {
    ...settings,
    scale: [
      ...orderedSlots.slice(1).map((entry) => entry.scaleText),
      tuningWorkspace.baseScale.equaveText,
    ],
    equivSteps: orderedSlots.length,
    equivInterval: tuningWorkspace.baseScale.equaveCents,
    fundamental: currentFundamental.fundamentalHz ?? settings.fundamental,
    reference_degree: 0,
    note_names: orderedSlots.map((entry) => entry.label ?? ""),
    note_colors: orderedSlots.map((entry) => entry.color ?? ""),
    heji_anchor_label: frame?.heji?.anchorLabel ?? settings.heji_anchor_label ?? "",
    heji_anchor_ratio: "1/1",
  };
}

export function bindControllerLedRefs(keys, bindings = {}, options = {}) {
  if (!keys) return;
  const { eagerSync = true } = options;

  if (Object.prototype.hasOwnProperty.call(bindings, "lumatone")) {
    keys.lumatoneLEDs = bindings.lumatone;
    if (eagerSync && bindings.lumatone && keys.settings?.lumatone_led_sync) {
      keys.autoSyncLumatoneLEDs?.();
    }
  }

  if (Object.prototype.hasOwnProperty.call(bindings, "exquis")) {
    keys.exquisLEDs = bindings.exquis;
    if (eagerSync && bindings.exquis?.ready && keys.settings?.exquis_led_sync) {
      keys.syncExquisLEDs?.();
    }
  }

  if (Object.prototype.hasOwnProperty.call(bindings, "linnstrument")) {
    keys.linnstrumentLEDs = bindings.linnstrument;
  }
}

export function sendLumatoneColorsNow(keys, leds) {
  if (!keys || !leds || typeof keys.syncLumatoneLEDs !== "function") return false;
  // The driver lifecycle and the Keys lifecycle are intentionally independent.
  // Re-assert the current driver at the user-action boundary so a port change or
  // Keys reconstruction cannot turn the manual send into a silent no-op.
  bindControllerLedRefs(keys, { lumatone: leds }, { eagerSync: false });
  return keys.syncLumatoneLEDs() !== false;
}

export function autoSyncLumatoneSurface({ keys, leds, scale, eligible = true }) {
  if (!leds || !eligible) return false;
  if (!Array.isArray(scale) || scale.length === 0) {
    return sendLumatoneBlankLayout(leds);
  }
  if (!keys) return false;
  bindControllerLedRefs(keys, { lumatone: leds }, { eagerSync: false });
  keys.autoSyncLumatoneLEDs?.();
  return true;
}

function readCssPxVar(name) {
  if (typeof window === "undefined") return 0;
  const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const parsed = parseFloat(raw);
  return Number.isFinite(parsed) ? parsed : 0;
}

function getDefaultModulationPalettePos() {
  if (typeof window === "undefined") return { x: 18, y: 58 };
  const isLandscape =
    typeof window.matchMedia === "function"
      ? window.matchMedia("(orientation: landscape)").matches
      : window.innerWidth > window.innerHeight;
  const isPhoneLandscape = window.innerHeight <= 500 && isLandscape;
  if (isPhoneLandscape) {
    const rightInset = readCssPxVar("--safe-area-right");
    const topInset = readCssPxVar("--safe-area-top");
    return {
      x: Math.max(16, window.innerWidth - rightInset - 258),
      y: Math.max(12, topInset + 14),
    };
  }
  if (window.innerWidth >= 480) {
    const sidebar = document.getElementById("sidebar");
    const sidebarRect = sidebar?.getBoundingClientRect();
    const sidebarVisibleRight = sidebarRect && sidebarRect.right > 80 ? sidebarRect.right : 0;
    if (sidebarVisibleRight > 0) {
      const gap = 16;
      const fallbackX = 18;
      const modulationPalette = document.getElementById("modulation-palette");
      const measuredPaletteWidth = modulationPalette?.getBoundingClientRect().width;
      const paletteWidth = measuredPaletteWidth > 0 ? measuredPaletteWidth : 340;
      const maxX = Math.max(fallbackX, window.innerWidth - paletteWidth - gap);
      const preferredX = Math.round(sidebarVisibleRight + gap);
      return {
        x: preferredX <= maxX ? preferredX : fallbackX,
        y: 58,
      };
    }
  }
  return { x: 18, y: 58 };
}

function getDefaultSnapshotPalettePos() {
  if (typeof window === "undefined") return { x: 18, y: 220 };
  const modulationPalette = document.getElementById("modulation-palette");
  const modulationRect = modulationPalette?.getBoundingClientRect();
  if (modulationRect && modulationRect.width > 0 && modulationRect.height > 0) {
    return {
      x: Math.round(modulationRect.left),
      y: Math.round(modulationRect.bottom + 22),
    };
  }
  if (window.innerWidth >= 480) {
    const sidebarRect = document.getElementById("sidebar")?.getBoundingClientRect();
    const sidebarVisibleRight = sidebarRect && sidebarRect.right > 80 ? sidebarRect.right : 0;
    if (sidebarVisibleRight > 0) {
      const gap = 16;
      const fallbackX = 18;
      const snapshotRect = document.getElementById("snapshot-palette")?.getBoundingClientRect();
      const paletteWidth = snapshotRect?.width > 0 ? snapshotRect.width : 180;
      const maxX = Math.max(fallbackX, window.innerWidth - paletteWidth - gap);
      return {
        x: Math.min(Math.round(sidebarVisibleRight + gap), maxX),
        y: 234,
      };
    }
  }
  const modulationDefault = getDefaultModulationPalettePos();
  return {
    x: modulationDefault.x,
    y: modulationDefault.y + 176,
  };
}

export {
  modulationCurrentSummaryDisplay,
  modulationRouteLabelPair,
} from "./tuning/modulation-frame-runtime.js";
export { getDefaultSnapshotPalettePos };

const ua = navigator.userAgent;
const isFirefoxIOS = /FxiOS/.test(ua);
const isChromiumToken = /Chrome|Chromium|CriOS|EdgiOS|EdgA|Edg\/|OPiOS/.test(ua);
const isSafariOnly = /Safari/.test(ua) && !isChromiumToken && !/Firefox/.test(ua) && !isFirefoxIOS; // Firefox on iOS uses FxiOS token, not "Firefox"
const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.maxTouchPoints > 1 && /Mac/.test(ua)); // iPadOS 13+ desktop mode
const isMIDIWeb = /MIDIWeb/.test(ua);
// Banner messages rendered in JSX (not alert()) so links are clickable.
// showBanner: null = no banner, "ios" = iOS MIDI warning, "safari" = Safari warning.
const BANNER_KEY_VERSION = "v1";
const ROTATION_DEBUG_STORAGE_KEY = "hexatone_rotation_debug";
const getBannerSessionKey = (bannerKey) =>
  `hexatone_banner_${bannerKey}_${BANNER_KEY_VERSION}_hidden_session`;
const getBannerDismissKey = (bannerKey) =>
  `hexatone_banner_${bannerKey}_${BANNER_KEY_VERSION}_dismissed`;
const getRotationDebugDefault = () =>
  isIOS &&
  typeof localStorage !== "undefined" &&
  localStorage.getItem(ROTATION_DEBUG_STORAGE_KEY) === "true";

function getBannerCandidate() {
  return isIOS && !isMIDIWeb ? "ios" : isSafariOnly ? "safari" : null;
}

function getInitialBanner() {
  const candidate = getBannerCandidate();
  if (!candidate) return null;
  if (localStorage.getItem(getBannerDismissKey(candidate)) === "true") return null;
  if (sessionStorage.getItem(getBannerSessionKey(candidate)) === "true") return null;
  return candidate;
}

function isTextEntryElement(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (el.tagName === "TEXTAREA") return true;
  if (el.tagName === "SELECT") return true;
  if (el.isContentEditable) return true;
  if (el.tagName !== "INPUT") return false;

  const type = (el.getAttribute("type") || "text").toLowerCase();
  return ![
    "button",
    "checkbox",
    "color",
    "file",
    "hidden",
    "image",
    "radio",
    "range",
    "reset",
    "submit",
  ].includes(type);
}

const MANUAL_VIEW_DEFAULT_SECTIONS = {
  main: "About",
  hexatone: "HEXATONE Tab",
  sequencer: "SEQUENCER Tab",
  io: "I/O tab",
  calculator: "CALCULATOR tab",
};

// Sequence snapshots store absolute MIDI pitches, so their playback does not
// require a loaded Hexatone tuning. Keys still needs a small valid tuning shape
// to own voices and fan them out to the configured synth graph. This runtime is
// hidden and is used only until the user loads a real musical surface.
const SEQUENCE_PLAYBACK_FALLBACK_TUNING = Object.freeze({
  scale: [0],
  equivInterval: 1200,
  equivSteps: 1,
  degree0toRefAsArray: [0, 1],
  degreeIntervals: null,
  equaveInterval: null,
  equaveCents: 1200,
});

// App is the orchestration boundary: below this point persisted settings are
// normalized into the live runtime slices consumed by Keyboard, Settings, and
// Sequencer.
const App = () => {
  const [ready, setReady] = useState(false);
  const [workspaceTab, setWorkspaceTab] = useState(loadReloadWorkspaceTab);
  const ioTransportTargetRef = useRef(null);
  // I/O and Calculator are auxiliary views over the current musical workspace.
  // Keeping the underlying workspace separate lets a running sequence continue
  // while sound/routing controls or pitch calculations are visible.
  const [performanceWorkspaceTab, setPerformanceWorkspaceTab] = useState(() =>
    workspaceTab === "sequencer" || workspaceTab === "io" ? "sequencer" : "hexatone",
  );
  const [inlineManualView, setInlineManualView] = useState(null);
  const [manualSectionTitles, setManualSectionTitles] = useState(MANUAL_VIEW_DEFAULT_SECTIONS);
  const sidebarRef = useRef(null);
  const manualScrollPositionsRef = useRef({
    main: 0,
    hexatone: 0,
    sequencer: 0,
    io: 0,
    calculator: 0,
  });
  const activeManualView = workspaceTab === "manual" ? "main" : inlineManualView;
  const workspaceScrollPositionsRef = useRef({});
  useLayoutEffect(() => {
    // The sidebar is shared DOM, but each workspace owns its viewing position.
    // Manual views retain their separate section-specific scroll handling.
    if (!activeManualView && sidebarRef.current) {
      sidebarRef.current.scrollTop = workspaceScrollPositionsRef.current[workspaceTab] ?? 0;
    }
  }, [workspaceTab, activeManualView]);
  const snapshotPaletteVisible = !inlineManualView && workspaceTab !== "sequencer";
  const performancePalettesVisible = snapshotPaletteVisible;
  const [userHasInteracted, setUserHasInteracted] = useState(false);
  const [showRotationDebug, setShowRotationDebug] = useState(getRotationDebugDefault);
  const [rotationDebugEvents, setRotationDebugEvents] = useState([]);
  const [, setRotationSettleRevision] = useState(0);
  const [banner, setBanner] = useState(getInitialBanner);
  const [landscapeSafeSide, setLandscapeSafeSide] = useState("none");
  const [textEntryActive, setTextEntryActive] = useState(false);
  const [viewportKeyboardOpen, setViewportKeyboardOpen] = useState(false);
  const keysRef = useRef(null); // live Keys instance for imperative color updates
  const [keysReadyRevision, setKeysReadyRevision] = useState(0);
  const synthRef = useRef(null); // live synth instance for imperative volume/mute control
  const viewportBaselineRef = useRef(0);
  const audioNeedsHardRefreshRef = useRef(false);
  const audioWakePromiseRef = useRef(null);

  // Session / lifecycle bootstrap.
  useEffect(() => {
    saveReloadWorkspaceTab(workspaceTab);
  }, [workspaceTab]);

  const rememberManualScrollPosition = useCallback(() => {
    if (!activeManualView) return;
    const sidebar = sidebarRef.current;
    if (sidebar) manualScrollPositionsRef.current[activeManualView] = sidebar.scrollTop;
  }, [activeManualView]);
  const openManualWorkspace = useCallback(() => {
    rememberManualScrollPosition();
    setInlineManualView(null);
    setWorkspaceTab("manual");
  }, [rememberManualScrollPosition]);
  const openInlineManual = useCallback(
    (nextManualView) => {
      rememberManualScrollPosition();
      setInlineManualView(nextManualView);
    },
    [rememberManualScrollPosition],
  );
  const closeInlineManual = useCallback(() => {
    rememberManualScrollPosition();
    setInlineManualView(null);
  }, [rememberManualScrollPosition]);
  const rememberManualSection = useCallback(
    (sectionTitle) => {
      if (!activeManualView) return;
      setManualSectionTitles((current) => ({
        ...current,
        [activeManualView]: sectionTitle,
      }));
    },
    [activeManualView],
  );
  const primeAudioFromUserInteraction = useCallback(async () => {
    const needsInitialPrepare = !userHasInteracted;
    const needsHardRefresh = audioNeedsHardRefreshRef.current;
    if (audioWakePromiseRef.current) {
      await audioWakePromiseRef.current;
      return;
    }
    if (!needsInitialPrepare && !needsHardRefresh) return;
    if (!userHasInteracted) {
      setUserHasInteracted(true);
    }
    const wakePromise = (async () => {
      if (isIOS) {
        await primeSharedSampleAudio();
      }
      if (typeof synthRef.current?.ensureAwake === "function") {
        await synthRef.current.ensureAwake();
      } else if (typeof synthRef.current?.prepare === "function") {
        await synthRef.current.prepare();
      }
      audioNeedsHardRefreshRef.current = false;
    })().finally(() => {
      audioWakePromiseRef.current = null;
    });
    audioWakePromiseRef.current = wakePromise;
    await wakePromise;
  }, [userHasInteracted]);

  useEffect(() => {
    if (typeof document === "undefined" || typeof window === "undefined") return undefined;

    const markAudioStale = () => {
      audioNeedsHardRefreshRef.current = true;
      keysRef.current?.releaseActiveBrowserNotes?.();
    };
    const revealSidebarOnReturn = () => {
      setActive(false);
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        markAudioStale();
        return;
      }
      if (document.visibilityState === "visible") {
        if (isIOS) revealSidebarOnReturn();
      }
    };
    const onPageShow = (event) => {
      // pageshow also fires on an ordinary initial load / reload. Only treat
      // it as a stale-audio resume path when the page is being restored from
      // the back-forward cache. Normal reload startup should not force the
      // destructive rebuild path on the first manual refresh.
      if (event?.persisted) {
        markAudioStale();
      }
      if (isIOS) revealSidebarOnReturn();
    };

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("pagehide", markAudioStale);
    window.addEventListener("pageshow", onPageShow);

    return () => {
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("pagehide", markAudioStale);
      window.removeEventListener("pageshow", onPageShow);
    };
  }, []);

  const noteRotationEvent = useCallback(
    (source) => {
      if (!isIOS) return;
      setRotationSettleRevision((revision) => revision + 1);
      if (!showRotationDebug) return;
      const viewport = window.visualViewport;
      const canvas = keysRef.current?.state?.canvas ?? null;
      const event = {
        at:
          new Date().toLocaleTimeString("en-GB", { hour12: false }) +
          `.${String(Date.now() % 1000).padStart(3, "0")}`,
        source,
        inner: `${window.innerWidth}x${window.innerHeight}`,
        viewport: viewport
          ? `${Math.round(viewport.width)}x${Math.round(viewport.height)} @ ${Math.round(viewport.offsetLeft)},${Math.round(viewport.offsetTop)}`
          : "none",
        canvas: canvas ? `${canvas.width}x${canvas.height}` : "none",
        orientation: window.matchMedia("(orientation: landscape)").matches
          ? "landscape"
          : "portrait",
        sidebarMode: window.matchMedia("(max-width: 480px)").matches ? "phone" : "desktop",
        shortLandscape: window.matchMedia("(max-height: 500px) and (orientation: landscape)")
          .matches
          ? "short"
          : "normal",
      };
      setRotationDebugEvents((events) => [...events.slice(-11), event]);
    },
    [showRotationDebug],
  );

  const hideBannerForSession = useCallback((bannerKey) => {
    sessionStorage.setItem(getBannerSessionKey(bannerKey), "true");
    setBanner(null);
  }, []);

  const dismissBanner = useCallback((bannerKey) => {
    localStorage.setItem(getBannerDismissKey(bannerKey), "true");
    sessionStorage.removeItem(getBannerSessionKey(bannerKey));
    setBanner(null);
  }, []);

  useEffect(() => {
    if (!activeManualView) return;
    const sidebar = sidebarRef.current;
    if (sidebar) sidebar.scrollTop = manualScrollPositionsRef.current[activeManualView] ?? 0;
  }, [activeManualView]);

  useEffect(() => {
    const readPxVar = (name) => {
      const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      const parsed = parseFloat(raw);
      return Number.isFinite(parsed) ? parsed : 0;
    };

    const updateLandscapeSafeSide = () => {
      const isLandscape = window.matchMedia("(orientation: landscape)").matches;
      if (!isLandscape) {
        setLandscapeSafeSide("none");
        return;
      }

      const leftInset = readPxVar("--safe-area-left");
      const rightInset = readPxVar("--safe-area-right");
      if (leftInset > rightInset && leftInset > 0.5) {
        setLandscapeSafeSide("left");
      } else if (rightInset > leftInset && rightInset > 0.5) {
        setLandscapeSafeSide("right");
      } else {
        setLandscapeSafeSide("none");
      }
    };

    updateLandscapeSafeSide();
    window.addEventListener("resize", updateLandscapeSafeSide);
    window.addEventListener("orientationchange", updateLandscapeSafeSide);
    return () => {
      window.removeEventListener("resize", updateLandscapeSafeSide);
      window.removeEventListener("orientationchange", updateLandscapeSafeSide);
    };
  }, []);

  useEffect(() => {
    const syncTextEntryState = () => {
      setTextEntryActive(isTextEntryElement(document.activeElement));
    };

    syncTextEntryState();
    document.addEventListener("focusin", syncTextEntryState);
    document.addEventListener("focusout", syncTextEntryState);
    return () => {
      document.removeEventListener("focusin", syncTextEntryState);
      document.removeEventListener("focusout", syncTextEntryState);
    };
  }, []);

  useEffect(() => {
    const viewport = window.visualViewport;
    if (!viewport) return;

    const resetBaseline = () => {
      viewportBaselineRef.current = viewport.height;
      setViewportKeyboardOpen(false);
    };

    const syncViewportKeyboardState = () => {
      const currentHeight = viewport.height;
      const baseline = viewportBaselineRef.current || currentHeight;
      const activeTextEntry = isTextEntryElement(document.activeElement);

      if (!activeTextEntry) {
        if (currentHeight > baseline) viewportBaselineRef.current = currentHeight;
        setViewportKeyboardOpen(false);
        return;
      }

      setViewportKeyboardOpen(baseline - currentHeight > 120);
    };

    resetBaseline();
    viewport.addEventListener("resize", syncViewportKeyboardState);
    window.addEventListener("orientationchange", resetBaseline);
    window.addEventListener("resize", syncViewportKeyboardState);
    return () => {
      viewport.removeEventListener("resize", syncViewportKeyboardState);
      window.removeEventListener("orientationchange", resetBaseline);
      window.removeEventListener("resize", syncViewportKeyboardState);
    };
  }, []);

  useEffect(() => {
    if (!textEntryActive && !viewportKeyboardOpen && keysRef.current) {
      keysRef.current.resizeHandler();
    }
  }, [textEntryActive, viewportKeyboardOpen]);

  useEffect(() => {
    if (!isIOS) return undefined;
    const onOrientationChange = () => noteRotationEvent("orientationchange");
    const onWindowResize = () => noteRotationEvent("window.resize");
    const onViewportResize = () => noteRotationEvent("visualViewport.resize");

    noteRotationEvent("mount");
    window.addEventListener("orientationchange", onOrientationChange);
    window.addEventListener("resize", onWindowResize);
    window.visualViewport?.addEventListener("resize", onViewportResize);
    return () => {
      window.removeEventListener("orientationchange", onOrientationChange);
      window.removeEventListener("resize", onWindowResize);
      window.visualViewport?.removeEventListener("resize", onViewportResize);
    };
  }, [noteRotationEvent]);

  const [settings, setSettings] = useQuery(
    buildQuerySpec({
      int: ExtractInt,
      float: ExtractFloat,
      bool: ExtractBool,
      string: ExtractString,
      joined: ExtractJoinedString,
    }),
    {
      // 1. Registry url/runtime defaults — blank-slate values for all keys.
      //    scale/note_names/note_colors are null so the table starts empty.
      ...buildRegistryDefaults(),
      // 2. Session defaults — restore device/output choices from sessionStorage.
      ...sessionDefaults,
      // 3. Preset-specific fields always start empty — populated only when a
      //    preset is explicitly loaded. null is handled gracefully everywhere.
      name: "",
      description: "",
      scale: null,
      note_names: null,
      note_colors: null,
    },
    [],
    PRESET_SKIP_KEYS,
  );
  const initialiseAudioRef = useRef(null);
  const engineLifecycleRef = useRef({ loading: true });
  const [restoringLocalSoundfont, setRestoringLocalSoundfont] = useState(false);
  const audioRecovery = useAudioRecovery(synthRef, keysRef, settings, initialiseAudioRef, engineLifecycleRef);
  const restoreBuiltInAudio = audioRecovery.restore;
  const [initialAudioPromptDismissed, setInitialAudioPromptDismissed] = useState(false);
  const [modulationArmed, setModulationArmed] = useState(false);
  const [modulationMode, setModulationMode] = useState("idle");
  const [modulationState, setModulationState] = useState(null);
  const [presetModulationLibrary, setPresetModulationLibrary] = useState([]);
  const [presetRuntimeResetRevision, setPresetRuntimeResetRevision] = useState(0);

  const { onImport, importCount, bumpImportCount } = useImport(settings, setSettings, {
    onReady: () => setReady(true),
    onUserInteraction: primeAudioFromUserInteraction,
  });

  const {
    activeSource,
    activePresetName,
    restoredOnMount,
    pendingRestoredPreset,
    isPresetDirty,
    persistOnReload,
    setPersistOnReload,
    activatePendingPreset,
    onLoadBuiltinPreset,
    onLoadCustomPreset,
    onClearUserPresets,
    onRevertBuiltin,
    onRevertUser,
    onUserScaleEdit,
  } = usePresets(settings, setSettings, {
    synthRef,
    onUserInteraction: primeAudioFromUserInteraction,
    bumpImportCount,
    bumpPresetRuntimeReset: () => setPresetRuntimeResetRevision((revision) => revision + 1),
    currentModulationLibrary: modulationState?.history ?? presetModulationLibrary,
    setPresetModulationLibrary,
    onPresetModulationLibraryLoaded: (library) => {
      setPresetModulationLibrary(library);
      setModulationState(presetModulationSnapshot(library));
      setModulationMode("idle");
      setModulationArmed(false);
    },
  });
  const deferRestoredSampleActivation = isIOS && restoredOnMount && !userHasInteracted;

  const {
    synth,
    readySampleInstrument,
    retryAudioOutputs,
    enginesLoading,
    engineStartupErrors,
    midi,
    midiAccess,
    midiAccessError,
    ensureMidiAccess,
    disableWebMidi,
    midiTick,
    loading,
    midiLearnActive,
    setMidiLearnActive,
    hakenPedalLearnActive,
    setHakenPedalLearnActive,
    octaveTranspose,
    octaveDeferred,
    shiftOctave,
    resetOctave,
    toggleOctaveDeferred,
    onVolumeChange,
    onOscLayerVolumeChange,
    oscBrightness,
    onOscBrightnessChange,
    onOscQuickReleaseChange,
    onOscQuickReleaseTimeChange,
    onOscQuickReleaseRasterOnlyChange,
    onAnchorLearn,
    onHakenPedalLearn,
    lumatoneRawPorts,
    exquisRawPorts,
    linnstrumentRawPorts,
    hakenRawPorts,
  } = useSynthWiring(settings, setSettings, {
    ready,
    userHasInteracted,
    keysRef,
    synthRef,
    deferSampleActivation: deferRestoredSampleActivation,
  });
  engineLifecycleRef.current = { loading: !ready || enginesLoading > 0 || restoringLocalSoundfont,
    errors: engineStartupErrors };
  const localSoundfontAttemptedRef = useRef(false);
  useEffect(() => {
    if (!ready || !userHasInteracted || !settings.output_fluidsynth || localSoundfontAttemptedRef.current) return;
    localSoundfontAttemptedRef.current = true;
    const controller = new AbortController();
    setRestoringLocalSoundfont(true);
    void import("./fluidsynth_synth/restore-local-soundfont.js")
      .then(({ restoreLocalSoundfont }) => restoreLocalSoundfont({
        signal: controller.signal, preferredPreset: settings.fluidsynth_preset,
      }))
      .then((result) => {
        if (controller.signal.aborted || !result) return;
        setSettings((current) => ({ ...current,
          fluidsynth_preset: result.selectedPreset
            ? `${result.selectedPreset.bank}:${result.selectedPreset.program}` : current.fluidsynth_preset,
          fluidsynth_runtime_revision: (Number(current.fluidsynth_runtime_revision) || 0) + 1,
        }));
      })
      .catch((error) => {
        if (!controller.signal.aborted) audioRecovery.startupFailed("FluidSynth", error);
      })
      .finally(() => { if (!controller.signal.aborted) setRestoringLocalSoundfont(false); });
    return () => { controller.abort(); setRestoringLocalSoundfont(false); };
    // One local-only attempt on first activation; preset changes must not cancel it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, userHasInteracted, settings.output_fluidsynth]);
  initialiseAudioRef.current = async (signal) => {
    // Begin shared-context activation on the original Restore gesture.
    const activation = primeAudioFromUserInteraction();
    if (pendingRestoredPreset) await activatePendingPreset();
    await activation;
    return retryAudioOutputs(signal);
  };
  initialiseAudioRef.current.needed = () => !!pendingRestoredPreset || !userHasInteracted;

  const { panic: guardianPanic } = useMidiGuardian(midi, settings);

  useEffect(() => {
    const panicLiveKeyboardOnUnload = () => {
      // The MIDI guardian sends channel-mode panic messages independently.
      // The live keyboard additionally releases exact MPE channel/note pairs,
      // which is required by receivers that ignore CC120/CC123 for an MPE zone.
      keysRef.current?.panic?.();
    };
    window.addEventListener("pagehide", panicLiveKeyboardOnUnload);
    window.addEventListener("beforeunload", panicLiveKeyboardOnUnload);
    return () => {
      window.removeEventListener("pagehide", panicLiveKeyboardOnUnload);
      window.removeEventListener("beforeunload", panicLiveKeyboardOnUnload);
    };
  }, []);

  const [active, setActive] = useState(false);
  const [latch, setLatch] = useState(false);
  const [modulationPalettePos, setModulationPalettePos] = useState(getDefaultModulationPalettePos);
  const [modulationPaletteCollapsed, setModulationPaletteCollapsed] = useState(false);
  const [snapshotPalettePos, setSnapshotPalettePos] = useState(getDefaultSnapshotPalettePos);
  const [snapshotPaletteCollapsed, setSnapshotPaletteCollapsed] = useState(false);

  // Exquis LED App Mode status — set asynchronously after firmware version check.
  // null = pending / not connected; { ok: true } = active; { ok: false, reason } = failed.
  const [exquisLedStatus, setExquisLedStatus] = useState(null);
  const exquisLedsRef = useRef(null);
  const lumatoneLedsRef = useRef(null);
  const [lumatoneDriverReady, setLumatoneDriverReady] = useState(false);
  const lumatoneAutoSyncKeyRef = useRef("");
  const linnstrumentLedsRef = useRef(null);

  // ── Snapshots ─────────────────────────────────────────────────────────────
  const [snapshots, setSnapshots] = useState([]);
  const switchWorkspaceTab = useCallback(
    (nextTab) => {
      rememberManualScrollPosition();
      setInlineManualView(null);
      if (nextTab === "hexatone" || nextTab === "sequencer") {
        setPerformanceWorkspaceTab(nextTab);
      } else if (nextTab === "io" && snapshots.length > 0) {
        // A loaded sequence is also available from I/O when arriving from
        // Hexatone. Keep its controller mounted for subsequent tab switches.
        setPerformanceWorkspaceTab("sequencer");
      }
      setWorkspaceTab(nextTab);
    },
    [rememberManualScrollPosition, snapshots.length],
  );
  const [playingSnapshotId, setPlayingSnapshotId] = useState(null);
  const [manualPlayingSnapshotIds, setManualPlayingSnapshotIds] = useState([]);
  const [selectedSnapshotId, setSelectedSnapshotId] = useState(null);
  const [selectedSnapshotMarker, setSelectedSnapshotMarker] = useState(null);
  const [snapshotLabelMode, setSnapshotLabelMode] = useState("proportion");
  const [activeSequenceSource, setActiveSequenceSource] = useState("");
  const [activeSequenceBuiltInName, setActiveSequenceBuiltInName] = useState("");
  const [activeSequenceName, setActiveSequenceName] = useState("");
  const [activeSequenceSavedName, setActiveSequenceSavedName] = useState("");
  const [activeSequenceDescription, setActiveSequenceDescription] = useState("");
  const [sequenceLegato, setSequenceLegato] = useState("per-note");
  const [sequencePlaybackSpeed, setSequencePlaybackSpeed] = useState(1);
  const [sequencePlaybackPitchOffset, setSequencePlaybackPitchOffset] = useState(0);
  const [sequenceTimbreModWheelEnabled, setSequenceTimbreModWheelEnabled] = useState(true);
  const sequenceTimbreModWheelEnabledRef = useRef(true);
  const sequenceTimbreModWheelValueRef = useRef(NEUTRAL_SEQUENCE_TIMBRE_MOD_WHEEL);
  const [snapSequenceToCurrentTuning, setSnapSequenceToCurrentTuning] = useState(false);
  const [chordDrift, setChordDrift] = useState(DEFAULT_CHORD_DRIFT);
  const chordSolverRef = useRef(null);
  if (!chordSolverRef.current) chordSolverRef.current = createChordSnapScheduler();
  useEffect(() => () => chordSolverRef.current?.dispose(), []);
  const [sequenceAutoCreateBars, setSequenceAutoCreateBars] = useState(true);
  const [manualArpeggiation, setManualArpeggiation] = useState(() => normalizeManualArpeggiation());
  const [sequenceBars, setSequenceBars] = useState(defaultSequenceBars);
  const [sequenceTempi, setSequenceTempi] = useState(defaultSequenceTempi);
  const [sequenceRepeats, setSequenceRepeats] = useState([]);
  const [sequencePlayRepeats, setSequencePlayRepeats] = useState(true);
  const sequencerScrollPositionRef = useRef(0);
  const timedTransportStopRef = useRef(null);
  const pendingManualCueUiCommitRef = useRef({ timerId: null, payload: null });
  const manualCueDiagnosticsRef = useRef({
    frameId: null,
    firstTriggerMs: null,
    lastTriggerMs: null,
    minimumIntervalMs: null,
    triggerCount: 0,
    maximumApplyDurationMs: 0,
    latestCueIndex: null,
  });
  const [sequencePlayhead, setSequencePlayhead] = useState({
    barIndex: 0,
    stepIndex: -1,
    markerIndex: null,
    stopped: true,
  });
  const sequencePlayheadRef = useRef(sequencePlayhead);
  useEffect(() => {
    // An unrelated render may still carry the last committed playhead while a
    // rapid manual-trigger burst is advancing the audio-only playhead. Do not
    // let that stale render move arrow navigation backwards mid-burst.
    if (pendingManualCueUiCommitRef.current.payload != null) return;
    sequencePlayheadRef.current = sequencePlayhead;
  }, [sequencePlayhead]);
  const pendingTransportSelectionRef = useRef(clearPendingTransportSelection());
  const timedPlaybackUiRef = useRef({
    clockSeconds: -Infinity,
    stepIndex: -1,
    markerIndex: null,
    barIndex: 0,
  });
  const sequenceRepeatPlaybackStateRef = useRef({});
  const previousSnapSequenceToCurrentTuningRef = useRef(false);
  const previousSequenceSnapRuntimeKeyRef = useRef(null);
  const liveSequenceSnapRuntimeRef = useRef(null);
  const previousSequencePlaybackPitchOffsetRef = useRef(0);
  const liveSequencePlaybackPitchOffsetRef = useRef(0);
  const appliedSequencePlaybackPitchOffsetRef = useRef(0);
  const snapshotIdRef = useRef(0);
  const sequenceBarIdRef = useRef(1);
  const snapshotsRef = useRef([]);
  const manualSnapshotGesturesRef = useRef(new Map());
  const manualGestureSnapshotsRef = useRef(new Map());
  const manualGestureEventVoicesRef = useRef(new Map());
  const manualGestureRuntimeRef = useRef(null);
  if (!manualGestureRuntimeRef.current) {
    manualGestureRuntimeRef.current = createManualSnapshotGestureRuntime();
  }
  const sequenceBarsRef = useRef(defaultSequenceBars);
  const dragIdRef = useRef(null);
  const [dragOverId, setDragOverId] = useState(null);
  const modulationPaletteRef = useRef(null);
  const modulationPaletteDragRef = useRef(null);
  const modulationPaletteUserMovedRef = useRef(false);
  const snapshotPaletteRef = useRef(null);
  const snapshotPaletteBodyRef = useRef(null);
  const timedPaletteSnapshotRef = useRef(null);
  const snapshotPaletteDragRef = useRef(null);
  const snapshotPaletteUserMovedRef = useRef(false);
  const previousSnapshotPaletteCollapsedRef = useRef(snapshotPaletteCollapsed);
  const previousSnapshotPaletteWorkspaceRef = useRef(workspaceTab);

  useEffect(() => {
    snapshotsRef.current = snapshots;
  }, [snapshots]);

  useEffect(() => {
    sequenceBarsRef.current = sequenceBars;
  }, [sequenceBars]);

  useEffect(() => {
    const wasCollapsed = previousSnapshotPaletteCollapsedRef.current;
    previousSnapshotPaletteCollapsedRef.current = snapshotPaletteCollapsed;
    const previousWorkspace = previousSnapshotPaletteWorkspaceRef.current;
    previousSnapshotPaletteWorkspaceRef.current = workspaceTab;
    const revealedByTab = previousWorkspace === "sequencer" && workspaceTab !== "sequencer";
    if ((!wasCollapsed && !revealedByTab) || snapshotPaletteCollapsed) return;

    // The manual audio cursor leads the deferred presentation during fast
    // stepping. Reveal that snapshot even before the tab handoff commits UI.
    const livePosition = sequencePlayheadRef.current;
    const liveSnapshotId =
      revealedByTab && !livePosition.stopped && livePosition.markerIndex == null
        ? snapshots[livePosition.stepIndex]?.id
        : null;
    const soundingSnapshotId = liveSnapshotId ?? manualPlayingSnapshotIds.at(-1) ?? playingSnapshotId;
    const body = snapshotPaletteBodyRef.current;
    if (soundingSnapshotId == null || !body) return;
    const row = [...body.querySelectorAll(".snapshot-row")].find(
      (candidate) => candidate.dataset.snapshotId === String(soundingSnapshotId),
    );
    if (!row) return;

    const bodyRect = body.getBoundingClientRect();
    const rowRect = row.getBoundingClientRect();
    if (revealedByTab) {
      const visibleTop = bodyRect.top + body.clientTop;
      const visibleBottom = visibleTop + body.clientHeight;
      if (rowRect.top < visibleTop) {
        body.scrollTop = Math.max(0, body.scrollTop + rowRect.top - visibleTop);
      } else if (rowRect.bottom > visibleBottom) {
        body.scrollTop += rowRect.bottom - visibleBottom;
      }
      return;
    }
    const rowTop = rowRect.top - bodyRect.top + body.scrollTop;
    body.scrollTop = Math.max(0, rowTop - (body.clientHeight - rowRect.height) / 2);
  }, [manualPlayingSnapshotIds, playingSnapshotId, snapshotPaletteCollapsed, snapshots, workspaceTab]);

  const appendSequenceSnapshot = useCallback(
    (notes = []) => {
      const snapshotCountBefore = snapshotsRef.current.length;
      const nextSnapshotId = snapshotIdRef.current + 1;
      const result = appendSnapshotToWorkspace({
        snapshots: snapshotsRef.current,
        notes,
        snapshotLabelMode,
        sequenceAutoCreateBars,
        sequenceBars: sequenceBarsRef.current,
        nextSnapshotId,
        nextBarId: sequenceBarIdRef.current,
        pitchFrame: captureSequencePitchFrame(keysRef.current),
      });
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-capture-appended",
        detail: "Appended snapshot to workspace",
        context: {
          source: "snapshot-capture",
          captureStage: "append",
          captureNoteCount: Array.isArray(notes) ? notes.length : 0,
          snapshotCountBefore,
          snapshotCountAfter: result.snapshots.length,
          snapshotId: result.selectedSnapshotId,
          selectedSnapshotId: result.selectedSnapshotId,
          workspaceTab,
        },
      });
      snapshotIdRef.current = result.ids.snapshotId;
      sequenceBarIdRef.current = result.ids.barId;
      snapshotsRef.current = result.snapshots;
      sequenceBarsRef.current = result.bars;
      setSnapshots(result.snapshots);
      setSequenceBars(result.bars);
      setSelectedSnapshotId(result.selectedSnapshotId);
      setSelectedSnapshotMarker(result.selectedSnapshotMarker);
    },
    [sequenceAutoCreateBars, snapshotLabelMode, workspaceTab],
  );

  const onTakeSnapshot = useCallback(() => {
    appendPersistedSequencerCrashDiagnostic({
      type: "snapshot-capture-requested",
      detail: "Requested live snapshot capture",
      context: {
        source: "snapshot-capture",
        captureStage: "requested",
        snapshotCountBefore: snapshotsRef.current.length,
        selectedSnapshotId,
        workspaceTab,
      },
    });
    let notes = null;
    try {
      notes = keysRef.current?.getSnapshot() ?? null;
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-capture-collected",
        detail: "Collected live snapshot notes",
        context: {
          source: "snapshot-capture",
          captureStage: "collected",
          captureNoteCount: Array.isArray(notes) ? notes.length : 0,
          snapshotCountBefore: snapshotsRef.current.length,
          selectedSnapshotId,
          workspaceTab,
        },
      });
    } catch (error) {
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-capture-error",
        detail: "Snapshot capture failed while collecting notes",
        context: {
          source: "snapshot-capture",
          captureStage: "collect",
          snapshotCountBefore: snapshotsRef.current.length,
          selectedSnapshotId,
          workspaceTab,
        },
        error,
      });
      throw error;
    }
    if (!notes?.length) return;
    try {
      appendSequenceSnapshot(notes);
    } catch (error) {
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-capture-error",
        detail: "Snapshot capture failed while appending workspace snapshot",
        context: {
          source: "snapshot-capture",
          captureStage: "append",
          captureNoteCount: Array.isArray(notes) ? notes.length : 0,
          snapshotCountBefore: snapshotsRef.current.length,
          selectedSnapshotId,
          workspaceTab,
        },
        error,
      });
      throw error;
    }
  }, [appendSequenceSnapshot, selectedSnapshotId, workspaceTab]);

  const onAddEmptySnapshot = useCallback(() => {
    appendPersistedSequencerCrashDiagnostic({
      type: "snapshot-capture-requested",
      detail: "Requested empty snapshot append",
      context: {
        source: "snapshot-capture",
        captureStage: "empty-requested",
        captureNoteCount: 0,
        snapshotCountBefore: snapshotsRef.current.length,
        selectedSnapshotId,
        workspaceTab,
      },
    });
    appendSequenceSnapshot([]);
  }, [appendSequenceSnapshot, selectedSnapshotId, workspaceTab]);

  const onLoadSequence = useCallback(
    (sequence, options = {}) => {
      // Choosing a sequence is itself a user gesture. Begin preparing the
      // browser synth here so playback does not depend on first touching the
      // Hexatone canvas. The explicit activation action covers restored
      // sequences that were not selected during this browser session.
      void primeAudioFromUserInteraction();
      const workspace = buildLoadedSequenceWorkspace(sequence, options);
      manualGestureRuntimeRef.current.cancelAll();
      keysRef.current?.stopSnapshot();
      pendingTransportSelectionRef.current = clearPendingTransportSelection();
      setPlayingSnapshotId(null);
      setManualPlayingSnapshotIds([]);
      snapshotsRef.current = workspace.snapshots;
      sequenceBarsRef.current = workspace.bars;
      setSnapshots(workspace.snapshots);
      setSequenceBars(workspace.bars);
      setSequenceTempi(workspace.tempi);
      setSequenceRepeats(workspace.repeats);
      snapshotIdRef.current = workspace.ids.snapshotId;
      sequenceBarIdRef.current = workspace.ids.barId;
      setSnapshotLabelMode(workspace.snapshotLabelMode);
      setSequenceLegato(workspace.sequenceLegato);
      setSequenceAutoCreateBars(workspace.sequenceAutoCreateBars);
      setManualArpeggiation(workspace.manualArpeggiation);
      setSelectedSnapshotId(null);
      setSelectedSnapshotMarker(null);
      setActiveSequenceSource(workspace.activeSequenceSource);
      setActiveSequenceBuiltInName(workspace.activeSequenceBuiltInName);
      setActiveSequenceName(workspace.activeSequenceName);
      setActiveSequenceSavedName(workspace.activeSequenceSavedName);
      setActiveSequenceDescription(workspace.activeSequenceDescription);
      setSequencePlayhead({
        barIndex: 0,
        stepIndex: -1,
        markerIndex: null,
        stopped: true,
      });
      timedPlaybackUiRef.current = {
        clockSeconds: -Infinity,
        stepIndex: -1,
        markerIndex: null,
        barIndex: 0,
      };
    },
    [primeAudioFromUserInteraction],
  );

  useEffect(() => {
    if (typeof localStorage === "undefined") return;
    if (localStorage.getItem("hexatone_persist_on_reload") !== "true") return;
    const restoredSequence = loadSequenceWorkspaceFromSession();
    if (!restoredSequence) return;
    const workspace = buildRestoredSequenceWorkspace(restoredSequence);

    snapshotsRef.current = workspace.snapshots;
    sequenceBarsRef.current = workspace.bars;
    pendingTransportSelectionRef.current = clearPendingTransportSelection();
    setSnapshots(workspace.snapshots);
    setSequenceBars(workspace.bars);
    setSequenceTempi(workspace.tempi);
    setSequenceRepeats(workspace.repeats);
    setSnapshotLabelMode(workspace.snapshotLabelMode);
    setActiveSequenceSource(workspace.activeSequenceSource);
    setActiveSequenceBuiltInName(workspace.activeSequenceBuiltInName);
    setActiveSequenceName(workspace.activeSequenceName);
    setActiveSequenceSavedName(workspace.activeSequenceSavedName);
    setActiveSequenceDescription(workspace.activeSequenceDescription);
    setSequenceLegato(workspace.sequenceLegato);
    setSnapSequenceToCurrentTuning(workspace.snapSequenceToCurrentTuning);
    setSequenceAutoCreateBars(workspace.sequenceAutoCreateBars);
    setManualArpeggiation(workspace.manualArpeggiation);
    setSelectedSnapshotId(null);
    setSelectedSnapshotMarker(null);
    setPlayingSnapshotId(null);
    setSequencePlayhead({
      barIndex: 0,
      stepIndex: -1,
      markerIndex: null,
      stopped: true,
    });
    timedPlaybackUiRef.current = {
      clockSeconds: -Infinity,
      stepIndex: -1,
      markerIndex: null,
      barIndex: 0,
    };
    snapshotIdRef.current = workspace.ids.snapshotId;
    sequenceBarIdRef.current = workspace.ids.barId;
  }, []);

  const sequenceSessionWriterRef = useRef(null);
  if (!sequenceSessionWriterRef.current) {
    sequenceSessionWriterRef.current = createSequenceWorkspaceSessionWriter();
  }
  const persistSequenceWorkspace = useCallback(
    (overrides = {}) => {
      sequenceSessionWriterRef.current({
        snapshots,
        bars: sequenceBars,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        snapshotLabelMode,
        activeSequenceSource,
        activeSequenceBuiltInName,
        activeSequenceName,
        activeSequenceSavedName,
        activeSequenceDescription,
        sequenceLegato,
        sequenceAutoCreateBars,
        manualArpeggiation,
        ...overrides,
      });
    },
    [
      activeSequenceDescription,
      activeSequenceBuiltInName,
      activeSequenceName,
      activeSequenceSource,
      activeSequenceSavedName,
      sequenceAutoCreateBars,
      sequenceBars,
      sequenceLegato,
      manualArpeggiation,
      sequenceRepeats,
      sequenceTempi,
      snapshotLabelMode,
      snapshots,
    ],
  );

  // State changes are persisted here; mutation handlers also call the same
  // helper with their freshly computed results so a reload between the event
  // and the next render cannot lose an edit.
  useEffect(() => {
    persistSequenceWorkspace();
  }, [persistSequenceWorkspace]);

  // Sequencer workspace derivation and playback-ready snapshot views.
  const sequenceSnapRuntimeCandidate = (() => {
    // A blank workspace still mounts a hidden one-note Keys runtime so the
    // sequencer can play. That fallback is not a user-selected canvas tuning.
    if (!Array.isArray(settings.scale) || settings.scale.length === 0) return null;
    const keys = keysRef.current;
    const frame = keys?._activeFrame?.();
    const liveRuntime = keys?._effectiveScaleRuntimeForFrame?.(frame);
    return resolveSequenceSnapRuntime(settings, liveRuntime, keys?.settings);
  })();
  const sequenceSnapRuntimeFingerprint = sequenceSnapRuntimeCandidate ? JSON.stringify([
    sequenceSnapRuntimeCandidate.scale, sequenceSnapRuntimeCandidate.equivInterval,
    sequenceSnapRuntimeCandidate.fundamental, sequenceSnapRuntimeCandidate.referenceDegree,
  ]) : null;
  // Stabilise equal runtimes: a timed UI tick must not rebuild every projected
  // snapshot or cancel and restart the preparation debounce.
  const stableSequenceSnapRuntimeRef = useRef({});
  if (stableSequenceSnapRuntimeRef.current.key !== sequenceSnapRuntimeFingerprint ||
      stableSequenceSnapRuntimeRef.current.revision !== keysReadyRevision) {
    stableSequenceSnapRuntimeRef.current = { key: sequenceSnapRuntimeFingerprint,
      revision: keysReadyRevision, runtime: sequenceSnapRuntimeCandidate };
  }
  const currentSequenceSnapRuntime = stableSequenceSnapRuntimeRef.current.runtime;
  liveSequenceSnapRuntimeRef.current = snapSequenceToCurrentTuning ? currentSequenceSnapRuntime : null;
  const sequenceSnapRuntimeKey = currentSequenceSnapRuntime ? JSON.stringify([
    currentSequenceSnapRuntime.scale, currentSequenceSnapRuntime.equivInterval,
    currentSequenceSnapRuntime.fundamental, currentSequenceSnapRuntime.referenceDegree,
    chordDrift,
  ]) : null;
  const chordSnapOptions = useMemo(() => ({ chordAware: chordDrift > 0, chordDrift,
    chordSolver: chordSolverRef.current,
    decisionToken: { runtimeKey: sequenceSnapRuntimeKey, snap: snapSequenceToCurrentTuning } }),
    [chordDrift, sequenceSnapRuntimeKey, snapSequenceToCurrentTuning]);
  const liveChordSnapOptionsRef = useRef(chordSnapOptions);
  liveChordSnapOptionsRef.current = chordSnapOptions;
  const chordPrefetchPosition = Number.isFinite(timedPlaybackUiRef.current.clockSeconds)
    ? timedPlaybackUiRef.current.stepIndex : sequencePlayhead.stepIndex;
  useEffect(() => {
    // Invalidate obsolete tuning/drift work immediately. Debounce only warmup,
    // not active retuning; a slider burst must not spawn many worker requests.
    const solver = chordSolverRef.current;
    solver.setContext(`${sequenceSnapRuntimeKey}|${sequenceLegato}`, snapshots);
    if (!currentSequenceSnapRuntime || !chordSnapOptions.chordAware || currentSequenceSnapRuntime.scale.length > 512) return;
    const timer = window.setTimeout(() => {
      for (const index of chordPrefetchIndices(snapshots.length, chordPrefetchPosition)) {
        const snapshot = snapshots[index];
        if (!snapshot.notes || snapshot.notes.length < 2 || snapshot.notes.length > 32) continue;
        const notes = (snapshot.notes ?? []).map((note, noteIndex) => ({ ...note,
          held: deriveSequenceLegatoFlags({ note, noteIndex, previousSnapshot: snapshots[index - 1],
            attackTime: Number(note.start) || 0, mode: sequenceLegato }).legatoContinuation === true,
        }));
        prepareSequenceChord(notes, currentSequenceSnapRuntime, chordSnapOptions);
        // Also prepare isolated snapshot triggers (no held-pair preference).
        if (notes.some(note => note.held))
          prepareSequenceChord(notes.map(note => ({ ...note, held: false })), currentSequenceSnapRuntime, chordSnapOptions);
      }
    }, 40);
    return () => window.clearTimeout(timer);
  }, [sequenceSnapRuntimeKey, currentSequenceSnapRuntime, chordSnapOptions,
    chordPrefetchPosition, snapshots, sequenceLegato]);
  const sequencePlaybackSnapshots = useMemo(() => {
    const keys = keysRef.current;
    if (!snapSequenceToCurrentTuning || !currentSequenceSnapRuntime) {
      return snapshots;
    }
    return remapSequenceSnapshotsToRuntime(snapshots, currentSequenceSnapRuntime, {
      ...chordSnapOptions,
      chordReadOnly: true,
      noteNames: Array.isArray(keys?.settings?.note_names) ? keys.settings.note_names : [],
      hejiNames: Array.isArray(keys?.settings?.heji_names) ? keys.settings.heji_names : [],
    });
  }, [currentSequenceSnapRuntime, snapSequenceToCurrentTuning, snapshots, chordSnapOptions]);
  const previousSequenceDisplaySnapshotsRef = useRef(null);
  const sequenceDisplaySnapshots = useMemo(() => {
    const displayedSnapshots = sequencePlaybackSnapshots;
    const nextDisplaySnapshots = displayedSnapshots.map((snapshot) => ({
      ...snapshot,
      description: buildSnapshotDisplayDescription(snapshot, snapshotLabelMode),
    }));
    const stableDisplaySnapshots = reuseEquivalentDisplaySnapshots(
      previousSequenceDisplaySnapshotsRef.current,
      nextDisplaySnapshots,
    );
    previousSequenceDisplaySnapshotsRef.current = stableDisplaySnapshots;
    return stableDisplaySnapshots;
  }, [sequencePlaybackSnapshots, snapshotLabelMode]);
  const sequencePlaybackRuntimeToken = useMemo(
    () =>
      buildDependencyToken([
        // Tuning snap changes pitch mapping, not timed-transport structure.
        // Keep the transport token tied to the stored sequence so live remapping
        // can update sounding and future notes without stopping the clock.
        snapshots,
        sequenceBars,
        sequenceTempi,
        sequenceRepeats,
      ]),
    [sequenceBars, sequenceRepeats, sequenceTempi, snapshots],
  );
  const sequenceTimedTriggerToken = useMemo(
    () => buildDependencyToken([sequencePlaybackRuntimeToken, sequenceLegato]),
    [sequenceLegato, sequencePlaybackRuntimeToken],
  );
  const sequenceRuntimeBuilderRef = useRef(null);
  if (!sequenceRuntimeBuilderRef.current)
    sequenceRuntimeBuilderRef.current = createSequenceRuntimeModelBuilder();
  const sequenceRuntimeModel = useMemo(
    () =>
      sequenceRuntimeBuilderRef.current({
        snapshots,
        displaySnapshots: sequenceDisplaySnapshots,
        playbackSnapshots: sequencePlaybackSnapshots,
        bars: sequenceBars,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        sequenceLegato,
        source: "app",
      }),
    [
      sequenceBars,
      sequenceDisplaySnapshots,
      sequenceLegato,
      sequencePlaybackSnapshots,
      sequenceRepeats,
      sequenceTempi,
      snapshots,
    ],
  );
  const previousSequenceRuntimeDepsRef = useRef(null);
  useEffect(() => {
    if (!isSequenceRuntimeDiagnosticsEnabled()) return;
    const nextDeps = {
      snapshots,
      displaySnapshots: sequenceDisplaySnapshots,
      playbackSnapshots: sequencePlaybackSnapshots,
      bars: sequenceBars,
      tempi: sequenceTempi,
      repeats: sequenceRepeats,
      sequenceLegato,
    };
    const previousDeps = previousSequenceRuntimeDepsRef.current;
    const changedKeys =
      previousDeps == null
        ? ["initial-build"]
        : Object.keys(nextDeps).filter((key) => previousDeps[key] !== nextDeps[key]);
    appendPersistedSequenceRuntimeDiagnostic({
      type: "rebuild-cause",
      step: "build-sequence-runtime-model",
      source: "app",
      runtimeInstanceId: sequenceRuntimeModel.runtimeInstanceId,
      playbackRuntimeToken: sequencePlaybackRuntimeToken,
      timedTriggerToken: sequenceTimedTriggerToken,
      changedKeys,
      detail: changedKeys.join(", "),
      snapshotCount: snapshots.length,
      playbackSnapshotCount: sequencePlaybackSnapshots.length,
      barCount: sequenceBars.length,
      tempoCount: sequenceTempi.length,
      repeatCount: sequenceRepeats.length,
    });
    previousSequenceRuntimeDepsRef.current = nextDeps;
  }, [
    sequenceBars,
    sequenceDisplaySnapshots,
    sequenceLegato,
    sequencePlaybackRuntimeToken,
    sequencePlaybackSnapshots,
    sequenceRepeats,
    sequenceRuntimeModel.runtimeInstanceId,
    sequenceTempi,
    sequenceTimedTriggerToken,
    snapshots,
  ]);
  useEffect(() => {
    if (!isSequencerCrashDiagnosticsEnabled()) return;
    const persisted = loadPersistedSequencerCrashDiagnostics();
    const lastEntry = persisted?.state?.entries?.at?.(-1) ?? null;
    if (!lastEntry) return;
    if (
      lastEntry.type !== "snapshot-update-applied" &&
      lastEntry.type !== "snapshot-move-applied" &&
      lastEntry.type !== "snapshot-range-move-applied" &&
      lastEntry.type !== "event-bar-relative-update-dispatched"
    ) {
      return;
    }
    appendPersistedSequencerCrashDiagnostic({
      type: "sequence-runtime-rebuilt",
      detail: "Rebuilt sequence runtime model after snapshot update",
      context: {
        source: "sequencer",
        transactionId: lastEntry.context?.transactionId,
        commitKind: lastEntry.context?.commitKind,
        ...readSequencerDiagnosticMemory(),
        snapshotCountBefore: lastEntry.context?.snapshotCountBefore ?? null,
        snapshotCountAfter: snapshots.length,
        selectedSnapshotId,
        sequenceEventCount: sequenceRuntimeModel.sequenceEvents?.length ?? null,
        cueGroupCount: sequenceRuntimeModel.sequenceCueGroups?.length ?? null,
        workspaceTab,
      },
    });
  }, [selectedSnapshotId, sequenceRuntimeModel, snapshots.length, workspaceTab]);
  const sequenceCueGroups = sequenceRuntimeModel.sequenceCueGroups;
  const onPresentTimedPaletteCue = useCallback((cueIndex) => {
    // A stopped or replaced transport must not revive a queued visual update.
    if (!Number.isFinite(timedPlaybackUiRef.current.clockSeconds)) return;
    const group = sequenceCueGroups[cueIndex];
    const id = snapshots[group?.snapshotIndex]?.id ?? null;
    timedPaletteSnapshotRef.current = id;
    presentSnapshotPalette(snapshotPaletteBodyRef.current, id);
  }, [sequenceCueGroups, snapshots]);
  const sequenceRepeatSections = sequenceRuntimeModel.sequenceRepeatSections;
  const sortedSequenceBars = sequenceRuntimeModel.sortedBars;

  const legatoTransitionDurationMs = useCallback(
    (markerIndex = null, stepIndex = null) => {
      const resolvedMarkerIndex =
        Number.isFinite(Number(markerIndex)) && Number(markerIndex) >= 0
          ? Number(markerIndex)
          : sequenceCueGroups.findIndex(
              (group) => Number(group?.snapshotIndex) === Number(stepIndex),
            );
      if (sequenceTempi.length > 0 && resolvedMarkerIndex >= 0) {
        const triggerMap = sequenceRuntimeModel.timedCueTriggerBySourceIndex;
        const current = triggerMap.get(resolvedMarkerIndex + 1);
        const next = triggerMap.get(resolvedMarkerIndex + 2);
        const previous = triggerMap.get(resolvedMarkerIndex);
        const spacingSeconds = Number.isFinite(next?.absoluteSeconds)
          ? Number(next.absoluteSeconds) - Number(current?.absoluteSeconds)
          : Number.isFinite(previous?.absoluteSeconds)
            ? Number(current?.absoluteSeconds) - Number(previous.absoluteSeconds)
            : NaN;
        if (Number.isFinite(spacingSeconds) && spacingSeconds > 0) {
          const speed = Math.max(0.01, Number(sequencePlaybackSpeed) || 1);
          return Math.max(100, Math.min(400, (spacingSeconds * 1000 * 0.25) / speed));
        }
      }
      return 200 + Math.random() * 100;
    },
    [
      sequenceCueGroups,
      sequencePlaybackSpeed,
      sequenceRuntimeModel.timedCueTriggerBySourceIndex,
      sequenceTempi.length,
    ],
  );

  const barIndexForTime = useCallback(
    (absoluteTime) => {
      const time = Number(absoluteTime);
      if (!Number.isFinite(time) || sortedSequenceBars.length === 0) return 0;
      let index = 0;
      for (let i = 0; i < sortedSequenceBars.length; i += 1) {
        if (Number(sortedSequenceBars[i].position) <= time) index = i;
        else break;
      }
      return index;
    },
    [sortedSequenceBars],
  );

  const barTimeForIndex = useCallback(
    (barIndex) => {
      if (!sortedSequenceBars.length) return 1;
      const safeIndex = Math.max(0, Math.min(sortedSequenceBars.length - 1, Number(barIndex) || 0));
      return Number(sortedSequenceBars[safeIndex]?.position) || 1;
    },
    [sortedSequenceBars],
  );

  const snapshotIndexNearBar = useCallback(
    (barIndex, direction) => {
      const anchorTime = barTimeForIndex(barIndex);
      const cueGroup =
        direction > 0
          ? sequenceCueGroups.find((group) => group.time >= anchorTime)
          : sequenceCueGroups.findLast((group) => group.time < anchorTime);
      if (cueGroup) return cueGroup.snapshotIndex;
      if (direction > 0) {
        const nextIndex = snapshots.findIndex((_, index) => index + 1 >= anchorTime);
        return nextIndex >= 0 ? nextIndex : snapshots.length;
      }
      return snapshots.findLastIndex((_, index) => index + 1 < anchorTime);
    },
    [barTimeForIndex, sequenceCueGroups, snapshots],
  );

  const cueIndexNearBar = useCallback(
    (barIndex, direction) => {
      const anchorTime = barTimeForIndex(barIndex);
      return direction > 0
        ? sequenceCueGroups.findIndex((group) => group.time >= anchorTime)
        : sequenceCueGroups.findLastIndex((group) => group.time < anchorTime);
    },
    [barTimeForIndex, sequenceCueGroups],
  );

  const applyStoppedSequenceTransportState = useCallback((nextState = {}) => {
    // Transport reducers return { playhead, selection }; direct actions pass
    // flat playhead fields. Preserve the reducer's cursor instead of replacing
    // it with the builder defaults (-1 / first bar).
    const resolvedState = buildStoppedSequenceTransportState({ ...nextState, ...nextState.playhead });
    sequencePlayheadRef.current = resolvedState.playhead;
    setPlayingSnapshotId(resolvedState.playingSnapshotId);
    setSelectedSnapshotId(resolvedState.selectedSnapshotId);
    setSelectedSnapshotMarker(resolvedState.selectedSnapshotMarker);
    setSequencePlayhead(resolvedState.playhead);
  }, []);

  const resetTimedPlaybackUi = useCallback((nextState = {}) => {
    if (timedPaletteSnapshotRef.current != null) {
      presentSnapshotPalette(snapshotPaletteBodyRef.current, null);
      timedPaletteSnapshotRef.current = null;
    }
    timedPlaybackUiRef.current = buildTimedPlaybackUiResetState(nextState);
  }, []);

  const releaseManualSnapshotGesture = useCallback((gestureId) => {
    const snapshotId = manualGestureSnapshotsRef.current.get(gestureId);
    keysRef.current?.stopSnapshotGesture?.(gestureId);
    manualGestureEventVoicesRef.current.delete(gestureId);
    manualGestureSnapshotsRef.current.delete(gestureId);
    if (snapshotId != null) {
      const gestureIds = manualSnapshotGesturesRef.current.get(snapshotId);
      gestureIds?.delete(gestureId);
      if (!gestureIds?.size) manualSnapshotGesturesRef.current.delete(snapshotId);
    }
    const activeSnapshotIds = [...manualSnapshotGesturesRef.current.keys()];
    setManualPlayingSnapshotIds(activeSnapshotIds);
    setPlayingSnapshotId((current) =>
      current === snapshotId ? (activeSnapshotIds.at(-1) ?? null) : current,
    );
    if (activeSnapshotIds.length === 0) {
      setSequencePlayhead((current) => ({ ...current, stopped: true }));
    }
  }, []);

  const cancelManualSnapshotGestures = useCallback((snapshotId = null) => {
    const runtime = manualGestureRuntimeRef.current;
    const gestureIds =
      snapshotId == null
        ? runtime.activeGestureIds()
        : [...(manualSnapshotGesturesRef.current.get(snapshotId) ?? [])];
    for (const gestureId of gestureIds) runtime.cancel(gestureId);
  }, []);

  const decayManualSnapshotGesturesForNextTrigger = useCallback(
    (settings) => {
      const runtime = manualGestureRuntimeRef.current;
      if (settings?.mode === "off") {
        cancelManualSnapshotGestures();
        return;
      }
      if (settings?.decayMode === "sustain") return;
      for (const gestureId of runtime.activeGestureIds()) {
        const releasePlan = planManualSnapshotRelease(runtime.attackEvents(gestureId), settings);
        runtime.release(gestureId, releasePlan);
      }
    },
    [cancelManualSnapshotGestures],
  );

  const commitSequencePlaybackUi = useCallback(
    ({ safeStepIndex, safeMarkerIndex, snapshot, cueGroup, normalizedNotes, barIndex }) => {
      const nextState = buildCommittedSequencePlaybackState({
        safeStepIndex,
        safeMarkerIndex,
        snapshot,
        cueGroup,
        normalizedNotes,
        barIndex,
        snapshots,
      });
      pendingTransportSelectionRef.current = nextState.pendingTransportSelection;
      sequencePlayheadRef.current = nextState.playhead;
      setPlayingSnapshotId(nextState.playingSnapshotId);
      setSelectedSnapshotId(nextState.selectedSnapshotId);
      setSelectedSnapshotMarker(nextState.selectedSnapshotMarker);
      setSequencePlayhead(nextState.playhead);
    },
    [snapshots],
  );

  const cancelPendingManualCueUiCommit = useCallback(() => {
    const pending = pendingManualCueUiCommitRef.current;
    if (pending.timerId != null) window.clearTimeout(pending.timerId);
    pending.timerId = null;
    pending.payload = null;
  }, []);

  const scheduleManualCueUiCommit = useCallback(
    (payload) => {
      const pending = pendingManualCueUiCommitRef.current;
      const nextState = buildCommittedSequencePlaybackState({
        ...payload,
        snapshots,
      });
      // Arrow navigation must advance from the latest sounding position even
      // while the corresponding Preact presentation is postponed.
      pendingTransportSelectionRef.current = nextState.pendingTransportSelection;
      sequencePlayheadRef.current = nextState.playhead;
      pending.payload = payload;
      if (pending.timerId != null) window.clearTimeout(pending.timerId);
      // The audible path has already run. Wait until a manual trigger burst is
      // quiet before asking Preact to reconcile the large editable sequence.
      pending.timerId = window.setTimeout(() => {
        pending.timerId = null;
        const latest = pending.payload;
        pending.payload = null;
        if (latest) commitSequencePlaybackUi(latest);
      }, 300);
    },
    [commitSequencePlaybackUi, snapshots],
  );

  useEffect(() => cancelPendingManualCueUiCommit, [cancelPendingManualCueUiCommit]);

  const applySequencePlayback = useCallback(
    (stepIndex, markerIndex = null, notes = [], options = {}) => {
      cancelManualSnapshotGestures();
      const playbackStartMs = performance.now();
      const hardRestart = options?.hardRestart === true;
      const updateUi = options?.updateUi !== false;
      const safeStepIndex = Math.max(0, Math.min(snapshots.length - 1, stepIndex));
      const snapshot = snapshots[safeStepIndex];
      if (!snapshot) return;
      const safeMarkerIndex =
        markerIndex == null || sequenceCueGroups.length === 0
          ? null
          : Math.max(0, Math.min(sequenceCueGroups.length - 1, markerIndex));
      const cueGroup = safeMarkerIndex == null ? null : sequenceCueGroups[safeMarkerIndex];
      const normalizedNotes = Array.isArray(notes) ? notes : [];
      const useLegato = safeMarkerIndex != null;
      const playheadTime = cueGroup?.time ?? safeStepIndex + 1;
      const barIndex = barIndexForTime(playheadTime);

      if (hardRestart) keysRef.current?.stopSnapshot();
      if (normalizedNotes.length > 0) {
        keysRef.current?.playSnapshot(normalizedNotes, {
          legato: hardRestart ? false : useLegato,
          pitchOffsetCents: liveSequencePlaybackPitchOffsetRef.current,
          legatoTransitionMs: legatoTransitionDurationMs(safeMarkerIndex, safeStepIndex),
        });
      } else {
        keysRef.current?.stopSnapshot();
      }
      if (updateUi) {
        commitSequencePlaybackUi({
          safeStepIndex,
          safeMarkerIndex,
          snapshot,
          cueGroup,
          normalizedNotes,
          barIndex,
        });
      }
      const durationMs = performance.now() - playbackStartMs;
      if (isTimedTransportDiagnosticsEnabled() && durationMs > 8) {
        appendPersistedTimedTransportDiagnostic({
          type: "apply-playback",
          clockSeconds: performance.now() / 1000,
          cueIndex: safeMarkerIndex == null ? null : safeMarkerIndex + 1,
          playbackIndex: safeMarkerIndex,
          durationMs,
          noteCount: normalizedNotes.length,
          detail: `${hardRestart ? "hard restart" : "playback apply"}${updateUi ? "" : " (audio only)"}`,
        });
      }
    },
    [
      barIndexForTime,
      cancelManualSnapshotGestures,
      commitSequencePlaybackUi,
      legatoTransitionDurationMs,
      sequenceCueGroups,
      snapshots,
    ],
  );

  const sequencePlaybackNotesAtPosition = useCallback(
    (stepIndex, markerIndex = null, options = {}) => {
      if (!Number.isFinite(stepIndex) || stepIndex < 0 || stepIndex >= snapshots.length) return [];
      const keys = keysRef.current;
      const noteNameOptions = {
        noteNames: Array.isArray(keys?.settings?.note_names) ? keys.settings.note_names : [],
        hejiNames: Array.isArray(keys?.settings?.heji_names) ? keys.settings.heji_names : [],
      };
      const pitchOffset = clampSequencePlaybackPitchCents(
        options?.pitchOffset ?? liveSequencePlaybackPitchOffsetRef.current,
      );
      const transformNotes = (notes) => {
        // A formation keeps its complete source chord even when only one attack
        // is due. Snapshot IDs/keys, not projected pitches, find original notes.
        const groups = new Map();
        let nextNotes = Array.isArray(notes) ? notes.map(note => {
          const snapshot = snapshots.find(s => s.id === note.snapshotId) ?? snapshots[stepIndex];
          if (!groups.has(snapshot)) {
            const sourceNotes = (snapshot?.notes ?? []).map(source => ({ ...source,
              legatoContinuation: notes.some(active => active.legatoContinuation &&
                (active.noteKey === sequenceNoteIdentity(source, snapshot.length) ||
                  (source.id != null && active.id === source.id))),
            }));
            groups.set(snapshot, withSequenceSnapGroup(sourceNotes));
          }
          const group = groups.get(snapshot);
          const index = group.findIndex(source => note.noteKey != null
            ? sequenceNoteIdentity(source, snapshot.length) === note.noteKey
            : source.id != null && source.id === note.id);
          // sequenceSlot is a voice/legato identity, not an array index: legacy
          // snapshots may use non-contiguous slots.
          const source = group[index >= 0 ? index : notes.indexOf(note)];
          return { ...note, sequenceSnapGroup: source?.sequenceSnapGroup,
            sequenceOriginalPitch: source?.sequenceSnapGroup.pitches[source.sequenceSnapGroup.index] ??
              note.sequenceOriginalPitch ?? { midicents: Number(note.midicents), frequency: note.frequency } };
        }) : [];
        if (snapSequenceToCurrentTuning && currentSequenceSnapRuntime) {
          nextNotes = nextNotes.map((note) =>
            resolveLiveSequencePitch(note, currentSequenceSnapRuntime, 0, { ...noteNameOptions, ...chordSnapOptions }),
          );
        }
        // PITCH is a global translation. Resolve any tuning snap first, then add
        // the exact same cents value to every resulting note.
        if (Math.abs(pitchOffset) > 1e-9) {
          nextNotes = applyPlaybackPitchOffsetToNotes(nextNotes, pitchOffset);
        }
        if (sequenceTimbreModWheelEnabledRef.current) {
          nextNotes = applySequenceTimbreModWheelToNotes(
            nextNotes,
            sequenceTimbreModWheelValueRef.current,
          );
        }
        return nextNotes;
      };
      if (markerIndex == null || sequenceCueGroups.length === 0) {
        const snapshot = snapshots[stepIndex];
        const previousSnapshot = snapshots[stepIndex - 1] ?? null;
        return transformNotes(
          (snapshot?.notes ?? []).map((note, noteIndex) => ({
            ...note,
            ...deriveSequenceLegatoFlags({
              note,
              noteIndex,
              previousSnapshot,
              attackTime: Number(note?.start) || 0,
              mode: sequenceLegato,
            }),
          })),
        );
      }
      const safeMarkerIndex = Math.max(0, Math.min(sequenceCueGroups.length - 1, markerIndex));
      return transformNotes(sequenceRuntimeModel.playbackNotesByCueIndex[safeMarkerIndex] ?? []);
    },
    [
      currentSequenceSnapRuntime,
      chordSnapOptions,
      sequenceCueGroups,
      sequenceLegato,
      sequenceRuntimeModel.playbackNotesByCueIndex,
      snapSequenceToCurrentTuning,
      snapshots,
    ],
  );

  const previewSequencePlaybackPitchOffset = useCallback((value) => {
    const nextPitchOffset = clampSequencePlaybackPitchCents(value);
    liveSequencePlaybackPitchOffsetRef.current = nextPitchOffset;
    const keys = keysRef.current;
    if (!Array.isArray(keys?._snapshotHexes) || keys._snapshotHexes.length === 0) return;
    retuneActiveSnapshotHexes(keys, nextPitchOffset);
    appliedSequencePlaybackPitchOffsetRef.current = nextPitchOffset;
  }, []);

  const commitSequencePlaybackPitchOffset = useCallback((value) => {
    const nextPitchOffset = clampSequencePlaybackPitchCents(value);
    liveSequencePlaybackPitchOffsetRef.current = nextPitchOffset;
    const keys = keysRef.current;
    if (Array.isArray(keys?._snapshotHexes) && keys._snapshotHexes.length > 0) {
      // Mouse-up/text commit is a synchronous final chord transaction. This
      // intentionally resends every active voice even if the last preview had
      // the same displayed value.
      retuneActiveSnapshotHexes(keys, nextPitchOffset);
      appliedSequencePlaybackPitchOffsetRef.current = nextPitchOffset;
    }
    setSequencePlaybackPitchOffset(nextPitchOffset);
  }, []);

  const onSequenceTimbreModWheelEnabledChange = useCallback((enabled) => {
    const nextEnabled = enabled === true;
    sequenceTimbreModWheelEnabledRef.current = nextEnabled;
    setSequenceTimbreModWheelEnabled(nextEnabled);
    applySequenceTimbreModWheelToActiveSnapshotHexes(
      keysRef.current,
      nextEnabled ? sequenceTimbreModWheelValueRef.current : NEUTRAL_SEQUENCE_TIMBRE_MOD_WHEEL,
    );
  }, []);

  const setSequenceBeforeStart = useCallback(
    ({ preStart = false } = {}) => {
      pendingTransportSelectionRef.current = clearPendingTransportSelection();
      cancelManualSnapshotGestures();
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      resetTimedPlaybackUi();
      applyStoppedSequenceTransportState({ preStart });
    },
    [applyStoppedSequenceTransportState, cancelManualSnapshotGestures, resetTimedPlaybackUi],
  );

  const playSequencePosition = useCallback(
    (stepIndex, markerIndex = null, options = {}) => {
      const deferUi = options?.deferUi === true;
      if (!deferUi) cancelPendingManualCueUiCommit();
      const hardRestart = options?.hardRestart === true;
      if (stepIndex == null || stepIndex < 0 || snapshots.length === 0) {
        setSequenceBeforeStart();
        return;
      }

      if (stepIndex >= snapshots.length) {
        pendingTransportSelectionRef.current = clearPendingTransportSelection();
        const safeMarkerIndex =
          markerIndex == null || sequenceCueGroups.length === 0
            ? null
            : Math.max(0, Math.min(sequenceCueGroups.length - 1, markerIndex));
        cancelManualSnapshotGestures();
        keysRef.current?.stopSnapshot();
        sequenceRepeatPlaybackStateRef.current = {};
        resetTimedPlaybackUi({
          stepIndex: snapshots.length,
          markerIndex: safeMarkerIndex,
          barIndex: 0,
        });
        applyStoppedSequenceTransportState({
          barIndex: 0,
          stepIndex: snapshots.length,
          markerIndex: safeMarkerIndex,
        });
        return;
      }

      const safeStepIndex = Math.max(0, Math.min(snapshots.length - 1, stepIndex));
      const snapshot = snapshots[safeStepIndex];
      if (!snapshot) return;
      const safeMarkerIndex =
        markerIndex == null || sequenceCueGroups.length === 0
          ? null
          : Math.max(0, Math.min(sequenceCueGroups.length - 1, markerIndex));
      const notes = sequencePlaybackNotesAtPosition(safeStepIndex, safeMarkerIndex);
      if (deferUi) {
        const cueGroup = safeMarkerIndex == null ? null : sequenceCueGroups[safeMarkerIndex];
        applySequencePlayback(safeStepIndex, safeMarkerIndex, notes, {
          hardRestart,
          updateUi: false,
        });
        scheduleManualCueUiCommit({
          safeStepIndex,
          safeMarkerIndex,
          snapshot,
          cueGroup,
          normalizedNotes: notes,
          barIndex: barIndexForTime(cueGroup?.time ?? safeStepIndex + 1),
        });
        return;
      }
      applySequencePlayback(safeStepIndex, safeMarkerIndex, notes, { hardRestart });
    },
    [
      applySequencePlayback,
      applyStoppedSequenceTransportState,
      barIndexForTime,
      cancelPendingManualCueUiCommit,
      cancelManualSnapshotGestures,
      resetTimedPlaybackUi,
      sequenceCueGroups,
      sequencePlaybackNotesAtPosition,
      scheduleManualCueUiCommit,
      snapshots,
      setSequenceBeforeStart,
    ],
  );

  const previousLiveChordDriftRef = useRef(chordDrift);
  useEffect(() => {
    const driftChanged = previousLiveChordDriftRef.current !== chordDrift;
    previousLiveChordDriftRef.current = chordDrift;
    const previousSnap = previousSnapSequenceToCurrentTuningRef.current;
    const previousRuntimeKey = previousSequenceSnapRuntimeKeyRef.current;
    previousSequenceSnapRuntimeKeyRef.current = sequenceSnapRuntimeKey;
    const previousPitch = previousSequencePlaybackPitchOffsetRef.current;
    const pitchAlreadyApplied =
      Math.abs(appliedSequencePlaybackPitchOffsetRef.current - sequencePlaybackPitchOffset) < 1e-9;
    previousSnapSequenceToCurrentTuningRef.current = snapSequenceToCurrentTuning;
    previousSequencePlaybackPitchOffsetRef.current = sequencePlaybackPitchOffset;
    liveSequencePlaybackPitchOffsetRef.current = sequencePlaybackPitchOffset;
    if (
      (previousSnap === snapSequenceToCurrentTuning || !currentSequenceSnapRuntime) &&
      (!snapSequenceToCurrentTuning || previousRuntimeKey === sequenceSnapRuntimeKey) &&
      (previousPitch === sequencePlaybackPitchOffset || pitchAlreadyApplied)
    )
      return;
    // Arpeggios can contain only a subset of a cue, or overlapping gestures.
    // Resolve each owned voice from its immutable source instead of pairing it
    // positionally with the current cue's complete note array.
    const remapped = remapActiveSnapshotHexes(keysRef.current,
      (note) => resolveLiveSequencePitch(note, liveSequenceSnapRuntimeRef.current,
        sequencePlaybackPitchOffset, { ...liveChordSnapOptionsRef.current,
          chordLiveEdit: driftChanged }), sequencePlaybackPitchOffset);
    if (remapped.size) {
      appliedSequencePlaybackPitchOffsetRef.current = sequencePlaybackPitchOffset;
      return;
    }
    // Timed transport deliberately leaves the navigation playhead stopped and
    // tracks its sounding position separately. SNAP must still bend the active
    // timed voices immediately, just like the live playback-pitch control.
    const timedPosition = timedPlaybackUiRef.current;
    // Manual arrows update the audio cursor immediately but defer presentation.
    // A SNAP toggle during that interval must use the sounding position, not
    // consume the change against the stale (possibly still stopped) UI cursor.
    const livePosition = sequencePlayheadRef.current;
    const activePosition =
      livePosition?.stopped && Number.isFinite(timedPosition?.clockSeconds)
        ? timedPosition
        : livePosition;
    if (activePosition?.stopped) return;
    if (!Number.isFinite(activePosition?.stepIndex) || activePosition.stepIndex < 0) return;
    const currentNotes = sequencePlaybackNotesAtPosition(
      activePosition.stepIndex,
      activePosition.markerIndex,
    );
    if (currentNotes.length > 0) {
      // SNAP and playback-pitch changes only alter the tuning of the notes at
      // the current playhead position. Keep their existing voice instances so
      // toggling either modifier bends smoothly instead of rearticulating the
      // snapshot. Sequence Legato still governs transitions between cues.
      const retunedHexes = retuneSnapshotHexes(keysRef.current, currentNotes, {
        bendOnly: true,
        sequencePitch: true,
        pitchOffsetCents: sequencePlaybackPitchOffset,
      });
      retuneActiveSnapshotHexes(keysRef.current, sequencePlaybackPitchOffset, {
        skipHexes: retunedHexes,
      });
    } else {
      keysRef.current?.stopSnapshot();
    }
    appliedSequencePlaybackPitchOffsetRef.current = sequencePlaybackPitchOffset;
  }, [
    chordDrift,
    currentSequenceSnapRuntime,
    sequenceSnapRuntimeKey,
    keysReadyRevision,
    sequenceLegato,
    sequencePlaybackNotesAtPosition,
    sequencePlayhead,
    sequencePlaybackPitchOffset,
    snapSequenceToCurrentTuning,
  ]);

  const onSelectSequencerSnapshot = useCallback((id) => {
    sequenceRepeatPlaybackStateRef.current = {};
    setSelectedSnapshotId(id);
    setSelectedSnapshotMarker((current) => (current?.snapshotId === id ? current : null));
  }, []);

  const onSelectSequencerMarker = useCallback((snapshotId, time) => {
    sequenceRepeatPlaybackStateRef.current = {};
    setSelectedSnapshotId(snapshotId);
    setSelectedSnapshotMarker({ snapshotId, time });
  }, []);

  const playManualSnapshotAtIndex = useCallback(
    (stepIndex, markerIndex = null, options = {}) => {
      const deferUi = options?.deferUi === true;
      sequenceRepeatPlaybackStateRef.current = {};
      const snap = snapshots[stepIndex];
      if (!snap) return;
      const id = snap.id;
      const safeMarkerIndex =
        markerIndex == null || sequenceCueGroups.length === 0
          ? null
          : Math.max(0, Math.min(sequenceCueGroups.length - 1, markerIndex));
      const cueGroup = safeMarkerIndex == null ? null : sequenceCueGroups[safeMarkerIndex];
      const notes = sequencePlaybackNotesAtPosition(stepIndex, safeMarkerIndex);
      const articulation = effectiveManualSnapshotArticulation(
        manualArpeggiation.mode,
        snap.manualTrigger,
      );
      const arpeggiate = articulation === "arpeggiate";
      const snapshotArpeggiationEnabled = manualArpeggiation.mode !== "off";
      decayManualSnapshotGesturesForNextTrigger(manualArpeggiation);
      if (!snapshotArpeggiationEnabled) {
        // A plain manual snapshot is a chord transaction, just like a cue.
        // Keeping it out of the per-note gesture scheduler ensures every
        // pitch gets the same future MIDI/OSC commit timestamp even when an
        // edited pitch takes longer to prepare.
        if (deferUi) {
          applySequencePlayback(stepIndex, safeMarkerIndex, notes, { updateUi: false });
          scheduleManualCueUiCommit({
            safeStepIndex: stepIndex,
            safeMarkerIndex,
            snapshot: snap,
            cueGroup,
            normalizedNotes: notes,
            barIndex: barIndexForTime(cueGroup?.time ?? stepIndex + 1),
          });
        } else {
          applySequencePlayback(stepIndex, safeMarkerIndex, notes);
        }
        return stepIndex;
      }
      if (!notes.length) {
        if (!snapshotArpeggiationEnabled) keysRef.current?.stopSnapshot();
        const payload = {
          safeStepIndex: stepIndex,
          safeMarkerIndex,
          snapshot: snap,
          cueGroup,
          normalizedNotes: [],
          barIndex: barIndexForTime(cueGroup?.time ?? stepIndex + 1),
        };
        if (deferUi) scheduleManualCueUiCommit(payload);
        else commitSequencePlaybackUi(payload);
        return stepIndex;
      }
      const plan = planManualSnapshotFormation(notes, {
        ...manualArpeggiation,
        initialSpreadMs: arpeggiate ? manualArpeggiation.initialSpreadMs : 0,
        timingVariation: arpeggiate ? manualArpeggiation.timingVariation : 0,
      });
      const legatoTransitionMs = legatoTransitionDurationMs(safeMarkerIndex, stepIndex);
      const runtime = manualGestureRuntimeRef.current;
      runtime.start(plan, {
        onStart: (gestureId) => {
          manualGestureSnapshotsRef.current.set(gestureId, id);
          const gestureIds = manualSnapshotGesturesRef.current.get(id) ?? new Set();
          gestureIds.add(gestureId);
          manualSnapshotGesturesRef.current.set(id, gestureIds);
          manualGestureEventVoicesRef.current.set(gestureId, new Map());
          setManualPlayingSnapshotIds([...manualSnapshotGesturesRef.current.keys()]);
          keysRef.current?.beginSnapshotGesture?.(gestureId, {
            replace: !snapshotArpeggiationEnabled,
          });
        },
        onAttack: (event, gestureId) => {
          const liveNote = resolveLiveSequencePitch(event.note, liveSequenceSnapRuntimeRef.current,
            liveSequencePlaybackPitchOffsetRef.current, liveChordSnapOptionsRef.current);
          const result = keysRef.current?.attackSnapshotGestureNote?.(gestureId, liveNote, {
            legato: event.note?.legatoContinuation === true,
            pitchOffsetCents: liveSequencePlaybackPitchOffsetRef.current,
            legatoTransitionMs,
          });
          if (result?.hex) {
            manualGestureEventVoicesRef.current.get(gestureId)?.set(event.eventId, result.hex);
          }
        },
        onRelease: (event, gestureId) => {
          const eventVoices = manualGestureEventVoicesRef.current.get(gestureId);
          const hex = eventVoices?.get(event.eventId);
          if (!hex) return;
          keysRef.current?.releaseSnapshotGestureNote?.(gestureId, hex);
          eventVoices.delete(event.eventId);
        },
        onCancel: releaseManualSnapshotGesture,
        onComplete: releaseManualSnapshotGesture,
      });
      const normalizedNotes = Array.isArray(notes) ? notes : [];
      const payload = {
        safeStepIndex: stepIndex,
        safeMarkerIndex,
        snapshot: snap,
        cueGroup,
        normalizedNotes,
        barIndex: barIndexForTime(cueGroup?.time ?? stepIndex + 1),
      };
      if (deferUi) scheduleManualCueUiCommit(payload);
      else commitSequencePlaybackUi(payload);
      return stepIndex;
    },
    [
      barIndexForTime,
      applySequencePlayback,
      commitSequencePlaybackUi,
      decayManualSnapshotGesturesForNextTrigger,
      legatoTransitionDurationMs,
      manualArpeggiation,
      releaseManualSnapshotGesture,
      sequenceCueGroups,
      sequencePlaybackNotesAtPosition,
      scheduleManualCueUiCommit,
      snapshots,
    ],
  );

  const onPlaySnapshot = useCallback(
    (id) => {
      const stepIndex = snapshots.findIndex((snapshot) => snapshot.id === id);
      if (stepIndex < 0) return;
      playManualSnapshotAtIndex(stepIndex);
    },
    [playManualSnapshotAtIndex, snapshots],
  );

  const onStopSnapshot = useCallback(
    (id = null, options = {}) => {
      if (id != null && id === timedPaletteSnapshotRef.current &&
        Number.isFinite(timedPlaybackUiRef.current.clockSeconds)) {
        timedTransportStopRef.current?.({ restoreStartTarget: false });
        return;
      }
      cancelPendingManualCueUiCommit();
      const hasManualGesture =
        id == null
          ? manualGestureRuntimeRef.current.activeGestureIds().length > 0
          : manualSnapshotGesturesRef.current.has(id);
      if (hasManualGesture) {
        cancelManualSnapshotGestures(id);
        if (id != null) return;
      }
      if (id != null && playingSnapshotId !== id) return;
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      resetTimedPlaybackUi();
      setManualPlayingSnapshotIds([]);
      const stoppedPlaybackState =
        id == null && options?.armCurrentPosition === true
          ? resolveManualPlaybackStopTransportState({
              playhead: sequencePlayhead,
              snapshots,
              sequenceCueGroups,
            })
          : null;
      if (stoppedPlaybackState) {
        pendingTransportSelectionRef.current = stoppedPlaybackState.pendingTransportSelection;
        applyStoppedSequenceTransportState(stoppedPlaybackState);
        return;
      }
      setPlayingSnapshotId(null);
      setSequencePlayhead((prev) => ({ ...prev, stopped: true }));
    },
    [
      applyStoppedSequenceTransportState,
      cancelPendingManualCueUiCommit,
      cancelManualSnapshotGestures,
      playingSnapshotId,
      resetTimedPlaybackUi,
      sequenceCueGroups,
      sequencePlayhead,
      snapshots,
    ],
  );

  const onPlayPaletteSnapshot = useCallback(
    (id) => {
      if (typeof timedTransportStopRef.current === "function") {
        // The timed transport owns its pending cue callbacks. Stop it through
        // that controller before forming the manually selected snapshot so a
        // scheduled cue cannot replace or join the palette selection later.
        timedTransportStopRef.current({ restoreStartTarget: false });
      } else {
        onStopSnapshot();
      }
      onPlaySnapshot(id);
    },
    [onPlaySnapshot, onStopSnapshot],
  );

  const previousPerformanceWorkspaceTabRef = useRef(performanceWorkspaceTab);
  const previousVisibleWorkspaceTabRef = useRef(workspaceTab);

  useEffect(() => {
    const previousTab = previousPerformanceWorkspaceTabRef.current;
    previousPerformanceWorkspaceTabRef.current = performanceWorkspaceTab;
    const previousVisibleTab = previousVisibleWorkspaceTabRef.current;
    previousVisibleWorkspaceTabRef.current = workspaceTab;
    const transition = sequenceWorkspaceTransition({
      previousPerformanceTab: previousTab, performanceTab: performanceWorkspaceTab,
      previousTab: previousVisibleTab, tab: workspaceTab,
      playhead: sequencePlayheadRef.current, timedClockSeconds: timedPlaybackUiRef.current.clockSeconds,
    });
    if (transition === "flush-manual-snapshot") {
      // Snapshot playback belongs to the shared palette, not the sequencer tab.
      // Flush only its pending visual state so a rapid arrow-then-tab switch
      // highlights the sounding snapshot immediately, without another attack.
      const pending = pendingManualCueUiCommitRef.current.payload;
      cancelPendingManualCueUiCommit();
      if (pending) commitSequencePlaybackUi(pending);
      return;
    }
    if (transition !== "stop-sequencer") return;
    // Leaving the Sequencer should stop only voices owned by sequencer
    // playback. Live MIDI/controller notes belong to the always-mounted Keys
    // runtime and must survive workspace navigation just as they do when
    // entering the Sequencer.
    if (timedTransportStopRef.current) {
      timedTransportStopRef.current({ restoreStartTarget: false });
    } else {
      onStopSnapshot();
    }
  }, [
    onStopSnapshot,
    performanceWorkspaceTab,
    workspaceTab,
    cancelPendingManualCueUiCommit,
    commitSequencePlaybackUi,
  ]);

  const onSelectSequenceBar = useCallback(
    (barIndex) => {
      manualGestureRuntimeRef.current.cancelAll();
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = clearPendingTransportSelection();
      applyStoppedSequenceTransportState({
        barIndex,
        stepIndex: -1,
      });
    },
    [applyStoppedSequenceTransportState],
  );

  const onCueSequenceSnapshot = useCallback(
    (targetIndex) => {
      const nextState = resolvePendingSnapshotTransportState({
        targetIndex,
        snapshots,
        sequenceCueGroups,
        barIndexForTime,
      });
      if (!nextState) return;
      manualGestureRuntimeRef.current.cancelAll();
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = nextState.pendingTransportSelection;
      applyStoppedSequenceTransportState(nextState);
    },
    [applyStoppedSequenceTransportState, barIndexForTime, sequenceCueGroups, snapshots],
  );

  const onCueSequenceCue = useCallback(
    (targetCueIndex) => {
      const previewExpandedIds = buildCueExpandedSnapshotIdsAt(
        targetCueIndex,
        sequenceRuntimeModel.renderedSnapshots,
        sortedSequenceBars,
        sequenceRuntimeModel.sortedTempi,
        sequenceRuntimeModel.sequenceEvents,
      );
      const nextState = resolvePendingCueTransportState({
        targetCueIndex,
        sequenceCueGroups,
        sequenceEvents: sequenceRuntimeModel.sequenceEvents,
        snapshots,
        previewExpandedIds,
        barIndexForTime,
      });
      if (!nextState) return;
      manualGestureRuntimeRef.current.cancelAll();
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = nextState.pendingTransportSelection;
      applyStoppedSequenceTransportState(nextState);
    },
    [
      applyStoppedSequenceTransportState,
      barIndexForTime,
      sequenceCueGroups,
      sequenceRuntimeModel.renderedSnapshots,
      sequenceRuntimeModel.sequenceEvents,
      sequenceRuntimeModel.sortedTempi,
      snapshots,
      sortedSequenceBars,
    ],
  );

  const onAddSequenceBar = useCallback((position = null, numerator = 4, denominator = 4) => {
    setSequenceBars((prev) => {
      const nextId = sequenceBarIdRef.current + 1;
      const result = addSequenceBarMarker({
        bars: prev,
        nextBarId: nextId,
        position,
        numerator,
        denominator,
        confirmReplace: () =>
          window.confirm("There already is a bar at the specified position. Replace?"),
      });
      sequenceBarIdRef.current = result.nextBarId;
      return result.bars;
    });
  }, []);

  const onAddBarsBeforeSnapshots = useCallback(() => {
    setSequenceBars((prev) => {
      const result = addBarsBeforeSnapshots({
        bars: prev,
        snapshotCount: snapshots.length,
        nextBarId: sequenceBarIdRef.current,
      });
      sequenceBarIdRef.current = result.nextBarId;
      return result.bars;
    });
  }, [snapshots.length]);

  const onDeleteSequenceBar = useCallback((id) => {
    setSequenceBars((prev) => prev.filter((bar) => bar.id !== id));
  }, []);

  const onAddSequenceTempo = useCallback(
    (position = null, bpm = 60, mode = "immediate", beatNumerator = 1, beatDenominator = 4) => {
      setSequenceTempi((prev) =>
        addSequenceTempoMarker({
          tempi: prev,
          position,
          bpm,
          mode,
          beatNumerator,
          beatDenominator,
        }),
      );
    },
    [],
  );

  const onDeleteSequenceTempo = useCallback((id) => {
    setSequenceTempi((prev) => prev.filter((tempo) => tempo.id !== id));
  }, []);

  const onAddSequenceRepeat = useCallback((position = null, kind = "start") => {
    setSequenceRepeats((prev) => addSequenceRepeatMarker({ repeats: prev, position, kind }));
  }, []);

  const onDeleteSequenceRepeat = useCallback((id) => {
    setSequenceRepeats((prev) => prev.filter((marker) => marker.id !== id));
  }, []);

  const onUpdateSequenceRepeat = useCallback((id, updates) => {
    setSequenceRepeats((prev) =>
      updateSequenceRepeatMarker({ repeats: prev, repeatId: id, updates }),
    );
  }, []);

  const onUpdateSequenceTempo = useCallback((id, updates) => {
    setSequenceTempi((prev) => updateSequenceTempoMarker({ tempi: prev, tempoId: id, updates }));
  }, []);

  const onUpdateSequenceBar = useCallback(
    (id, updates) => {
      setSequenceBars((prev) => {
        const result = updateSequenceBarMarker({
          bars: prev,
          snapshots,
          barId: id,
          updates,
          nextBarId: sequenceBarIdRef.current,
          confirmReplace: () =>
            window.confirm("There already is a bar at the specified position. Replace?"),
        });
        sequenceBarIdRef.current = result.nextBarId;
        return result.bars;
      });
    },
    [snapshots],
  );

  const onMoveSequenceBar = useCallback(
    (fromId, position) => {
      setSequenceBars((prev) => {
        const result = moveSequenceBarMarker({
          bars: prev,
          snapshots,
          barId: fromId,
          position,
          nextBarId: sequenceBarIdRef.current,
          confirmReplace: () =>
            window.confirm("There already is a bar at the specified position. Replace?"),
        });
        sequenceBarIdRef.current = result.nextBarId;
        return result.bars;
      });
    },
    [snapshots],
  );

  const onStepSequence = useCallback(
    (direction) => {
      const livePlayhead = sequencePlayheadRef.current;
      sequenceRepeatPlaybackStateRef.current = {};
      if (!snapshots.length) return;
      if (livePlayhead.preStart === true) {
        if (direction > 0) setSequenceBeforeStart();
        return;
      }
      const pendingSnapshotIndex = pendingTransportSelectionRef.current.snapshotIndex;
      if (
        livePlayhead.stopped === true &&
        Number.isFinite(pendingSnapshotIndex) &&
        pendingSnapshotIndex >= 0
      ) {
        if (direction > 0) {
          playManualSnapshotAtIndex(pendingSnapshotIndex, null, { deferUi: true });
          return pendingSnapshotIndex;
        }
        const previousIndex = pendingSnapshotIndex - 1;
        if (previousIndex >= 0) {
          playManualSnapshotAtIndex(previousIndex, null, { deferUi: true });
          return previousIndex;
        }
        playSequencePosition(-1, null);
        return;
      }
      const current = Number.isFinite(livePlayhead.stepIndex) ? livePlayhead.stepIndex : -1;
      if (current < 0) {
        const target = snapshotIndexNearBar(livePlayhead.barIndex, direction);
        if (target < 0) {
          setSequenceBeforeStart({ preStart: direction < 0 });
          return;
        }
        if (target >= snapshots.length) {
          playSequencePosition(snapshots.length, null);
          return;
        }
        playManualSnapshotAtIndex(target, null, { deferUi: true });
        return target;
      }
      const next = Math.max(-1, Math.min(snapshots.length, current + direction));
      if (next >= 0 && next < snapshots.length) {
        playManualSnapshotAtIndex(next, null, { deferUi: true });
        return next;
      }
      playSequencePosition(next, null);
    },
    [
      playManualSnapshotAtIndex,
      playSequencePosition,
      snapshotIndexNearBar,
      snapshots.length,
      setSequenceBeforeStart,
    ],
  );

  const onStepSequenceMarker = useCallback(
    (direction) => {
      const livePlayhead = sequencePlayheadRef.current;
      const currentCueIndex = Number.isFinite(livePlayhead.markerIndex)
        ? livePlayhead.markerIndex
        : null;
      const playheadStepIndex = Number.isFinite(livePlayhead.stepIndex)
        ? livePlayhead.stepIndex
        : null;
      const playheadBarIndex = Number.isFinite(livePlayhead.barIndex)
        ? livePlayhead.barIndex
        : null;
      const recordCueNavigation = (type, detail, extraContext = {}, error = null) => {
        appendPersistedSequencerCrashDiagnostic({
          type,
          detail,
          context: {
            source: "cue-navigation",
            navigationDirection: direction,
            currentCueIndex,
            playheadStepIndex,
            playheadBarIndex,
            snapshotCountBefore: snapshots.length,
            workspaceTab,
            ...extraContext,
          },
          error,
        });
      };

      recordCueNavigation(
        "cue-navigation-requested",
        direction < 0 ? "Requested previous cue" : "Requested next cue",
        { navigationStage: "requested" },
      );

      try {
        if (!snapshots.length) {
          recordCueNavigation(
            "cue-navigation-resolved",
            "Ignored cue navigation because the sequence is empty",
            { navigationStage: "resolved", nextCueIndex: null },
          );
          return;
        }

        if (livePlayhead.preStart === true) {
          recordCueNavigation(
            "cue-navigation-resolved",
            direction > 0
              ? "Prepared the first cue from sequence pre-start"
              : "Kept cue navigation at sequence pre-start",
            { navigationStage: "resolved", nextCueIndex: -1, preStart: direction <= 0 },
          );
          if (direction > 0) setSequenceBeforeStart();
          return;
        }

        const cueCount = sequenceCueGroups.length;
        if (cueCount === 0) {
          const currentStep = playheadStepIndex ?? -1;
          if (currentStep < 0) {
            const target = snapshotIndexNearBar(livePlayhead.barIndex, direction);
            if (target < 0) {
              recordCueNavigation(
                "cue-navigation-resolved",
                "Resolved cue navigation to sequence start",
                { navigationStage: "resolved", nextCueIndex: -1 },
              );
              setSequenceBeforeStart({ preStart: direction < 0 });
              return;
            }
            if (target >= snapshots.length) {
              recordCueNavigation(
                "cue-navigation-resolved",
                "Resolved cue navigation to sequence end",
                { navigationStage: "resolved", nextCueIndex: cueCount },
              );
              playSequencePosition(snapshots.length, null);
              return;
            }
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved cue navigation to snapshot playhead",
              {
                navigationStage: "resolved",
                nextCueIndex: null,
                snapshotId: snapshots[target]?.id ?? null,
              },
            );
            playSequencePosition(target, null);
            return;
          }

          const nextStep = Math.max(-1, Math.min(snapshots.length, currentStep + direction));
          recordCueNavigation(
            "cue-navigation-resolved",
            "Resolved cue navigation without cue markers",
            {
              navigationStage: "resolved",
              nextCueIndex: null,
              snapshotId: snapshots[nextStep]?.id ?? null,
            },
          );
          playSequencePosition(nextStep, null);
          return;
        }

        const atOff = playheadStepIndex == null || playheadStepIndex < 0;
        const atEnd = playheadStepIndex != null && playheadStepIndex >= snapshots.length;
        let nextCue = currentCueIndex;
        const queuedCueIndex = pendingTransportSelectionRef.current.cueIndex;

        if (livePlayhead.stopped === true && queuedCueIndex != null) {
          if (direction > 0) {
            const queuedCueGroup = sequenceCueGroups[queuedCueIndex];
            if (!queuedCueGroup) {
              recordCueNavigation(
                "cue-navigation-error",
                "Resolved queued cue playback without a cue group",
                { navigationStage: "error", nextCueIndex: queuedCueIndex },
              );
              return;
            }
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved next cue navigation to the queued cue",
              {
                navigationStage: "resolved",
                nextCueIndex: queuedCueIndex,
                snapshotId: snapshots[queuedCueGroup.snapshotIndex]?.id ?? null,
              },
            );
            playSequencePosition(queuedCueGroup.snapshotIndex, queuedCueIndex, { deferUi: true });
            return queuedCueIndex;
          }
          nextCue = queuedCueIndex - 1;
          if (nextCue < 0) {
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved previous cue navigation to off state",
              { navigationStage: "resolved", nextCueIndex: -1 },
            );
            playSequencePosition(-1, null);
            return;
          }
        } else if (atOff) {
          nextCue = cueIndexNearBar(livePlayhead.barIndex, direction);
          if (nextCue < 0) {
            if (direction < 0) {
              recordCueNavigation(
                "cue-navigation-resolved",
                "Resolved previous cue navigation to off state",
                { navigationStage: "resolved", nextCueIndex: -1 },
              );
              setSequenceBeforeStart({ preStart: true });
              return;
            }
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved next cue navigation to sequence end",
              { navigationStage: "resolved", nextCueIndex: cueCount - 1 },
            );
            playSequencePosition(snapshots.length, cueCount - 1);
            return;
          }
        } else if (atEnd) {
          if (direction >= 0) {
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved next cue navigation to stay at sequence end",
              { navigationStage: "resolved", nextCueIndex: cueCount - 1 },
            );
            return;
          }
          nextCue = currentCueIndex == null ? cueCount - 1 : Math.max(0, currentCueIndex - 1);
        } else if (currentCueIndex == null) {
          const currentTime = Number(livePlayhead.stepIndex) + 1;
          nextCue =
            direction > 0
              ? sequenceCueGroups.findIndex((group) => group.time > currentTime)
              : sequenceCueGroups.findLastIndex((group) => group.time < currentTime);
          if (nextCue < 0) {
            recordCueNavigation(
              "cue-navigation-resolved",
              direction > 0
                ? "Resolved next cue navigation to sequence end"
                : "Resolved previous cue navigation to off state",
              { navigationStage: "resolved", nextCueIndex: direction > 0 ? cueCount - 1 : -1 },
            );
            playSequencePosition(direction > 0 ? snapshots.length : -1, null);
            return;
          }
        } else if (direction > 0) {
          const repeatAdvance = advanceCueIndexWithRepeats({
            currentCueIndex,
            cueCount,
            cueGroups: sequenceCueGroups,
            repeatSections: sequenceRepeatSections,
            repeatPlaybackState: sequenceRepeatPlaybackStateRef.current,
            playRepeats: sequencePlayRepeats,
          });
          sequenceRepeatPlaybackStateRef.current = repeatAdvance.nextRepeatPlaybackState;
          nextCue = repeatAdvance.nextCueIndex;
          if (nextCue >= cueCount) {
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved next cue navigation beyond final cue",
              { navigationStage: "resolved", nextCueIndex: cueCount - 1 },
            );
            playSequencePosition(snapshots.length, cueCount - 1);
            return;
          }
          const nextCueGroup = sequenceCueGroups[nextCue];
          if (!nextCueGroup) {
            recordCueNavigation(
              "cue-navigation-error",
              "Resolved next cue index without a cue group",
              { navigationStage: "error", nextCueIndex: nextCue },
            );
            return;
          }
          recordCueNavigation(
            "cue-navigation-resolved",
            repeatAdvance.didLoop
              ? "Resolved next cue navigation with repeat loop"
              : "Resolved next cue navigation",
            {
              navigationStage: "resolved",
              nextCueIndex: nextCue,
              snapshotId: snapshots[nextCueGroup.snapshotIndex]?.id ?? null,
            },
          );
          playSequencePosition(nextCueGroup.snapshotIndex, nextCue, {
            hardRestart: repeatAdvance.didLoop,
            deferUi: true,
          });
          return nextCue;
        } else {
          sequenceRepeatPlaybackStateRef.current = {};
          nextCue = Math.max(-1, Math.min(cueCount, currentCueIndex + direction));
          if (nextCue < 0) {
            recordCueNavigation(
              "cue-navigation-resolved",
              "Resolved previous cue navigation to off state",
              { navigationStage: "resolved", nextCueIndex: -1 },
            );
            playSequencePosition(-1, null);
            return;
          }
        }

        const cueGroup = sequenceCueGroups[nextCue];
        if (!cueGroup) {
          recordCueNavigation("cue-navigation-error", "Resolved cue index without a cue group", {
            navigationStage: "error",
            nextCueIndex: nextCue,
          });
          return;
        }
        recordCueNavigation(
          "cue-navigation-resolved",
          direction < 0 ? "Resolved previous cue navigation" : "Resolved next cue navigation",
          {
            navigationStage: "resolved",
            nextCueIndex: nextCue,
            snapshotId: snapshots[cueGroup.snapshotIndex]?.id ?? null,
          },
        );
        playSequencePosition(cueGroup.snapshotIndex, nextCue, { deferUi: true });
        return nextCue;
      } catch (error) {
        recordCueNavigation(
          "cue-navigation-error",
          direction < 0
            ? "Previous cue navigation threw an error"
            : "Next cue navigation threw an error",
          { navigationStage: "error" },
          error,
        );
        throw error;
      }
    },
    [
      sequenceRepeatSections,
      cueIndexNearBar,
      playSequencePosition,
      sequenceCueGroups,
      sequencePlayRepeats,
      snapshotIndexNearBar,
      snapshots,
      setSequenceBeforeStart,
      workspaceTab,
    ],
  );

  const onJumpSequenceSnapshot = useCallback(
    (targetIndex) => {
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = clearPendingTransportSelection();
      const nextIndex = Number(targetIndex);
      if (!Number.isFinite(nextIndex)) return;
      if (nextIndex >= 0 && nextIndex < snapshots.length) {
        playManualSnapshotAtIndex(nextIndex);
        return;
      }
      playSequencePosition(nextIndex, null);
    },
    [playManualSnapshotAtIndex, playSequencePosition, snapshots.length],
  );

  const onJumpSequenceCue = useCallback(
    (targetCueIndex) => {
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = clearPendingTransportSelection();
      const nextCueIndex = Number(targetCueIndex);
      if (!Number.isFinite(nextCueIndex) || sequenceCueGroups.length === 0) return;
      if (nextCueIndex < 0 || nextCueIndex >= sequenceCueGroups.length) {
        playSequencePosition(nextCueIndex < 0 ? -1 : snapshots.length, null);
        return;
      }
      const safeCueIndex = Math.max(0, Math.min(sequenceCueGroups.length - 1, nextCueIndex));
      const cueGroup = sequenceCueGroups[safeCueIndex];
      if (!cueGroup) return;
      playSequencePosition(cueGroup.snapshotIndex, safeCueIndex);
    },
    [playSequencePosition, sequenceCueGroups, snapshots.length],
  );

  const onPlaySequence = useCallback(() => {
    if (!snapshots.length) return;
    const pendingSnapshotIndex = pendingTransportSelectionRef.current.snapshotIndex;
    pendingTransportSelectionRef.current = clearPendingTransportSelection();
    if (sequencePlayheadRef.current.stopped === true &&
        Number.isInteger(pendingSnapshotIndex) && pendingSnapshotIndex >= 0 &&
        pendingSnapshotIndex < snapshots.length) {
      sequenceRepeatPlaybackStateRef.current = {};
      playManualSnapshotAtIndex(pendingSnapshotIndex);
      return;
    }
    if ((sequencePlayhead.stepIndex ?? -1) < 0) {
      const target = snapshotIndexNearBar(sequencePlayhead.barIndex, 1);
      sequenceRepeatPlaybackStateRef.current = {};
      if (target < 0) {
        playSequencePosition(-1, null);
        return;
      }
      if (target >= snapshots.length) {
        playSequencePosition(snapshots.length, null);
        return;
      }
      playManualSnapshotAtIndex(target);
      return;
    }
    if ((sequencePlayhead.stepIndex ?? -1) >= snapshots.length) {
      sequenceRepeatPlaybackStateRef.current = {};
      playSequencePosition(sequencePlayhead.stepIndex ?? -1, null);
      return;
    }
    playManualSnapshotAtIndex(sequencePlayhead.stepIndex ?? 0, sequencePlayhead.markerIndex);
  }, [
    playManualSnapshotAtIndex,
    playSequencePosition,
    sequencePlayhead.barIndex,
    sequencePlayhead.markerIndex,
    sequencePlayhead.stepIndex,
    snapshotIndexNearBar,
    snapshots.length,
  ]);

  const onResetSequencePlayhead = useCallback(() => {
    sequenceRepeatPlaybackStateRef.current = {};
    pendingTransportSelectionRef.current = clearPendingTransportSelection();
    resetTimedPlaybackUi();
    playSequencePosition(-1, null);
  }, [playSequencePosition, resetTimedPlaybackUi]);

  const onJumpSequenceEnd = useCallback(() => {
    const lastCueIndex = sequenceCueGroups.length > 0 ? sequenceCueGroups.length - 1 : null;
    const lastBarIndex = sortedSequenceBars.length > 0 ? sortedSequenceBars.length - 1 : 0;
    manualGestureRuntimeRef.current.cancelAll();
    keysRef.current?.stopSnapshot();
    sequenceRepeatPlaybackStateRef.current = {};
    pendingTransportSelectionRef.current = clearPendingTransportSelection();
    applyStoppedSequenceTransportState({
      barIndex: lastBarIndex,
      stepIndex: snapshots.length,
      markerIndex: lastCueIndex,
    });
    resetTimedPlaybackUi({
      stepIndex: snapshots.length,
      markerIndex: lastCueIndex,
      barIndex: lastBarIndex,
    });
  }, [
    applyStoppedSequenceTransportState,
    resetTimedPlaybackUi,
    sequenceCueGroups.length,
    snapshots.length,
    sortedSequenceBars.length,
  ]);

  const timedTransportClockRef = useRef(null);
  if (!timedTransportClockRef.current) timedTransportClockRef.current = createTransportClock();
  const getTimedTransportClockSeconds = useCallback(() =>
    timedTransportClockRef.current(keysRef.current?.synth, performance.now() / 1000), []);

  const recordManualCueBurstDiagnostic = useCallback((cueIndex, startedAtMs, applyDurationMs) => {
    if (!isTimedTransportDiagnosticsEnabled()) return;
    const state = manualCueDiagnosticsRef.current;
    const intervalMs =
      Number.isFinite(state.lastTriggerMs) && Number.isFinite(startedAtMs)
        ? Math.max(0, startedAtMs - state.lastTriggerMs)
        : null;
    state.lastTriggerMs = startedAtMs;
    state.firstTriggerMs ??= startedAtMs;
    state.minimumIntervalMs =
      intervalMs == null
        ? state.minimumIntervalMs
        : state.minimumIntervalMs == null
          ? intervalMs
          : Math.min(state.minimumIntervalMs, intervalMs);
    state.triggerCount += 1;
    state.maximumApplyDurationMs = Math.max(
      state.maximumApplyDurationMs,
      Number(applyDurationMs) || 0,
    );
    state.latestCueIndex = cueIndex;
    if (state.frameId != null) return;

    state.frameId = window.requestAnimationFrame((frameAtMs) => {
      const pending = manualCueDiagnosticsRef.current;
      const firstTriggerMs = pending.firstTriggerMs;
      appendPersistedTimedTransportDiagnostic({
        type: "manual-cue-frame",
        clockSeconds: frameAtMs / 1000,
        cueIndex: Number.isFinite(pending.latestCueIndex) ? pending.latestCueIndex + 1 : null,
        playbackIndex: pending.latestCueIndex,
        frameIntervalMs: Number.isFinite(firstTriggerMs) ? frameAtMs - firstTriggerMs : null,
        triggerIntervalMs: pending.minimumIntervalMs,
        durationMs: pending.maximumApplyDurationMs,
        queueDepth: pending.triggerCount,
        detail: "manual cue triggers received before the next animation frame",
      });
      pending.frameId = null;
      pending.firstTriggerMs = null;
      pending.minimumIntervalMs = null;
      pending.triggerCount = 0;
      pending.maximumApplyDurationMs = 0;
      pending.latestCueIndex = null;
    });
  }, []);

  useEffect(
    () => () => {
      const frameId = manualCueDiagnosticsRef.current.frameId;
      if (frameId != null) window.cancelAnimationFrame(frameId);
    },
    [],
  );

  const onPlaySequenceCue = useCallback(
    (cueIndex, options = {}) => {
      const startedAtMs = performance.now();
      sequenceRepeatPlaybackStateRef.current = {};
      const index = Number(cueIndex);
      if (!Number.isFinite(index) || index < 0 || index >= sequenceCueGroups.length) return;
      const cueGroup = sequenceCueGroups[index];
      if (!cueGroup) return;
      playSequencePosition(cueGroup.snapshotIndex, index, {
        deferUi: options?.deferUi === true,
      });
      recordManualCueBurstDiagnostic(index, startedAtMs, performance.now() - startedAtMs);
    },
    [playSequencePosition, recordManualCueBurstDiagnostic, sequenceCueGroups],
  );

  const onPlayTimedSequenceCue = useCallback(
    (cueIndex, timedCueTrigger, options = {}) => {
      cancelPendingManualCueUiCommit();
      const index = Number(cueIndex);
      if (!Number.isFinite(index) || index < 0 || index >= sequenceCueGroups.length) return;
      const cueGroup = sequenceCueGroups[index];
      if (!cueGroup) return;
      const clockSeconds = getTimedTransportClockSeconds();
      const barIndex = barIndexForTime(cueGroup.time);
      const hardRestart = options?.hardRestart === true || timedCueTrigger?.repeatJump != null;
      const notes = sequencePlaybackNotesAtPosition(cueGroup.snapshotIndex, index);
      applySequencePlayback(cueGroup.snapshotIndex, index, notes, {
        hardRestart,
        updateUi: false,
      });
      timedPlaybackUiRef.current = {
        clockSeconds,
        stepIndex: cueGroup.snapshotIndex,
        markerIndex: index,
        barIndex,
      };
    },
    [
      applySequencePlayback,
      barIndexForTime,
      cancelPendingManualCueUiCommit,
      getTimedTransportClockSeconds,
      sequenceCueGroups,
      sequencePlaybackNotesAtPosition,
    ],
  );

  const applySequenceWorkspaceMutationFocus = useCallback(
    (result) => {
      const nextState = resolveWorkspaceMutationTransportState({
        focus: result?.focus,
        snapshots: result?.snapshots,
        bars: result?.bars,
      });
      if (!nextState) return;
      manualGestureRuntimeRef.current.cancelAll();
      keysRef.current?.stopSnapshot();
      sequenceRepeatPlaybackStateRef.current = {};
      pendingTransportSelectionRef.current = nextState.pendingTransportSelection;
      resetTimedPlaybackUi(nextState.timedPlaybackUi);
      applyStoppedSequenceTransportState(nextState);
      setManualPlayingSnapshotIds([]);
    },
    [applyStoppedSequenceTransportState, resetTimedPlaybackUi],
  );

  const onDeleteSnapshot = useCallback(
    (id) => {
      const manualGestureIds = [...(manualSnapshotGesturesRef.current.get(id) ?? [])];
      for (const gestureId of manualGestureIds) {
        manualGestureRuntimeRef.current.cancel(gestureId);
      }
      if (playingSnapshotId === id && manualGestureIds.length === 0) {
        keysRef.current?.stopSnapshot();
        setPlayingSnapshotId(null);
      }
      const result = deleteSnapshotFromWorkspace({
        snapshots,
        bars: sequenceBars,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        snapshotId: id,
        selectedSnapshotId,
        selectedSnapshotMarker,
      });
      snapshotsRef.current = result.snapshots;
      sequenceBarsRef.current = result.bars;
      setSequenceBars(result.bars);
      setSequenceTempi(result.tempi);
      setSequenceRepeats(result.repeats);
      setSnapshots(result.snapshots);
      setSelectedSnapshotId(result.selectedSnapshotId);
      setSelectedSnapshotMarker(result.selectedSnapshotMarker);
      applySequenceWorkspaceMutationFocus(result);
      return result;
    },
    [
      applySequenceWorkspaceMutationFocus,
      playingSnapshotId,
      selectedSnapshotId,
      selectedSnapshotMarker,
      sequenceBars,
      sequenceRepeats,
      sequenceTempi,
      snapshots,
    ],
  );

  const onDeleteAllSnapshots = useCallback(() => {
    manualGestureRuntimeRef.current.cancelAll();
    keysRef.current?.stopSnapshot();
    setPlayingSnapshotId(null);
    setManualPlayingSnapshotIds([]);
    const cleared = buildClearedSequenceWorkspaceState();
    setSnapshots(cleared.snapshots);
    setSelectedSnapshotId(cleared.selectedSnapshotId);
    setSelectedSnapshotMarker(cleared.selectedSnapshotMarker);
    setSequenceBars(cleared.bars);
    setSequenceTempi(cleared.tempi);
    setSequenceRepeats(cleared.repeats);
    snapshotIdRef.current = cleared.ids.snapshotId;
    sequenceBarIdRef.current = cleared.ids.barId;
    setActiveSequenceSource(cleared.activeSequenceSource);
    setActiveSequenceBuiltInName(cleared.activeSequenceBuiltInName);
    setActiveSequenceName(cleared.activeSequenceName);
    setActiveSequenceSavedName(cleared.activeSequenceSavedName);
    setActiveSequenceDescription(cleared.activeSequenceDescription);
    setManualArpeggiation(cleared.manualArpeggiation);
    playSequencePosition(-1, null);
  }, [playSequencePosition]);

  const onClearSequence = useCallback(() => {
    manualGestureRuntimeRef.current.cancelAll();
    keysRef.current?.stopSnapshot();
    setPlayingSnapshotId(null);
    setManualPlayingSnapshotIds([]);
    const cleared = buildClearedSequenceWorkspaceState();
    setSnapshots(cleared.snapshots);
    setSelectedSnapshotId(cleared.selectedSnapshotId);
    setSelectedSnapshotMarker(cleared.selectedSnapshotMarker);
    setSequenceBars(cleared.bars);
    setSequenceTempi(cleared.tempi);
    setSequenceRepeats(cleared.repeats);
    snapshotIdRef.current = cleared.ids.snapshotId;
    sequenceBarIdRef.current = cleared.ids.barId;
    setActiveSequenceSource(cleared.activeSequenceSource);
    setActiveSequenceBuiltInName(cleared.activeSequenceBuiltInName);
    setActiveSequenceName(cleared.activeSequenceName);
    setActiveSequenceSavedName(cleared.activeSequenceSavedName);
    setActiveSequenceDescription(cleared.activeSequenceDescription);
    setManualArpeggiation(cleared.manualArpeggiation);
    playSequencePosition(-1, null);
  }, [playSequencePosition]);

  const onSequenceNameChange = useCallback((value) => {
    const nextName = String(value ?? "");
    setActiveSequenceName(nextName);
  }, []);

  const onSequenceSaved = useCallback((name) => {
    const nextName = String(name ?? "").trim();
    setActiveSequenceSource("user");
    setActiveSequenceBuiltInName("");
    setActiveSequenceName(nextName);
    setActiveSequenceSavedName(nextName);
  }, []);

  const onMoveSnapshot = useCallback(
    (fromId, toId, side = "before") => {
      const currentSnapshots = snapshotsRef.current;
      const fromIndex = currentSnapshots.findIndex((snapshot) => snapshot.id === fromId);
      const toIndex = currentSnapshots.findIndex((snapshot) => snapshot.id === toId);
      const transactionId = createSequencerDiagnosticTransactionId("snapshot-move");
      appendPersistedSequencerCrashDiagnostic(
        {
          type: "snapshot-move-requested",
          detail: "Requested snapshot reposition",
          context: {
            source: "sequencer",
            snapshotId: fromId,
            targetSnapshotId: toId,
            transactionId,
            commitKind: "snapshot-move",
            targetKind: side,
            fromPosition: fromIndex < 0 ? null : fromIndex + 1,
            toPosition: toIndex < 0 ? null : toIndex + 1,
            snapshotCountBefore: currentSnapshots.length,
            workspaceTab,
            ...readSequencerDiagnosticMemory(),
          },
        },
        globalThis.sessionStorage,
        { immediate: true },
      );
      const nextSnapshots = moveSnapshotInWorkspace({
        snapshots: currentSnapshots,
        fromId,
        toId,
        side,
      });
      if (nextSnapshots === currentSnapshots) return;
      const nextIndex = nextSnapshots.findIndex((snapshot) => snapshot.id === fromId);
      snapshotsRef.current = nextSnapshots;
      persistSequenceWorkspace({ snapshots: nextSnapshots });
      setSnapshots(nextSnapshots);
      appendPersistedSequencerCrashDiagnostic(
        {
          type: "snapshot-move-applied",
          detail: "Applied snapshot reposition",
          context: {
            source: "sequencer",
            snapshotId: fromId,
            targetSnapshotId: toId,
            transactionId,
            commitKind: "snapshot-move",
            targetKind: side,
            fromPosition: fromIndex + 1,
            toPosition: nextIndex < 0 ? null : nextIndex + 1,
            snapshotCountBefore: currentSnapshots.length,
            snapshotCountAfter: nextSnapshots.length,
            workspaceTab,
            ...readSequencerDiagnosticMemory(),
          },
        },
        globalThis.sessionStorage,
        { immediate: true },
      );
    },
    [persistSequenceWorkspace, workspaceTab],
  );

  const onDuplicateSnapshot = useCallback(
    (fromId, toId, side = "before") => {
      const result = duplicateSnapshotInWorkspace({
        snapshots,
        bars: sequenceBars,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        fromId,
        toId,
        side,
        nextSnapshotId: snapshotIdRef.current + 1,
      });
      snapshotIdRef.current = result.ids.snapshotId;
      setSnapshots(result.snapshots);
      setSequenceBars(result.bars);
      setSequenceTempi(result.tempi);
      setSequenceRepeats(result.repeats);
    },
    [sequenceBars, sequenceRepeats, sequenceTempi, snapshots],
  );

  const onInsertSnapshotCopyBlock = useCallback(
    (block, insertionPosition) => {
      const result = insertSnapshotCopyBlock({
        snapshots: snapshotsRef.current,
        bars: sequenceBars,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        block,
        insertionPosition,
        nextSnapshotId: snapshotIdRef.current + 1,
        nextBarId: sequenceBarIdRef.current,
      });
      if (result.error) return result.error;
      snapshotIdRef.current = result.ids.snapshotId;
      sequenceBarIdRef.current = result.ids.barId;
      snapshotsRef.current = result.snapshots;
      sequenceBarsRef.current = result.bars;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: result.bars,
        tempi: result.tempi,
        repeats: result.repeats,
      });
      setSnapshots(result.snapshots);
      setSequenceBars(result.bars);
      setSequenceTempi(result.tempi);
      setSequenceRepeats(result.repeats);
      setSelectedSnapshotId(result.selectedSnapshotId);
      setSelectedSnapshotMarker(result.selectedSnapshotMarker);
      applySequenceWorkspaceMutationFocus(result);
      return result;
    },
    [
      applySequenceWorkspaceMutationFocus,
      persistSequenceWorkspace,
      sequenceBars,
      sequenceRepeats,
      sequenceTempi,
    ],
  );

  const onMoveSnapshotRange = useCallback(
    (selection, insertionPosition) => {
      const snapshotCountBefore = snapshotsRef.current.length;
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-move-requested",
        detail: "Requested move of snapshot range",
        context: {
          source: "sequencer",
          startPosition: selection?.startPosition ?? null,
          endPosition: selection?.endPosition ?? null,
          insertionPosition,
          includeBars: selection?.includeBars === true,
          includeTempi: selection?.includeTempi === true,
          includeRepeats: selection?.includeRepeats === true,
          snapshotCountBefore,
          selectedSnapshotId,
          workspaceTab,
        },
      });
      const result = moveSnapshotRangeInWorkspace({
        snapshots: snapshotsRef.current,
        bars: sequenceBarsRef.current,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        startPosition: selection?.startPosition,
        endPosition: selection?.endPosition,
        insertionPosition,
        includeBars: selection?.includeBars === true,
        includeTempi: selection?.includeTempi === true,
        includeRepeats: selection?.includeRepeats === true,
        selectedSnapshotId,
        selectedSnapshotMarker,
        nextSnapshotId: snapshotIdRef.current + 1,
        nextBarId: sequenceBarIdRef.current,
      });
      if (result.error) return result.error;
      if (!result.changed) return result;
      snapshotsRef.current = result.snapshots;
      sequenceBarsRef.current = result.bars;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: result.bars,
        tempi: result.tempi,
        repeats: result.repeats,
      });
      setSnapshots(result.snapshots);
      setSequenceBars(result.bars);
      setSequenceTempi(result.tempi);
      setSequenceRepeats(result.repeats);
      setSelectedSnapshotId(result.selectedSnapshotId);
      setSelectedSnapshotMarker(result.selectedSnapshotMarker);
      applySequenceWorkspaceMutationFocus(result);
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-move-applied",
        detail: "Applied move of snapshot range",
        context: {
          source: "sequencer",
          startPosition: result.range?.startPosition ?? null,
          endPosition: result.range?.endPosition ?? null,
          insertionPosition: result.insertionPosition ?? null,
          includeBars: selection?.includeBars === true,
          includeTempi: selection?.includeTempi === true,
          includeRepeats: selection?.includeRepeats === true,
          snapshotCountBefore,
          snapshotCountAfter: result.snapshots.length,
          selectedSnapshotId: result.selectedSnapshotId,
          workspaceTab,
        },
      });
      return result;
    },
    [
      applySequenceWorkspaceMutationFocus,
      persistSequenceWorkspace,
      selectedSnapshotId,
      selectedSnapshotMarker,
      sequenceRepeats,
      sequenceTempi,
      workspaceTab,
    ],
  );

  const onResetSnapshotRangeNoteOffsetsInPlace = useCallback(
    (selection) => {
      const snapshotCountBefore = snapshotsRef.current.length;
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-reset-requested",
        detail: "Requested in-place reset of note offsets for snapshot range",
        context: {
          source: "sequencer",
          startPosition: selection?.startPosition ?? null,
          endPosition: selection?.endPosition ?? null,
          includeBars: selection?.includeBars === true,
          snapshotCountBefore: snapshotsRef.current.length,
          selectedSnapshotId,
          workspaceTab,
        },
      });
      const result = resetSnapshotRangeNoteOffsetsInWorkspace({
        snapshots: snapshotsRef.current,
        bars: sequenceBarsRef.current,
        startPosition: selection?.startPosition,
        endPosition: selection?.endPosition,
        includeBars: selection?.includeBars === true,
      });
      if (result.error) {
        appendPersistedSequencerCrashDiagnostic({
          type: "snapshot-range-reset-failed",
          detail: "Failed to reset note offsets for snapshot range",
          context: {
            source: "sequencer",
            startPosition: selection?.startPosition ?? null,
            endPosition: selection?.endPosition ?? null,
            includeBars: selection?.includeBars === true,
            snapshotCountBefore: snapshotsRef.current.length,
            selectedSnapshotId,
            workspaceTab,
          },
        });
        return result.error;
      }
      snapshotsRef.current = result.snapshots;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: sequenceBarsRef.current,
      });
      setSnapshots(result.snapshots);
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-reset-applied",
        detail: "Applied in-place reset of note offsets for snapshot range",
        context: {
          source: "sequencer",
          startPosition: result.range?.startPosition ?? null,
          endPosition: result.range?.endPosition ?? null,
          includeBars: result.range?.includeBars === true,
          snapshotCountBefore,
          snapshotCountAfter: result.snapshots.length,
          selectedSnapshotId,
          workspaceTab,
        },
      });
      return result;
    },
    [persistSequenceWorkspace, selectedSnapshotId, workspaceTab],
  );

  const onSetSnapshotRangeArticulation = useCallback(
    (selection, articulation) => {
      const result = setSnapshotRangeArticulationInWorkspace({
        snapshots: snapshotsRef.current,
        bars: sequenceBarsRef.current,
        startPosition: selection?.startPosition,
        endPosition: selection?.endPosition,
        includeBars: selection?.includeBars === true,
        articulation,
      });
      if (result.error) return result.error;
      snapshotsRef.current = result.snapshots;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: sequenceBarsRef.current,
      });
      setSnapshots(result.snapshots);
      return result;
    },
    [persistSequenceWorkspace],
  );

  const onRestoreSnapshotRangeChanges = useCallback(
    (replacements) => {
      const result = restoreSnapshotsInWorkspace({
        snapshots: snapshotsRef.current,
        replacements,
      });
      if (result.error) return result.error;
      snapshotsRef.current = result.snapshots;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: sequenceBarsRef.current,
      });
      setSnapshots(result.snapshots);
      return result;
    },
    [persistSequenceWorkspace],
  );

  const onDeleteSnapshotRange = useCallback(
    (selection) => {
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-delete-requested",
        detail: "Requested deletion of snapshot range",
        context: {
          source: "sequencer",
          startPosition: selection?.startPosition ?? null,
          endPosition: selection?.endPosition ?? null,
          includeBars: selection?.includeBars === true,
          includeTempi: selection?.includeTempi === true,
          includeRepeats: selection?.includeRepeats === true,
          snapshotCountBefore: snapshotsRef.current.length,
          selectedSnapshotId,
          workspaceTab,
        },
      });
      const result = deleteSnapshotRangeFromWorkspace({
        snapshots: snapshotsRef.current,
        bars: sequenceBarsRef.current,
        tempi: sequenceTempi,
        repeats: sequenceRepeats,
        startPosition: selection?.startPosition,
        endPosition: selection?.endPosition,
        includeBars: selection?.includeBars === true,
        includeTempi: selection?.includeTempi === true,
        includeRepeats: selection?.includeRepeats === true,
        selectedSnapshotId,
        selectedSnapshotMarker,
      });
      if (result.error) {
        appendPersistedSequencerCrashDiagnostic({
          type: "snapshot-range-delete-failed",
          detail: "Failed to delete snapshot range",
          context: {
            source: "sequencer",
            startPosition: selection?.startPosition ?? null,
            endPosition: selection?.endPosition ?? null,
            includeBars: selection?.includeBars === true,
            includeTempi: selection?.includeTempi === true,
            includeRepeats: selection?.includeRepeats === true,
            snapshotCountBefore: snapshotsRef.current.length,
            selectedSnapshotId,
            workspaceTab,
          },
        });
        return result.error;
      }
      const snapshotCountBefore = snapshotsRef.current.length;
      snapshotsRef.current = result.snapshots;
      sequenceBarsRef.current = result.bars;
      persistSequenceWorkspace({
        snapshots: result.snapshots,
        bars: result.bars,
        tempi: result.tempi,
        repeats: result.repeats,
      });
      setSnapshots(result.snapshots);
      setSequenceBars(result.bars);
      setSequenceTempi(result.tempi);
      setSequenceRepeats(result.repeats);
      setSelectedSnapshotId(result.selectedSnapshotId);
      setSelectedSnapshotMarker(result.selectedSnapshotMarker);
      applySequenceWorkspaceMutationFocus(result);
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-range-delete-applied",
        detail: "Applied deletion of snapshot range",
        context: {
          source: "sequencer",
          startPosition: result.range?.startPosition ?? null,
          endPosition: result.range?.endPosition ?? null,
          includeBars: selection?.includeBars === true,
          includeTempi: selection?.includeTempi === true,
          includeRepeats: selection?.includeRepeats === true,
          snapshotCountBefore,
          snapshotCountAfter: result.snapshots.length,
          selectedSnapshotId: result.selectedSnapshotId,
          workspaceTab,
        },
      });
      return result;
    },
    [
      applySequenceWorkspaceMutationFocus,
      persistSequenceWorkspace,
      selectedSnapshotId,
      selectedSnapshotMarker,
      sequenceRepeats,
      sequenceTempi,
      workspaceTab,
    ],
  );

  const pendingEditedSnapshotReplayRef = useRef(null);
  useEffect(() => {
    const pending = pendingEditedSnapshotReplayRef.current;
    pendingEditedSnapshotReplayRef.current = null;
    if (pending == null) return;
    const position = sequencePlayheadRef.current;
    if (position.stopped || position.markerIndex !== pending.markerIndex ||
        position.stepIndex !== pending.stepIndex ||
        Number.isFinite(timedPlaybackUiRef.current.clockSeconds) ||
        (position.markerIndex == null && snapshots[position.stepIndex]?.id !== pending.id)) return;
    if (position.markerIndex != null) {
      const pitches = sequencePlaybackNotesAtPosition(position.stepIndex, position.markerIndex)
        .map(note => note.midicents).sort((a, b) => a - b);
      if (JSON.stringify(pitches) === pending.cuePitches) return;
    }
    // Wait for the edited notes and derived playback callbacks, not the old
    // render's snapshot. This is edit-driven; cursor/scroll updates do no work.
    cancelPendingManualCueUiCommit();
    cancelManualSnapshotGestures();
    if (position.markerIndex != null) {
      playSequencePosition(position.stepIndex, position.markerIndex, { hardRestart: true });
    } else {
      playManualSnapshotAtIndex(position.stepIndex);
    }
  }, [snapshots, cancelPendingManualCueUiCommit, cancelManualSnapshotGestures,
    playManualSnapshotAtIndex, playSequencePosition, sequencePlaybackNotesAtPosition]);

  const onUpdateSnapshot = useCallback(
    (id, updates) => {
      const diagnosticContext = getActiveSequencerDiagnosticTransaction() ?? {};
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-update-requested",
        detail: "Requested snapshot workspace update",
        context: {
          source: "sequencer",
          transactionId: diagnosticContext.transactionId,
          commitKind: diagnosticContext.commitKind,
          snapshotId: id,
          selectedSnapshotId,
          snapshotCountBefore: snapshotsRef.current.length,
          updateKeys: Object.keys(updates ?? {}),
          noteCountBefore:
            snapshotsRef.current.find((snapshot) => snapshot.id === id)?.notes?.length ?? null,
          noteCountAfter: Array.isArray(updates?.notes) ? updates.notes.length : null,
          workspaceTab,
        },
      });
      const nextSnapshots = updateSnapshotInWorkspace({
        snapshots: snapshotsRef.current,
        snapshotId: id,
        updates,
        snapshotLabelMode,
      });
      const before = snapshotsRef.current.find(snapshot => snapshot.id === id);
      const after = nextSnapshots.find(snapshot => snapshot.id === id);
      const pitches = snapshot => JSON.stringify(
        (snapshot?.notes ?? []).map(note => note.midicents).sort((a, b) => a - b),
      );
      const position = sequencePlayheadRef.current;
      if (updates.notes && before?.notes?.length === after?.notes?.length &&
          pitches(before) !== pitches(after) && !position.stopped &&
          !Number.isFinite(timedPlaybackUiRef.current.clockSeconds) &&
          (position.markerIndex != null || snapshotsRef.current[position.stepIndex]?.id === id)) {
        pendingEditedSnapshotReplayRef.current = {
          id, stepIndex: position.stepIndex, markerIndex: position.markerIndex,
          cuePitches: JSON.stringify(sequencePlaybackNotesAtPosition(
            position.stepIndex, position.markerIndex,
          ).map(note => note.midicents).sort((a, b) => a - b)),
        };
      }
      appendPersistedSequencerCrashDiagnostic({
        type: "snapshot-update-applied",
        detail: "Applied snapshot workspace update",
        context: {
          source: "sequencer",
          transactionId: diagnosticContext.transactionId,
          commitKind: diagnosticContext.commitKind,
          snapshotId: id,
          selectedSnapshotId,
          snapshotCountBefore: snapshotsRef.current.length,
          snapshotCountAfter: nextSnapshots.length,
          updateKeys: Object.keys(updates ?? {}),
          noteCountBefore:
            snapshotsRef.current.find((snapshot) => snapshot.id === id)?.notes?.length ?? null,
          noteCountAfter:
            nextSnapshots.find((snapshot) => snapshot.id === id)?.notes?.length ?? null,
          workspaceTab,
        },
      });
      snapshotsRef.current = nextSnapshots;
      persistSequenceWorkspace({
        snapshots: nextSnapshots,
      });
      setSnapshots(nextSnapshots);
    },
    [persistSequenceWorkspace, selectedSnapshotId, snapshotLabelMode, workspaceTab,
      sequencePlaybackNotesAtPosition],
  );

  const onResetSnapshotDescription = useCallback(
    (id) => {
      const nextSnapshots = resetSnapshotDescriptionInWorkspace({
        snapshots: snapshotsRef.current,
        snapshotId: id,
        snapshotLabelMode,
      });
      snapshotsRef.current = nextSnapshots;
      persistSequenceWorkspace({ snapshots: nextSnapshots });
      setSnapshots(nextSnapshots);
    },
    [persistSequenceWorkspace, snapshotLabelMode],
  );

  useEffect(() => {
    setSequencePlayhead((prev) => {
      if (snapshots.length === 0) {
        return prev.stepIndex === -1 && prev.markerIndex == null && prev.stopped
          ? prev
          : { ...prev, stepIndex: -1, markerIndex: null, stopped: true };
      }
      const previousStep = Number.isFinite(prev.stepIndex) ? prev.stepIndex : -1;
      if (previousStep < 0) {
        return prev.markerIndex == null ? prev : { ...prev, markerIndex: null };
      }
      if (previousStep >= snapshots.length) {
        const markerIndex =
          prev.markerIndex == null || sequenceCueGroups.length === 0
            ? null
            : Math.max(0, Math.min(sequenceCueGroups.length - 1, prev.markerIndex));
        return prev.stepIndex === snapshots.length && markerIndex === prev.markerIndex
          ? prev
          : { ...prev, stepIndex: snapshots.length, markerIndex };
      }
      const stepIndex = Math.max(0, Math.min(snapshots.length - 1, previousStep));
      const markerIndex =
        prev.markerIndex == null || sequenceCueGroups.length === 0
          ? null
          : Math.max(0, Math.min(sequenceCueGroups.length - 1, prev.markerIndex));
      return stepIndex === prev.stepIndex && markerIndex === prev.markerIndex
        ? prev
        : { ...prev, stepIndex, markerIndex };
    });
  }, [sequenceCueGroups, snapshots]);

  const panicPlayback = useCallback(() => {
    // Cancel schedulers and deferred UI commits before silencing engines so
    // neither a queued cue nor its presentation can revive after PANIC.
    cancelPendingManualCueUiCommit();
    cancelManualSnapshotGestures();
    if (timedTransportStopRef.current) {
      timedTransportStopRef.current({ restoreStartTarget: false });
    } else {
      onStopSnapshot();
    }
    presentSnapshotPalette(snapshotPaletteBodyRef.current, null);
    guardianPanic();
    keysRef.current?.panic();
    resetOctave();
  }, [guardianPanic, onStopSnapshot, resetOctave, cancelManualSnapshotGestures, cancelPendingManualCueUiCommit]);

  const suppressTouchClickUntilRef = useRef(0);
  const runTouchControlAction = useCallback((e, action) => {
    if (e.pointerType !== "touch") return false;
    e.preventDefault();
    e.stopPropagation();
    suppressTouchClickUntilRef.current = Date.now() + 700;
    action();
    return true;
  }, []);
  const skipSuppressedTouchClick = useCallback((e) => {
    if (Date.now() > suppressTouchClickUntilRef.current) return false;
    suppressTouchClickUntilRef.current = 0;
    e.preventDefault();
    e.stopPropagation();
    return true;
  }, []);
  const refreshKeyboardAndAudio = useCallback(async () => {
    if (keysRef.current) {
      keysRef.current.resizeHandler();
      keysRef.current.scheduleImmediateGridRedraw();
    }
    if (pendingRestoredPreset) {
      await activatePendingPreset();
      if (keysRef.current) keysRef.current.scheduleImmediateGridRedraw();
      return;
    }
    if (!userHasInteracted) {
      await primeAudioFromUserInteraction();
      if (keysRef.current) keysRef.current.scheduleImmediateGridRedraw();
      return;
    }
    // Explicit iOS refresh is the escape hatch for a context which reports
    // running but produces no audio. Do not await normal resume first: that
    // promise itself can stall after a lock-screen interruption.
    await restoreBuiltInAudio();
    audioNeedsHardRefreshRef.current = false;
    if (keysRef.current) keysRef.current.scheduleImmediateGridRedraw();
  }, [
    activatePendingPreset,
    pendingRestoredPreset,
    primeAudioFromUserInteraction,
    userHasInteracted,
    restoreBuiltInAudio,
  ]);

  const clampModulationPalettePos = useCallback((position) => {
    if (typeof window === "undefined") return position;
    const paletteEl = modulationPaletteRef.current;
    const rect = paletteEl?.getBoundingClientRect();
    const viewport = window.visualViewport;
    const viewportWidth = viewport?.width ?? window.innerWidth;
    const viewportHeight = viewport?.height ?? window.innerHeight;
    const width = rect?.width ?? 260;
    const headerHeight =
      paletteEl?.querySelector(".modulation-palette-header")?.getBoundingClientRect().height ?? 34;
    const minVisibleWidth = Math.min(120, Math.max(80, width * 0.45));
    const minX = Math.round(8 - width + minVisibleWidth);
    const maxX = Math.round(viewportWidth - minVisibleWidth - 8);
    const minY = 8;
    const maxY = Math.round(viewportHeight - headerHeight - 8);
    return {
      x: Math.min(Math.max(position.x, minX), Math.max(minX, maxX)),
      y: Math.min(Math.max(position.y, minY), Math.max(minY, maxY)),
    };
  }, []);

  const clampSnapshotPalettePos = useCallback((position) => {
    if (typeof window === "undefined") return position;
    const paletteEl = snapshotPaletteRef.current;
    const rect = paletteEl?.getBoundingClientRect();
    const viewport = window.visualViewport;
    const viewportWidth = viewport?.width ?? window.innerWidth;
    const viewportHeight = viewport?.height ?? window.innerHeight;
    const width = rect?.width ?? 220;
    const headerHeight =
      paletteEl?.querySelector(".snapshot-palette-header")?.getBoundingClientRect().height ?? 34;
    const minVisibleWidth = Math.min(120, Math.max(84, width * 0.5));
    const minX = Math.round(8 - width + minVisibleWidth);
    const maxX = Math.round(viewportWidth - minVisibleWidth - 8);
    const minY = 8;
    const maxY = Math.round(viewportHeight - headerHeight - 8);
    return {
      x: Math.min(Math.max(position.x, minX), Math.max(minX, maxX)),
      y: Math.min(Math.max(position.y, minY), Math.max(minY, maxY)),
    };
  }, []);

  useEffect(() => {
    const onPointerMove = (e) => {
      if (!modulationPaletteDragRef.current) return;
      const { pointerId, offsetX, offsetY } = modulationPaletteDragRef.current;
      if (e.pointerId !== pointerId) return;
      modulationPaletteUserMovedRef.current = true;
      setModulationPalettePos(
        clampModulationPalettePos({
          x: Math.max(8, e.clientX - offsetX),
          y: Math.max(8, e.clientY - offsetY),
        }),
      );
    };
    const onPointerUp = (e) => {
      if (!modulationPaletteDragRef.current) return;
      if (e.pointerId !== modulationPaletteDragRef.current.pointerId) return;
      modulationPaletteDragRef.current = null;
    };
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
    };
  }, [clampModulationPalettePos]);

  useEffect(() => {
    const onPointerMove = (e) => {
      if (!snapshotPaletteDragRef.current) return;
      const { pointerId, offsetX, offsetY } = snapshotPaletteDragRef.current;
      if (e.pointerId !== pointerId) return;
      snapshotPaletteUserMovedRef.current = true;
      setSnapshotPalettePos(
        clampSnapshotPalettePos({
          x: Math.max(8, e.clientX - offsetX),
          y: Math.max(8, e.clientY - offsetY),
        }),
      );
    };
    const onPointerUp = (e) => {
      if (!snapshotPaletteDragRef.current) return;
      if (e.pointerId !== snapshotPaletteDragRef.current.pointerId) return;
      snapshotPaletteDragRef.current = null;
    };
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
    };
  }, [clampSnapshotPalettePos]);

  useEffect(() => {
    if (!performancePalettesVisible) return undefined;
    const applyDefaultPosition = () => {
      if (!modulationPaletteUserMovedRef.current) {
        setModulationPalettePos(clampModulationPalettePos(getDefaultModulationPalettePos()));
        return;
      }
      setModulationPalettePos((current) => clampModulationPalettePos(current));
    };
    let frameId = null;
    const applyAfterLayout = () => {
      if (frameId != null) window.cancelAnimationFrame(frameId);
      frameId = window.requestAnimationFrame(() => {
        frameId = null;
        applyDefaultPosition();
      });
    };
    window.addEventListener("resize", applyAfterLayout);
    window.addEventListener("orientationchange", applyAfterLayout);
    window.visualViewport?.addEventListener("resize", applyAfterLayout);
    applyAfterLayout();
    return () => {
      if (frameId != null) window.cancelAnimationFrame(frameId);
      window.removeEventListener("resize", applyAfterLayout);
      window.removeEventListener("orientationchange", applyAfterLayout);
      window.visualViewport?.removeEventListener("resize", applyAfterLayout);
    };
  }, [clampModulationPalettePos, performancePalettesVisible]);

  useEffect(() => {
    if (!snapshotPaletteVisible || snapshots.length === 0) return undefined;
    const applyDefaultPosition = () => {
      if (!snapshotPaletteUserMovedRef.current) {
        setSnapshotPalettePos(clampSnapshotPalettePos(getDefaultSnapshotPalettePos()));
        return;
      }
      setSnapshotPalettePos((current) => clampSnapshotPalettePos(current));
    };
    let firstFrameId = null;
    let settledFrameId = null;
    const applyAfterLayout = () => {
      if (firstFrameId != null) window.cancelAnimationFrame(firstFrameId);
      if (settledFrameId != null) window.cancelAnimationFrame(settledFrameId);
      firstFrameId = window.requestAnimationFrame(() => {
        firstFrameId = null;
        settledFrameId = window.requestAnimationFrame(() => {
          settledFrameId = null;
          applyDefaultPosition();
        });
      });
    };
    window.addEventListener("resize", applyAfterLayout);
    window.addEventListener("orientationchange", applyAfterLayout);
    window.visualViewport?.addEventListener("resize", applyAfterLayout);
    // The snapshot palette's default position is stacked below Modulation
    // History. When both palettes remount after visiting SEQUENCER, wait for
    // the modulation palette's real content height (including loaded fonts)
    // instead of retaining geometry measured while that DOM was absent.
    const modulationResizeObserver =
      typeof ResizeObserver === "function" ? new ResizeObserver(applyAfterLayout) : null;
    if (modulationPaletteRef.current) {
      modulationResizeObserver?.observe(modulationPaletteRef.current);
    }
    applyAfterLayout();
    return () => {
      if (firstFrameId != null) window.cancelAnimationFrame(firstFrameId);
      if (settledFrameId != null) window.cancelAnimationFrame(settledFrameId);
      modulationResizeObserver?.disconnect();
      window.removeEventListener("resize", applyAfterLayout);
      window.removeEventListener("orientationchange", applyAfterLayout);
      window.visualViewport?.removeEventListener("resize", applyAfterLayout);
    };
  }, [
    clampSnapshotPalettePos,
    modulationPaletteCollapsed,
    modulationState?.history?.length,
    snapshotPaletteVisible,
    snapshots.length,
  ]);

  // Long-press sidebar button to toggle latch (sustain while playing)
  const longPressTimer = useRef(null);
  const longPressFired = useRef(false);

  const onSidebarTouchStart = useCallback(
    (_e) => {
      primeAudioFromUserInteraction();
      longPressFired.current = false;
      longPressTimer.current = setTimeout(() => {
        longPressFired.current = true;
        if (keysRef.current) keysRef.current.latchToggle();
      }, 400);
    },
    [primeAudioFromUserInteraction],
  );

  const onSidebarTouchEnd = useCallback((e) => {
    clearTimeout(longPressTimer.current);
    if (longPressFired.current) {
      e.preventDefault();
    }
  }, []);

  const onSidebarTouchMove = useCallback(() => {
    clearTimeout(longPressTimer.current);
  }, []);

  useEffect(() => {
    if (!keysRef.current || textEntryActive || viewportKeyboardOpen) return undefined;
    const timer = setTimeout(() => {
      keysRef.current?.resizeHandler?.();
      keysRef.current?.scheduleImmediateGridRedraw?.();
    }, 320);
    return () => {
      clearTimeout(timer);
    };
  }, [active, workspaceTab, textEntryActive, viewportKeyboardOpen]);

  useEffect(() => {
    // Enable the app — triggers synth creation and makes the keyboard visible.
    setReady(true);
  }, []);

  const { onChange, onAtomicChange } = useSettingsChange(settings, setSettings, {
    midi,
    setMidiLearnActive,
    setHakenPedalLearnActive,
    keysRef,
    setLatch,
    bumpImportCount,
    onUserScaleEdit,
  });

  // Validate that all required settings are present and consistent.
  // This prevents Keys from being constructed with invalid state that would crash.
  const isValid = useMemo(() => {
    // Layout validation: hexSize must be >= 20, rotation must be a number
    const hasLayout =
      settings.rSteps &&
      settings.drSteps &&
      settings.hexSize &&
      settings.hexSize >= 20 &&
      typeof settings.rotation === "number";

    // Scale validation: must have a scale array with at least one element
    const hasScale =
      settings.scale &&
      Array.isArray(settings.scale) &&
      settings.scale.length > 0 &&
      settings.equivSteps;

    // Label validation: check requirements based on selected key_labels type.
    // Each label type has different data requirements:
    // - 'no_labels', 'enumerate', 'cents': need only scale
    // - 'scala_names': needs scale (to generate scala_names)
    // - 'note_names': needs note_names array with elements
    const labelType = settings.key_labels;
    const labelsValid =
      !labelType ||
      labelType === "no_labels" ||
      labelType === "enumerate" ||
      labelType === "cents" ||
      (labelType === "scala_names" && hasScale) ||
      (labelType === "note_names" &&
        settings.note_names &&
        Array.isArray(settings.note_names) &&
        settings.note_names.length > 0) ||
      (labelType === "heji" && hasScale);

    const normalizedColors = normalizeColors(settings);
    // Color validation: spectrum mode uses the central hue directly; when
    // spectrum is off, missing note_colors are auto-derived from that same hue.
    const colorsValid =
      !!normalizedColors.fundamental_color &&
      Array.isArray(normalizedColors.note_colors) &&
      normalizedColors.note_colors.length > 0;

    return hasLayout && hasScale && labelsValid && colorsValid;
  }, [settings]);

  // Tuning/runtime derivation for the live Hexatone surface.
  const tuningImpactKey = useMemo(() => settingsImpactKey(settings, "tuning"), [settings]);
  const structuralImpactKey = useMemo(() => settingsImpactKey(settings, "structural"), [settings]);
  const keysReconstructionImpactKey = useMemo(
    () =>
      settingsImpactKey(settings, "keysReconstruction", {
        midiAccess,
        midiTick,
        presetRuntimeResetRevision,
      }),
    [settings, midiAccess, midiTick, presetRuntimeResetRevision],
  );
  const musicalSurfaceResetImpactKey = useMemo(
    () => settingsImpactKey(settings, "musicalSurfaceReset", { presetRuntimeResetRevision }),
    [settings, presetRuntimeResetRevision],
  );
  const colorImpactKey = useMemo(() => settingsImpactKey(settings, "colors"), [settings]);
  const inputRuntimeImpactKey = useMemo(
    () => settingsImpactKey(settings, "inputRuntime"),
    [settings],
  );
  const outputRuntimeImpactKey = useMemo(
    () => settingsImpactKey(settings, "outputRuntime"),
    [settings],
  );
  const tuningWorkspace = useMemo(
    () =>
      settings.scale && Array.isArray(settings.scale) && settings.scale.length > 0
        ? createScaleWorkspace({
            scale: settings.scale,
            reference_degree: settings.reference_degree,
            fundamental: settings.fundamental,
          })
        : null,
    // eslint-disable-next-line react-hooks/exhaustive-deps -- tuningImpactKey is the settings-impact registry key; unrelated settings must not rebuild the tuning workspace.
    [tuningImpactKey],
  );
  const tuningRuntime = useMemo(
    () => (tuningWorkspace ? normalizeWorkspaceForKeys(tuningWorkspace) : null),
    [tuningWorkspace],
  );
  const modulationDegreeLabel = useCallback(
    (degree) => {
      if (degree == null) return "";
      const slot = tuningWorkspace?.lookup?.byDegree?.get(degree);
      return slot?.sourceText || slot?.exactRole?.ratioText || String(degree);
    },
    [tuningWorkspace],
  );
  const modulationSummary = useMemo(() => {
    return deriveModulationSummaryText(modulationState, modulationDegreeLabel, tuningWorkspace);
  }, [modulationDegreeLabel, modulationState, tuningWorkspace]);
  const {
    modulationHistory,
    deferredModulationHistory,
    activeDeferredModulationKey,
    hasActiveDeferredModulation,
  } = useDeferredModulationHistory(modulationState, keysRef);
  const activeModulationLibrary = useMemo(
    () => modulationState?.history ?? presetModulationLibrary,
    [modulationState, presetModulationLibrary],
  );
  const hasCommittableModulation = useMemo(
    () => hasActiveModulationHistory(activeModulationLibrary),
    [activeModulationLibrary],
  );
  const modulationPaletteVisible = modulationHistory.length > 0;
  const currentFundamentalSummary = useMemo(() => {
    return deriveCurrentFundamentalSummary(tuningWorkspace, deferredModulationHistory, {
      fundamental: settings.fundamental,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deferredModulationHistory is intentionally represented by deferredModulationHistoryKey so palette clicks do not synchronously re-render modulation-dependent table displays.
  }, [tuningWorkspace, activeDeferredModulationKey, settings.fundamental]);
  const modulationPaletteTitle = useMemo(() => {
    return deriveModulationPaletteTitles(modulationHistory, modulationDegreeLabel, tuningWorkspace);
  }, [modulationDegreeLabel, modulationHistory, tuningWorkspace]);
  const onStepModulationRoute = useCallback((routeIndex, delta) => {
    if (!keysRef.current?.stepModulationRoute) return;
    keysRef.current.stepModulationRoute(routeIndex, delta);
  }, []);
  const onClearModulationRoute = useCallback((routeIndex) => {
    if (!keysRef.current?.clearModulationRoute) return;
    keysRef.current.clearModulationRoute(routeIndex);
  }, []);
  const onResetModulationRoutes = useCallback(() => {
    if (!keysRef.current?.resetModulationRouteCounts) return;
    keysRef.current.resetModulationRouteCounts();
  }, []);
  // Input runtime: derived from settings, passed to Keys as the authoritative
  // source of truth for all input mode decisions. Keys reads from inputRuntime
  // rather than from settings directly for any input-related branch.
  const connectedInput =
    midi && settings.midiin_device && settings.midiin_device !== "OFF"
      ? (midi.inputs.get(settings.midiin_device) ??
        Array.from(midi.inputs.values()).find((input) => input.id === settings.midiin_device) ??
        null)
      : null;
  const inputController = useMemo(() => {
    const overrideId = settings.midiin_controller_override || "auto";
    if (overrideId !== "auto") return getControllerById(overrideId);
    return connectedInput?.name ? detectController(connectedInput.name.toLowerCase()) : null;
  }, [connectedInput, settings.midiin_controller_override]);
  const effectiveMpeInput =
    controllerRequiresMpeInput(inputController) ||
    (getControllerMpeInputPolicy(inputController) !== "never" && !!settings.midiin_mpe_input);
  const linnstrumentUserFirmwareEligible =
    inputController?.id === "linnstrument" &&
    (settings.midiin_mapping_target || "hex_layout") !== "scale" &&
    !settings.midi_passthrough &&
    !!settings.midiin_device &&
    settings.midiin_device !== "OFF";
  const linnstrumentBypassNonMpe =
    inputController?.id === "linnstrument" &&
    (settings.midiin_mapping_target || "hex_layout") !== "scale" &&
    !!settings.midi_passthrough &&
    !effectiveMpeInput &&
    !!settings.midiin_device &&
    settings.midiin_device !== "OFF";
  const linnstrumentBypassChannelPerRow =
    linnstrumentBypassNonMpe && settings.linnstrument_channel_allocation === "channel_per_row";
  const linnstrumentBypassSingleChannel =
    linnstrumentBypassNonMpe &&
    (settings.linnstrument_channel_allocation || "single_channel") === "single_channel";
  const forceScaleTarget =
    inputController?.id === "tonalplexus" && settings.tonalplexus_input_mode === "layout_205";
  const inputTarget = forceScaleTarget ? "scale" : settings.midiin_mapping_target || "hex_layout";
  const lumatoneSequentialInput = inputController?.id === "lumatone" && settings.midi_passthrough;
  const inputNormalizationSettings = useMemo(
    () => ({
      tonalplexus_input_mode: settings.tonalplexus_input_mode,
      equivSteps: settings.equivSteps,
      scale: settings.scale,
      equivInterval: settings.equivInterval,
      center_degree: settings.center_degree,
    }),
    [
      settings.tonalplexus_input_mode,
      settings.equivSteps,
      settings.scale,
      settings.equivInterval,
      settings.center_degree,
    ],
  );
  const normalizedSeqAnchor = useMemo(
    () =>
      inputController?.normalizeInput?.(
        settings.midiin_anchor_channel ?? 1,
        settings.midiin_anchor_note ?? 60,
        inputNormalizationSettings,
      ) ?? {
        channel: settings.midiin_anchor_channel ?? 1,
        note: settings.midiin_anchor_note ?? 60,
      },
    [
      inputController,
      settings.midiin_anchor_channel,
      settings.midiin_anchor_note,
      inputNormalizationSettings,
    ],
  );

  const inputRuntime = useMemo(
    () => ({
      target: inputTarget,
      layoutMode:
        inputController?.id === "hakenaudio"
          ? "controller_geometry"
          : settings.midi_passthrough
            ? "sequential"
            : "controller_geometry",
      mpeInput: effectiveMpeInput,
      seqAnchorNote: normalizedSeqAnchor.note,
      seqAnchorChannel: normalizedSeqAnchor.channel,
      stepsPerChannel: settings.midiin_steps_per_channel,
      stepsPerChannelDefault: settings.equivSteps,
      channelGroupSize: settings.midiin_channel_group_size ?? 1,
      legacyChannelMode: settings.midiin_channel_legacy,
      scaleTolerance: settings.midiin_scale_tolerance ?? 25,
      scaleFallback: settings.midiin_scale_fallback || "accept",
      pitchBendMode: settings.midiin_pitchbend_mode || "recency",
      pressureMode: settings.midiin_pressure_mode || "recency",
      // Wheel settings kept here for Keys to use alongside routing mode.
      // wheelRange and bendRange both read from midiin_bend_range — the UI
      // unified the old separate "Wheel Range (Scala)" field into Pitch Bend Interval.
      wheelToRecent: linnstrumentBypassNonMpe ? false : settings.wheel_to_recent,
      wheelPortamento: settings.wheel_portamento ?? true,
      wheelPortamentoTime: settings.wheel_portamento_time ?? 60,
      wheelRange: settings.midiin_bend_range ?? "28/27",
      // In sequential/bypass mode, each Lumatone channel is an independent
      // polyphonic input stream in either Hex Layout or nearest-scale mode.
      // Keep bend/pressure/timbre attached to notes from that channel.
      perChannelExpression: linnstrumentBypassChannelPerRow || lumatoneSequentialInput,
      wheelUsesInterval: linnstrumentBypassSingleChannel,
      wheelScaleAware: settings.wheel_scale_aware,
      wheelSemitones: settings.midi_wheel_semitones ?? 2,
      // Pitch bend range for incoming hardware controller bend messages.
      bendRange: settings.midiin_bend_range ?? "28/27",
      bendFlip: !!settings.midiin_bend_flip,
      // Haken Continuum MPE+ uses a 96-semitone pitch-bend range.
      scaleBendRange:
        inputController?.id === "hakenaudio" ? 96 : (settings.midiin_scale_bend_range ?? 48),
      hakenXGlideShaping: settings.hakenaudio_x_glide_shaping ?? 100,
      hakenXGlideMode: settings.hakenaudio_x_glide_mode ?? "pitch_bending",
      hakenPressureVelocity: settings.hakenaudio_pressure_velocity ?? 64,
      hakenNoteOffDelay: settings.hakenaudio_note_off_delay ?? 20,
      hakenRasterThrottleMs: settings.hakenaudio_raster_throttle_ms ?? 10,
      hakenRasterAttackSuppressionMs: settings.hakenaudio_raster_attack_suppression_ms ?? 80,
      hakenRasterStability: settings.hakenaudio_raster_stability ?? 25,
      hakenRasterFilterMode: settings.hakenaudio_raster_filter_mode ?? "all",
      hakenRasterFilter: settings.hakenaudio_raster_filter ?? "",
      hakenApplyRasterInPitchBending: settings.hakenaudio_apply_raster_in_pitch_bending ?? false,
      hakenShapeXGlideToRaster: settings.hakenaudio_shape_x_glide_to_raster ?? false,
    }),
    [
      inputController,
      inputTarget,
      lumatoneSequentialInput,
      normalizedSeqAnchor,
      settings.midi_passthrough,
      effectiveMpeInput,
      settings.midiin_steps_per_channel,
      settings.equivSteps,
      settings.midiin_channel_group_size,
      settings.midiin_channel_legacy,
      settings.midiin_scale_tolerance,
      settings.midiin_scale_fallback,
      settings.midiin_pitchbend_mode,
      settings.midiin_pressure_mode,
      settings.wheel_to_recent,
      settings.wheel_portamento,
      settings.wheel_portamento_time,
      settings.midiin_bend_range,
      linnstrumentBypassChannelPerRow,
      linnstrumentBypassSingleChannel,
      settings.wheel_scale_aware,
      linnstrumentBypassNonMpe,
      settings.midi_wheel_semitones,
      settings.midiin_bend_flip,
      settings.midiin_scale_bend_range,
      settings.hakenaudio_x_glide_shaping,
      settings.hakenaudio_x_glide_mode,
      settings.hakenaudio_pressure_velocity,
      settings.hakenaudio_note_off_delay,
      settings.hakenaudio_raster_throttle_ms,
      settings.hakenaudio_raster_attack_suppression_ms,
      settings.hakenaudio_raster_stability,
      settings.hakenaudio_raster_filter_mode,
      settings.hakenaudio_raster_filter,
      settings.hakenaudio_apply_raster_in_pitch_bending,
      settings.hakenaudio_shape_x_glide_to_raster,
    ],
  );
  const lumatoneAutoSyncEligible =
    inputController?.id === "lumatone" &&
    inputRuntime.target !== "scale" &&
    inputRuntime.layoutMode !== "sequential";

  const liveInputSettings = useMemo(
    () => settingsImpactSnapshot(settings, "inputRuntime"),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- inputRuntimeImpactKey is the settings-impact registry key.
    [inputRuntimeImpactKey],
  );

  // Structural settings: everything except colors. Memoized so Keys is only
  // reconstructed when scale/layout/MIDI changes — not on every color-picker drag.
  const structuralSettings = useMemo(
    () => normalizeStructural(settings, { tuningRuntime }),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- structuralImpactKey is the settings-impact registry key; input/output binding fields are intentionally excluded.
    [structuralImpactKey, tuningRuntime],
  );
  const calculatorSeedKey = useMemo(
    () =>
      buildDependencyToken([
        tuningImpactKey,
        settings.heji_anchor_label,
        settings.heji_anchor_ratio,
        settings.heji_anchor_frequency,
        settings.heji_palette_structure,
        settings.heji_palette_deviation,
        settings.heji_palette_decimals,
        structuralSettings.heji_anchor_label_effective,
        structuralSettings.heji_anchor_ratio_effective,
      ]),
    [
      settings.heji_anchor_frequency,
      settings.heji_anchor_label,
      settings.heji_anchor_ratio,
      settings.heji_palette_decimals,
      settings.heji_palette_deviation,
      settings.heji_palette_structure,
      structuralSettings.heji_anchor_label_effective,
      structuralSettings.heji_anchor_ratio_effective,
      tuningImpactKey,
    ],
  );

  // Output-runtime architecture controls should update the live Keys instance
  // imperatively, not trigger a full keyboard reconstruction. These are
  // distinct from both structural tuning/workspace settings and fine-grained
  // runtime transport controls such as volume, sustain, OCT, or modulation.
  const liveOutputSettings = useMemo(
    () => settingsImpactSnapshot(settings, "outputRuntime"),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- outputRuntimeImpactKey is the settings-impact registry key.
    [outputRuntimeImpactKey],
  );
  const onCommitCurrentModulation = useCallback(() => {
    if (!hasCommittableModulation || !tuningWorkspace) return null;
    if (keysRef.current?.panic) keysRef.current.panic();
    return commitModulationHistoryToPreset(settings, tuningWorkspace, activeModulationLibrary, {
      hejiAnchorLabel: structuralSettings.heji_anchor_label_effective,
      hejiAnchorRatio: structuralSettings.heji_anchor_ratio_effective,
      hejiTemperedOnly: settings.heji_tempered_only === true,
    });
  }, [
    hasCommittableModulation,
    tuningWorkspace,
    settings,
    activeModulationLibrary,
    structuralSettings.heji_anchor_label_effective,
    structuralSettings.heji_anchor_ratio_effective,
  ]);

  // Reset latch/octave only when the musical surface changes. MIDI/WebMIDI
  // rebinding can reconstruct Keys, but should not reset transport state or
  // invalidate cached labels.
  // Using a ref to skip the initial render (no reset on first mount).
  const prevMusicalSurfaceRef = useRef(null);
  useEffect(() => {
    if (
      prevMusicalSurfaceRef.current !== null &&
      prevMusicalSurfaceRef.current !== musicalSurfaceResetImpactKey
    ) {
      setLatch(false);
      setModulationArmed(false);
      setModulationMode("idle");
      setModulationState(
        activeModulationLibrary.length > 0
          ? presetModulationSnapshot(activeModulationLibrary)
          : null,
      );
      if (typeof resetOctave === "function") resetOctave();
    }
    prevMusicalSurfaceRef.current = musicalSurfaceResetImpactKey;
    // eslint-disable-next-line react-hooks/exhaustive-deps -- the registry key is the complete reset boundary; callback identities and preset-library updates must not reset the musical surface.
  }, [musicalSurfaceResetImpactKey]);

  // Tuning changes replace Keys and release its owned voices. Restore a manually
  // held snapshot only after the replacement has been published and rendered,
  // so SNAP resolves against its new tuning, not the retired runtime. Timed
  // transport and ordinary MIDI/output rebinding keep their own lifecycle.
  const snapshotReplayKeys = keysRef.current;
  const previousReadySampleInstrumentRef = useRef(readySampleInstrument);
  useEffect(() => {
    const previous = previousReadySampleInstrumentRef.current;
    previousReadySampleInstrumentRef.current = readySampleInstrument;
    if (!previous || !readySampleInstrument || previous === readySampleInstrument) return;
    const position = sequencePlayheadRef.current;
    if (workspaceTab !== "io" || position.stopped || position.markerIndex != null ||
        Number.isFinite(timedPlaybackUiRef.current.clockSeconds)) return;
    if (!snapshots[position.stepIndex]) return;
    cancelPendingManualCueUiCommit();
    cancelManualSnapshotGestures();
    playManualSnapshotAtIndex(position.stepIndex);
  }, [readySampleInstrument, workspaceTab, snapshots, cancelPendingManualCueUiCommit,
    cancelManualSnapshotGestures, playManualSnapshotAtIndex]);
  const previousSnapshotReplaySurfaceRef = useRef(null);
  useEffect(() => {
    if (!snapshotReplayKeys || snapshotReplayKeys !== keysRef.current) return;
    const previous = previousSnapshotReplaySurfaceRef.current;
    if (previous?.keys === snapshotReplayKeys) return;
    previousSnapshotReplaySurfaceRef.current = {
      keys: snapshotReplayKeys,
      surface: musicalSurfaceResetImpactKey,
    };
    if (!previous || previous.surface === musicalSurfaceResetImpactKey) return;
    // Keyboard now transfers sequencer voices across a tuning reconstruction.
    // Replaying an adopted gesture would release it and schedule fresh attacks
    // while its output graph/reference is still handing over.
    const hasTransferredVoices = [
      ...(snapshotReplayKeys._snapshotHexes ?? []),
      ...(snapshotReplayKeys._soundingSnapshotHexes ?? []),
      ...(snapshotReplayKeys._snapshotVoiceOwners?.keys?.() ?? []),
    ].some(hex => hex && hex.release !== true);
    if (hasTransferredVoices) return;
    const position = sequencePlayheadRef.current;
    if (workspaceTab !== "hexatone" || position.stopped || position.markerIndex != null) return;
    if (!snapshots[position.stepIndex]) return;
    cancelPendingManualCueUiCommit();
    cancelManualSnapshotGestures();
    playManualSnapshotAtIndex(position.stepIndex);
  }, [
    snapshotReplayKeys,
    musicalSurfaceResetImpactKey,
    workspaceTab,
    snapshots,
    cancelPendingManualCueUiCommit,
    cancelManualSnapshotGestures,
    playManualSnapshotAtIndex,
  ]);

  // ── Exquis App Mode lifecycle ─────────────────────────────────────────────
  // Lives here (not in Keyboard) so App Mode is active even before a scale is
  // loaded (Keyboard only mounts when isValid — i.e. a scale is present).
  useEffect(() => {
    const wantAppMode =
      !!exquisRawPorts && inputRuntime?.target !== "scale" && !settings.midi_passthrough;

    if (!wantAppMode) {
      if (exquisLedsRef.current) {
        exquisLedsRef.current.exit();
        exquisLedsRef.current = null;
        if (keysRef.current) keysRef.current.exquisLEDs = null;
      }
      return;
    }

    if (exquisLedsRef.current) return;

    let disposed = false;

    loadExquisLEDs().then(({ ExquisLEDs }) => {
      if (disposed || exquisLedsRef.current) return;
      const leds = new ExquisLEDs(
        exquisRawPorts.output,
        exquisRawPorts.input,
        (ok, reason) => {
          setExquisLedStatus(ok ? { ok: true } : { ok: false, reason });
          if (ok && keysRef.current?.settings?.exquis_led_sync) {
            keysRef.current.syncExquisLEDs();
          }
        },
        settings.exquis_led_luminosity ?? 15,
        settings.exquis_led_saturation ?? 1.3,
        effectiveMpeInput,
        settings.exquis_orientation ?? 90,
      );
      if (disposed) {
        leds.exit();
        return;
      }
      exquisLedsRef.current = leds;
      bindControllerLedRefs(keysRef.current, { exquis: leds });
    });

    return () => {
      disposed = true;
      const leds = exquisLedsRef.current;
      if (leds) leds.exit();
      exquisLedsRef.current = null;
      bindControllerLedRefs(keysRef.current, { exquis: null });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- LED appearance settings update the existing driver; only port/routing changes own its lifecycle.
  }, [exquisRawPorts, inputRuntime?.target, settings.midi_passthrough]);

  useEffect(() => {
    exquisLedsRef.current?.setOrientation(settings.exquis_orientation ?? 90);
  }, [settings.exquis_orientation]);

  // Sync MPE mode to Exquis whenever midiin_mpe_input changes.
  // ExquisLEDs.setMPEMode() defers the send until all pads are released.
  useEffect(() => {
    if (exquisLedsRef.current?.ready) {
      exquisLedsRef.current.setMPEMode(effectiveMpeInput);
    }
  }, [effectiveMpeInput]);

  useEffect(() => {
    if (
      !exquisRawPorts ||
      inputRuntime?.target === "scale" ||
      settings.midi_passthrough ||
      typeof document === "undefined"
    )
      return;

    const recoverExquisAppMode = () => {
      if (document.visibilityState && document.visibilityState !== "visible") return;
      exquisLedsRef.current?.recoverIfHeartbeatStale?.();
    };

    document.addEventListener("visibilitychange", recoverExquisAppMode);
    window.addEventListener("pageshow", recoverExquisAppMode);

    return () => {
      document.removeEventListener("visibilitychange", recoverExquisAppMode);
      window.removeEventListener("pageshow", recoverExquisAppMode);
    };
  }, [exquisRawPorts, inputRuntime?.target, settings.midi_passthrough]);

  // ── Lumatone LED lifecycle ─────────────────────────────────────────────────
  // Mirrors the Exquis pattern: LumatoneLEDs lives here in app.jsx, not inside
  // Keys, so it is constructed as soon as the Lumatone ports are resolved —
  // independently of Keys reconstruction. Keys receives a reference via
  // onKeysReady and lumatoneLedsRef, exactly like exquisLedsRef.
  //
  // Depend on the raw port objects themselves. Sleep/wake and Vite HMR can
  // recreate WebMidi port instances without changing their IDs, so ID-only
  // tracking leaves the ACK/input listeners attached to stale ports.
  const lumatoneInputPort = lumatoneRawPorts?.input ?? null;
  const lumatoneOutputPort = lumatoneRawPorts?.output ?? null;
  const lumatoneInId = lumatoneInputPort?.id ?? null;
  const lumatoneOutId = lumatoneOutputPort?.id ?? null;
  useEffect(() => {
    setLumatoneDriverReady(false);
    if (!lumatoneRawPorts) {
      if (lumatoneLedsRef.current) {
        lumatoneLedsRef.current.destroy();
        lumatoneLedsRef.current = null;
        if (keysRef.current) keysRef.current.lumatoneLEDs = null;
      }
      return;
    }

    let disposed = false;

    loadLumatoneLEDs().then(({ LumatoneLEDs }) => {
      if (disposed) return;
      const leds = new LumatoneLEDs(lumatoneRawPorts.output, lumatoneRawPorts.input);
      if (
        typeof document !== "undefined" &&
        document.visibilityState &&
        document.visibilityState !== "visible"
      ) {
        leds.suspend();
      }
      if (disposed) {
        leds.destroy();
        return;
      }
      lumatoneLedsRef.current = leds;
      // Binding the lazy driver must not itself start a second 280-command
      // transfer; established Keys/settings synchronization owns auto-send.
      bindControllerLedRefs(keysRef.current, { lumatone: leds }, { eagerSync: false });
      setLumatoneDriverReady(true);
    });

    return () => {
      disposed = true;
      const leds = lumatoneLedsRef.current;
      if (leds) leds.destroy();
      lumatoneLedsRef.current = null;
      setLumatoneDriverReady(false);
      bindControllerLedRefs(keysRef.current, { lumatone: null }, { eagerSync: false });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- raw port identity is the lifecycle boundary; colour settings synchronize through Keys without reconstructing the driver.
  }, [lumatoneInputPort, lumatoneOutputPort]);

  useEffect(() => {
    if (
      !lumatoneInputPort ||
      !lumatoneOutputPort ||
      typeof document === "undefined" ||
      typeof window === "undefined"
    ) {
      return undefined;
    }

    const suspendLumatoneColors = () => lumatoneLedsRef.current?.suspend?.();
    const resumeLumatoneColors = () => {
      if (document.visibilityState && document.visibilityState !== "visible") return;
      lumatoneLedsRef.current?.resume?.();
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === "hidden") suspendLumatoneColors();
      else resumeLumatoneColors();
    };

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("pagehide", suspendLumatoneColors);
    window.addEventListener("pageshow", resumeLumatoneColors);

    return () => {
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("pagehide", suspendLumatoneColors);
      window.removeEventListener("pageshow", resumeLumatoneColors);
    };
  }, [lumatoneInputPort, lumatoneOutputPort]);

  // ── LinnStrument 128 lifecycle ────────────────────────────────────────────
  // Mirrors the Lumatone/Exquis pattern.  LinnStrumentLEDs and the initial
  // NRPN config burst live here so they survive Keys reconstruction.
  //
  // Depend on the raw output object so a recreated WebMidi port with the same
  // ID still rebuilds the LED/config driver after sleep/wake or HMR.
  const linnstrumentOutput = linnstrumentRawPorts?.output ?? null;
  useEffect(() => {
    if (!linnstrumentRawPorts) {
      if (linnstrumentLedsRef.current) {
        // Port is already gone (device unplugged) — just drop the reference.
        linnstrumentLedsRef.current.exit();
        linnstrumentLedsRef.current = null;
        if (keysRef.current) keysRef.current.linnstrumentLEDs = null;
      }
      return;
    }

    let disposed = false;
    let detach = null;

    // LED driver attachment lives with the UF module so LinnStrument-specific
    // lifecycle rules stay centralized.
    loadLinnstrumentUserFirmware().then((module) => {
      if (disposed) return;
      const leds = module.attachLinnstrumentLedDriver(linnstrumentRawPorts.output, keysRef.current);
      if (disposed) {
        module.detachLinnstrumentLedDriver(leds, keysRef.current);
        return;
      }
      detach = () => module.detachLinnstrumentLedDriver(leds, keysRef.current);
      linnstrumentLedsRef.current = leds;
      if (linnstrumentUserFirmwareEligible && keysRef.current) {
        leds.userFirmwareActive = true;
      }
      bindControllerLedRefs(keysRef.current, { linnstrument: leds });
    });

    return () => {
      disposed = true;
      linnstrumentLedsRef.current = null;
      bindControllerLedRefs(keysRef.current, { linnstrument: null });
      if (detach) detach();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- raw output identity and firmware eligibility own attachment; LED appearance updates are imperative.
  }, [linnstrumentOutput, linnstrumentUserFirmwareEligible]);

  useEffect(() => {
    const output = linnstrumentOutput;
    if (!output) return;

    let activatedKeys = null;
    let deactivate = null;
    let disposed = false;
    if (!linnstrumentUserFirmwareEligible) {
      loadLinnstrumentUserFirmware().then((module) => {
        if (disposed) return;
        module.deactivateLinnstrumentUserFirmware(output, keysRef.current ?? null);
      });
      return;
    }

    const id = setTimeout(() => {
      loadLinnstrumentUserFirmware().then((module) => {
        if (disposed) return;
        activatedKeys = keysRef.current ?? null;
        deactivate = module.deactivateLinnstrumentUserFirmware;
        module.activateLinnstrumentUserFirmware(output, activatedKeys);
      });
    }, 50);

    return () => {
      disposed = true;
      clearTimeout(id);
      if (deactivate) {
        deactivate(output, activatedKeys ?? keysRef.current ?? null);
      }
    };
  }, [linnstrumentOutput, linnstrumentUserFirmwareEligible]);

  useEffect(() => {
    const output = linnstrumentOutput;
    if (!output || !linnstrumentUserFirmwareEligible || typeof window === "undefined") return;

    const deactivateOnUnload = () => {
      loadLinnstrumentUserFirmware().then((module) => {
        module.deactivateLinnstrumentUserFirmware(output, keysRef.current ?? null);
      });
    };

    window.addEventListener("pagehide", deactivateOnUnload);
    window.addEventListener("beforeunload", deactivateOnUnload);

    return () => {
      window.removeEventListener("pagehide", deactivateOnUnload);
      window.removeEventListener("beforeunload", deactivateOnUnload);
    };
  }, [linnstrumentOutput, linnstrumentUserFirmwareEligible]);

  useEffect(() => {
    if (!linnstrumentUserFirmwareEligible || !settings.linnstrument_led_sync) return;
    const keys = keysRef.current;
    if (!keys?.syncLinnstrumentLEDs) return;
    keys.syncLinnstrumentLEDs();
  }, [
    linnstrumentUserFirmwareEligible,
    settings.linnstrument_led_sync,
    colorImpactKey,
    keysReadyRevision,
  ]);

  const hakenOutId = hakenRawPorts?.output?.id ?? null;
  const hakenOutput = hakenRawPorts?.output ?? null;
  useEffect(() => {
    if (!hakenOutput) return;
    const managerChannel = Math.max(
      1,
      Math.min(16, parseInt(settings.midiin_mpe_manager_ch ?? 1, 10) || 1),
    );
    loadHakenController().then(({ sendHakenMpeConfig }) => {
      sendHakenMpeConfig(hakenOutput, managerChannel, {
        bendRange: 96,
      });
    });
  }, [hakenOutId, hakenOutput, settings.midiin_mpe_manager_ch]);

  // Color settings: only the color fields. Changes here update the live Keys
  // instance imperatively (via updateColors) without reconstructing it.
  const colorSettings = useMemo(
    () => normalizeColors(settings),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- colorImpactKey is the settings-impact registry key.
    [colorImpactKey],
  );

  const hasActiveKeyboardModulation = useMemo(
    () => hasActiveModulationHistory(modulationHistory),
    [modulationHistory],
  );

  const keyboardHejiFrame = useMemo(() => {
    return deriveActiveHejiFrame(tuningWorkspace, modulationHistory, {
      hejiEnabled: structuralSettings.heji,
      hejiSupported: structuralSettings.heji_supported,
      anchorLabel: structuralSettings.heji_anchor_label_effective,
      anchorRatioText: structuralSettings.heji_anchor_ratio_effective,
      referenceDegree: structuralSettings.reference_degree ?? 0,
      temperedOnly: settings.heji_tempered_only === true,
    });
  }, [modulationHistory, structuralSettings, tuningWorkspace, settings.heji_tempered_only]);

  const activeHejiFrame = useMemo(() => {
    return deriveActiveHejiFrame(tuningWorkspace, deferredModulationHistory, {
      hejiEnabled: structuralSettings.heji,
      hejiSupported: structuralSettings.heji_supported,
      anchorLabel: structuralSettings.heji_anchor_label_effective,
      anchorRatioText: structuralSettings.heji_anchor_ratio_effective,
      referenceDegree: structuralSettings.reference_degree ?? 0,
      temperedOnly: settings.heji_tempered_only === true,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deferredModulationHistory is intentionally represented by activeDeferredModulationKey so zero-count preset libraries do not invalidate HEJI spelling.
  }, [
    hasActiveDeferredModulation,
    structuralSettings,
    tuningWorkspace,
    activeDeferredModulationKey,
    settings.heji_tempered_only,
  ]);

  // Label settings: display-only fields extracted from structuralSettings.
  // Passed to Keyboard so it can call updateLabels imperatively whenever
  // structuralSettings recomputes due to label-related changes, without
  // those changes causing a Keys reconstruction.
  const labelSettings = useMemo(() => {
    const hejiShowCents = settings.heji_show_cents !== false;
    const hejiTemperedOnly = settings.heji_tempered_only === true;
    let liveHejiNames = structuralSettings.heji_names_keys ?? structuralSettings.heji_names;
    if (
      hasActiveKeyboardModulation &&
      structuralSettings.heji &&
      structuralSettings.heji_supported !== false &&
      tuningWorkspace &&
      keyboardHejiFrame
    ) {
      liveHejiNames = deriveHejiLabelsForFrame(tuningWorkspace, keyboardHejiFrame, {
        suppressDeviation: !hejiShowCents && !hejiTemperedOnly,
        temperedOnly: hejiTemperedOnly,
        forceShowZeroDeviation: hejiTemperedOnly && hejiShowCents,
      });
    }

    return {
      key_labels: structuralSettings.key_labels,
      degree: !!structuralSettings.degree,
      note: !!structuralSettings.note,
      scala: !!structuralSettings.scala,
      cents: !!structuralSettings.cents,
      heji: !!structuralSettings.heji,
      equaves: !!structuralSettings.equaves,
      no_labels: !!structuralSettings.no_labels,
      show_equaves: !!structuralSettings.equaves,
      note_names: structuralSettings.note_names,
      scala_names: structuralSettings.scala_names,
      heji_names: liveHejiNames,
      heji_anchor_label_eff: structuralSettings.heji_anchor_label_effective,
      heji_anchor_ratio_eff: structuralSettings.heji_anchor_ratio_effective,
      scale: structuralSettings.scale,
      reference_degree: structuralSettings.reference_degree,
    };
  }, [
    structuralSettings,
    tuningWorkspace,
    keyboardHejiFrame,
    hasActiveKeyboardModulation,
    settings.heji_show_cents,
    settings.heji_tempered_only,
  ]);

  const tableHejiNames = useMemo(() => {
    if (
      !structuralSettings.heji ||
      !hasActiveDeferredModulation ||
      structuralSettings.heji_supported === false ||
      !tuningWorkspace ||
      !activeHejiFrame
    ) {
      return structuralSettings.heji_names ?? [];
    }

    return deriveHejiLabelsForFrame(tuningWorkspace, activeHejiFrame, {
      suppressDeviation: false,
      temperedOnly: settings.heji_tempered_only === true,
      forceShowZeroDeviation: settings.heji_tempered_only === true,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deferredModulationHistory is intentionally represented by activeDeferredModulationKey so zero-count preset libraries do not invalidate HEJI spelling.
  }, [
    structuralSettings,
    tuningWorkspace,
    activeHejiFrame,
    activeDeferredModulationKey,
    hasActiveDeferredModulation,
    settings.heji_tempered_only,
    labelSettings.heji_names,
  ]);

  const normalizedSettings = useMemo(
    () => ({
      ...structuralSettings,
      ...liveInputSettings,
      ...liveOutputSettings,
      ...labelSettings,
      ...colorSettings,
    }),
    [structuralSettings, liveInputSettings, liveOutputSettings, labelSettings, colorSettings],
  );
  const sequenceOnlyPlaybackSurface = !isValid && snapshots.length > 0;
  const keyboardSettings = useMemo(
    () =>
      sequenceOnlyPlaybackSurface
        ? {
            ...normalizedSettings,
            scale: [0],
            equivSteps: 1,
            equivInterval: 1200,
            reference_degree: 0,
            center_degree: 0,
            fundamental:
              Number.isFinite(Number(normalizedSettings.fundamental)) &&
              Number(normalizedSettings.fundamental) > 0
                ? Number(normalizedSettings.fundamental)
                : 440,
            key_labels: "no_labels",
            no_labels: true,
            note_colors: [normalizedSettings.fundamental_color || "#ffdbe8"],
            fundamental_color: normalizedSettings.fundamental_color || "#ffdbe8",
          }
        : normalizedSettings,
    [normalizedSettings, sequenceOnlyPlaybackSurface],
  );
  const keyboardTuningRuntime = sequenceOnlyPlaybackSurface
    ? SEQUENCE_PLAYBACK_FALLBACK_TUNING
    : tuningRuntime;

  // Imperative volume/mute — does not rebuild Keys

  // Null synth: visual-only, no audio. Used when no output is configured.
  const nullSynth = {
    makeHex: (coords, cents) => ({
      coords,
      cents,
      release: false,
      noteOn: () => {},
      noteOff: () => {},
      retune: () => {},
    }),
  };

  // Stable callbacks for Keyboard props — must be declared unconditionally
  // outside JSX so they don't violate the rules of hooks when the Keyboard
  // is conditionally rendered.
  const applySequenceModWheelChange = useCallback((value) => {
    const nextValue = clampSequenceTimbreModWheel(value);
    sequenceTimbreModWheelValueRef.current = nextValue;
    // The synth-level CC1 route runs first so live/non-sequence voices still
    // follow the physical wheel. Sequence voices then assert their intended
    // timbre: either the wheel-shaped value or the unmodified stored value.
    applySequenceTimbreModWheelToActiveSnapshotHexes(
      keysRef.current,
      sequenceTimbreModWheelEnabledRef.current ? nextValue : NEUTRAL_SEQUENCE_TIMBRE_MOD_WHEEL,
    );
  }, []);
  const onKeysModWheelChange = useCallback((value) => {
    onOscBrightnessChange(clampSequenceTimbreModWheel(value) / 127, false);
    applySequenceModWheelChange(value);
  }, [onOscBrightnessChange, applySequenceModWheelChange]);
  const onBrightnessFaderChange = useCallback((value) => {
    onOscBrightnessChange(value);
    // Like physical CC1, shape stored sequence timbre only when its preference
    // is enabled. Keep the value for future attacks and subsequent re-enabling.
    applySequenceModWheelChange(Math.round(Math.max(0, Math.min(1, Number(value) || 0)) * 127));
  }, [onOscBrightnessChange, applySequenceModWheelChange]);

  const onKeysReady = useCallback(
    (keys) => {
      keysRef.current = keys;
      setKeysReadyRevision((revision) => revision + 1);
      if (linnstrumentUserFirmwareEligible && linnstrumentLedsRef.current) {
        linnstrumentLedsRef.current.userFirmwareActive = true;
      }
      bindControllerLedRefs(
        keys,
        {
          lumatone: lumatoneLedsRef.current,
          exquis: exquisLedsRef.current,
          linnstrument: linnstrumentLedsRef.current,
        },
        { eagerSync: false },
      );
      if (settings.lumatone_led_sync && lumatoneLedsRef.current) {
        const syncKey = buildLumatoneAutoSyncKey({
          lumatoneInId,
          lumatoneOutId,
          name: settings.name,
          referenceDegree: settings.reference_degree,
          fundamental: settings.fundamental,
          noteColors: settings.note_colors,
          keyLabels: settings.key_labels,
          scale: settings.scale,
          equivInterval: settings.equivInterval,
          centerDegree: settings.center_degree,
          rSteps: settings.rSteps,
          drSteps: settings.drSteps,
          anchorNote: settings.midiin_anchor_note,
          anchorChannel: settings.midiin_anchor_channel,
        });
        lumatoneAutoSyncKeyRef.current = syncKey;
        setTimeout(() => {
          if (keysRef.current !== keys) return;
          if (lumatoneLedsRef.current == null) return;
          keys.autoSyncLumatoneLEDs?.();
        }, 0);
      }
    },
    [
      linnstrumentUserFirmwareEligible,
      lumatoneInId,
      lumatoneOutId,
      settings.lumatone_led_sync,
      settings.name,
      settings.reference_degree,
      settings.fundamental,
      settings.note_colors,
      settings.key_labels,
      settings.scale,
      settings.equivInterval,
      settings.center_degree,
      settings.rSteps,
      settings.drSteps,
      settings.midiin_anchor_note,
      settings.midiin_anchor_channel,
    ],
  );
  const onLatchChange = useCallback((v) => setLatch(v), []);
  const modulationSnapshotKeyRef = useRef("");
  const onModulationStateChange = useCallback((state) => {
    const snapshot = snapshotModulationState(state);
    if (snapshot?.lastDecision?.reason === "deconstruct") return;
    const nextKey = modulationSnapshotKey(snapshot);
    if (nextKey === modulationSnapshotKeyRef.current) return;
    modulationSnapshotKeyRef.current = nextKey;
    setModulationState(snapshot);
    setModulationMode(snapshot?.mode ?? "idle");
    setModulationArmed(snapshot?.mode === "awaiting_target");
  }, []);
  const onModulationArmChange = useCallback((v) => setModulationArmed(v), []);
  const onFirstInteraction = primeAudioFromUserInteraction;
  const controlsHiddenForKeyboard = textEntryActive && viewportKeyboardOpen;
  const enableLumatoneAutoSyncNow = useCallback(() => {
    const keys = keysRef.current;
    const leds = lumatoneLedsRef.current;
    if (!leds || !lumatoneAutoSyncEligible) return;
    lumatoneAutoSyncKeyRef.current = buildLumatoneAutoSyncKey({
      lumatoneInId,
      lumatoneOutId,
      name: settings.name,
      referenceDegree: settings.reference_degree,
      fundamental: settings.fundamental,
      noteColors: settings.note_colors,
      keyLabels: settings.key_labels,
      scale: settings.scale,
      equivInterval: settings.equivInterval,
      centerDegree: settings.center_degree,
      rSteps: settings.rSteps,
      drSteps: settings.drSteps,
      anchorNote: settings.midiin_anchor_note,
      anchorChannel: settings.midiin_anchor_channel,
    });
    autoSyncLumatoneSurface({
      keys,
      leds,
      scale: settings.scale,
      eligible: lumatoneAutoSyncEligible,
    });
  }, [
    lumatoneAutoSyncEligible,
    lumatoneInId,
    lumatoneOutId,
    settings.fundamental,
    settings.note_colors,
    settings.key_labels,
    settings.name,
    settings.reference_degree,
    settings.scale,
    settings.equivInterval,
    settings.center_degree,
    settings.rSteps,
    settings.drSteps,
    settings.midiin_anchor_note,
    settings.midiin_anchor_channel,
  ]);
  const probeLumatoneConnection = useCallback(() => {
    const leds = lumatoneLedsRef.current;
    if (!leds?.probeConnection) {
      return Promise.resolve({ ok: false, reason: "driver-not-ready", bytes: [] });
    }
    // The driver is owned by App, independently of Keys reconstruction. Probe
    // it directly so a transient Keys/ref attachment race cannot block Edge or
    // other browsers that load the optional controller chunk more slowly.
    return leds.probeConnection();
  }, []);

  useEffect(() => {
    if (pendingRestoredPreset) return;
    const keys = keysRef.current;
    const leds = lumatoneLedsRef.current;
    if (!settings.lumatone_led_sync) {
      lumatoneAutoSyncKeyRef.current = "";
      return;
    }
    if (!leds || !lumatoneAutoSyncEligible) return;
    const blankLayout = !Array.isArray(settings.scale) || settings.scale.length === 0;
    if (!blankLayout && !keys) return;
    const syncKey = buildLumatoneAutoSyncKey({
      lumatoneInId,
      lumatoneOutId,
      name: settings.name,
      referenceDegree: settings.reference_degree,
      fundamental: settings.fundamental,
      noteColors: settings.note_colors,
      keyLabels: settings.key_labels,
      scale: settings.scale,
      equivInterval: settings.equivInterval,
      centerDegree: settings.center_degree,
      rSteps: settings.rSteps,
      drSteps: settings.drSteps,
      anchorNote: settings.midiin_anchor_note,
      anchorChannel: settings.midiin_anchor_channel,
    });
    if (syncKey === lumatoneAutoSyncKeyRef.current) return;
    lumatoneAutoSyncKeyRef.current = syncKey;
    const timer = setTimeout(() => {
      if (lumatoneLedsRef.current !== leds) return;
      if (!blankLayout && keysRef.current !== keys) return;
      autoSyncLumatoneSurface({
        keys,
        leds,
        scale: settings.scale,
        eligible: lumatoneAutoSyncEligible,
      });
    }, 0);
    return () => clearTimeout(timer);
  }, [
    keysReadyRevision,
    lumatoneInId,
    lumatoneOutId,
    lumatoneAutoSyncEligible,
    lumatoneDriverReady,
    pendingRestoredPreset,
    settings.fundamental,
    settings.note_colors,
    settings.key_labels,
    settings.lumatone_led_sync,
    settings.name,
    settings.reference_degree,
    settings.scale,
    settings.equivInterval,
    settings.center_degree,
    settings.rSteps,
    settings.drSteps,
    settings.midiin_anchor_note,
    settings.midiin_anchor_channel,
  ]);

  // A first visit lazy-loads I/O. Keep that suspension local: suspending the
  // shared sidebar also cleans up the hidden Sequencer's scheduled callbacks.
  const ioSettingsSidebar = (
    <>
    <Suspense fallback={<SidebarLoadingFallback />}>
      <IOSettings
        onChange={onChange}
        midiLearnActive={midiLearnActive}
        hakenPedalLearnActive={hakenPedalLearnActive}
        onVolumeChange={onVolumeChange}
        onOscLayerVolumeChange={onOscLayerVolumeChange}
        oscBrightness={oscBrightness}
        onOscBrightnessChange={onBrightnessFaderChange}
        onOscQuickReleaseChange={onOscQuickReleaseChange}
        onOscQuickReleaseTimeChange={onOscQuickReleaseTimeChange}
        onOscQuickReleaseRasterOnlyChange={onOscQuickReleaseRasterOnlyChange}
        settings={settings}
        midi={midi}
        midiAccess={midiAccess}
        midiAccessError={midiAccessError}
        enableWebMidi={ensureMidiAccess}
        disableWebMidi={disableWebMidi}
        midiTick={midiTick}
        instruments={instruments}
        keysRef={keysRef}
        lumatoneRawPorts={lumatoneRawPorts}
        exquisRawPorts={exquisRawPorts}
        linnstrumentRawPorts={linnstrumentRawPorts}
        hakenRawPorts={hakenRawPorts}
        exquisLedStatus={exquisLedStatus}
        snapshots={snapshots}
        tuningRuntime={tuningRuntime}
        onEnableLumatoneAutoSync={enableLumatoneAutoSyncNow}
        onProbeLumatoneConnection={probeLumatoneConnection}
        lumatoneDriverReady={lumatoneDriverReady}
      />
    </Suspense>
    </>
  );
  const calculatorSidebar = (
    <CalculatorTab
      key={`calculator-${calculatorSeedKey}`}
      hidden={workspaceTab !== "calculator" || Boolean(activeManualView)}
      workspaceKey={calculatorSeedKey}
      settings={settings}
      effectiveAnchorLabel={structuralSettings.heji_anchor_label_effective}
      effectiveAnchorRatio={structuralSettings.heji_anchor_ratio_effective}
    />
  );

  return (
    <div
      className={[active ? "hide" : "show", controlsHiddenForKeyboard ? "text-entry-active" : ""]
        .filter(Boolean)
        .join(" ")}
    >
      {((ready && !initialAudioPromptDismissed &&
          (!!pendingRestoredPreset || (!userHasInteracted &&
            (settings.output_sample || settings.output_fluidsynth || (settings.output_osc && settings.osc_local))))) ||
        (audioRecovery.status && !audioRecovery.status.startsWith("Audio engines restored"))) && (
        <div className="audio-recovery-alert" role="status">
          <span>{audioRecovery.status && !audioRecovery.status.startsWith("Audio engines restored")
            ? audioRecovery.status : "Tap Start Audio to prepare the built-in sounds before playing."}</span>{" "}
          <button type="button" disabled={audioRecovery.restoring}
            onPointerDown={e => runTouchControlAction(e, restoreBuiltInAudio)}
            onClick={e => { if (!skipSuppressedTouchClick(e)) void restoreBuiltInAudio(); }}>
            {audioRecovery.restoring ? (audioRecovery.status === "Starting audio…" ? "Starting Audio…" : "Restoring Audio…") : pendingRestoredPreset || !userHasInteracted ? "Start Audio" : "Restore Audio"}
          </button>{" "}
          <button type="button" onClick={audioRecovery.save}>Save Report</button>
          {" "}<button type="button" disabled={audioRecovery.restoring} onClick={() => {
            setInitialAudioPromptDismissed(true);
            audioRecovery.dismiss();
          }}>Dismiss</button>
        </div>
      )}
      {ready && (isValid || sequenceOnlyPlaybackSurface) && (
        <Keyboard
          synth={synth || nullSynth}
          settings={keyboardSettings}
          tuningRuntime={keyboardTuningRuntime}
          reconstructionKey={`${sequenceOnlyPlaybackSurface ? "sequence" : "canvas"}:${keysReconstructionImpactKey}`}
          hidden={sequenceOnlyPlaybackSurface}
          liveInputSettings={liveInputSettings}
          liveOutputSettings={liveOutputSettings}
          liveMidiInputPort={connectedInput}
          colorSettings={colorSettings}
          inputRuntime={inputRuntime}
          labelSettings={labelSettings}
          initialModulationLibrary={activeModulationLibrary}
          onKeysReady={onKeysReady}
          onLatchChange={onLatchChange}
          onModulationArmChange={onModulationArmChange}
          onModulationStateChange={onModulationStateChange}
          onModWheelChange={onKeysModWheelChange}
          onTakeSnapshot={onTakeSnapshot}
          active={active}
          midiLearnActive={midiLearnActive}
          onAnchorLearn={onAnchorLearn}
          hakenPedalLearnActive={hakenPedalLearnActive}
          onHakenPedalLearn={onHakenPedalLearn}
          lumatoneLedsRef={lumatoneLedsRef}
          exquisLedsRef={exquisLedsRef}
          linnstrumentLedsRef={linnstrumentLedsRef}
          onFirstInteraction={onFirstInteraction}
        />
      )}

      {loading > 0 && <Loading />}
      {banner === "ios" && (
        <div id="ios-banner">
          <div className="ios-banner__message">
            WebMIDI on iOS is an experimental feature. Install the{" "}
            <a
              href="https://testflight.apple.com/join/f7YNhJ3j"
              target="_blank"
              rel="noopener noreferrer"
            >
              MIDIWeb browser
            </a>{" "}
            to use MIDI features in PLAINSOUND HEXATONE. After returning from the lock screen or
            another app, use the onscreen refresh button to resume audio if playback is silent.
          </div>
          <div className="ios-banner__actions">
            <button onClick={() => hideBannerForSession("ios")}>Remind Me Later</button>
            <button onClick={() => dismissBanner("ios")}>Dismiss</button>
          </div>
        </div>
      )}
      {banner === "safari" && (
        <div id="ios-banner">
          <div className="ios-banner__message">
            Safari is not fully supported. For the best experience use a Chromium-based browser such
            as Chrome or Edge.
          </div>
          <div className="ios-banner__actions">
            <button onClick={() => hideBannerForSession("safari")}>Remind Me Later</button>
            <button onClick={() => dismissBanner("safari")}>Dismiss</button>
          </div>
        </div>
      )}
      {showRotationDebug && (
        <div className="app-shell__rotation-debug">
          <div className="app-shell__rotation-debug-header">
            <strong>Rotation Debug</strong>
            <div className="app-shell__rotation-debug-actions">
              <button type="button" onClick={() => setRotationDebugEvents([])}>
                Clear
              </button>
              <button type="button" onClick={() => setShowRotationDebug(false)}>
                Hide
              </button>
            </div>
          </div>
          {rotationDebugEvents.map((event, index) => (
            <div
              key={`${event.at}-${event.source}-${index}`}
              className={`app-shell__rotation-debug-entry${index === 0 ? " app-shell__rotation-debug-entry--first" : ""}`}
            >
              <div>
                {event.at} {event.source}
              </div>
              <div>inner {event.inner}</div>
              <div>viewport {event.viewport}</div>
              <div>canvas {event.canvas}</div>
              <div>
                {event.orientation} / {event.sidebarMode} / {event.shortLandscape}
              </div>
            </div>
          ))}
        </div>
      )}
      <button
        id="sidebar-button"
        className={[
          latch ? "latch-active" : "",
          landscapeSafeSide !== "none" ? `landscape-safe-${landscapeSafeSide}` : "",
        ]
          .filter(Boolean)
          .join(" ")}
        onClick={() => {
          primeAudioFromUserInteraction();
          setActive((s) => !s);
        }}
        onTouchStart={onSidebarTouchStart}
        onTouchEnd={onSidebarTouchEnd}
        onTouchMove={onSidebarTouchMove}
        onContextMenu={(e) => e.preventDefault()}
      >
        <span className="sidebar-button__hit-area">
          <div>&gt;</div>
        </span>
      </button>
      <div id="bottom-bar">
        <div id="main-bottom-controls">
          <div id="octave-island">
            <button
              className="octave-btn"
              title="Octave down"
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                runTouchControlAction(e, () => shiftOctave(-1));
              }}
              onClick={(e) => {
                if (skipSuppressedTouchClick(e)) return;
                e.stopPropagation();
                shiftOctave(-1);
              }}
              onContextMenu={(e) => e.preventDefault()}
            >
              ▼
            </button>
            <span
              className={`octave-display app-shell__octave-toggle${!octaveDeferred ? " octave-defer-active" : ""}`}
              title={
                octaveDeferred ? "Transpose on next event" : "Transpose sounding notes immediately"
              }
              onClick={(e) => {
                if (skipSuppressedTouchClick(e)) return;
                toggleOctaveDeferred();
              }}
              onPointerDown={(e) => {
                runTouchControlAction(e, toggleOctaveDeferred);
              }}
            >
              {octaveTranspose === 0
                ? "OCT"
                : octaveTranspose > 0
                  ? `+${octaveTranspose}`
                  : `${octaveTranspose}`}
            </span>
            <button
              className="octave-btn"
              title="Octave up"
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                runTouchControlAction(e, () => shiftOctave(+1));
              }}
              onClick={(e) => {
                if (skipSuppressedTouchClick(e)) return;
                e.stopPropagation();
                shiftOctave(+1);
              }}
              onContextMenu={(e) => e.preventDefault()}
            >
              ▲
            </button>
          </div>
          <button
            id="sustain-island"
            className={latch ? "latch-active" : ""}
            onClick={(e) => {
              if (skipSuppressedTouchClick(e)) return;
              e.stopPropagation();
              if (keysRef.current) keysRef.current.latchToggle();
            }}
            onPointerDown={(e) => {
              runTouchControlAction(e, () => {
                if (keysRef.current) keysRef.current.latchToggle();
              });
            }}
            onContextMenu={(e) => e.preventDefault()}
          >
            <b>SUSTAIN</b>
          </button>
          <button
            id="modulation-island"
            className={[
              modulationArmed ? "modulation-active" : "",
              modulationMode === "pending_settlement" ? "modulation-pending" : "",
            ]
              .filter(Boolean)
              .join(" ")}
            title={
              modulationMode === "pending_settlement"
                ? `Modulation pending settlement${modulationSummary ? `: ${modulationSummary}` : ""}`
                : modulationSummary
                  ? `Arm modulation target selection (Shift+Backquote): ${modulationSummary}`
                  : "Arm modulation target selection (Shift+Backquote)"
            }
            onClick={(e) => {
              if (skipSuppressedTouchClick(e)) return;
              e.stopPropagation();
              if (!keysRef.current?.toggleModulationArm) return;
              if (modulationMode === "idle") setModulationArmed(true);
              keysRef.current.toggleModulationArm();
            }}
            onPointerDown={(e) => {
              runTouchControlAction(e, () => {
                if (!keysRef.current?.toggleModulationArm) return;
                if (modulationMode === "idle") setModulationArmed(true);
                keysRef.current.toggleModulationArm();
              });
            }}
            onContextMenu={(e) => e.preventDefault()}
          >
            <b>MOD</b>
            {modulationSummary ? (
              <span className="modulation-route">{modulationSummary}</span>
            ) : null}
          </button>
          <button
            id="panic-button"
            title="Panic - kill all stuck notes"
            onClick={(e) => {
              if (skipSuppressedTouchClick(e)) return;
              e.stopPropagation();
              panicPlayback();
            }}
            onPointerDown={(e) => {
              runTouchControlAction(e, () => {
                panicPlayback();
              });
            }}
            onContextMenu={(e) => e.preventDefault()}
          >
            <b>PANIC</b>
          </button>
        </div>
        <button
          id="snapshot-button"
          title="Capture current notes as a snapshot"
          onPointerDown={(e) => {
            runTouchControlAction(e, onTakeSnapshot);
          }}
          onClick={(e) => {
            if (skipSuppressedTouchClick(e)) return;
            e.stopPropagation();
            onTakeSnapshot();
          }}
          onContextMenu={(e) => e.preventDefault()}
        >
          ◉
        </button>
        <button
          id="redraw-button"
          title="Redraw keyboard / Resume audio"
          onPointerDown={(e) => {
            runTouchControlAction(e, () => {
              void refreshKeyboardAndAudio();
            });
          }}
          onClick={async (e) => {
            if (skipSuppressedTouchClick(e)) return;
            e.stopPropagation();
            await refreshKeyboardAndAudio();
          }}
          onContextMenu={(e) => e.preventDefault()}
        >
          <span class="refresh-glyph" aria-hidden="true">
            ⟳
          </span>
        </button>
      </div>

      {/* ── Snapshot palette — floating overlay, visible without opening the sidebar ── */}
      {snapshotPaletteVisible && snapshots.length > 0 && (
        <div
          id="snapshot-palette"
          onPointerDownCapture={bringPaletteToFront}
          onClickCapture={bringPaletteToFront}
          onFocusCapture={bringPaletteToFront}
          ref={snapshotPaletteRef}
          style={{
            left: `${snapshotPalettePos.x}px`,
            top: `${snapshotPalettePos.y}px`,
          }}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className="modulation-palette-header snapshot-palette-header"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              const rect = e.currentTarget.parentElement?.getBoundingClientRect();
              snapshotPaletteDragRef.current = {
                pointerId: e.pointerId,
                offsetX: rect ? e.clientX - rect.left : 0,
                offsetY: rect ? e.clientY - rect.top : 0,
              };
            }}
          >
            <span className="modulation-palette-handle" title="Drag snapshots">
              ⠿
            </span>
            <strong>SNAPSHOTS</strong>
            <button
              className="modulation-palette-toggle"
              title={snapshotPaletteCollapsed ? "Expand snapshots" : "Collapse snapshots"}
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={(e) => {
                e.stopPropagation();
                setSnapshotPaletteCollapsed((value) => !value);
              }}
            >
              <span
                className={`disclosure-toggle-glyph disclosure-toggle-glyph--${snapshotPaletteCollapsed ? "collapsed" : "expanded"}`}
                aria-hidden="true"
              />
            </button>
            {!snapshotPaletteCollapsed && (
              <label
                className="snapshot-palette-snap-toggle"
                title="Retune saved snapshots to the nearest pitches in the current tuning"
                onPointerDown={(e) => {
                  // The rest of the header is the palette drag handle. Keep the
                  // checkbox interactive without beginning a palette drag.
                  e.stopPropagation();
                }}
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={snapSequenceToCurrentTuning}
                  aria-label="Snap palette snapshots to current tuning"
                  onChange={(e) => setSnapSequenceToCurrentTuning(e.currentTarget.checked)}
                />
                <span>Snap to current tuning</span>
              </label>
            )}
          </div>
          {!snapshotPaletteCollapsed && (
            <>
            {snapSequenceToCurrentTuning && <ChordSnapControls palette
              drift={chordDrift} onDriftChange={setChordDrift} />}
            <div className="snapshot-palette-body" ref={snapshotPaletteBodyRef}>
              {snapshots.map((snap, index) => {
                const isPlaying =
                  Number.isFinite(timedPlaybackUiRef.current.clockSeconds) && timedPaletteSnapshotRef.current != null
                    ? snap.id === timedPaletteSnapshotRef.current
                    : snap.id === playingSnapshotId || manualPlayingSnapshotIds.includes(snap.id);
                const isEmpty = !Array.isArray(snap.notes) || snap.notes.length === 0;
                const isDragOver = dragOverId === snap.id;
                return (
                  <div
                    key={snap.id}
                    data-snapshot-id={String(snap.id)}
                    class={`snapshot-row${isPlaying ? " snapshot-playing" : ""}${isDragOver ? " snapshot-drag-over" : ""}`}
                    draggable={true}
                    onDragStart={(e) => {
                      dragIdRef.current = snap.id;
                      e.dataTransfer.effectAllowed = "move";
                    }}
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.dataTransfer.dropEffect = "move";
                      setDragOverId(snap.id);
                    }}
                    onDragLeave={() => setDragOverId(null)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragOverId(null);
                      if (dragIdRef.current !== null && dragIdRef.current !== snap.id) {
                        onMoveSnapshot(dragIdRef.current, snap.id);
                      }
                      dragIdRef.current = null;
                    }}
                    onDragEnd={() => {
                      setDragOverId(null);
                      dragIdRef.current = null;
                    }}
                  >
                    <span class="snapshot-drag-handle" title="Drag to reorder">
                      ⠿
                    </span>
                    <span class="snapshot-list-index" title={`Snapshot ${index + 1}`}>
                      {index + 1}
                    </span>
                    <button
                      class="snapshot-play-btn"
                      title={isEmpty ? "Empty snapshot" : "Play snapshot"}
                      aria-label={
                        isEmpty ? `Snapshot ${index + 1} is empty` : `Play snapshot ${index + 1}`
                      }
                      disabled={isEmpty}
                      onPointerDown={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayPaletteSnapshot(snap.id);
                      }}
                    >
                      <span
                        className="snapshot-play-glyph snapshot-play-glyph--play"
                        aria-hidden="true"
                      />
                    </button>
                    <button
                      class="snapshot-play-btn snapshot-stop-btn"
                      title="Stop snapshot"
                      aria-label={`Stop snapshot ${index + 1}`}
                      disabled={!isPlaying}
                      onPointerDown={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onStopSnapshot(snap.id);
                      }}
                    >
                      <span class="snapshot-stop-glyph" aria-hidden="true" />
                    </button>
                    <button
                      class="snapshot-del-btn"
                      title="Delete snapshot"
                      onPointerDown={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSnapshot(snap.id);
                      }}
                    >
                      ×
                    </button>
                  </div>
                );
              })}
            </div>
            </>
          )}
        </div>
      )}

      {modulationPaletteVisible && performancePalettesVisible && (
        <div
          id="modulation-palette"
          onPointerDownCapture={bringPaletteToFront}
          onClickCapture={bringPaletteToFront}
          onFocusCapture={bringPaletteToFront}
          ref={modulationPaletteRef}
          style={{
            left: `${modulationPalettePos.x}px`,
            top: `${modulationPalettePos.y}px`,
          }}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className="modulation-palette-header"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              const rect = e.currentTarget.parentElement?.getBoundingClientRect();
              modulationPaletteDragRef.current = {
                pointerId: e.pointerId,
                offsetX: rect ? e.clientX - rect.left : 0,
                offsetY: rect ? e.clientY - rect.top : 0,
              };
            }}
          >
            <span className="modulation-palette-handle" title="Drag modulation history">
              ⠿
            </span>
            <strong>MODULATION HISTORY</strong>
            <button
              className="modulation-palette-toggle"
              title={
                modulationPaletteCollapsed
                  ? "Expand modulation history"
                  : "Collapse modulation history"
              }
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={(e) => {
                e.stopPropagation();
                setModulationPaletteCollapsed((value) => !value);
              }}
            >
              <span
                className={`disclosure-toggle-glyph disclosure-toggle-glyph--${modulationPaletteCollapsed ? "collapsed" : "expanded"}`}
                aria-hidden="true"
              />
            </button>
          </div>
          {currentFundamentalSummary && (
            <div
              className="modulation-palette-summary"
              title="Current degree-0 fundamental after all active modulation steps"
            >
              <span className="modulation-palette-summary-label">1/1 Shift:</span>
              <span className="modulation-palette-summary-value">
                {currentFundamentalSummary.display}
              </span>
              <span className="modulation-palette-summary-placeholder" aria-hidden="true" />
              <span className="modulation-palette-summary-placeholder" aria-hidden="true" />
              <span className="modulation-palette-summary-placeholder" aria-hidden="true" />
              {Math.abs(currentFundamentalSummary.cents ?? 0) > 0.000001 ? (
                <button
                  className="modulation-palette-close modulation-palette-summary-reset"
                  title="Reset all modulation counts to zero"
                  onPointerDown={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onResetModulationRoutes();
                  }}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                  }}
                >
                  <span class="refresh-glyph" aria-hidden="true">
                    ⟳
                  </span>
                </button>
              ) : null}
            </div>
          )}
          {!modulationPaletteCollapsed &&
            modulationHistory.map((entry, index) => {
              const count = Number.isFinite(entry?.count) ? Math.trunc(entry.count) : 0;
              const { sourceLabel, targetLabel } = modulationRouteLabelPair(
                entry,
                modulationDegreeLabel,
                tuningWorkspace,
              );
              const routeLabel = `${sourceLabel} ↔ ${targetLabel}`;
              const canClearRoute = modulationMode === "idle" && count === 0;
              return (
                <div
                  key={`${entry.sourceDegree}:${entry.targetDegree}:${index}`}
                  className={`modulation-palette-row${count !== 0 ? " modulation-palette-row-active" : ""}`}
                  title={modulationPaletteTitle[index] || routeLabel}
                >
                  <span className="modulation-palette-route">
                    {sourceLabel}
                    <span className="modulation-palette-route-arrow" aria-hidden="true" />
                    {targetLabel}
                  </span>
                  <span className="modulation-palette-modulation">
                    {modulationEntryDisplayText(entry, tuningWorkspace)}
                  </span>
                  <button
                    className="modulation-palette-step modulation-palette-step--left"
                    aria-label="Step modulation backward"
                    disabled={modulationMode !== "idle"}
                    title="Step modulation backward"
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onStepModulationRoute(index, -1);
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                  />
                  <span className="modulation-palette-count">
                    {count > 0 ? `+${count}` : `${count}`}
                  </span>
                  <button
                    className="modulation-palette-step modulation-palette-step--right"
                    aria-label="Step modulation forward"
                    disabled={modulationMode !== "idle"}
                    title="Step modulation forward"
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onStepModulationRoute(index, 1);
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                  />
                  <span className="modulation-palette-close-slot">
                    {canClearRoute ? (
                      <button
                        className="modulation-palette-close"
                        title="Remove modulation history row"
                        onPointerDown={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          onClearModulationRoute(index);
                        }}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                        }}
                      >
                        ×
                      </button>
                    ) : null}
                  </span>
                </div>
              );
            })}
        </div>
      )}

      <nav id="sidebar" ref={sidebarRef} onScroll={event => {
        if (event.target === sidebarRef.current && !activeManualView) {
          workspaceScrollPositionsRef.current[workspaceTab] = event.currentTarget.scrollTop;
        }
      }}>
        <div class="workspace-tabs" role="tablist" aria-label="Workspace">
          <button
            type="button"
            role="tab"
            aria-selected={workspaceTab === "hexatone"}
            class={`workspace-tab${workspaceTab === "hexatone" ? " workspace-tab--active" : ""}`}
            onClick={() => switchWorkspaceTab("hexatone")}
          >
            HEXATONE
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={workspaceTab === "sequencer"}
            class={`workspace-tab${workspaceTab === "sequencer" ? " workspace-tab--active" : ""}`}
            onClick={() => switchWorkspaceTab("sequencer")}
          >
            SEQUENCER
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={workspaceTab === "io"}
            class={`workspace-tab${workspaceTab === "io" ? " workspace-tab--active" : ""}`}
            onClick={() => switchWorkspaceTab("io")}
          >
            I/O
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={workspaceTab === "calculator"}
            class={`workspace-tab${workspaceTab === "calculator" ? " workspace-tab--active" : ""}`}
            onClick={() => switchWorkspaceTab("calculator")}
          >
            CALCULATOR
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={workspaceTab === "manual"}
            class={`workspace-tab${workspaceTab === "manual" ? " workspace-tab--active" : ""}`}
            onClick={openManualWorkspace}
          >
            MANUAL
          </button>
        </div>
        <div class="workspace-tabs-deadzone" aria-hidden="true" />
        <h1>
          {workspaceTab === "manual"
            ? "USER MANUAL"
            : workspaceTab === "calculator"
              ? "HEJI CALCULATOR"
              : workspaceTab === "io"
                ? "INPUT / OUTPUT"
                : workspaceTab === "sequencer"
                  ? "PLAINSOUND SEQUENCER"
                  : "PLAINSOUND HEXATONE"}
        </h1>
        {workspaceTab === "sequencer" ? (
          <p class="sidebar-intro">
            <em>
              Capture SNAPSHOTS of chords and momentary expression data (velocity, pressure, timbre)
              while playing or sustaining. Trigger the sequence event by event. Edit start and stop
              times within a chord to make CUES that sound a melody or arpeggiation. Create bars,
              repeats, and tempo markers to generate automated timed playback.{" "}
              <button
                type="button"
                className="app-shell__intro-more"
                onClick={() => openInlineManual("sequencer")}
              >
                … more
              </button>
            </em>
          </p>
        ) : workspaceTab === "io" ? (
          <p class="sidebar-intro">
            <em>
              Choose built-in sounds, connect MIDI controllers, send controller colours, and route
              MTS, MPE, and OSC output. These controls remain available while live input or a
              sequence is sounding.{" "}
              <button
                type="button"
                className="app-shell__intro-more"
                onClick={() => openInlineManual("io")}
              >
                … more
              </button>
            </em>
          </p>
        ) : workspaceTab === "calculator" ? (
          <p class="sidebar-intro">
            <em>Choose a tuning reference (for example, </em>*nA = 440 Hz
            <em>
              ), then input a HEJI spelling, ratio or cents value to determine its staff notation,
              cents deviation, frequency, and nearby rational intonation options. Choosing a tuning
              in HEXATONE tab changes the Reference Frequency and Spelling Anchor in CALCULATOR but
              changing the settings does not retune the Keyboard canvas.{" "}
              <button
                type="button"
                className="app-shell__intro-more"
                onClick={() => openInlineManual("calculator")}
              >
                … more
              </button>
            </em>
          </p>
        ) : workspaceTab === "hexatone" ? (
          <p class="sidebar-intro">
            <em>
              To play, choose a built-in tuning or build your own scale in "Scale Settings" by
              changing "Scale Size" or clicking on "Add Scale Degree". Click or touch notes. Edit
              the scale in the table below; drag to retune notes; rationalise; modulate. SHIFT+ESC
              or F8 toggles sustain. SHIFT+ENTER captures notes into snapshots you can edit in
              SEQUENCER. Visit the I/O tab to choose internal sounds, connect a MIDI keyboard or an
              isomorphic controller like Lumatone or Exquis, and retune external synths using MTS,
              MPE, OSC.{" "}
              <button
                type="button"
                className="app-shell__intro-more"
                onClick={() => openInlineManual("hexatone")}
              >
                … more
              </button>
            </em>
          </p>
        ) : null}

        <Suspense fallback={<SidebarLoadingFallback />}>
          <>
            {calculatorSidebar}
            {activeManualView ? (
              <ManualSidebar
                key={activeManualView}
                initialSectionTitle={manualSectionTitles[activeManualView]}
                onSectionChange={rememberManualSection}
                onClose={workspaceTab === "manual" ? undefined : closeInlineManual}
                scrollContainerRef={sidebarRef}
              />
            ) : performanceWorkspaceTab === "sequencer" ? (
              <>
                <div
                  hidden={workspaceTab !== "sequencer"}
                  aria-hidden={workspaceTab !== "sequencer"}
                >
                  <Sequencer
                    workspaceVisible={workspaceTab === "sequencer"}
                    transportTarget={workspaceTab === "io" && snapshots.length > 0 ? ioTransportTargetRef.current : null}
                    snapshots={snapshots}
                    runtimeModel={sequenceRuntimeModel}
                    displaySnapshots={sequenceDisplaySnapshots}
                    playbackSnapshots={sequencePlaybackSnapshots}
                    bars={sequenceBars}
                    repeats={sequenceRepeats}
                    tempi={sequenceTempi}
                    snapshotLabelMode={snapshotLabelMode}
                    autoCreateBars={sequenceAutoCreateBars}
                    activeSequenceSource={activeSequenceSource}
                    activeSequenceBuiltInName={activeSequenceBuiltInName}
                    activeSequenceName={activeSequenceName}
                    activeSequenceSavedName={activeSequenceSavedName}
                    activeSequenceDescription={activeSequenceDescription}
                    sequenceLegato={sequenceLegato}
                    sequencePlaybackSpeed={sequencePlaybackSpeed}
                    sequencePlaybackPitchOffset={sequencePlaybackPitchOffset}
                    sequenceTimbreModWheelEnabled={sequenceTimbreModWheelEnabled}
                    sequencePlayRepeats={sequencePlayRepeats}
                    snapSequenceToCurrentTuning={snapSequenceToCurrentTuning}
                    chordDrift={chordDrift}
                    onChordDriftChange={setChordDrift}
                    sequenceAutoCreateBars={sequenceAutoCreateBars}
                    manualArpeggiation={manualArpeggiation}
                    selectedSnapshotId={selectedSnapshotId}
                    selectedMarker={selectedSnapshotMarker}
                    pendingTransportSelection={pendingTransportSelectionRef.current}
                    playingSnapshotId={playingSnapshotId}
                    playingSnapshotIds={manualPlayingSnapshotIds}
                    scrollPositionRef={sequencerScrollPositionRef}
                    playhead={sequencePlayhead}
                    onTakeSnapshot={onTakeSnapshot}
                    onAddEmptySnapshot={onAddEmptySnapshot}
                    onLoadSequence={onLoadSequence}
                    onSequenceNameChange={onSequenceNameChange}
                    onSequenceDescriptionChange={setActiveSequenceDescription}
                    onSequenceSaved={onSequenceSaved}
                    onSequenceLegatoChange={(mode) =>
                      setSequenceLegato(normalizeSequenceLegatoMode(mode))
                    }
                    onSequencePlaybackSpeedChange={(value) =>
                      setSequencePlaybackSpeed(clampSequencePlaybackSpeed(value))
                    }
                    onSequencePlaybackPitchOffsetChange={commitSequencePlaybackPitchOffset}
                    onSequencePlaybackPitchOffsetPreview={previewSequencePlaybackPitchOffset}
                    onSequenceTimbreModWheelEnabledChange={onSequenceTimbreModWheelEnabledChange}
                    onSequencePlayRepeatsChange={setSequencePlayRepeats}
                    onSnapSequenceToCurrentTuningChange={setSnapSequenceToCurrentTuning}
                    onSequenceAutoCreateBarsChange={setSequenceAutoCreateBars}
                    onManualArpeggiationChange={(updates) => {
                      setManualArpeggiation((current) =>
                        normalizeManualArpeggiation({
                          ...current,
                          ...updates,
                        }),
                      );
                    }}
                    onSetSnapshotLabelMode={setSnapshotLabelMode}
                    onSelectSnapshot={onSelectSequencerSnapshot}
                    onSelectMarker={onSelectSequencerMarker}
                    onPlaySnapshot={onPlaySnapshot}
                    onStopSnapshot={onStopSnapshot}
                    timedTransportStopRef={timedTransportStopRef}
                    onSelectSequenceBar={onSelectSequenceBar}
                    onCueSequenceSnapshot={onCueSequenceSnapshot}
                    onCueSequenceCue={onCueSequenceCue}
                    onStepSequence={onStepSequence}
                    onStepSequenceMarker={onStepSequenceMarker}
                    onJumpSequenceSnapshot={onJumpSequenceSnapshot}
                    onJumpSequenceCue={onJumpSequenceCue}
                    onPlaySequence={onPlaySequence}
                    onPlayCue={onPlaySequenceCue}
                    onPlayTimedCue={onPlayTimedSequenceCue}
                    onPresentTimedCue={onPresentTimedPaletteCue}
                    onEnsureAudioReady={primeAudioFromUserInteraction}
                    onResetSequencePlayhead={onResetSequencePlayhead}
                    onJumpSequenceEnd={onJumpSequenceEnd}
                    getTimedTransportClockSeconds={getTimedTransportClockSeconds}
                    onAddBar={onAddSequenceBar}
                    onAddTempo={onAddSequenceTempo}
                    onAddRepeat={onAddSequenceRepeat}
                    onAddBarsBeforeSnapshots={onAddBarsBeforeSnapshots}
                    onDeleteBar={onDeleteSequenceBar}
                    onDeleteTempo={onDeleteSequenceTempo}
                    onDeleteRepeat={onDeleteSequenceRepeat}
                    onUpdateBar={onUpdateSequenceBar}
                    onUpdateTempo={onUpdateSequenceTempo}
                    onUpdateRepeat={onUpdateSequenceRepeat}
                    onMoveBar={onMoveSequenceBar}
                    onDeleteSnapshot={onDeleteSnapshot}
                    onDeleteAllSnapshots={onDeleteAllSnapshots}
                    onClearSequence={onClearSequence}
                    onMoveSnapshot={onMoveSnapshot}
                    onDuplicateSnapshot={onDuplicateSnapshot}
                    onInsertSnapshotCopyBlock={onInsertSnapshotCopyBlock}
                    onMoveSnapshotRange={onMoveSnapshotRange}
                    onResetSnapshotRangeNoteOffsetsInPlace={onResetSnapshotRangeNoteOffsetsInPlace}
                    onSetSnapshotRangeArticulation={onSetSnapshotRangeArticulation}
                    onRestoreSnapshotRangeChanges={onRestoreSnapshotRangeChanges}
                    onDeleteSnapshotRange={onDeleteSnapshotRange}
                    onUpdateSnapshot={onUpdateSnapshot}
                    onResetSnapshotDescription={onResetSnapshotDescription}
                  />
                </div>
                {workspaceTab === "io" ? ioSettingsSidebar : null}
              </>
            ) : workspaceTab === "io" ? (
              ioSettingsSidebar
            ) : workspaceTab === "calculator" ? null : (
              <>
                <Settings
                  onChange={onChange}
                  onAtomicChange={onAtomicChange}
                  onImport={onImport}
                  importCount={importCount}
                  onLoadBuiltinPreset={onLoadBuiltinPreset}
                  onLoadCustomPreset={onLoadCustomPreset}
                  onClearUserPresets={onClearUserPresets}
                  activeSource={activeSource}
                  activePresetName={activePresetName}
                  pendingRestoredPreset={pendingRestoredPreset}
                  isPresetDirty={isPresetDirty}
                  currentModulationLibrary={modulationState?.history ?? presetModulationLibrary}
                  canCommitModulation={hasCommittableModulation}
                  onCommitCurrentModulation={onCommitCurrentModulation}
                  persistOnReload={persistOnReload}
                  setPersistOnReload={setPersistOnReload}
                  activatePendingPreset={activatePendingPreset}
                  onRevertBuiltin={onRevertBuiltin}
                  onRevertUser={onRevertUser}
                  settings={settings}
                  heji_names={labelSettings.heji_names}
                  heji_names_table={tableHejiNames}
                  modulation_transposition_cents={currentFundamentalSummary?.cents ?? 0}
                  modulation_display_active={
                    Math.abs(currentFundamentalSummary?.cents ?? 0) > 0.000001
                  }
                  heji_anchor_label_eff={structuralSettings.heji_anchor_label_effective}
                  heji_anchor_ratio_eff={structuralSettings.heji_anchor_ratio_effective}
                  heji_supported={structuralSettings.heji_supported}
                  heji_warning={structuralSettings.heji_warning}
                  keysRef={keysRef}
                  keysReadyRevision={keysReadyRevision}
                  playingSnapshotId={playingSnapshotId}
                  onPlaySnapshot={onPlaySnapshot}
                  onDeleteSnapshot={onDeleteSnapshot}
                />
                <Credits />
              </>
            )}
          </>
        </Suspense>
        {/* Keep the portal host outside Suspense and mounted across tab changes.
            Ref detach/attach updates inside a suspending subtree can otherwise
            repeatedly set App state and rebuild that same subtree. */}
        <fieldset className="io-sequencer-transport" hidden={workspaceTab !== "io" || snapshots.length === 0 || Boolean(activeManualView)}>
          <legend><b>Sequencer Transport</b></legend>
          <div id="io-sequencer-transport-host" ref={ioTransportTargetRef} />
        </fieldset>
        <div id="sidebar-spacer"></div>
      </nav>
    </div>
  );
};

export default App;
