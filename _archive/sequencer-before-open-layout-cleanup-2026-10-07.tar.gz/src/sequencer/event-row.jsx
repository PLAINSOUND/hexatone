// EventRow renders one sequencer note-on or note-off row.
// It is the leaf editor for note timing, pitch, expression, and drag/drop
// movement between snapshots, while delegating all mutation policy back up to
// the sequencer controllers.

import { useMemo } from "preact/hooks";
import { absolutePositionToBarBeat } from "./transport.js";
import {
  buildBlurCommit,
  buildDraftEnterCommit,
  buildEnterCommit,
  buildSelectAllOnFirstPointerDown,
  buildSelectOnFocus,
  buildStopPropagationProps,
} from "./field-props.js";
import {
  displayValue,
  formatDisplaySequenceOffset,
  formatEditableFrequency,
  formatEditableMidicents,
  formatFrequency,
  formatMidicents,
  formatSequenceOffset,
  formatSequenceTime,
  isOutOfSnapshotRange,
  soundingOnTextStyle,
} from "./value-runtime.js";
import {
  formatEditableSequenceScalaInterval,
  formatSequenceHejiNameForDisplay,
  formatSequenceScalaInterval,
  resolveSequenceScalaInterval,
  splitOctaveHejiName,
} from "./pitch-frame.js";

const renderCueTransport = ({
  cueIndex,
  playingSnapshotId,
  onPlayCue,
  onStopSnapshot,
  runTransportAction,
}) => (
  <span class="sequencer-event__cue-actions">
    <button
      type="button"
      class="snapshot-play-btn sequencer-event__cue-play"
      title={`Play cue ${cueIndex}`}
      aria-label={`play cue ${cueIndex}`}
      onClick={(e) => {
        e.stopPropagation();
        runTransportAction(() => onPlayCue?.(cueIndex - 1));
      }}
    >
      <span className="snapshot-play-glyph snapshot-play-glyph--play" aria-hidden="true" />
    </button>
    <button
      type="button"
      class="snapshot-play-btn snapshot-stop-btn sequencer-event__cue-stop"
      title="Stop cue playback"
      aria-label={`stop cue ${cueIndex}`}
      disabled={!playingSnapshotId}
      onClick={(e) => {
        e.stopPropagation();
        runTransportAction(() => onStopSnapshot?.());
      }}
    >
      <span class="snapshot-stop-glyph" aria-hidden="true" />
    </button>
  </span>
);

export function shouldShowCourtesyCueDot(cueIndex) {
  const displayedCueNumber = Number(cueIndex);
  return !Number.isFinite(displayedCueNumber) || Math.abs(Math.trunc(displayedCueNumber)) < 1000;
}

const renderCueMarker = ({ snapshot, event, sequenceTime, firstSnapshotCueEventIds }) => {
  if (event.cueDisplayLead) {
    return (
      <span class="sequencer-event__cue-marker" title={`Cue ${event.cueIndex} at ${sequenceTime}`}>
        <span class="sequencer-event__cue-number-wrap">
          <span class="sequencer-event__cue-number-group" aria-hidden="true">
            <span class="sequencer-event__cue-number">{event.cueIndex}</span>
          </span>
          <span class="sequencer-event__cue-dot" aria-hidden="true" />
        </span>
      </span>
    );
  }

  const isCourtesyStart =
    firstSnapshotCueEventIds.get(`${snapshot.id}:${event.cueIndex}`) === event.eventId;
  if (!isCourtesyStart) return null;

  return (
    <span
      class="sequencer-event__cue-marker sequencer-event__cue-marker--courtesy"
      title={`Cue ${event.cueIndex} continues here`}
    >
      <span class="sequencer-event__cue-number-wrap">
        <span class="sequencer-event__cue-number-group" aria-hidden="true">
          <span class="sequencer-event__cue-bracket">(</span>
          <span class="sequencer-event__cue-number">{event.cueIndex}</span>
          <span class="sequencer-event__cue-bracket">)</span>
        </span>
        {shouldShowCourtesyCueDot(event.cueIndex) ? (
          <span class="sequencer-event__cue-dot" aria-hidden="true" />
        ) : null}
      </span>
    </span>
  );
};

const EventRow = ({
  snapshot,
  snapshotIndex,
  event,
  keySuffix = "row",
  view,
  drafts,
  drag,
  editing,
  transport,
}) => {
  const stopProps = buildStopPropagationProps();
  const sourceSnapshot = view.findSnapshotById(snapshot.id) ?? snapshot;
  const noteRef = { noteId: event.noteId ?? null, noteKey: event.noteKey };
  const isMarkerSelected =
    view.selectedMarker?.snapshotId === snapshot.id &&
    view.selectedMarker?.time === event.relativeTime;
  const isCueActive = view.activeNavigationMode === "cue" && view.activeCueIndex === event.cueIndex;
  const isSnapshotActive =
    view.activeNavigationMode === "snapshot" && view.activeSnapshotId === snapshot.id;
  const isSoundingAttack =
    view.sequencePlaybackActive &&
    event.kind === "attack" &&
    (view.soundingAttackEventIds.has(event.eventId) || isCueActive || isSnapshotActive);
  const sequenceTime = formatSequenceTime(
    view.snapshotIndexById.get(snapshot.id) ?? snapshotIndex + 1,
    event.relativeTime,
  );
  const eventSnapshotNumber = view.snapshotIndexById.get(snapshot.id) ?? snapshotIndex + 1;
  const barBeat =
    drafts.barBeatByEventId?.get(event.eventId) ??
    absolutePositionToBarBeat(
      event.absoluteTime,
      drafts.sortedBars,
      event.fractionDenominator,
      9,
      drafts.terminalBarlinePosition,
      event.kind === "release",
    );
  const draftKey = drafts.eventBarRelativeDraftKey(snapshot.id, event.eventId, event.kind);
  const barRelativeDraft = drafts.barRelativeDrafts[draftKey] ?? null;
  const eventSequenceKey = drafts.eventSequenceDraftKey(snapshot.id, event.eventId, event.kind);
  const eventSequenceDraft = drafts.eventSequenceDrafts[eventSequenceKey] ?? null;
  const isEventSequenceDraftActive = eventSequenceDraft != null;
  const isBarRelativeDraftActive = view.currentEventPane === "timing" && barRelativeDraft != null;
  const beatValue = barRelativeDraft?.beat ?? String(barBeat?.beat ?? 1);
  const numeratorValue = barRelativeDraft?.numerator ?? String(barBeat?.numerator ?? 0);
  const denominatorValue = barRelativeDraft?.denominator ?? String(barBeat?.denominator ?? 1);
  const isLegatoContinuation = event.kind === "attack" && event.legatoContinuation === true;
  const canToggleReattack =
    event.kind === "attack" &&
    view.sequenceLegatoMode === "per-note" &&
    event.perNoteLegatoCandidate === true;
  const kindText = isLegatoContinuation ? "…" : event.kind === "attack" ? "on" : "off";
  const kindClass = `${isSoundingAttack ? " sequencer-event__kind--active" : ""}${event.forceReattack === true && canToggleReattack ? " sequencer-event__kind--forced-reattack" : ""}`;
  const normalizeNameInput = (eventArg) => {
    const previousName = event.hejiName || event.displayLabel || "";
    const fallbackOctave = splitOctaveHejiName(previousName)?.octave ?? 4;
    eventArg.currentTarget.value =
      formatSequenceHejiNameForDisplay(eventArg.currentTarget.value, {
        fallbackOctave,
        fallbackName: previousName,
      }) ??
      formatSequenceHejiNameForDisplay(previousName) ??
      previousName;
  };
  const resolveNameInput = (eventArg) =>
    editing.updateEventField(sourceSnapshot, noteRef, "displayLabel", eventArg.currentTarget.value);
  const lockedPitchProps = editing.snapSequenceToCurrentTuning ? {
    role: "button",
    tabIndex: 0,
    "aria-label": "Disable Snap to edit pitch",
    "data-snap-locked": "true",
    onClick: (e) => { e.stopPropagation(); editing.requestDisableSnap?.(); },
    onKeyDown: (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        editing.requestDisableSnap?.();
      }
    },
  } : {};
  // Scala resolution can parse and factor rational pitch data. Keep it out of
  // ordinary HEJI/timing cue renders, and retain the result while only the
  // playhead changes.
  const { currentScalaInterval, editableScalaInterval } = useMemo(
    () =>
      view.currentEventPane === "expression"
        ? {
            currentScalaInterval: formatSequenceScalaInterval(event, sourceSnapshot.pitchFrame),
            editableScalaInterval: formatEditableSequenceScalaInterval(
              event,
              sourceSnapshot.pitchFrame,
            ),
          }
        : { currentScalaInterval: "", editableScalaInterval: "" },
    [event, sourceSnapshot.pitchFrame, view.currentEventPane],
  );
  const normalizeScalaInput = (eventArg) => {
    const resolved = resolveSequenceScalaInterval(
      eventArg.currentTarget.value,
      sourceSnapshot.pitchFrame,
    );
    eventArg.currentTarget.value = resolved
      ? formatSequenceScalaInterval(
          { scalaIntervalDraft: resolved.intervalText },
          sourceSnapshot.pitchFrame,
        )
      : currentScalaInterval;
  };
  const resolveScalaInput = (eventArg) =>
    editing.updateEventField(
      sourceSnapshot,
      noteRef,
      "scalaInterval",
      eventArg.currentTarget.value,
    );

  return (
    <div
      key={`${event.eventId}:${keySuffix}`}
      ref={(node) => {
        if (node) drag.eventRowRefs.current.set(event.eventId, node);
        else drag.eventRowRefs.current.delete(event.eventId);
      }}
      class={`sequencer-event-row sequencer-event-row--${event.kind}${isMarkerSelected ? " sequencer-group--selected" : ""}${isCueActive ? " sequencer-event-row--cue-active" : ""}${isSnapshotActive ? " sequencer-event-row--snapshot-active" : ""}${isBarRelativeDraftActive ? " sequencer-event-row--bar-relative-draft" : ""}${isEventSequenceDraftActive ? " sequencer-event-row--sequence-draft" : ""}${drag.draggedEventId === event.eventId ? " sequencer-event-row--dragging" : ""}`}
      data-sequence-event-id={event.eventId}
      data-bar-relative-draft-scope={`event:${draftKey}`}
      data-event-sequence-draft-scope={`event-sequence:${eventSequenceKey}`}
      onClick={() => {
        editing.onSelectMarker(snapshot.id, event.relativeTime);
      }}
      onDragOver={(e) => {
        if (drag.barDragIdRef.current == null) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
      }}
      onDrop={(e) => {
        if (drag.barDragIdRef.current == null) return;
        e.preventDefault();
        drag.onMoveBar?.(drag.barDragIdRef.current, event.absoluteTime);
        drag.setDraggedBarId(null);
        drag.barDragIdRef.current = null;
      }}
    >
      <div class="sequencer-event__delete-cell">
        <button
          type="button"
          class="sequencer-gutter__delete"
          aria-label={`delete snapshot ${snapshotIndex + 1} ${event.kind} event`}
          title={`Delete snapshot ${snapshotIndex + 1} ${event.kind} event`}
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            editing.deleteEventNote(snapshot.id, noteRef);
          }}
        >
          <span class="sequencer-gutter__delete-glyph" aria-hidden="true">
            ×
          </span>
        </button>
      </div>
      <div
        class="sequencer-event__cue-cell sequencer-event__cue-cell--draggable"
        draggable="true"
        aria-label={`drag snapshot ${snapshotIndex + 1} ${event.kind} event`}
        title="Drag to move this event; Option-drag to duplicate"
        onDragStart={(e) => {
          drag.eventDragRef.current = {
            snapshotId: snapshot.id,
            noteId: event.noteId ?? null,
            noteKey: event.noteKey,
            kind: event.kind,
            eventId: event.eventId,
          };
          drag.setDraggedEventId(event.eventId);
          e.dataTransfer.effectAllowed = "copyMove";
        }}
        onDragEnd={() => {
          drag.eventDragRef.current = null;
          drag.setDraggedEventId(null);
          drag.setDragOverId(null);
        }}
      >
        {renderCueMarker({
          snapshot,
          event,
          sequenceTime,
          firstSnapshotCueEventIds: view.firstSnapshotCueEventIds,
        })}
      </div>
      <div class="sequencer-event__cell">
        <input
          type="number"
          step="1"
          min="1"
          max={String(view.snapshotIndexById.size)}
          class={`sequencer-event__input sequencer-event__input--stepper sequencer-event__snapshot-number${isEventSequenceDraftActive ? " sequencer-event__input--draft" : ""}`}
          value={eventSequenceDraft?.snapshotNumber ?? String(eventSnapshotNumber)}
          aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} snapshot`}
          {...stopProps}
          onFocus={buildSelectOnFocus({ stop: true })}
          onInput={(e) =>
            editing.updateEventSequenceDraftField(
              eventSequenceKey,
              "snapshotNumber",
              e.currentTarget.value,
              {
                snapshotId: snapshot.id,
                noteId: event.noteId ?? null,
                noteKey: event.noteKey,
                kind: event.kind,
                snapshotNumber: eventSnapshotNumber,
                relativeTime: event.relativeTime,
              },
            )
          }
          onKeyDown={buildDraftEnterCommit(() =>
            editing.applyEventSequenceDraft(drafts.eventSequenceDrafts[eventSequenceKey]),
          )}
        />
      </div>
      <div class="sequencer-event__cell sequencer-grid-offset">
        <input
          key={`${event.eventId}-offset`}
          type="text"
          class={`sequencer-event__input sequencer-event__position${isOutOfSnapshotRange(snapshot, event.relativeTime) ? " sequencer-event__position--out-of-range" : ""}${isEventSequenceDraftActive ? " sequencer-event__input--draft" : ""}`}
          defaultValue={formatDisplaySequenceOffset(
            eventSequenceDraft?.offset ?? event.relativeTime,
          )}
          aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} offset`}
          {...stopProps}
          onPointerDown={buildSelectAllOnFirstPointerDown({ stop: true })}
          onFocus={buildSelectOnFocus({
            stop: true,
            setValue: () => formatSequenceOffset(eventSequenceDraft?.offset ?? event.relativeTime),
          })}
          onInput={(e) =>
            editing.updateEventSequenceDraftField(
              eventSequenceKey,
              "offset",
              e.currentTarget.value,
              {
                snapshotId: snapshot.id,
                noteId: event.noteId ?? null,
                noteKey: event.noteKey,
                kind: event.kind,
                snapshotNumber: eventSnapshotNumber,
                relativeTime: event.relativeTime,
              },
            )
          }
          onKeyDown={buildDraftEnterCommit(() =>
            editing.applyEventSequenceDraft(drafts.eventSequenceDrafts[eventSequenceKey]),
          )}
          onBlur={(e) => {
            const value = Number(e.currentTarget.value);
            e.currentTarget.value = formatDisplaySequenceOffset(
              Number.isFinite(value) ? value : (eventSequenceDraft?.offset ?? event.relativeTime),
            );
          }}
        />
      </div>
      <div
        class={`sequencer-event__cell sequencer-event__kind-cell sequencer-grid-offset${isSoundingAttack ? " sequencer-event__kind-cell--active" : ""}`}
      >
        {canToggleReattack ? (
          <button
            type="button"
            class={`sequencer-event__content sequencer-event__kind sequencer-event__kind-toggle${kindClass}`}
            style={soundingOnTextStyle(isSoundingAttack)}
            title={
              isLegatoContinuation
                ? "Legato continuation; click to force reattack"
                : "Forced reattack; click to restore legato"
            }
            aria-label={`snapshot ${snapshotIndex + 1} ${isLegatoContinuation ? "legato continuation" : "forced reattack"}`}
            onClick={(clickEvent) => {
              clickEvent.stopPropagation();
              editing.toggleEventReattack(sourceSnapshot, noteRef);
            }}
          >
            {kindText}
          </button>
        ) : (
          <span
            class={`sequencer-event__content sequencer-event__kind${kindClass}`}
            style={soundingOnTextStyle(isSoundingAttack)}
          >
            {kindText}
          </span>
        )}
      </div>
      <div class="sequencer-event__cell sequencer-grid-offset" {...lockedPitchProps}>
        <input
          key={`${event.eventId}-midicents-${event.midicents}`}
          type="text"
          class={`sequencer-event__input${event.displayLabelEdited ? " sequencer-event__pitch-draft" : ""}`}
          defaultValue={formatMidicents(event.midicents)}
          aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} midicents`}
          {...stopProps}
          onPointerDown={buildSelectAllOnFirstPointerDown({ stop: true })}
          onFocus={buildSelectOnFocus({
            stop: true,
            clearCommitted: true,
            setValue: () => formatEditableMidicents(event.midicents),
          })}
          disabled={editing.snapSequenceToCurrentTuning}
          onKeyDown={buildEnterCommit(editing, (value) =>
            editing.updateEventField(sourceSnapshot, noteRef, "midicents", value),
          )}
          onBlur={buildBlurCommit(
            editing,
            (value) => editing.updateEventField(sourceSnapshot, noteRef, "midicents", value),
            (eventArg) => {
              const next = Number(eventArg.currentTarget.value);
              eventArg.currentTarget.value = Number.isFinite(next)
                ? formatMidicents(next)
                : formatMidicents(event.midicents);
            },
          )}
        />
      </div>
      <div class="sequencer-event__cell sequencer-grid-offset" {...lockedPitchProps}>
        <input
          key={`${event.eventId}-frequency-${event.frequency}`}
          type="text"
          class={`sequencer-event__input${event.displayLabelEdited ? " sequencer-event__pitch-draft" : ""}`}
          defaultValue={formatFrequency(event.frequency)}
          aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} frequency`}
          {...stopProps}
          onPointerDown={buildSelectAllOnFirstPointerDown({ stop: true })}
          onFocus={buildSelectOnFocus({
            stop: true,
            clearCommitted: true,
            setValue: () => formatEditableFrequency(event.frequency),
          })}
          disabled={editing.snapSequenceToCurrentTuning}
          onKeyDown={buildEnterCommit(editing, (value) =>
            editing.updateEventField(sourceSnapshot, noteRef, "frequency", value),
          )}
          onBlur={buildBlurCommit(
            editing,
            (value) => editing.updateEventField(sourceSnapshot, noteRef, "frequency", value),
            (eventArg) => {
              const next = Number(eventArg.currentTarget.value);
              eventArg.currentTarget.value = Number.isFinite(next)
                ? formatFrequency(next)
                : formatFrequency(event.frequency);
            },
          )}
        />
      </div>
      <div class="sequencer-event__cell sequencer-grid-offset" {...lockedPitchProps}>
        {view.currentEventPane === "expression" ? (
          <input
            key={`${event.eventId}-scala-${currentScalaInterval}-${event.displayLabelEdited ? "edited" : "captured"}`}
            type="text"
            class={`sequencer-event__input sequencer-event__scala${event.displayLabelEdited ? " sequencer-event__input--draft sequencer-event__pitch-draft" : ""}`}
            defaultValue={currentScalaInterval}
            aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} scala`}
            {...stopProps}
            disabled={editing.snapSequenceToCurrentTuning || !sourceSnapshot.pitchFrame}
            onFocus={buildSelectOnFocus({
              stop: true,
              clearCommitted: true,
              setValue: () => editableScalaInterval,
            })}
            onKeyDown={(eventArg) => {
              if (eventArg.key !== "Enter") return;
              eventArg.preventDefault();
              editing.handleBlurCommit(
                eventArg,
                () => resolveScalaInput(eventArg),
                () => normalizeScalaInput(eventArg),
              );
            }}
            onBlur={(eventArg) =>
              editing.handleBlurCommit(
                eventArg,
                () => resolveScalaInput(eventArg),
                () => normalizeScalaInput(eventArg),
              )
            }
          />
        ) : (
          <span class="sequencer-event__content sequencer-event__heji-wrap">
            <input
              key={`${event.eventId}-displayLabel-${event.hejiName ?? event.displayLabel ?? ""}-${event.displayLabelEdited ? "edited" : "captured"}`}
              type="text"
              class={`sequencer-event__input sequencer-event__heji${event.displayLabelEdited ? " sequencer-event__heji--edited sequencer-event__input--draft sequencer-event__pitch-draft" : ""}`}
              defaultValue={
                formatSequenceHejiNameForDisplay(event.hejiName || event.displayLabel || "") ??
                (event.hejiName || event.displayLabel || "")
              }
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} name`}
              {...stopProps}
              disabled={editing.snapSequenceToCurrentTuning}
              onFocus={buildSelectOnFocus({ stop: true, clearCommitted: true })}
              onKeyDown={(eventArg) => {
                if (eventArg.key !== "Enter") return;
                eventArg.preventDefault();
                editing.handleBlurCommit(
                  eventArg,
                  () => resolveNameInput(eventArg),
                  () => normalizeNameInput(eventArg),
                );
              }}
              onBlur={(eventArg) =>
                editing.handleBlurCommit(
                  eventArg,
                  () => resolveNameInput(eventArg),
                  () => normalizeNameInput(eventArg),
                )
              }
            />
          </span>
        )}
      </div>
      {view.currentEventPane === "timing" ? (
        <>
          <div
            key={`${event.eventId}-timing-bar`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="number"
              step="1"
              min="1"
              class={`sequencer-event__input sequencer-event__input--stepper sequencer-event__bar${isBarRelativeDraftActive ? " sequencer-event__input--draft" : ""}`}
              value={barRelativeDraft?.barNumber ?? String(barBeat?.barNumber ?? 1)}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} bar`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true })}
              onInput={(e) =>
                editing.updateEventBarRelativeDraftField(
                  draftKey,
                  barBeat,
                  "bar",
                  e.currentTarget.value,
                  {
                    snapshotId: snapshot.id,
                    noteId: event.noteId ?? null,
                    noteKey: event.noteKey,
                    kind: event.kind,
                  },
                )
              }
              onKeyDown={buildDraftEnterCommit(() =>
                editing.commitEventBarRelativeDraft(snapshot, noteRef, event.kind, draftKey),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-timing-beat`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="number"
              step="1"
              min="1"
              class={`sequencer-event__input sequencer-event__input--stepper sequencer-event__beat${isBarRelativeDraftActive ? " sequencer-event__input--draft" : ""}`}
              value={beatValue}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} beat`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true })}
              onInput={(e) =>
                editing.updateEventBarRelativeDraftField(
                  draftKey,
                  barBeat,
                  "beat",
                  e.currentTarget.value,
                  {
                    snapshotId: snapshot.id,
                    noteId: event.noteId ?? null,
                    noteKey: event.noteKey,
                    kind: event.kind,
                  },
                )
              }
              onKeyDown={buildDraftEnterCommit(() =>
                editing.commitEventBarRelativeDraft(snapshot, noteRef, event.kind, draftKey),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-timing-num`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="number"
              step="1"
              min="0"
              class={`sequencer-event__input sequencer-event__input--stepper sequencer-event__fraction-num${isBarRelativeDraftActive ? " sequencer-event__input--draft" : ""}`}
              value={numeratorValue}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} beat fraction numerator`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true })}
              onInput={(e) =>
                editing.updateEventBarRelativeDraftField(
                  draftKey,
                  barBeat,
                  "numerator",
                  e.currentTarget.value,
                  {
                    snapshotId: snapshot.id,
                    noteId: event.noteId ?? null,
                    noteKey: event.noteKey,
                    kind: event.kind,
                  },
                )
              }
              onKeyDown={buildDraftEnterCommit(() =>
                editing.commitEventBarRelativeDraft(snapshot, noteRef, event.kind, draftKey),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-timing-den`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="number"
              step="1"
              min="1"
              class={`sequencer-event__input sequencer-event__input--stepper sequencer-event__fraction-den${isBarRelativeDraftActive ? " sequencer-event__input--draft" : ""}`}
              value={denominatorValue}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} beat fraction denominator`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true })}
              onInput={(e) =>
                editing.updateEventBarRelativeDraftField(
                  draftKey,
                  barBeat,
                  "denominator",
                  e.currentTarget.value,
                  {
                    snapshotId: snapshot.id,
                    noteId: event.noteId ?? null,
                    noteKey: event.noteKey,
                    kind: event.kind,
                  },
                )
              }
              onKeyDown={buildDraftEnterCommit(() =>
                editing.commitEventBarRelativeDraft(snapshot, noteRef, event.kind, draftKey),
              )}
            />
          </div>
        </>
      ) : (
        <>
          <div
            key={`${event.eventId}-expression-onvel`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="text"
              class="sequencer-event__input"
              defaultValue={displayValue(event.attackVelocity)}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} on velocity`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true, clearCommitted: true })}
              onKeyDown={buildEnterCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "attackVelocity", value),
              )}
              onBlur={buildBlurCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "attackVelocity", value),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-expression-offvel`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="text"
              class="sequencer-event__input"
              defaultValue={displayValue(event.releaseVelocity)}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} off velocity`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true, clearCommitted: true })}
              onKeyDown={buildEnterCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "releaseVelocity", value),
              )}
              onBlur={buildBlurCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "releaseVelocity", value),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-expression-pressure`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="text"
              class="sequencer-event__input"
              defaultValue={displayValue(event.pressure)}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} pressure`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true, clearCommitted: true })}
              onKeyDown={buildEnterCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "pressure", value),
              )}
              onBlur={buildBlurCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "pressure", value),
              )}
            />
          </div>
          <div
            key={`${event.eventId}-expression-timbre`}
            class="sequencer-event__cell sequencer-grid-offset"
          >
            <input
              type="text"
              class="sequencer-event__input"
              defaultValue={displayValue(event.timbre)}
              aria-label={`snapshot ${snapshotIndex + 1} ${event.kind} timbre`}
              {...stopProps}
              onFocus={buildSelectOnFocus({ stop: true, clearCommitted: true })}
              onKeyDown={buildEnterCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "timbre", value),
              )}
              onBlur={buildBlurCommit(editing, (value) =>
                editing.updateEventField(snapshot, noteRef, "timbre", value),
              )}
            />
          </div>
        </>
      )}
      <div class="sequencer-event__actions-cell">
        {isEventSequenceDraftActive ? (
          <span class="sequencer-event__draft-actions">
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`commit snapshot ${snapshotIndex + 1} ${event.kind} sequence placement`}
              title="Commit snapshot and offset edit"
              onClick={(e) => {
                e.stopPropagation();
                editing.applyEventSequenceDraft(drafts.eventSequenceDrafts[eventSequenceKey]);
              }}
            >
              ✓
            </button>
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`cancel snapshot ${snapshotIndex + 1} ${event.kind} sequence placement`}
              title="Cancel snapshot and offset edit"
              onClick={(e) => {
                e.stopPropagation();
                editing.cancelEventSequenceDraft(eventSequenceKey);
              }}
            >
              ×
            </button>
          </span>
        ) : isBarRelativeDraftActive ? (
          <span class="sequencer-event__draft-actions">
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`commit snapshot ${snapshotIndex + 1} ${event.kind} bar-relative timing`}
              title="Commit timing edit"
              onClick={(e) => {
                e.stopPropagation();
                editing.commitEventBarRelativeDraft(snapshot, noteRef, event.kind, draftKey);
              }}
            >
              ✓
            </button>
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`cancel snapshot ${snapshotIndex + 1} ${event.kind} bar-relative timing`}
              title="Cancel timing edit"
              onClick={(e) => {
                e.stopPropagation();
                editing.cancelEventBarRelativeDraft(draftKey);
              }}
            >
              ×
            </button>
          </span>
        ) : event.kind === "attack" && event.canRestoreDisplayLabel ? (
          <span class="sequencer-event__draft-actions">
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`commit snapshot ${snapshotIndex + 1} ${event.kind} current pitch and name`}
              title="Commit current pitch and name to snapshot"
              onClick={(e) => {
                e.stopPropagation();
                editing.commitEventPitchLabel(snapshot, noteRef);
              }}
            >
              ✓
            </button>
            <button
              type="button"
              class="sequencer-event__draft-btn"
              aria-label={`restore snapshot ${snapshotIndex + 1} ${event.kind} captured pitch and name`}
              title="Restore captured pitch and name"
              onClick={(e) => {
                e.stopPropagation();
                editing.restoreEventPitchLabel(snapshot, noteRef);
              }}
            >
              ×
            </button>
          </span>
        ) : event.cueDisplayLead ||
          view.firstSnapshotCueEventIds.get(`${snapshot.id}:${event.cueIndex}`) ===
            event.eventId ? (
          renderCueTransport({
            cueIndex: event.cueIndex,
            playingSnapshotId: transport.playingSnapshotId,
            onPlayCue: transport.onPlayCue,
            onStopSnapshot: transport.onStopSnapshot,
            runTransportAction: transport.runTransportAction,
          })
        ) : null}
      </div>
    </div>
  );
};

export default EventRow;
