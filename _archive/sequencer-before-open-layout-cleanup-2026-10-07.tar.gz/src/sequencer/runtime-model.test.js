import { describe, expect, it } from "vitest";

import { buildSequenceRuntimeModel, createSequenceRuntimeModelBuilder } from "./runtime-model.js";

describe("buildSequenceRuntimeModel", () => {
  it("precomputes the sounding note set for direct manual cue lookup", () => {
    const runtime = buildSequenceRuntimeModel({
      snapshots: [
        {
          id: "s1",
          length: 1,
          notes: [
            { id: "held", midicents: 60, start: 0, end: 1 },
            { id: "later", midicents: 67, start: 0.5, end: 1 },
          ],
        },
      ],
      source: "test",
    });

    expect(
      runtime.playbackNotesByCueIndex.map((notes) => notes.map((note) => note.midicents)),
    ).toEqual([[60], [67, 60], []]);
  });

  it("keeps piled tempi in the event list in creation order", () => {
    const runtime = buildSequenceRuntimeModel({
      snapshots: [{ id: "s1", length: 2, notes: [] }],
      tempi: [
        { id: 9, position: 1, bpm: 60 },
        { id: 10, position: 1, bpm: 72 },
        { id: 11, position: 1, bpm: 84 },
      ],
      source: "test",
    });

    expect(runtime.sortedTempi.map((tempo) => tempo.id)).toEqual([9, 10, 11]);
    expect(
      runtime.sequenceEvents
        .filter((event) => event.type === "tempo")
        .map((event) => event.tempoId),
    ).toEqual([9, 10, 11]);
  });

  it("can preserve visual repeat sections while disabling repeat playback", () => {
    const snapshots = [
      {
        id: "s1",
        length: 2,
        notes: [
          { id: "held", midicents: 69, attackVelocity: 80, releaseVelocity: 40, start: 0, end: 2 },
        ],
      },
    ];
    const repeats = [
      { id: "start", position: 1, kind: "start" },
      { id: "end", position: 2, kind: "end", repeatCount: 2 },
    ];

    const withRepeats = buildSequenceRuntimeModel({
      snapshots,
      repeats,
      source: "test",
    });
    const withoutPlaybackRepeats = buildSequenceRuntimeModel({
      snapshots,
      repeats,
      playbackRepeats: [],
      source: "test",
    });

    expect(withRepeats.sequenceRepeatSections).toHaveLength(1);
    expect(withoutPlaybackRepeats.sequenceRepeatSections).toHaveLength(1);
    expect(withRepeats.timedPlaybackBursts.length).toBeGreaterThan(
      withoutPlaybackRepeats.timedPlaybackBursts.length,
    );
    expect(
      withoutPlaybackRepeats.timedPlaybackBursts.some((burst) => burst.repeatJump != null),
    ).toBe(false);
  });
});

it("reuses playback timing for label changes and invalidates it for tempo or pitch edits", () => {
  const build = createSequenceRuntimeModelBuilder();
  const snapshots = [{ id: "s", length: 1, notes: [{ midicents: 60, start: 0, end: 1 }] }];
  const options = { snapshots, playbackSnapshots: snapshots, bars: [], tempi: [], repeats: [] };
  const first = build(options);
  const relabeled = build({
    ...options,
    displaySnapshots: snapshots.map((s) => ({ ...s, name: "new label" })),
  });
  expect(relabeled.sequenceEvents).not.toBe(first.sequenceEvents);
  expect(relabeled.playbackTimeline).toBe(first.playbackTimeline);
  expect(relabeled.timedCueTriggers).toBe(first.timedCueTriggers);
  const tempo = build({ ...options, tempi: [{ id: "t", position: 1, bpm: 120 }] });
  expect(tempo.playbackTimeline).not.toBe(first.playbackTimeline);
  expect(build({ ...options, playbackSnapshots: [...snapshots] }).playbackTimeline).not.toBe(
    tempo.playbackTimeline,
  );
});
