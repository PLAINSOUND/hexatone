// This module owns direct note-row mutations inside a snapshot.
// It updates editable pitch/name/timing fields and note deletion in the shape
// expected by the sequencer UI, while leaving cross-snapshot moves to the
// higher-level sequence-operations helpers.

import {
  assignStableSequencerNoteIds,
  clamp,
  frequencyToMidicents,
  noteMatchesReference,
  sortSnapshotNotes,
} from "./value-runtime.js";
import {
  buildSnapshotRationalContext,
  rebuildSnapshotRationalIdentity,
} from "./snapshot-rational-identity.js";
import {
  deriveSequenceScalaInterval,
  formatEditableSequenceScalaInterval,
  normalizeSequenceHejiName,
  resolveSequenceScalaInterval,
  resolveSequenceHejiName,
  splitOctaveHejiName,
} from "./pitch-frame.js";

function editableNameOctave(note) {
  const existing = splitOctaveHejiName(note?.hejiName ?? note?.displayLabel);
  if (existing) return existing.octave;
  const pitch = Number(note?.originalMidicents ?? note?.midicents);
  return Number.isFinite(pitch) ? Math.floor(Math.round(pitch) / 12) - 1 : 4;
}

function editableNameOptions(note) {
  return {
    fallbackOctave: editableNameOctave(note),
    fallbackName: note?.hejiName ?? note?.displayLabel ?? null,
  };
}

function restoreEditedName(note) {
  const originalMidicents = Number(note?.originalMidicents);
  const restoresRatioText = Object.prototype.hasOwnProperty.call(note, "originalRatioText");
  const restoresMonzo = Object.prototype.hasOwnProperty.call(note, "originalMonzo");
  const restoresRationalContext = Object.prototype.hasOwnProperty.call(
    note,
    "originalRationalContext",
  );
  const restoresScalaInterval = Object.prototype.hasOwnProperty.call(note, "originalScalaInterval");
  const {
    originalMidicents: _originalMidicents,
    originalDisplayLabel,
    originalHejiName,
    originalRatioText,
    originalMonzo,
    originalRationalContext,
    originalScalaInterval,
    scalaIntervalDraft: _scalaIntervalDraft,
    displayLabelEdited: _displayLabelEdited,
    ...rest
  } = note;
  const restored = {
    ...rest,
    midicents: Number.isFinite(originalMidicents) ? originalMidicents : note.midicents,
    displayLabel: originalDisplayLabel ?? note.displayLabel,
    hejiName: originalHejiName ?? originalDisplayLabel ?? note.hejiName ?? note.displayLabel,
  };
  if (restoresRatioText) {
    if (originalRatioText !== undefined) restored.ratioText = originalRatioText;
    else delete restored.ratioText;
  }
  if (restoresMonzo) {
    if (originalMonzo !== undefined) restored.monzo = originalMonzo;
    else delete restored.monzo;
  }
  if (restoresRationalContext) {
    if (originalRationalContext !== undefined) restored.rationalContext = originalRationalContext;
    else delete restored.rationalContext;
  }
  if (restoresScalaInterval) {
    if (originalScalaInterval !== undefined) restored.scalaInterval = originalScalaInterval;
    else delete restored.scalaInterval;
  }
  return restored;
}

function rationalContextBeforeEdit(note) {
  return buildSnapshotRationalContext({
    displayLabel: note?.originalDisplayLabel ?? note?.displayLabel,
    monzo: note?.monzo,
    midicents: note?.originalMidicents ?? note?.midicents,
    existingContext: note?.rationalContext,
  });
}

export function deleteEventNoteFromSnapshot(snapshot, noteRef) {
  if (!snapshot) return null;
  const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
  const nextNotes = (snapshot.notes ?? []).filter(
    (note) => !noteMatchesReference(note, noteRef, length),
  );
  return sortSnapshotNotes(assignStableSequencerNoteIds(nextNotes, length), length);
}

export function applyEventBarRelativeDraftToSnapshot(
  snapshot,
  draft,
  absoluteTime,
  snapshotNumber,
) {
  if (!snapshot || !draft || !Number.isFinite(absoluteTime)) return null;
  const denominator = Math.max(1, Math.round(Number(draft.denominator) || 1));
  const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
  return assignStableSequencerNoteIds(
    (snapshot.notes ?? []).map((note) => {
      if (!noteMatchesReference(note, draft, length)) return note;
      const nextRelativeTime = Math.round((absoluteTime - snapshotNumber) * 1000000) / 1000000;
      if (draft.kind === "attack") {
        return {
          ...note,
          start: nextRelativeTime,
          end: Math.max(
            nextRelativeTime,
            Number.isFinite(Number(note?.end)) ? Number(note.end) : length,
          ),
          startFractionDenominator: denominator,
        };
      }
      return {
        ...note,
        end: Math.max(
          Number.isFinite(Number(note?.start)) ? Number(note.start) : 0,
          nextRelativeTime,
        ),
        endFractionDenominator: denominator,
      };
    }),
    length,
  );
}

export function updateEventFieldInSnapshot(snapshot, noteKey, field, rawValue) {
  if (!snapshot) return null;
  if (field === "scalaInterval") {
    const resolved = resolveSequenceScalaInterval(rawValue, snapshot.pitchFrame);
    if (!resolved) return null;
    const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
    return assignStableSequencerNoteIds(
      (snapshot.notes ?? []).map((note) => {
        if (!noteMatchesReference(note, noteKey, length)) return note;
        const currentInterval = formatEditableSequenceScalaInterval(note, snapshot.pitchFrame);
        if (
          currentInterval === resolved.intervalText &&
          Math.abs(Number(note.midicents) - resolved.midicents) < 0.0000005
        ) {
          return note;
        }
        return {
          ...note,
          originalMidicents: Number.isFinite(Number(note.originalMidicents))
            ? Number(note.originalMidicents)
            : Number(note.midicents),
          originalDisplayLabel: note.originalDisplayLabel ?? note.displayLabel ?? "",
          originalHejiName: note.originalHejiName ?? note.hejiName ?? note.displayLabel ?? "",
          originalRatioText: Object.prototype.hasOwnProperty.call(note, "originalRatioText")
            ? note.originalRatioText
            : note.ratioText,
          originalMonzo: Object.prototype.hasOwnProperty.call(note, "originalMonzo")
            ? note.originalMonzo
            : note.monzo,
          originalRationalContext: Object.prototype.hasOwnProperty.call(
            note,
            "originalRationalContext",
          )
            ? note.originalRationalContext
            : note.rationalContext,
          originalScalaInterval: Object.prototype.hasOwnProperty.call(
            note,
            "originalScalaInterval",
          )
            ? note.originalScalaInterval
            : note.scalaInterval,
          midicents: resolved.midicents,
          displayLabel: resolved.hejiName ?? "edited",
          hejiName: resolved.hejiName ?? "edited",
          displayLabelEdited: true,
          scalaIntervalDraft: resolved.intervalText,
        };
      }),
      length,
    );
  }
  if (field === "displayLabel") {
    const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
    return assignStableSequencerNoteIds(
      (snapshot.notes ?? []).map((note) => {
        if (!noteMatchesReference(note, noteKey, length)) return note;
        const options = editableNameOptions(note);
        const nextLabel = snapshot.pitchFrame
          ? normalizeSequenceHejiName(rawValue, options)
          : String(rawValue ?? "");
        if (!nextLabel) return restoreEditedName(note);
        if ((note.displayLabel ?? "") === nextLabel) return note;
        const originalDisplayLabel = note.originalDisplayLabel ?? note.displayLabel ?? "";
        const originalHejiName = note.originalHejiName ?? note.hejiName ?? originalDisplayLabel;
        const originalMidicents = Number.isFinite(Number(note.originalMidicents))
          ? Number(note.originalMidicents)
          : Number(note.midicents);
        const originalScalaInterval = Object.prototype.hasOwnProperty.call(
          note,
          "originalScalaInterval",
        )
          ? note.originalScalaInterval
          : note.scalaInterval;
        const originalRatioText = Object.prototype.hasOwnProperty.call(note, "originalRatioText")
          ? note.originalRatioText
          : note.ratioText;
        const originalMonzo = Object.prototype.hasOwnProperty.call(note, "originalMonzo")
          ? note.originalMonzo
          : note.monzo;
        const originalRationalContext = Object.prototype.hasOwnProperty.call(
          note,
          "originalRationalContext",
        )
          ? note.originalRationalContext
          : note.rationalContext;
        const namedPitch = resolveSequenceHejiName(nextLabel, snapshot.pitchFrame, options);
        const nextIdentity = namedPitch?.ratioText
          ? {
              ratioText: namedPitch.ratioText,
              ...(namedPitch.monzo ? { monzo: namedPitch.monzo } : {}),
            }
          : {};
        const {
          ratioText: _ratioText,
          monzo: _monzo,
          rationalContext: _rationalContext,
          scalaIntervalDraft: _scalaIntervalDraft,
          ...withoutIdentity
        } = note;
        return {
          ...withoutIdentity,
          originalDisplayLabel,
          originalHejiName,
          originalMidicents,
          originalScalaInterval,
          originalRatioText,
          originalMonzo,
          originalRationalContext,
          displayLabel: nextLabel,
          hejiName: nextLabel,
          displayLabelEdited: true,
          midicents: namedPitch?.midicents ?? note.midicents,
          ...nextIdentity,
          rationalContext: rationalContextBeforeEdit(note) ?? note.rationalContext,
        };
      }),
      length,
    );
  }
  const numeric = Number(rawValue);
  if (!Number.isFinite(numeric)) return null;
  const pitchUnchanged = (a, b) => Math.abs(Number(a) - Number(b)) < 0.0000005;
  const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;

  return assignStableSequencerNoteIds(
    (snapshot.notes ?? []).map((note) => {
      if (!noteMatchesReference(note, noteKey, length)) return note;

      const originalMidicents = Number.isFinite(Number(note.originalMidicents))
        ? Number(note.originalMidicents)
        : Number(note.midicents);
      const originalDisplayLabel = note.originalDisplayLabel ?? note.displayLabel ?? "";

      if (field === "midicents") {
        if (pitchUnchanged(numeric, note.midicents)) return note;
        const { scalaIntervalDraft: _scalaIntervalDraft, ...withoutScalaDraft } = note;
        return {
          ...withoutScalaDraft,
          midicents: numeric,
          originalMidicents,
          originalDisplayLabel,
          displayLabel: "edited",
          displayLabelEdited: true,
          rationalContext: rationalContextBeforeEdit(note) ?? note.rationalContext,
        };
      }
      if (field === "frequency") {
        const midicents = frequencyToMidicents(numeric);
        if (midicents == null || pitchUnchanged(midicents, note.midicents)) return note;
        const { scalaIntervalDraft: _scalaIntervalDraft, ...withoutScalaDraft } = note;
        return {
          ...withoutScalaDraft,
          midicents,
          originalMidicents,
          originalDisplayLabel,
          displayLabel: "edited",
          displayLabelEdited: true,
          rationalContext: rationalContextBeforeEdit(note) ?? note.rationalContext,
        };
      }
      if (field === "attackVelocity") {
        return { ...note, attackVelocity: clamp(Math.round(numeric), 0, 127) };
      }
      if (field === "releaseVelocity") {
        return { ...note, releaseVelocity: clamp(Math.round(numeric), 0, 127) };
      }
      if (field === "pressure") {
        return { ...note, pressure: clamp(Math.round(numeric), 0, 127) };
      }
      if (field === "timbre") {
        return { ...note, timbre: clamp(Math.round(numeric), 0, 127) };
      }
      return note;
    }),
    length,
  );
}

export function commitEventPitchLabelInSnapshot(snapshot, noteKey) {
  if (!snapshot) return null;
  const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
  return assignStableSequencerNoteIds(
    (snapshot.notes ?? []).map((note) => {
      if (!noteMatchesReference(note, noteKey, length)) return note;
      if (note.scalaIntervalDraft) {
        const resolved = resolveSequenceScalaInterval(note.scalaIntervalDraft, snapshot.pitchFrame);
        if (!resolved) return restoreEditedName(note);
        const {
          originalMidicents: _originalMidicents,
          originalDisplayLabel: _originalDisplayLabel,
          originalHejiName: _originalHejiName,
          originalRatioText: _originalRatioText,
          originalMonzo: _originalMonzo,
          originalRationalContext: _originalRationalContext,
          originalScalaInterval: _originalScalaInterval,
          scalaIntervalDraft: _scalaIntervalDraft,
          displayLabelEdited: _displayLabelEdited,
          ratioText: _ratioText,
          monzo: _monzo,
          rationalContext: _rationalContext,
          ...rest
        } = note;
        return {
          ...rest,
          midicents: resolved.midicents,
          scalaInterval: resolved.intervalText,
          ...(resolved.ratioText ? { ratioText: resolved.ratioText } : {}),
          ...(resolved.monzo ? { monzo: resolved.monzo } : {}),
        };
      }
      const namedPitch = resolveSequenceHejiName(note.displayLabel, snapshot.pitchFrame, {
        ...editableNameOptions(note),
      });
      if (snapshot.pitchFrame && !namedPitch) {
        return restoreEditedName(note);
      }
      if (namedPitch) {
        const {
          originalMidicents: _originalMidicents,
          originalDisplayLabel: _originalDisplayLabel,
          originalHejiName: _originalHejiName,
          originalRatioText: _originalRatioText,
          originalMonzo: _originalMonzo,
          originalRationalContext: _originalRationalContext,
          originalScalaInterval: _originalScalaInterval,
          scalaIntervalDraft: _scalaIntervalDraft,
          displayLabelEdited: _displayLabelEdited,
          rationalContext: _rationalContext,
          ratioText: _ratioText,
          monzo: _monzo,
          ...rest
        } = note;
        return {
          ...rest,
          midicents: namedPitch.midicents,
          displayLabel: namedPitch.hejiName,
          hejiName: namedPitch.hejiName,
          scalaInterval:
            namedPitch.ratioText ??
            deriveSequenceScalaInterval(
              { ...rest, ...namedPitch, displayLabelEdited: false },
              snapshot.pitchFrame,
            ),
          ...(namedPitch.ratioText ? { ratioText: namedPitch.ratioText } : {}),
          ...(namedPitch.monzo ? { monzo: namedPitch.monzo } : {}),
        };
      }
      const pitchChanged =
        Number.isFinite(Number(note.originalMidicents)) &&
        Math.abs(Number(note.originalMidicents) - Number(note.midicents)) >= 0.0000005;
      const rebuilt = rebuildSnapshotRationalIdentity(note);
      const {
        originalMidicents: _originalMidicents,
        originalDisplayLabel: _originalDisplayLabel,
        originalHejiName: _originalHejiName,
        originalRatioText: _originalRatioText,
        originalMonzo: _originalMonzo,
        originalRationalContext: _originalRationalContext,
        originalScalaInterval: _originalScalaInterval,
        scalaIntervalDraft: _scalaIntervalDraft,
        displayLabelEdited: _displayLabelEdited,
        ...rest
      } = note;
      if (rebuilt?.pitchMatches) {
        return {
          ...rest,
          ratioText: rebuilt.ratioText,
          monzo: rebuilt.monzo,
          rationalContext: rebuilt.rationalContext,
        };
      }
      if (pitchChanged || (rebuilt && !rebuilt.pitchMatches)) {
        const {
          ratioText: _ratioText,
          monzo: _monzo,
          rationalContext: _rationalContext,
          ...withoutStaleIdentity
        } = rest;
        return withoutStaleIdentity;
      }
      return rest;
    }),
    length,
  );
}

export function restoreEventPitchLabelInSnapshot(snapshot, noteKey) {
  if (!snapshot) return null;
  const length = Number.isFinite(Number(snapshot?.length)) ? Number(snapshot.length) : 1;
  return assignStableSequencerNoteIds(
    (snapshot.notes ?? []).map((note) => {
      if (!noteMatchesReference(note, noteKey, length)) return note;
      const restoresRatioText = Object.prototype.hasOwnProperty.call(note, "originalRatioText");
      const restoresMonzo = Object.prototype.hasOwnProperty.call(note, "originalMonzo");
      const restoresRationalContext = Object.prototype.hasOwnProperty.call(
        note,
        "originalRationalContext",
      );
      const restoresScalaInterval = Object.prototype.hasOwnProperty.call(
        note,
        "originalScalaInterval",
      );
      const originalMidicents = Number(note.originalMidicents);
      const canRestorePitch = Number.isFinite(originalMidicents);
      const canRestoreLabel = note.displayLabelEdited === true && note.originalDisplayLabel != null;
      if (!canRestorePitch && !canRestoreLabel) return note;
      const {
        originalMidicents: _originalMidicents,
        originalDisplayLabel,
        originalHejiName,
        originalRatioText,
        originalMonzo,
        originalRationalContext,
        originalScalaInterval,
        scalaIntervalDraft: _scalaIntervalDraft,
        displayLabelEdited: _displayLabelEdited,
        ...rest
      } = note;
      const restored = {
        ...rest,
        midicents: canRestorePitch ? originalMidicents : note.midicents,
        displayLabel: originalDisplayLabel ?? "",
        hejiName: originalHejiName ?? originalDisplayLabel ?? "",
      };
      if (restoresRatioText) {
        if (originalRatioText !== undefined) restored.ratioText = originalRatioText;
        else delete restored.ratioText;
      }
      if (restoresMonzo) {
        if (originalMonzo !== undefined) restored.monzo = originalMonzo;
        else delete restored.monzo;
      }
      if (restoresRationalContext) {
        if (originalRationalContext !== undefined)
          restored.rationalContext = originalRationalContext;
        else delete restored.rationalContext;
      }
      if (restoresScalaInterval) {
        if (originalScalaInterval !== undefined) restored.scalaInterval = originalScalaInterval;
        else delete restored.scalaInterval;
      }
      return restored;
    }),
    length,
  );
}
