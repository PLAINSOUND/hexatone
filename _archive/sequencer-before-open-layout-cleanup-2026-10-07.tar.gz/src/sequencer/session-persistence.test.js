import { describe, expect, it, beforeEach, vi } from "vitest";

import {
  createSequenceWorkspaceSessionWriter,
  SEQUENCE_WORKSPACE_STORAGE_KEY,
  clearSequenceWorkspaceSession,
  loadSequenceWorkspaceFromSession,
  saveSequenceWorkspaceToSession,
} from "./session-persistence.js";

describe("sequencer session persistence", () => {
  beforeEach(() => {
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it("round-trips the active sequencer workspace through sessionStorage", () => {
    saveSequenceWorkspaceToSession({
      snapshots: [
        {
          id: 1,
          length: 1,
          notes: [],
          manualTrigger: { articulation: "arpeggiate" },
        },
      ],
      bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
      tempi: [
        {
          id: 1,
          position: 1,
          bpm: 60,
          beatNumerator: 1,
          beatDenominator: 4,
          beatLength: 1,
          mode: "immediate",
        },
      ],
      repeats: [{ id: "r1", position: 2, kind: "end", repeatCount: 3 }],
      snapshotLabelMode: "proportion",
      activeSequenceSource: "builtin",
      activeSequenceBuiltInName: "FALL",
      activeSequenceName: "FALL",
      activeSequenceSavedName: "FALL",
      activeSequenceDescription: "demo",
      sequenceLegato: "per-note",
      snapSequenceToCurrentTuning: true,
      sequenceAutoCreateBars: true,
      manualArpeggiation: {
        mode: "per-snapshot",
        initialSpreadMs: 950,
        timingVariation: 0.27,
      },
    });

    expect(loadSequenceWorkspaceFromSession()).toEqual({
      version: 2,
      snapshots: [
        {
          id: 1,
          length: 1,
          notes: [],
          manualTrigger: {
            articulation: "arpeggiate",
            styleId: null,
            styleParameters: null,
          },
        },
      ],
      bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
      tempi: [
        {
          id: 1,
          position: 1,
          bpm: 60,
          beatNumerator: 1,
          beatDenominator: 4,
          beatLength: 1,
          mode: "immediate",
        },
      ],
      repeats: [{ id: "r1", position: 2, kind: "end", repeatCount: 3 }],
      snapshotLabelMode: "proportion",
      activeSequenceSource: "builtin",
      activeSequenceBuiltInName: "FALL",
      activeSequenceName: "FALL",
      activeSequenceSavedName: "FALL",
      activeSequenceDescription: "demo",
      sequenceLegato: "per-note",
      sequenceAutoCreateBars: true,
      manualArpeggiation: {
        mode: "per-snapshot",
        styleId: "positional",
        initialSpreadMs: 950,
        spreadVariation: 0.3,
        timingVariation: 0.27,
        decayMode: "timed",
        decayMs: 500,
        decayVariation: 0.3,
        styleParameters: {},
      },
    });
  });

  it("clears the stored sequence workspace", () => {
    saveSequenceWorkspaceToSession({ snapshots: [{ id: 1, length: 1, notes: [] }] });
    clearSequenceWorkspaceSession();
    expect(loadSequenceWorkspaceFromSession()).toBeNull();
  });

  it("migrates the former checked Legato value to All Common Tones", () => {
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({ snapshots: [], sequenceLegato: true }),
    );

    expect(loadSequenceWorkspaceFromSession().sequenceLegato).toBe("all-common-tones");
  });
});

it("writes a workspace revision once and saves subsequent edits synchronously", () => {
  const save = createSequenceWorkspaceSessionWriter();
  const workspace = { snapshots: [{ id: "s", notes: [] }], activeSequenceName: "first" };
  const spy = vi.spyOn(Storage.prototype, "setItem");
  try {
    save(workspace);
    save({ ...workspace });
    expect(spy).toHaveBeenCalledTimes(1);
    save({ ...workspace, activeSequenceName: "edited" });
    expect(spy).toHaveBeenCalledTimes(2);
    expect(loadSequenceWorkspaceFromSession().activeSequenceName).toBe("edited");
  } finally {
    spy.mockRestore();
  }
});
