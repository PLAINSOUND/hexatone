import { expect, it, vi } from "vitest";
import seeds from "./preset-sequences/marc-sabat/Seeds-of-Skies-Alibis.json";
import tree from "../hexatone/preset-tunings/odd-partial-pitch-class-sets/81-47-limit-256-sabat-the-tree.json";
import { scalaToCents } from "../settings/scale/parse-scale.js";
import { create_composite_synth } from "../composite_synth/index.js";
import { playSnapshot, retuneActiveSnapshotHexes, retuneSnapshotHexes,
  beginSnapshotGesture, attackSnapshotGestureNote, remapActiveSnapshotHexes,
  stopSnapshotGesture } from "./snapshots.js";
import { remapSequenceNoteToRuntime, resolveLiveSequencePitch, resolveSequenceSnapRuntime } from "./runtime-pitch-map.js";

const frequency = (note) => 440 * 2 ** ((note.midicents - 69) / 12);

it("uses 441 Hz before the live keyboard has caught up with the fundamental change", () => {
  const scale = [0, ...tree.scale.slice(0, -1).map(scalaToCents)];
  const old = { scale, fundamental: 440, referenceDegree: tree.reference_degree, equivInterval: 1200 };
  const tuning = resolveSequenceSnapRuntime({ ...tree, fundamental: 441 }, old, tree);
  expect(tuning.fundamental).toBe(441);
  const notes = seeds.snapshots.find(snapshot => snapshot.id === 6).notes;
  notes.forEach(note => expect(resolveLiveSequencePitch(note, tuning).frequency)
    .toBeCloseTo(frequency(note) * 441 / 440, 8));
});

it("snaps Seeds snapshot 6 to the same JI chord at 441 Hz in Sabat the Tree", () => {
  const notes = seeds.snapshots.find(snapshot => snapshot.id === 6).notes;
  const scale = [0, ...tree.scale.slice(0, -1).map(scalaToCents)];
  const tuning = { scale, fundamental: 441, referenceDegree: tree.reference_degree, equivInterval: 1200 };
  const reference = { fundamental: 441, cents: scale[tree.reference_degree],
    ratio: 2 ** (scale[tree.reference_degree] / 1200) };
  const engine = output(reference);
  const runtime = {
    settings: { fundamental: 441, midi_velocity: 72 },
    tuning: { degree0toRef_asArray: [reference.cents, reference.ratio], equivSteps: scale.length },
    state: { sustainedNotes: [] }, stopSnapshot: vi.fn(),
    synth: create_composite_synth([engine], new Set(), reference),
  };
  const snapped = notes.map(note => resolveLiveSequencePitch(note, tuning));
  runtime._snapshotHexes = playSnapshot(runtime, snapped);
  engine.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]) * 441 / 440, 8));
});

it("retunes held and queued Seeds arpeggio notes from their original pitches with Snap active", () => {
  const notes = seeds.snapshots.find(snapshot => snapshot.notes.length >= 4).notes;
  const planned = notes.map(note => resolveLiveSequencePitch(note));
  const reference = { fundamental: 440, cents: 0, ratio: 1 };
  const engine = output(reference);
  const runtime = {
    settings: { fundamental: 440, midi_velocity: 72 },
    tuning: { degree0toRef_asArray: [0, 1], equivSteps: 1 },
    state: { sustainedNotes: [] },
    synth: create_composite_synth([engine], new Set(), reference),
  };
  beginSnapshotGesture(runtime, "seeds");
  attackSnapshotGestureNote(runtime, "seeds", planned[0]);
  for (const [index, divisions] of [7, 19, 12].entries()) {
    const tuning = {
      fundamental: 440, referenceDegree: 0, equivInterval: 1200,
      scale: Array.from({ length: divisions }, (_, degree) => degree * 1200 / divisions),
    };
    remapActiveSnapshotHexes(runtime, note => resolveLiveSequencePitch(note, tuning));
    attackSnapshotGestureNote(runtime, "seeds", resolveLiveSequencePitch(planned[index + 1], tuning));
    engine.voices.forEach((voice, i) => {
      expect(voice.frequency()).toBeCloseTo(frequency(remapSequenceNoteToRuntime(notes[i], tuning)), 8);
    });
  }
  stopSnapshotGesture(runtime, "seeds");
  engine.voices.forEach(voice => expect(voice.noteOff).toHaveBeenCalledOnce());
  expect(runtime._snapshotVoiceOwners.size).toBe(0);
  expect(runtime._soundingSnapshotHexes.size).toBe(0);
});
function output(reference) {
  const voices = [];
  return {
    voices,
    setTuningReference(fundamental) { reference = { ...reference, fundamental }; },
    makeHex(coords, cents, ...args) {
      const fundamental = reference.fundamental;
      const ratio = args[8];
      const voice = {
        coords, cents, noteOn: vi.fn(), noteOff: vi.fn(),
        retune(target) { this.cents = target; },
        standardWheelRetune(target) { this.cents = target; },
        frequency() { return fundamental / ratio * 2 ** (this.cents / 1200); },
      };
      voices.push(voice);
      return voice;
    },
  };
}

it("keeps Seeds of Skies absolute pitches through a first preset and delayed output handoff", () => {
  const notes = seeds.snapshots.find((snapshot) => snapshot.notes.length > 0).notes;
  const neutral = { fundamental: 440, cents: 0, ratio: 1 };
  const preset = { fundamental: 432, cents: 700, ratio: 2 ** (700 / 1200) };
  const old = output(neutral);
  const runtime = {
    settings: { fundamental: 440, midi_velocity: 72 },
    tuning: { degree0toRef_asArray: [0, 1], equivSteps: 1 },
    state: { sustainedNotes: [] },
    stopSnapshot: vi.fn(),
    synth: create_composite_synth([old], new Set(), neutral),
  };
  runtime._snapshotHexes = playSnapshot(runtime, notes);
  old.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));

  // The canvas changes before its asynchronous replacement outputs are ready.
  runtime.settings.fundamental = preset.fundamental;
  runtime.tuning = { degree0toRef_asArray: [preset.cents, preset.ratio], equivSteps: 12 };
  retuneSnapshotHexes(runtime, notes, { sequencePitch: true });
  old.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));
  const waitingVoices = playSnapshot(runtime, notes);
  old.voices.slice(notes.length).forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));

  const replacement = output(preset);
  runtime.synth = create_composite_synth([replacement], new Set(), preset);
  waitingVoices.forEach((voice) => voice.reconcileSynths([replacement]));
  runtime._snapshotHexes = waitingVoices;
  replacement.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));

  // Playback transposition still works after changing the reference.
  retuneActiveSnapshotHexes(runtime, 100);
  replacement.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]) * 2 ** (1 / 12), 8));

  // Explicit snapping remains a real pitch change, not bypassed by the handoff.
  const snapped = notes.map((note) => remapSequenceNoteToRuntime(note, {
    fundamental: 432, referenceDegree: 0, scale: [0, 1200], equivInterval: 1200,
  }));
  retuneSnapshotHexes(runtime, snapped, { sequencePitch: true });
  replacement.voices.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(snapped[i]), 8));
  expect(snapped.some((note, i) => Math.abs(note.midicents - notes[i].midicents) > 0.01)).toBe(true);

  playSnapshot(runtime, notes);
  replacement.voices.slice(notes.length).forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));
  // Ordinary canvas pitches must still use the selected tuning reference.
  const canvas = runtime.synth.makeHex({ x: 0, y: 0 }, 700, 0, 0, 12, 700, 700,
    undefined, 72, 0, preset.ratio);
  canvas.noteOn();
  expect(replacement.voices.at(-1).frequency()).toBeCloseTo(432, 8);

  // Reuse the same running engine across another preset: queued/held arpeggio
  // notes retain their old reference, while new notes use the new reference.
  const held = replacement.voices.slice(0, notes.length);
  replacement.setTuningReference(466);
  runtime.settings.fundamental = 466;
  runtime.tuning = { degree0toRef_asArray: [0, 1], equivSteps: 1 };
  runtime.synth = create_composite_synth([replacement], new Set(), {
    fundamental: 466, cents: 0, ratio: 1,
  });
  retuneSnapshotHexes(runtime, notes, { sequencePitch: true });
  held.forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));
  const previousCount = replacement.voices.length;
  playSnapshot(runtime, notes);
  replacement.voices.slice(previousCount).forEach((voice, i) => expect(voice.frequency()).toBeCloseTo(frequency(notes[i]), 8));
});
