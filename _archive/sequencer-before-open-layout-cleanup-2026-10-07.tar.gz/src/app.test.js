/**
 * Tests for src/app.jsx
 *
 * The App component has deep dependencies (WebMidi, AudioContext, canvas,
 * SVG imports) that make full integration testing expensive. These tests
 * cover what can be verified without a real browser environment:
 *
 * - The Loading spinner component renders
 * - The useQuery extractors used by App work correctly (covered in use-query.test.js)
 *
 * Broader App rendering tests (settings panel toggle, keyboard visibility)
 * require a more complete browser mock and are left as todos for future work.
 */

import { fireEvent, render, waitFor, screen } from "@testing-library/preact";
import userEvent from "@testing-library/user-event";
import { act } from "preact/test-utils";
import { parseExactInterval } from "./tuning/interval.js";
import { SEQUENCE_WORKSPACE_STORAGE_KEY } from "./sequencer/session-persistence.js";
import { CALCULATOR_WORKSPACE_STORAGE_KEY } from "./calculator/session-persistence.js";
import { chooseChordSteps } from "./sequencer/chord-snap.js";

let lastKeyboardProps = null;
let lastUsePresetsOptions = null;
let mockDetectedController = null;
let mockControllerById = null;
let pendingIOSettingsLoad = null;
const { guardianPanicMock } = vi.hoisted(() => ({ guardianPanicMock: vi.fn() }));

vi.mock("normalize.css", () => ({}));
vi.mock("./hex-style.css", () => ({}));
vi.mock("./loader.css", () => ({}));

vi.mock("./keyboard", () => ({
  default: (props) => {
    lastKeyboardProps = props;
    return <div data-testid="keyboard">Keyboard Stub</div>;
  },
}));
vi.mock("./settings", () => ({
  default: () => <div data-testid="settings">Settings Stub</div>,
}));
vi.mock("./settings/io-settings.jsx", () => ({
  default: ({ onOscBrightnessChange }) => {
    if (pendingIOSettingsLoad) throw pendingIOSettingsLoad;
    return <div data-testid="io-settings">I/O Settings Stub
      <button onClick={() => onOscBrightnessChange(1)}>Test Brightness</button>
    </div>;
  },
}));
vi.mock("./credits", () => ({
  default: () => <div>Credits Stub</div>,
}));
vi.mock("./manual/manual-sidebar.jsx", () => ({
  default: ({ initialSectionTitle, onSectionChange, onClose }) => (
    <div data-testid="manual-sidebar" data-initial-section-title={initialSectionTitle}>
      Manual Stub
      <button type="button" onClick={() => onSectionChange?.("Quick Start")}>
        Select Quick Start
      </button>
      {onClose ? (
        <button type="button" onClick={onClose}>
          Close contextual manual
        </button>
      ) : null}
    </div>
  ),
}));
vi.mock("./sample_synth/instruments", () => ({ instruments: [] }));
vi.mock("./keyboard/keycodes", () => ({ default: {} }));
vi.mock("./settings/normalize-settings.js", () => ({
  normalizeColors: (s) => s,
  normalizeStructural: (s) => s,
}));

const synthWiringState = {
  synth: null,
  midi: null,
  midiAccess: "none",
  midiAccessError: null,
  ensureMidiAccess: vi.fn(),
  midiTick: 0,
  loading: 0,
  midiLearnActive: false,
  setMidiLearnActive: vi.fn(),
  octaveTranspose: 0,
  setOctaveTranspose: vi.fn(),
  octaveDeferred: false,
  shiftOctave: vi.fn(),
  resetOctave: vi.fn(),
  toggleOctaveDeferred: vi.fn(),
  onVolumeChange: vi.fn(),
  oscBrightness: 0,
  onOscBrightnessChange: vi.fn(),
  onAnchorLearn: vi.fn(),
  lumatoneRawPorts: null,
  exquisRawPorts: null,
  linnstrumentRawPorts: null,
  hakenRawPorts: null,
};

let settings = {
  rSteps: 1,
  drSteps: 5,
  hexSize: 60,
  rotation: 0,
  scale: ["100.", "200.", "1200."],
  equivSteps: 3,
  note_names: ["A", "B", "C"],
  note_colors: ["#ffffff", "#eeeeee", "#dddddd"],
  key_labels: "no_labels",
  spectrum_colors: false,
  fundamental_color: "#ffffff",
  reference_degree: 0,
  center_degree: 0,
  fundamental: 440,
  instrument: "OFF",
  output_sample: false,
  output_mts: false,
  output_mpe: false,
  output_mts_bulk: false,
  output_osc: false,
  midiin_device: "OFF",
  midiin_controller_override: "auto",
  midiin_mapping_target: "hex_layout",
  midiin_anchor_channel: 1,
  midiin_anchor_note: 60,
  midiin_channel_group_size: 1,
  midiin_channel_legacy: false,
  midiin_scale_tolerance: 25,
  midiin_scale_fallback: "accept",
  midiin_pitchbend_mode: "recency",
  midiin_pressure_mode: "recency",
  wheel_to_recent: false,
  midiin_bend_range: "28/27",
  wheel_scale_aware: false,
  midi_wheel_semitones: 2,
  midiin_bend_flip: false,
  midiin_scale_bend_range: 48,
  midi_passthrough: false,
  midiin_mpe_input: false,
  midiin_steps_per_channel: 0,
};

vi.mock("./hooks/use-query", () => ({
  useQuery: () => [settings, vi.fn()],
  ExtractInt: {},
  ExtractString: {},
  ExtractFloat: {},
  ExtractBool: {},
  ExtractJoinedString: {},
}));
vi.mock("./hooks/use-presets.js", () => ({
  default: (_settings, _setSettings, options) => {
    lastUsePresetsOptions = options;
    return {
      activeSource: "",
      activePresetName: "",
      isPresetDirty: false,
      persistOnReload: false,
      setPersistOnReload: vi.fn(),
      presetChanged: vi.fn(),
      onLoadCustomPreset: vi.fn(),
      onClearUserPresets: vi.fn(),
      onRevertBuiltin: vi.fn(),
      onRevertUser: vi.fn(),
      onUserScaleEdit: vi.fn(),
    };
  },
  SCALE_KEYS_TO_CLEAR: [],
}));
vi.mock("./hooks/use-import.js", () => ({
  default: () => ({
    onImport: vi.fn(),
    importCount: 0,
    bumpImportCount: vi.fn(),
  }),
}));
vi.mock("./hooks/use-settings-change.js", () => ({
  default: () => ({
    onChange: vi.fn(),
    onAtomicChange: vi.fn(),
  }),
}));
vi.mock("./hooks/use-synth-wiring.js", () => ({
  default: () => synthWiringState,
}));
vi.mock("./hooks/use-midi-guardian.js", () => ({
  useMidiGuardian: () => ({ panic: guardianPanicMock }),
}));
vi.mock("./persistence/settings-registry.js", () => ({
  SETTINGS_REGISTRY: [],
  buildQuerySpec: () => ({}),
  buildRegistryDefaults: () => ({}),
  PRESET_SKIP_KEYS: [],
}));
vi.mock("./settings/session-defaults.js", () => ({ default: {} }));
vi.mock("./controllers/exquis-leds.js", () => ({ ExquisLEDs: class {} }));
vi.mock("./controllers/lumatone-leds.js", () => ({ LumatoneLEDs: class {} }));
vi.mock("./controllers/linnstrument-user-firmware.js", () => ({
  attachLinnstrumentLedDriver: vi.fn(() => ({ userFirmwareActive: false })),
  activateLinnstrumentUserFirmware: vi.fn(),
  deactivateLinnstrumentUserFirmware: vi.fn(),
  detachLinnstrumentLedDriver: vi.fn(),
}));
vi.mock("./controllers/registry.js", () => ({
  detectController: () => mockDetectedController,
  getControllerById: () => mockControllerById,
  getControllerMpeInputPolicy: (controller) => controller?.mpeInputPolicy ?? "never",
  controllerRequiresMpeInput: (controller) => controller?.mpeInputPolicy === "always",
}));

// ── Loading spinner ───────────────────────────────────────────────────────────
// Loading is a trivially simple named export — just verify it renders without
// throwing. The SVG content is mocked by the asset stub.

vi.mock("./loading-icon.jsx", () => ({
  default: () => <svg data-testid="loading-icon" />,
}));

import {
  applyReloadPersistencePolicy,
  autoSyncLumatoneSurface,
  bindControllerLedRefs,
  commitModulationHistoryToPreset,
  getDefaultSnapshotPalettePos,
  loadReloadWorkspaceTab,
  Loading,
  modulationCurrentSummaryDisplay,
  modulationRouteLabelPair,
  RELOAD_WORKSPACE_TAB_KEY,
  saveReloadWorkspaceTab,
  sendLumatoneColorsNow,
} from "./app";
import App from "./app";
import {
  attachLinnstrumentLedDriver,
  deactivateLinnstrumentUserFirmware,
} from "./controllers/linnstrument-user-firmware.js";

describe("floating palette placement", () => {
  it("uses the snapshot palette width beside a wide auxiliary sidebar", () => {
    const originalInnerWidth = window.innerWidth;
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 900 });
    const sidebar = document.createElement("nav");
    sidebar.id = "sidebar";
    sidebar.getBoundingClientRect = () => ({
      bottom: 700,
      height: 700,
      left: 0,
      right: 600,
      top: 0,
      width: 600,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    });
    const snapshot = document.createElement("div");
    snapshot.id = "snapshot-palette";
    snapshot.getBoundingClientRect = () => ({
      bottom: 500,
      height: 280,
      left: 18,
      right: 178,
      top: 220,
      width: 160,
      x: 18,
      y: 220,
      toJSON: () => ({}),
    });
    document.body.append(sidebar, snapshot);

    expect(getDefaultSnapshotPalettePos()).toEqual({ x: 616, y: 234 });

    sidebar.remove();
    snapshot.remove();
    Object.defineProperty(window, "innerWidth", {
      configurable: true,
      value: originalInnerWidth,
    });
  });
});

describe("Loading", () => {
  it("renders without crashing", () => {
    const { container } = render(<Loading />);
    expect(container).not.toBeNull();
  });

  it("renders the loading icon SVG", () => {
    const { getByTestId } = render(<Loading />);
    expect(getByTestId("loading-icon")).not.toBeNull();
  });
});

describe("applyReloadPersistencePolicy", () => {
  it("does not clear I/O access or auto-send intent when clearing the preset", () => {
    for (const key of ["webmidi_access", "mts_bulk_sysex_auto"])
      sessionStorage.setItem(key, "retained");
    applyReloadPersistencePolicy({ navigationType: "reload", shouldPersist: false });
    for (const key of ["webmidi_access", "mts_bulk_sysex_auto"]) {
      expect(sessionStorage.getItem(key)).toBe("retained");
      sessionStorage.removeItem(key);
    }
  });
  it("clears the query string on reload when restore-on-reload is disabled", () => {
    history.replaceState({}, "", "http://localhost/?scale=3/2,2/1&instrument=WMRIByzantineST");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({ snapshots: [{ id: 1 }] }),
    );
    sessionStorage.setItem(CALCULATOR_WORKSPACE_STORAGE_KEY, JSON.stringify({ state: {} }));

    applyReloadPersistencePolicy({ navigationType: "reload", shouldPersist: false });

    expect(window.location.search).toBe("");
    expect(sessionStorage.getItem(SEQUENCE_WORKSPACE_STORAGE_KEY)).toBeNull();
    expect(sessionStorage.getItem(CALCULATOR_WORKSPACE_STORAGE_KEY)).toBeNull();
  });

  it("keeps the visible Sequencer or Calculator tab independent of preset restoration", () => {
    sessionStorage.setItem(RELOAD_WORKSPACE_TAB_KEY, "calculator");

    applyReloadPersistencePolicy({ navigationType: "reload", shouldPersist: false });

    expect(sessionStorage.getItem(RELOAD_WORKSPACE_TAB_KEY)).toBe("calculator");
  });

  it("keeps the query string on reload when restore-on-reload is enabled", () => {
    history.replaceState({}, "", "http://localhost/?scale=3/2,2/1&instrument=WMRIByzantineST");

    applyReloadPersistencePolicy({ navigationType: "reload", shouldPersist: true });

    expect(window.location.search).toBe("?scale=3/2,2/1&instrument=WMRIByzantineST");
  });
});

describe("reload workspace tab", () => {
  beforeEach(() => {
    sessionStorage.removeItem(RELOAD_WORKSPACE_TAB_KEY);
    localStorage.removeItem("hexatone_restore_io_on_reload");
  });

  it.each(["sequencer", "calculator"])("restores the %s workspace", (workspaceTab) => {
    saveReloadWorkspaceTab(workspaceTab);

    expect(loadReloadWorkspaceTab()).toBe(workspaceTab);
  });

  it.each(["hexatone", "manual"])(
    "returns to Hexatone after leaving the %s workspace active",
    (workspaceTab) => {
      sessionStorage.setItem(RELOAD_WORKSPACE_TAB_KEY, "sequencer");

      saveReloadWorkspaceTab(workspaceTab);

      expect(loadReloadWorkspaceTab()).toBe("hexatone");
      expect(sessionStorage.getItem(RELOAD_WORKSPACE_TAB_KEY)).toBeNull();
    },
  );

  it("restores I/O only while its restore preference is enabled", () => {
    saveReloadWorkspaceTab("io");
    expect(loadReloadWorkspaceTab()).toBe("io");
    localStorage.setItem("hexatone_restore_io_on_reload", "false");
    expect(loadReloadWorkspaceTab()).toBe("hexatone");
    // Changing the checkbox while remaining in I/O must take effect too.
    localStorage.setItem("hexatone_restore_io_on_reload", "true");
    expect(loadReloadWorkspaceTab()).toBe("io");
    localStorage.removeItem("hexatone_restore_io_on_reload");
  });

  it("falls back to Hexatone when stored navigation state is invalid", () => {
    sessionStorage.setItem(RELOAD_WORKSPACE_TAB_KEY, "unknown");

    expect(loadReloadWorkspaceTab()).toBe("hexatone");
  });
});

beforeEach(() => {
  sessionStorage.removeItem(RELOAD_WORKSPACE_TAB_KEY);
  sessionStorage.removeItem(CALCULATOR_WORKSPACE_STORAGE_KEY);
  lastKeyboardProps = null;
  lastUsePresetsOptions = null;
  mockDetectedController = null;
  mockControllerById = null;
  synthWiringState.linnstrumentRawPorts = null;
  synthWiringState.hakenRawPorts = null;
  settings = {
    ...settings,
    midiin_mpe_manager_ch: undefined,
  };
  vi.clearAllMocks();
});

describe("Haken Continuum config", () => {
  it("sends the Continuum MPE+ setup burst when a Haken output is available", async () => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    const output = {
      id: "haken-out-1",
      sendControlChange: vi.fn(),
    };
    synthWiringState.hakenRawPorts = {
      input: { id: "haken-in-1" },
      output,
    };
    settings = {
      ...settings,
      midiin_mpe_manager_ch: 3,
    };

    render(<App />);

    await waitFor(() => {
      expect(output.sendControlChange).toHaveBeenCalled();
    });

    expect(output.sendControlChange).toHaveBeenCalledWith(101, 0, { channels: 3 });
    expect(output.sendControlChange).toHaveBeenCalledWith(100, 0, { channels: 3 });
    expect(output.sendControlChange).toHaveBeenCalledWith(6, 96, { channels: 3 });
    expect(output.sendControlChange).toHaveBeenCalledWith(38, 0, { channels: 3 });
    expect(output.sendControlChange).toHaveBeenCalledWith(101, 127, { channels: 3 });
    expect(output.sendControlChange).toHaveBeenCalledWith(100, 127, { channels: 3 });
  });
});

describe("preset runtime reset wiring", () => {
  it("changes the keyboard reconstruction key only when the sidebar preset refresh path requests it", async () => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    render(<App />);

    await waitFor(() => {
      expect(lastKeyboardProps).not.toBeNull();
      expect(lastUsePresetsOptions?.bumpPresetRuntimeReset).toBeTypeOf("function");
    });

    const initialReconstructionKey = lastKeyboardProps.reconstructionKey;

    await act(async () => {
      lastUsePresetsOptions.bumpPresetRuntimeReset();
    });

    await waitFor(() => {
      expect(lastKeyboardProps.reconstructionKey).not.toBe(initialReconstructionKey);
    });
  });
});

describe("sequence-only playback surface", () => {
  it("mounts a hidden playback runtime when a sequence is loaded without a Hexatone scale", async () => {
    const previousSettings = settings;
    settings = {
      ...settings,
      scale: null,
      note_names: null,
      note_colors: null,
    };
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [
          {
            id: 1,
            length: 1,
            notes: [{ id: "note-1", midicents: 69, attackVelocity: 72 }],
          },
        ],
        bars: [],
        tempi: [],
        repeats: [],
      }),
    );

    const { unmount } = render(<App />);

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    expect(lastKeyboardProps.hidden).toBe(true);
    expect(lastKeyboardProps.settings.scale).toEqual([0]);
    expect(lastKeyboardProps.tuningRuntime).toMatchObject({
      scale: [0],
      equivSteps: 1,
      degree0toRefAsArray: [0, 1],
    });

    unmount();
    settings = previousSettings;
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });
});

describe("modulationRouteLabelPair", () => {
  it("omits the equave annotation for an octave-displaced target ratio", () => {
    const pair = modulationRouteLabelPair(
      {
        sourceDegree: 0,
        targetDegree: 6,
        transpositionRatioText: "8/7",
      },
      (degree) => (degree === 0 ? "1/1" : degree === 6 ? "7/4" : String(degree)),
      {
        baseScale: {
          equaveCents: 1200,
        },
        lookup: {
          byDegree: new Map([
            [0, { cents: parseExactInterval("1/1").cents }],
            [6, { cents: parseExactInterval("7/4").cents }],
          ]),
        },
      },
    );

    expect(pair).toEqual({
      sourceLabel: "1/1",
      targetLabel: "7/4",
    });
  });
});

describe("commitModulationHistoryToPreset", () => {
  it("rewrites the current modulation into a new exact scale and clears history", async () => {
    const { createScaleWorkspace } = await import("./tuning/workspace.js");
    const workspace = createScaleWorkspace({
      scale: ["9/8", "5/4", "4/3", "2/1"],
      fundamental: 440,
      reference_degree: 0,
    });

    const committed = commitModulationHistoryToPreset(
      {
        scale: ["9/8", "5/4", "4/3", "2/1"],
        note_names: ["1/1", "9/8", "5/4", "4/3"],
        note_colors: ["#111111", "#222222", "#333333", "#444444"],
        key_labels: "note_names",
        fundamental: 440,
        reference_degree: 0,
      },
      workspace,
      [
        {
          sourceDegree: 0,
          targetDegree: 2,
          count: 1,
          transpositionDeltaCents: -parseExactInterval("5/4").cents,
          transpositionRatioText: "4/5",
        },
      ],
      {
        hejiAnchorLabel: "A",
        hejiAnchorRatio: "1/1",
      },
    );

    expect(committed.scale).toEqual(["16/15", "8/5", "9/5", "2/1"]);
    expect(committed.note_names).toEqual(["5/4", "4/3", "1/1", "9/8"]);
    expect(committed.note_colors).toEqual(["#111111", "#222222", "#333333", "#444444"]);
    expect(committed.fundamental).toBeCloseTo(440 / 1.25, 6);
    expect(committed.reference_degree).toBe(0);
    expect(committed.heji_anchor_ratio).toBe("1/1");
  });
});

describe("modulationCurrentSummaryDisplay", () => {
  it("renders signed cents without monzo or equave annotations for exact ratios", () => {
    expect(
      modulationCurrentSummaryDisplay({
        ratioText: "7/8",
        cents: parseExactInterval("7/8").cents,
      }),
    ).toBe("-231¢");
  });

  it("renders cents only when the current ratio is not exact", () => {
    expect(
      modulationCurrentSummaryDisplay({
        ratioText: null,
        cents: 12.345,
      }),
    ).toBe("+12¢");
  });
});

describe("legacy modulation row interval fallback", () => {
  it("can derive an exact row monzo from workspace ratios when ratio text was not stored", async () => {
    const { createScaleWorkspace } = await import("./tuning/workspace.js");
    const workspace = createScaleWorkspace({
      scale: ["9/8", "5/4", "4/3", "2/1"],
      fundamental: 440,
      reference_degree: 0,
    });

    const committed = commitModulationHistoryToPreset(
      {
        scale: ["9/8", "5/4", "4/3", "2/1"],
        note_names: ["1/1", "9/8", "5/4", "4/3"],
        note_colors: ["#111111", "#222222", "#333333", "#444444"],
        key_labels: "note_names",
        fundamental: 440,
        reference_degree: 0,
      },
      workspace,
      [
        {
          sourceDegree: 0,
          targetDegree: 2,
          count: 1,
          transpositionDeltaCents: -parseExactInterval("5/4").cents,
        },
      ],
      {
        hejiAnchorLabel: "A",
        hejiAnchorRatio: "1/1",
      },
    );

    expect(committed.scale).toEqual(["16/15", "8/5", "9/5", "2/1"]);
  });
});

describe("bindControllerLedRefs", () => {
  it("attaches a Lumatone driver and triggers auto-sync when enabled", () => {
    const keys = {
      settings: { lumatone_led_sync: true },
      autoSyncLumatoneLEDs: vi.fn(),
    };
    const leds = { id: "lumatone-leds" };

    bindControllerLedRefs(keys, { lumatone: leds });

    expect(keys.lumatoneLEDs).toBe(leds);
    expect(keys.autoSyncLumatoneLEDs).toHaveBeenCalledTimes(1);
  });

  it("attaches a ready Exquis driver and triggers sync when enabled", () => {
    const keys = {
      settings: { exquis_led_sync: true },
      syncExquisLEDs: vi.fn(),
    };
    const leds = { ready: true };

    bindControllerLedRefs(keys, { exquis: leds });

    expect(keys.exquisLEDs).toBe(leds);
    expect(keys.syncExquisLEDs).toHaveBeenCalledTimes(1);
  });

  it("attaches a LinnStrument driver without triggering an eager sync", () => {
    const keys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };
    const leds = { id: "linn-leds" };

    bindControllerLedRefs(keys, { linnstrument: leds });

    expect(keys.linnstrumentLEDs).toBe(leds);
    expect(keys.syncLinnstrumentLEDs).not.toHaveBeenCalled();
  });

  it("clears individual bindings without touching the others", () => {
    const keys = {
      settings: {},
      lumatoneLEDs: { id: "l" },
      exquisLEDs: { id: "e" },
      linnstrumentLEDs: { id: "n" },
      autoSyncLumatoneLEDs: vi.fn(),
      syncExquisLEDs: vi.fn(),
      syncLinnstrumentLEDs: vi.fn(),
    };

    bindControllerLedRefs(keys, { lumatone: null });

    expect(keys.lumatoneLEDs).toBeNull();
    expect(keys.exquisLEDs).toEqual({ id: "e" });
    expect(keys.linnstrumentLEDs).toEqual({ id: "n" });
    expect(keys.autoSyncLumatoneLEDs).not.toHaveBeenCalled();
    expect(keys.syncExquisLEDs).not.toHaveBeenCalled();
    expect(keys.syncLinnstrumentLEDs).not.toHaveBeenCalled();
  });
});

describe("sendLumatoneColorsNow", () => {
  it("repairs a stale driver binding before a manual colour send", () => {
    const staleLeds = { id: "stale" };
    const currentLeds = { id: "current" };
    const keys = {
      settings: { lumatone_led_sync: false },
      lumatoneLEDs: staleLeds,
      syncLumatoneLEDs: vi.fn(() => true),
    };

    expect(sendLumatoneColorsNow(keys, currentLeds)).toBe(true);
    expect(keys.lumatoneLEDs).toBe(currentLeds);
    expect(keys.syncLumatoneLEDs).toHaveBeenCalledTimes(1);
  });

  it("reports that no send occurred while the driver is unavailable", () => {
    const keys = { syncLumatoneLEDs: vi.fn() };

    expect(sendLumatoneColorsNow(keys, null)).toBe(false);
    expect(keys.syncLumatoneLEDs).not.toHaveBeenCalled();
  });
});

describe("autoSyncLumatoneSurface", () => {
  it("sends the blank layout when the musical surface has scale size 0", () => {
    const keys = { autoSyncLumatoneLEDs: vi.fn() };
    const leds = { sendLayout: vi.fn() };

    expect(autoSyncLumatoneSurface({ keys, leds, scale: [] })).toBe(true);

    expect(leds.sendLayout).toHaveBeenCalledTimes(1);
    expect(leds.sendLayout.mock.calls[0][0]).toHaveLength(280);
    expect(keys.autoSyncLumatoneLEDs).not.toHaveBeenCalled();
  });

  it("keeps ordinary automatic colour sync for a populated scale", () => {
    const keys = { autoSyncLumatoneLEDs: vi.fn() };
    const leds = { sendLayout: vi.fn() };

    expect(autoSyncLumatoneSurface({ keys, leds, scale: ["2/1"] })).toBe(true);

    expect(keys.lumatoneLEDs).toBe(leds);
    expect(keys.autoSyncLumatoneLEDs).toHaveBeenCalledTimes(1);
    expect(leds.sendLayout).not.toHaveBeenCalled();
  });

  it("does not send a blank layout outside eligible Lumatone mapping modes", () => {
    const leds = { sendLayout: vi.fn() };

    expect(autoSyncLumatoneSurface({ keys: null, leds, scale: [], eligible: false })).toBe(false);
    expect(leds.sendLayout).not.toHaveBeenCalled();
  });
});

describe("App input runtime", () => {
  it.each(["scale", "hex_layout"])(
    "treats sequential Lumatone %s input as channel-polyphonic",
    async (target) => {
      Object.assign(settings, {
        midiin_device: "input-1",
        midiin_controller_override: "auto",
        midiin_mapping_target: target,
        midi_passthrough: true,
        midiin_mpe_input: false,
      });
      synthWiringState.midi = {
        inputs: new Map([["input-1", { id: "input-1", name: "Lumatone" }]]),
        outputs: new Map(),
      };
      mockDetectedController = { id: "lumatone" };
      window.matchMedia = vi.fn().mockReturnValue({
        matches: false,
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
      });

      render(<App />);

      await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
      expect(lastKeyboardProps.inputRuntime.layoutMode).toBe("sequential");
      expect(lastKeyboardProps.inputRuntime.target).toBe(target);
      expect(lastKeyboardProps.inputRuntime.perChannelExpression).toBe(true);
    },
  );

  it("keeps configured wheel semitones and forces standard wheel mode for LinnStrument bypass with MPE input off", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: true,
      midiin_mpe_input: false,
      midi_wheel_semitones: 12,
      wheel_to_recent: true,
    });
    synthWiringState.midi = {
      inputs: new Map([["input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" }]]),
      outputs: new Map(),
    };
    mockDetectedController = { id: "linnstrument" };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });

    render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    expect(lastKeyboardProps.inputRuntime.wheelSemitones).toBe(12);
    expect(lastKeyboardProps.inputRuntime.wheelToRecent).toBe(false);
  });

  it("re-syncs LinnStrument colors after onKeysReady when UF mode is eligible", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: false,
      midiin_mpe_input: false,
      linnstrument_led_sync: true,
    });
    synthWiringState.midi = {
      inputs: new Map([["input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" }]]),
      outputs: new Map(),
    };
    mockDetectedController = { id: "linnstrument" };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    const keys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };

    lastKeyboardProps.onKeysReady(keys);

    await waitFor(() => expect(keys.syncLinnstrumentLEDs).toHaveBeenCalledTimes(1));
  });

  it("re-syncs LinnStrument colors only after the rebuilt Keys instance is ready when center_degree changes under UF mode", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: false,
      midiin_mpe_input: false,
      linnstrument_led_sync: true,
      center_degree: 0,
    });
    synthWiringState.midi = {
      inputs: new Map([["input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" }]]),
      outputs: new Map(),
    };
    mockDetectedController = { id: "linnstrument" };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });

    const { rerender } = render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    const staleKeys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };
    lastKeyboardProps.onKeysReady(staleKeys);
    await waitFor(() => expect(staleKeys.syncLinnstrumentLEDs).toHaveBeenCalledTimes(1));
    staleKeys.syncLinnstrumentLEDs.mockClear();

    settings = { ...settings, center_degree: 9 };
    rerender(<App />);

    expect(staleKeys.syncLinnstrumentLEDs).not.toHaveBeenCalled();

    const rebuiltKeys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };
    lastKeyboardProps.onKeysReady(rebuiltKeys);

    await waitFor(() => expect(rebuiltKeys.syncLinnstrumentLEDs).toHaveBeenCalledTimes(1));
  });

  it("marks the LinnStrument LED driver UF-active when Keys mounts after UF activation", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: false,
      midiin_mpe_input: false,
      linnstrument_led_sync: true,
    });
    synthWiringState.midi = {
      inputs: new Map([["input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" }]]),
      outputs: new Map(),
    };
    synthWiringState.linnstrumentRawPorts = {
      output: { id: "out-1" },
    };
    mockDetectedController = { id: "linnstrument" };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });

    render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    const keys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };

    lastKeyboardProps.onKeysReady(keys);

    await waitFor(() => {
      const leds = attachLinnstrumentLedDriver.mock.results[0]?.value;
      expect(leds?.userFirmwareActive).toBe(true);
    });
  });

  it("re-evaluates Auto Detect on midiTick when the selected input appears later", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: false,
      midiin_mpe_input: false,
      linnstrument_led_sync: true,
    });
    const midi = {
      inputs: new Map(),
      outputs: new Map(),
    };
    synthWiringState.midi = midi;
    synthWiringState.midiTick = 0;
    mockDetectedController = null;
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    const raf = vi.fn((cb) => {
      cb();
      return 1;
    });
    window.requestAnimationFrame = raf;
    globalThis.requestAnimationFrame = raf;

    const { rerender } = render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    const staleKeys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };
    lastKeyboardProps.onKeysReady(staleKeys);
    expect(staleKeys.syncLinnstrumentLEDs).not.toHaveBeenCalled();

    midi.inputs.set("input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" });
    synthWiringState.midiTick = 1;
    mockDetectedController = { id: "linnstrument" };
    rerender(<App />);

    const recoveredKeys = {
      settings: { linnstrument_led_sync: true },
      syncLinnstrumentLEDs: vi.fn(),
    };
    lastKeyboardProps.onKeysReady(recoveredKeys);
    await waitFor(() => expect(recoveredKeys.syncLinnstrumentLEDs).toHaveBeenCalledTimes(1));
  });

  it("sends LinnStrument UF deactivation on page unload while UF mode is eligible", async () => {
    Object.assign(settings, {
      midiin_device: "input-1",
      midiin_controller_override: "auto",
      midiin_mapping_target: "hex_layout",
      midi_passthrough: false,
      midiin_mpe_input: false,
      linnstrument_led_sync: true,
    });
    synthWiringState.midi = {
      inputs: new Map([["input-1", { id: "input-1", name: "Roger Linn Design LinnStrument 128" }]]),
      outputs: new Map(),
    };
    synthWiringState.linnstrumentRawPorts = {
      output: { id: "out-1" },
    };
    mockDetectedController = { id: "linnstrument" };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });

    render(<App />);

    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());
    const keys = {};
    lastKeyboardProps.onKeysReady(keys);

    window.dispatchEvent(new Event("pagehide"));

    await waitFor(() =>
      expect(deactivateLinnstrumentUserFirmware).toHaveBeenCalledWith(
        synthWiringState.linnstrumentRawPorts.output,
        keys,
      ),
    );
  });
});

describe("App workspace tabs", () => {
  it("offers Start Audio on fresh load without presenting it as a recovery failure", async () => {
    settings = { ...settings, output_sample: true };
    render(<App />);
    expect(await screen.findByRole("button", { name: "Start Audio" })).toBeTruthy();
    expect(screen.getByText("Tap Start Audio to prepare the built-in sounds before playing.")).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Restore Audio" })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(screen.queryByRole("button", { name: "Start Audio" })).toBeNull();
  });
  it.each([
    ["sequencer", "SEQUENCER"],
    ["calculator", "CALCULATOR"],
    ["io", "I/O"],
  ])("opens the restored %s workspace on startup", async (storedTab, tabName) => {
    sessionStorage.setItem(RELOAD_WORKSPACE_TAB_KEY, storedTab);
    if (storedTab === "io") {
      localStorage.setItem("hexatone_persist_on_reload", "true");
      sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
        snapshots: [{ id: 1, notes: [{ id: "a", midicents: 60, start: 0, end: 1 }] }],
        bars: [], tempi: [], repeats: [],
      }));
    }

    render(<App />);

    await waitFor(() =>
      expect(screen.getByRole("tab", { name: tabName }).getAttribute("aria-selected")).toBe("true"),
    );
    if (storedTab === "io") {
      const play = await screen.findByLabelText("play timed transport");
      expect(document.getElementById("io-sequencer-transport-host").contains(play)).toBe(true);
    }
  });

  it("restores stored sequence timbre after Mod Wheel input when sequence shaping is unchecked", async () => {
    render(<App />);
    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    fireEvent.click(await screen.findByLabelText("Sequencer Timbre Control"));
    const polyTimbre = vi.fn();
    const soundingHex = {
      release: false,
      _snapshotSourceTimbre: 80,
      _snapshotSourceTimbre14: null,
      polyTimbre,
    };
    const keys = {
      _snapshotHexes: [soundingHex],
      _soundingSnapshotHexes: new Set([soundingHex]),
    };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    act(() => lastKeyboardProps.onModWheelChange(127));

    expect(polyTimbre).toHaveBeenCalledWith(80);
    expect(synthWiringState.onOscBrightnessChange).toHaveBeenCalledWith(1, false);
  });

  it.each([true, false])("routes Brightness fader to sequence timbre when shaping is %s", async (enabled) => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    render(<App />);
    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    const preference = await screen.findByLabelText("Sequencer Timbre Control");
    if (!enabled) fireEvent.click(preference);
    const polyTimbre = vi.fn();
    const hex = { release: false, _snapshotSourceTimbre: 80,
      _snapshotSourceTimbre14: null, polyTimbre };
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady({ _snapshotHexes: [hex],
      _soundingSnapshotHexes: new Set([hex]) }));
    fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
    polyTimbre.mockClear();
    fireEvent.click(await screen.findByText("Test Brightness"));
    expect(polyTimbre).toHaveBeenCalledWith(enabled ? 127 : 80);
    expect(synthWiringState.onOscBrightnessChange).toHaveBeenCalledWith(1);
    if (!enabled) {
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      fireEvent.click(await screen.findByLabelText("Sequencer Timbre Control"));
      expect(polyTimbre).toHaveBeenLastCalledWith(127);
    }
  });

  it("shapes stored sequence timbre after Mod Wheel input when sequence shaping is checked", async () => {
    render(<App />);
    const polyTimbre = vi.fn();
    const soundingHex = {
      release: false,
      _snapshotSourceTimbre: 80,
      _snapshotSourceTimbre14: null,
      polyTimbre,
    };
    const keys = {
      _snapshotHexes: [soundingHex],
      _soundingSnapshotHexes: new Set([soundingHex]),
    };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect((await screen.findByLabelText("Sequencer Timbre Control")).checked).toBe(true);
    polyTimbre.mockClear();
    act(() => lastKeyboardProps.onModWheelChange(127));

    expect(polyTimbre).toHaveBeenCalledWith(127);
  });

  it.each(["next", "panic"])("uses manual arpeggiation and cancels queued attacks on %s", async (action) => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [
          {
            id: 1,
            length: 1,
            notes: [
              { id: "first", midicents: 60, start: 0, attackVelocity: 90 },
              { id: "second", midicents: 64, start: 0.5, attackVelocity: 90 },
            ],
          },
          {
            id: 2,
            length: 1,
            notes: [{ id: "next", midicents: 67, start: 0, attackVelocity: 90 }],
          },
        ],
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [],
        repeats: [],
        manualArpeggiation: {
          mode: "all",
          initialSpreadMs: 1000,
          spreadVariation: 0,
          timingVariation: 0,
          decayMode: "immediate",
          decayMs: 5000,
          decayVariation: 0,
        },
      }),
    );
    const { unmount } = render(<App />);
    const keys = {
      settings: {
        note_names: [],
        heji_names: [],
      },
      beginSnapshotGesture: vi.fn(),
      attackSnapshotGestureNote: vi.fn((_gestureId, note) => ({ hex: { note } })),
      releaseSnapshotGestureNote: vi.fn(),
      stopSnapshotGesture: vi.fn(),
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    await waitFor(() => {
      expect(lastKeyboardProps).not.toBeNull();
    });
    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });

    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    fireEvent.click(await screen.findByLabelText("play current sequence position"));

    expect(keys.beginSnapshotGesture).toHaveBeenCalledWith(expect.any(Number), { replace: false });
    expect(keys.attackSnapshotGestureNote).toHaveBeenCalledTimes(1);
    expect(keys.attackSnapshotGestureNote.mock.calls[0][1].id).toBe("first");

    if (action === "panic") {
      fireEvent.click(screen.getByRole("button", { name: "PANIC" }));
      expect(keys.stopSnapshotGesture).toHaveBeenCalledTimes(1);
      expect(keys.panic).toHaveBeenCalledTimes(1);
      await new Promise(resolve => setTimeout(resolve, 1100));
      expect(keys.attackSnapshotGestureNote).toHaveBeenCalledTimes(1);
      unmount();
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
      return;
    }
    fireEvent.click(screen.getByLabelText("next sequence step"));

    expect(keys.releaseSnapshotGestureNote).toHaveBeenCalledTimes(1);
    expect(keys.stopSnapshotGesture).toHaveBeenCalledTimes(1);
    expect(keys.attackSnapshotGestureNote).toHaveBeenCalledTimes(2);
    expect(keys.attackSnapshotGestureNote.mock.calls[1][1].id).toBe("next");

    unmount();
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it("advances rapid cue and snapshot arrows from the live audio playhead", async () => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [60, 62, 64].map((midicents, index) => ({
          id: index + 1,
          length: 1,
          notes: [
            {
              id: `note-${index + 1}`,
              midicents,
              start: 0,
              end: 1,
              attackVelocity: 90,
            },
          ],
        })),
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [],
        repeats: [],
      }),
    );
    const keys = {
      settings: { note_names: [], heji_names: [] },
      playSnapshot: vi.fn(),
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    const { unmount } = render(<App />);
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));

    const nextCue = await screen.findByLabelText("next sequence marker");
    fireEvent.click(nextCue);
    fireEvent.click(nextCue);
    fireEvent.click(nextCue);

    expect(keys.playSnapshot.mock.calls.map(([notes]) => notes[0]?.midicents)).toEqual([
      60, 62, 64,
    ]);

    const previousSnapshot = screen.getByLabelText("previous sequence step");
    fireEvent.click(previousSnapshot);
    fireEvent.click(previousSnapshot);
    expect(keys.playSnapshot.mock.calls.map(([notes]) => notes[0]?.midicents)).toEqual([
      60, 62, 64, 62, 60,
    ]);

    unmount();
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it("retunes active timed-playback voices while the navigation playhead is stopped", async () => {
    render(<App />);
    const user = userEvent.setup();
    const soundingHex = {
      _baseCents: 0,
      _snapshotSourceBaseCents: 0,
      _snapshotSourceMidicents: 69,
      _snapshotAppliedPitchOffsetCents: 0,
      sequenceRetune: vi.fn(),
    };
    const keys = {
      _snapshotHexes: [soundingHex],
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    await waitFor(() => {
      expect(lastKeyboardProps).not.toBeNull();
    });
    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    const pitchSlider = await screen.findByRole("slider", {
      name: "sequence playback pitch slider",
    });
    fireEvent.keyDown(pitchSlider, { key: "ArrowRight" });

    expect(soundingHex.sequenceRetune).toHaveBeenCalledWith(1);
  });

  it.each([
    [true, "play timed transport"],
    [false, "play timed transport"],
    [true, "next sequence marker"],
    [false, "next sequence marker"],
    [true, "next sequence step"],
    [false, "next sequence step"],
    [true, "play timed transport", false],
    [true, "next sequence marker", false],
  ])("snaps sounding voices only with an active tuning (stored note id: %s, trigger: %s, canvas: %s)", async (hasId, trigger, hasCanvas = true) => {
    const previousSettings = settings;
    if (!hasCanvas) settings = { ...settings, scale: [] };
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [
          {
            id: 1,
            length: 1,
            notes: [
              {
                ...(hasId ? { id: "note" } : {}),
                midicents: 70.5,
                start: 0,
                end: 1,
                attackVelocity: 90,
              },
            ],
          },
        ],
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [
          { id: 1, position: 1, bpm: 60, beatNumerator: 1, beatDenominator: 4, beatLength: 1 },
        ],
        repeats: [],
      }),
    );

    const soundingHex = {
      _snapshotInstanceKey: null,
      sequenceRetune: vi.fn(),
    };
    const tuningRuntime = {
      scale: hasCanvas ? [0, 200, 1200] : [0],
      referenceDegree: 0,
      fundamental: 440,
      equivInterval: 1200,
    };
    const keys = {
      settings: {
        fundamental: 440,
        note_names: ["A", "B", "C"],
        heji_names: [],
      },
      tuning: { degree0toRef_asArray: [0] },
      _snapshotHexes: [],
      _activeFrame: () => ({}),
      _effectiveScaleRuntimeForFrame: () => tuningRuntime,
      playSnapshot: vi.fn((notes) => {
        soundingHex._snapshotInstanceKey =
          notes[0]?.instanceKey ?? (notes[0]?.id ? `:${notes[0].id}` : null);
        keys._snapshotHexes = [soundingHex];
      }),
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    const { unmount } = render(<App />);
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });

    fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    const triggerButton = await screen.findByLabelText(trigger);
    // Also check future attacks while SNAP is enabled on the hidden fallback.
    if (!hasCanvas) {
      fireEvent.click(screen.getByLabelText("Snap Sequence to Current Hexatone Tuning"));
    }
    fireEvent.click(triggerButton);
    await waitFor(() => expect(keys.playSnapshot).toHaveBeenCalled());

    fireEvent.click(screen.getByLabelText("Snap Sequence to Current Hexatone Tuning"));

    if (hasCanvas) {
      expect(soundingHex.sequenceRetune.mock.calls.at(-1)[0]).toBeCloseTo(200, 6);
    } else {
      expect(soundingHex.sequenceRetune).not.toHaveBeenCalled();
      expect(keys.playSnapshot.mock.calls[0][0][0].midicents).toBe(70.5);
    }
    expect(keys.stopSnapshot).not.toHaveBeenCalled();

    fireEvent.click(screen.getByLabelText("Snap Sequence to Current Hexatone Tuning"));
    if (hasCanvas) {
      expect(soundingHex.sequenceRetune.mock.calls.at(-1)[0]).toBeCloseTo(150, 6);
    } else {
      expect(soundingHex.sequenceRetune).not.toHaveBeenCalled();
    }
    expect(keys.playSnapshot).toHaveBeenCalledTimes(1);

    unmount();
    settings = previousSettings;
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it("remembers independent sidebar positions when changing workspaces", async () => {
    const view = render(<App />);
    try {
      const sidebar = view.container.querySelector("#sidebar");
      sidebar.scrollTop = 670;
      fireEvent.scroll(sidebar);
      fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
      expect(sidebar.scrollTop).toBe(0);
      sidebar.scrollTop = 230;
      fireEvent.scroll(sidebar);
      fireEvent.click(screen.getByRole("tab", { name: "HEXATONE" }));
      expect(sidebar.scrollTop).toBe(670);
      fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
      expect(sidebar.scrollTop).toBe(230);
    } finally {
      view.unmount();
    }
  });

  it.each(["next sequence step", "next sequence marker"])("replays an edited sounding note after %s with the resolved HEJI pitch", async (trigger) => {
    sessionStorage.setItem("hexatone_sequencer_edit_play_expanded", "true");
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: 1, length: 1,
        pitchFrame: { id: "frame", referenceLabel: "A4", referenceFrequency: 440,
          referenceInterval: "1/1", hejiAnchorLabel: "*nA", hejiAnchorInterval: "1/1" },
        notes: [{ id: "held", midicents: 69, displayLabel: "*nA4", start: 0, end: 1 }] }],
      bars: [], tempi: [], repeats: [],
    }));
    const keys = { settings: { note_names: [], heji_names: [] },
      playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(), resizeHandler: vi.fn() };
    const view = render(<App />);
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      act(() => lastKeyboardProps.onKeysReady(keys));
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      fireEvent.click(await screen.findByLabelText(trigger));
      expect(keys.playSnapshot).toHaveBeenCalledTimes(1);
      const name = await screen.findByLabelText("snapshot 1 attack name");
      fireEvent.input(name, { target: { value: "a5" } });
      fireEvent.keyDown(name, { key: "Enter" });
      await waitFor(() => expect(keys.playSnapshot).toHaveBeenCalledTimes(2));
      expect(keys.playSnapshot.mock.calls.at(-1)[0][0].midicents).toBeCloseTo(81, 6);
      const unchanged = screen.getByLabelText("snapshot 1 attack name");
      fireEvent.keyDown(unchanged, { key: "Enter" });
      expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
      fireEvent.click(screen.getByLabelText("restore snapshot 1 attack captured pitch and name"));
      await waitFor(() => expect(keys.playSnapshot).toHaveBeenCalledTimes(3));
      expect(keys.playSnapshot.mock.calls.at(-1)[0][0].midicents).toBeCloseTo(69, 6);
      fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
      fireEvent.click(screen.getByLabelText("Stop snapshot 1"));
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      const stopped = screen.getByLabelText("snapshot 1 attack name");
      fireEvent.input(stopped, { target: { value: "a3" } });
      fireEvent.keyDown(stopped, { key: "Enter" });
      expect(keys.playSnapshot).toHaveBeenCalledTimes(3);
    } finally {
      view.unmount();
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  });

  it.each(["Play snapshot 1", "next sequence step", "next sequence marker", "play timed transport"])(
    "PANIC clears playback highlights after %s, including deferred presentation", async (trigger) => {
      window.matchMedia = vi.fn().mockReturnValue({
        matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
      });
      localStorage.setItem("hexatone_persist_on_reload", "true");
      sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
        snapshots: [{ id: 1, length: 100, notes: [{ id: "held", midicents: 69, start: 0, end: 100 }] }],
        bars: [], tempi: [], repeats: [],
      }));
      const keys = { playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn() };
      const view = render(<App />);
      try {
        await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
        act(() => lastKeyboardProps.onKeysReady(keys));
        if (trigger !== "Play snapshot 1") {
          fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
        }
        fireEvent.click(await screen.findByLabelText(trigger));
        expect(keys.playSnapshot).toHaveBeenCalled();
        fireEvent.click(screen.getByRole("button", { name: "PANIC" }));
        expect(keys.panic).toHaveBeenCalledOnce();
        const highlights = ".snapshot-playing, .sequencer-item--manual-playing, .sequencer-item--timed-playing, .sequencer-event-row--manual-sounding, .sequencer-event-row--timed-sounding";
        await waitFor(() => expect(document.querySelector(highlights)).toBeNull());
        const attackCount = keys.playSnapshot.mock.calls.length;
        // Wait past the 300 ms manual UI commit and queued visual frames.
        await act(async () => { await new Promise(resolve => setTimeout(resolve, 350)); });
        expect(document.querySelector(highlights)).toBeNull();
        expect(keys.playSnapshot).toHaveBeenCalledTimes(attackCount);
        expect(screen.queryByLabelText("pause timed transport")).toBeNull();
        fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
        expect((await screen.findByLabelText("Stop snapshot 1")).disabled).toBe(true);
      } finally {
        view.unmount();
      }
    },
  );

  it("keeps a restored invalid HEJI edit clean after Enter followed by blur", async () => {
    sessionStorage.setItem("hexatone_sequencer_edit_play_expanded", "true");
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: 1, length: 1,
        pitchFrame: { id: "frame", referenceLabel: "A4", referenceFrequency: 440,
          referenceInterval: "1/1", hejiAnchorLabel: "*nA", hejiAnchorInterval: "1/1" },
        notes: [{ id: "held", midicents: 69, displayLabel: "A", hejiName: "*nA4", start: 0, end: 1 }] }],
      bars: [], tempi: [], repeats: [],
    }));
    const view = render(<App />);
    try {
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      const input = await screen.findByLabelText("snapshot 1 attack name");
      fireEvent.focus(input);
      fireEvent.input(input, { target: { value: "rubbish!" } });
      fireEvent.keyDown(input, { key: "Enter" });
      const restored = screen.getByLabelText("snapshot 1 attack name");
      expect(restored.value).not.toBe("rubbish!");
      fireEvent.blur(restored);
      expect(screen.getByLabelText("snapshot 1 attack name").classList.contains("sequencer-event__pitch-draft")).toBe(false);
    } finally { view.unmount(); }
  });

  it("replays a manual snapshot only when a replacement instrument is ready in I/O", async () => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: 1, length: 1, notes: [{ id: "held", midicents: 70.5, start: 0, end: 1 }] }],
      bars: [], tempi: [], repeats: [],
    }));
    const previousSettings = settings;
    synthWiringState.readySampleInstrument = "reed";
    const keys = { settings: { note_names: [], heji_names: [] },
      playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(), resizeHandler: vi.fn() };
    const view = render(<App />);
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      act(() => lastKeyboardProps.onKeysReady(keys));
      fireEvent.click(screen.getByLabelText("Play snapshot 1"));
      fireEvent.click(screen.getByRole("tab", { name: "I/O" }));
      settings = { ...settings, instrument: "hammond" };
      view.rerender(<App />);
      expect(keys.playSnapshot).toHaveBeenCalledTimes(1);
      synthWiringState.readySampleInstrument = "hammond";
      view.rerender(<App />);
      await waitFor(() => expect(keys.playSnapshot).toHaveBeenCalledTimes(2));
      view.rerender(<App />);
      expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
      fireEvent.click(screen.getByLabelText("Stop snapshot 1"));
      synthWiringState.readySampleInstrument = "sruti";
      view.rerender(<App />);
      expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
    } finally {
      view.unmount();
      settings = previousSettings;
      delete synthWiringState.readySampleInstrument;
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  });

  it("shares chord drift between palette and Sequencer without changing stored pitches", async () => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: "chord", length: 1, notes: [
        { id: "a", midicents: 69, start: 0, end: 1 },
        { id: "b", midicents: 76, start: 0, end: 1 },
      ] }], bars: [], tempi: [], repeats: [],
    }));
    const view = render(<App />);
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      expect(screen.queryByLabelText("Palette Chord Drift")).toBeNull();
      fireEvent.click(screen.getByLabelText("Snap palette snapshots to current tuning"));
      expect(screen.getByLabelText("Palette Chord Drift").getAttribute("aria-valuenow")).toBe("33");
      expect(screen.getByLabelText("Palette Chord Drift").classList.contains("settings-range-slider")).toBe(true);
      expect(screen.getByLabelText("Palette Chord Drift").parentElement.lastElementChild.textContent).toBe("33¢");
      fireEvent.keyDown(screen.getByLabelText("Palette Chord Drift"), { key: "End" });
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      expect((await screen.findByLabelText("Chord Drift")).getAttribute("aria-valuenow")).toBe("66");
      fireEvent.keyDown(screen.getByLabelText("Chord Drift"), { key: "Home" });
      fireEvent.click(screen.getByRole("tab", { name: "HEXATONE" }));
      expect(screen.getByLabelText("Palette Chord Drift").getAttribute("aria-valuenow")).toBe("0");
      const workspace = JSON.parse(sessionStorage.getItem(SEQUENCE_WORKSPACE_STORAGE_KEY));
      expect(workspace.snapshots[0].notes.map(note => note.midicents)).toEqual([69, 76]);
      fireEvent.click(screen.getByLabelText("Snap palette snapshots to current tuning"));
      expect(screen.queryByLabelText("Chord Drift")).toBeNull();
      expect(screen.queryByLabelText("Palette Chord Drift")).toBeNull();
    } finally {
      view.unmount();
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  });

  it.each([false, true])("preserves Snap source pitches with non-contiguous slots (worker ready: %s)", async (workerReady) => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    const previousSettings = settings;
    const previousWorker = globalThis.Worker;
    let prepared = 0;
    if (workerReady) globalThis.Worker = class {
      postMessage(job) {
        queueMicrotask(() => {
          if (this.closed) return;
          this.onmessage?.({ data: { id: job.id,
            steps: chooseChordSteps(job.pitches, job.runtime, job.drift, job.held) } });
          prepared++;
        });
      }
      terminate() { this.closed = true; }
    };
    settings = { ...settings, scale: ["10.", "696.", "710.", "1200."],
      fundamental: 440, reference_degree: 0, equivSteps: 4 };
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: "chord", length: 1, notes: [
        { midicents: 69, start: 0, end: 1, sequenceSlot: 9 },
        { midicents: 76, start: 0, end: 1, sequenceSlot: 15 },
      ] }], bars: [], tempi: [], repeats: [], manualArpeggiation: { mode: "off" },
    }));
    const keys = {
      settings: { ...settings, note_names: [], heji_names: [] },
      _activeFrame: () => ({}),
      _effectiveScaleRuntimeForFrame: () => ({ scale: [0, 10, 696, 710],
        fundamental: 440, referenceDegree: 0, equivInterval: 1200 }),
      playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(), resizeHandler: vi.fn(),
    };
    const view = render(<App />);
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      act(() => lastKeyboardProps.onKeysReady(keys));
      if (workerReady) await waitFor(() => expect(prepared).toBeGreaterThan(0));
      fireEvent.click(screen.getByLabelText("Snap palette snapshots to current tuning"));
      fireEvent.click(screen.getByLabelText("Play snapshot 1"));
      const pitches = () => keys.playSnapshot.mock.calls.at(-1)[0].map(note => note.midicents);
      // Cold/unavailable workers use ordinary Snap; ready decisions preserve
      // the chord's interval pattern. Both retain immutable source pitches.
      expect(pitches()[0]).toBeCloseTo(workerReady ? 69.1 : 69);
      expect(pitches()[1]).toBeCloseTo(workerReady ? 76.1 : 75.96);
      fireEvent.keyDown(screen.getByLabelText("Palette Chord Drift"), { key: "Home" });
      fireEvent.click(screen.getByLabelText("Play snapshot 1"));
      expect(pitches()[0]).toBeCloseTo(69);
      expect(pitches()[1]).toBeCloseTo(75.96);
      fireEvent.click(screen.getByLabelText("Snap palette snapshots to current tuning"));
      fireEvent.click(screen.getByLabelText("Play snapshot 1"));
      expect(pitches()).toEqual([69, 76]);
    } finally {
      view.unmount();
      settings = previousSettings;
      if (previousWorker === undefined) delete globalThis.Worker;
      else globalThis.Worker = previousWorker;
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  });

  it("plays the selected Seeds snapshot 6 from the right-hand PLAY button on fresh load", async () => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    const { default: seeds } = await import("./sequencer/preset-sequences/marc-sabat/Seeds-of-Skies-Alibis.json");
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      ...seeds, manualArpeggiation: { ...seeds.manualArpeggiation, mode: "off" },
    }));
    const view = render(<App />);
    const keys = { settings: { note_names: [], heji_names: [] },
      playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(), resizeHandler: vi.fn() };
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      act(() => lastKeyboardProps.onKeysReady(keys));
      fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
      const target = await screen.findByLabelText("next snapshot target");
      act(() => {
        target.value = "5";
        target.dispatchEvent(new Event("change", { bubbles: true }));
      });
      await waitFor(() => expect(screen.getByLabelText("next snapshot target").value).toBe("5"));
      fireEvent.click(screen.getByLabelText("play current sequence position"));
      expect(keys.playSnapshot).toHaveBeenCalledOnce();
      // Seeds uses an arpeggiated trigger: its first attack must belong to 6,
      // not the snapshot inferred from the initial bar position.
      expect(keys.playSnapshot.mock.calls[0][0][0].midicents)
        .toBe(seeds.snapshots[5].notes[0].midicents);
      expect(screen.getByLabelText("next snapshot target").value).toBe("5");
    } finally {
      view.unmount();
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  // Mounting the full Seeds editor is costly under parallel CI workers. Keep
  // assertion waits bounded; allow this integration test more overall time.
  }, 15000);

  it.each([
    { snap: false, transferred: false }, { snap: true, transferred: false },
    { snap: false, transferred: true }, { snap: true, transferred: true },
  ])("replays only untransferred palette voices after tuning replacement ($snap, $transferred)", async ({ snap, transferred }) => {
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
    });
    const previousSettings = settings;
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [{ id: 1, length: 1, notes: [{ id: "held", midicents: 70.5, start: 0, end: 1 }] }],
      bars: [], tempi: [], repeats: [],
    }));
    const makeKeys = scale => ({
      settings: { fundamental: 440, note_names: [], heji_names: [] },
      _activeFrame: () => ({}),
      _effectiveScaleRuntimeForFrame: () => ({
        scale, fundamental: 440, referenceDegree: 0, equivInterval: 1200,
      }),
      playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(),
    });
    const first = makeKeys([0, 200]);
    const replacement = makeKeys([0, 100]);
    if (transferred) replacement._snapshotHexes = [{ release: false }];
    const view = render(<App />);
    try {
      await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
      act(() => lastKeyboardProps.onKeysReady(first));
      if (snap) fireEvent.click(screen.getByLabelText("Snap palette snapshots to current tuning"));
      fireEvent.click(screen.getByLabelText("Play snapshot 1"));
      expect(first.playSnapshot).toHaveBeenCalledTimes(1);
      const previousReconstructionKey = lastKeyboardProps.reconstructionKey;

      settings = { ...settings, scale: ["100.", "1200."], equivSteps: 2 };
      view.rerender(<App />);
      await waitFor(() => expect(lastKeyboardProps.reconstructionKey).not.toBe(previousReconstructionKey));
      // A changed setting is not sufficient: wait for the new Keys instance.
      expect(first.playSnapshot).toHaveBeenCalledTimes(1);
      act(() => lastKeyboardProps.onKeysReady(replacement));
      await waitFor(() => expect(replacement.playSnapshot).toHaveBeenCalledTimes(transferred ? 0 : 1));
      if (!transferred)
        expect(replacement.playSnapshot.mock.calls[0][0][0].midicents).toBeCloseTo(snap ? 70 : 70.5, 6);
      expect(screen.getByLabelText("Stop snapshot 1").disabled).toBe(false);
      view.rerender(<App />);
      expect(replacement.playSnapshot).toHaveBeenCalledTimes(transferred ? 0 : 1);

      // A MIDI-only rebuild must not cause an unsolicited retrigger.
      const rebound = makeKeys([0, 100]);
      act(() => lastKeyboardProps.onKeysReady(rebound));
      expect(rebound.playSnapshot).not.toHaveBeenCalled();

      // Stopping before the next runtime is ready must not resurrect the note.
      fireEvent.click(screen.getByLabelText("Stop snapshot 1"));
      settings = { ...settings, scale: ["300.", "1200."] };
      view.rerender(<App />);
      const stopped = makeKeys([0, 300]);
      act(() => lastKeyboardProps.onKeysReady(stopped));
      expect(stopped.playSnapshot).not.toHaveBeenCalled();
      expect(screen.getByLabelText("Stop snapshot 1").disabled).toBe(true);
    } finally {
      view.unmount();
      settings = previousSettings;
      localStorage.removeItem("hexatone_persist_on_reload");
      sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
    }
  });

  it("resizes and redraws the keyboard after toggling the sidebar", async () => {
    vi.useFakeTimers();
    const { container } = render(<App />);

    await waitFor(() => {
      expect(lastKeyboardProps).not.toBeNull();
    });

    const keys = {
      resizeHandler: vi.fn(),
      scheduleImmediateGridRedraw: vi.fn(),
    };

    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });

    act(() => {
      vi.advanceTimersByTime(350);
    });
    keys.resizeHandler.mockClear();
    keys.scheduleImmediateGridRedraw.mockClear();

    act(() => {
      fireEvent.click(container.querySelector("#sidebar-button"));
    });
    act(() => {
      vi.advanceTimersByTime(350);
    });

    expect(keys.resizeHandler).toHaveBeenCalledTimes(1);
    expect(keys.scheduleImmediateGridRedraw).toHaveBeenCalledTimes(1);

    vi.useRealTimers();
  });

  it("keeps independent remembered positions for the main and contextual manuals", async () => {
    render(<App />);
    const user = userEvent.setup();

    await user.click(screen.getByRole("tab", { name: "MANUAL" }));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe("About");
    await user.click(screen.getByRole("button", { name: "Select Quick Start" }));
    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));
    await user.click(screen.getByRole("tab", { name: "MANUAL" }));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "Quick Start",
    );

    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));
    await user.click(screen.getByText("… more"));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "HEXATONE Tab",
    );
    expect(screen.getByRole("tab", { name: "HEXATONE" }).getAttribute("aria-selected")).toBe(
      "true",
    );
    expect(screen.getByRole("tab", { name: "MANUAL" }).getAttribute("aria-selected")).toBe("false");
    expect(screen.getByRole("heading", { name: "PLAINSOUND HEXATONE" })).not.toBeNull();

    await user.click(screen.getByRole("button", { name: "Select Quick Start" }));
    await user.click(screen.getByRole("button", { name: "Close contextual manual" }));
    await user.click(screen.getByText("… more"));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "Quick Start",
    );

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await waitFor(() => {
      expect(screen.queryByTestId("manual-sidebar")).toBeNull();
    });

    await user.click(screen.getByText("… more"));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "SEQUENCER Tab",
    );

    await user.click(screen.getByRole("tab", { name: "I/O" }));
    await waitFor(() => {
      expect(screen.queryByTestId("manual-sidebar")).toBeNull();
    });

    await user.click(screen.getByText("… more"));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "I/O tab",
    );

    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    await waitFor(() => {
      expect(screen.queryByTestId("manual-sidebar")).toBeNull();
    });

    await user.click(screen.getByText("… more"));
    expect((await screen.findByTestId("manual-sidebar")).dataset.initialSectionTitle).toBe(
      "CALCULATOR tab",
    );

    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));
    await waitFor(() => {
      expect(screen.queryByTestId("manual-sidebar")).toBeNull();
    });
  });

  it("stops sequencer-owned playback without interrupting live notes", async () => {
    render(<App />);
    const user = userEvent.setup();
    const keys = {
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    await waitFor(() => {
      expect(lastKeyboardProps).not.toBeNull();
    });

    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));

    expect(keys.stopSnapshot).toHaveBeenCalledTimes(1);
    expect(keys.panic).not.toHaveBeenCalled();
    expect(guardianPanicMock).not.toHaveBeenCalled();
  });

  it("keeps sequencer-owned playback running while the I/O panel is open", async () => {
    render(<App />);
    const user = userEvent.setup();
    const keys = {
      stopSnapshot: vi.fn(),
      panic: vi.fn(),
    };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    const timedPlayButton = await screen.findByLabelText("play timed transport");
    await user.click(screen.getByRole("tab", { name: "I/O" }));

    expect(await screen.findByTestId("io-settings")).not.toBeNull();
    // Timed playback is owned by the Sequencer component. It must remain the
    // same mounted instance while I/O is visible or its transport cleanup will
    // cancel the running schedule.
    expect(timedPlayButton.isConnected).toBe(true);
    expect(keys.stopSnapshot).not.toHaveBeenCalled();
    expect(keys.panic).not.toHaveBeenCalled();

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(screen.getByLabelText("play timed transport")).toBe(timedPlayButton);
    expect(keys.stopSnapshot).not.toHaveBeenCalled();
  });

  it("does not suspend the sequencer while the first I/O visit loads its panel", async () => {
    render(<App />);
    const user = userEvent.setup();
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    const timedPlayButton = await screen.findByLabelText("play timed transport");
    let finishLoading;
    pendingIOSettingsLoad = new Promise((resolve) => {
      finishLoading = resolve;
    });
    try {
      await user.click(screen.getByRole("tab", { name: "I/O" }));
      // Suspense detaches its subtree and invokes hook cleanups, including the
      // timed scheduler cleanup. The sequencer must stay attached throughout.
      expect(screen.queryByTestId("io-settings")).toBeNull();
      expect(timedPlayButton.isConnected).toBe(true);
    } finally {
      await act(async () => {
        pendingIOSettingsLoad = null;
        finishLoading();
      });
    }
    expect(await screen.findByTestId("io-settings")).not.toBeNull();
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(screen.getByLabelText("play timed transport")).toBe(timedPlayButton);
  });

  it("keeps the I/O portal host stable across workspace changes and suspended I/O loading", async () => {
    render(<App />);
    const user = userEvent.setup();
    const host = document.getElementById("io-sequencer-transport-host");
    expect(host).not.toBeNull();
    let finishLoading;
    pendingIOSettingsLoad = new Promise(resolve => { finishLoading = resolve; });
    try {
      await user.click(screen.getByRole("tab", { name: "I/O" }));
      expect(screen.queryByTestId("io-settings")).toBeNull();
      expect(document.getElementById("io-sequencer-transport-host")).toBe(host);
      expect(host.isConnected).toBe(true);
    } finally {
      await act(async () => {
        pendingIOSettingsLoad = null;
        finishLoading();
      });
    }
    await screen.findByTestId("io-settings");
    for (const name of ["SEQUENCER", "I/O", "HEXATONE", "I/O"]) {
      await user.click(screen.getByRole("tab", { name }));
      expect(document.getElementById("io-sequencer-transport-host")).toBe(host);
      expect(host.isConnected).toBe(true);
    }
  });

  it("shares transport and speed with I/O and stops sequence voices on entering Calculator", async () => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [{ id: 1, length: 100, notes: [{ id: "note", midicents: 60, start: 0 }] }],
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [],
        repeats: [],
      }),
    );
    render(<App />);
    const user = userEvent.setup();
    const keys = { stopSnapshot: vi.fn(), panic: vi.fn(), playSnapshot: vi.fn() };
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await user.click(await screen.findByLabelText("play timed transport"));
    expect(await screen.findByLabelText("pause timed transport")).not.toBeNull();
    await user.click(screen.getByRole("tab", { name: "I/O" }));
    const transport = await screen.findByRole("group", { name: "Sequencer Transport" });
    expect(transport.contains(screen.getByLabelText("pause timed transport"))).toBe(true);
    const speed = screen.getByLabelText("sequence playback speed");
    fireEvent.input(speed, { target: { value: "1.5" } });
    fireEvent.keyDown(speed, { key: "Enter" });
    const pitch = screen.getByLabelText("sequence playback pitch");
    expect(transport.contains(pitch)).toBe(true);
    fireEvent.input(pitch, { target: { value: "100.0" } });
    fireEvent.keyDown(pitch, { key: "Enter" });
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(Number(screen.getByLabelText("sequence playback speed").value)).toBe(1.5);
    expect(Number(screen.getByLabelText("sequence playback pitch").value)).toBe(100);
    expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
    keys.stopSnapshot.mockClear();
    // Paused transport and its readouts survive moving the same controls to I/O.
    fireEvent.click(screen.getByLabelText("pause timed transport"));
    const pausedCue = screen.getByLabelText("next cue target").value;
    const pausedSnapshot = screen.getByLabelText("next snapshot target").value;
    const stopCount = keys.stopSnapshot.mock.calls.length;
    const attackCount = keys.playSnapshot.mock.calls.length;
    for (const tab of ["I/O", "SEQUENCER", "I/O", "SEQUENCER"]) {
      await user.click(screen.getByRole("tab", { name: tab }));
      expect(screen.getByLabelText("play timed transport")).not.toBeNull();
      expect(screen.getByLabelText("next cue target").value).toBe(pausedCue);
      expect(screen.getByLabelText("next snapshot target").value).toBe(pausedSnapshot);
      expect(keys.stopSnapshot).toHaveBeenCalledTimes(stopCount);
      expect(keys.playSnapshot).toHaveBeenCalledTimes(attackCount);
    }
    fireEvent.click(screen.getByLabelText("play timed transport"));
    expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
    keys.stopSnapshot.mockClear();
    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    expect(keys.stopSnapshot).toHaveBeenCalled();
    expect(keys.panic).not.toHaveBeenCalled();
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(screen.getByLabelText("play timed transport")).not.toBeNull();
    expect(screen.queryByLabelText("pause timed transport")).toBeNull();
    await user.click(screen.getByRole("tab", { name: "I/O" }));
    await user.click(screen.getByLabelText("play timed transport"));
    expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
    await user.click(screen.getByLabelText("stop timed transport"));
    expect(screen.getByLabelText("play timed transport")).not.toBeNull();
    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));
    await user.click(screen.getByRole("tab", { name: "I/O" }));
    const restoredTransport = await screen.findByRole("group", { name: "Sequencer Transport" });
    expect(restoredTransport.contains(screen.getByLabelText("play timed transport"))).toBe(true);
    await user.click(screen.getByLabelText("play timed transport"));
    expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    expect(screen.queryByLabelText("pause timed transport")).toBeNull();
  });

  it("follows timed playback in the I/O snapshot palette without a manual playhead commit", async () => {
    window.matchMedia = vi.fn().mockReturnValue({ matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn() });
    const raf = vi.spyOn(window, "requestAnimationFrame").mockImplementation(callback =>
      window.setTimeout(() => callback(performance.now()), 16));
    const caf = vi.spyOn(window, "cancelAnimationFrame").mockImplementation(id => window.clearTimeout(id));
    try {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
      snapshots: [
        { id: 1, length: 0.1, notes: [{ id: "a", midicents: 60, start: 0, end: 0.1 }] },
        { id: 2, length: 100, notes: [{ id: "b", midicents: 64, start: 0, end: 100 }] },
      ], bars: [{ id: 1, position: 1 }], tempi: [], repeats: [],
    }));
    render(<App />);
    const user = userEvent.setup();
    let clock = 0;
    const keys = { stopSnapshot: vi.fn(), panic: vi.fn(), playSnapshot: vi.fn(),
      synth: { currentTime: () => clock } };
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await user.click(await screen.findByLabelText("play timed transport"));
    await user.click(screen.getByRole("tab", { name: "I/O" }));
    await waitFor(() => {
      if (screen.getByLabelText("Stop snapshot 2").disabled) clock += 0.1;
      expect(screen.getByLabelText("Stop snapshot 2").disabled).toBe(false);
    }, { timeout: 3000 });
    expect(screen.getByLabelText("Stop snapshot 1").closest(".snapshot-row").classList.contains("snapshot-playing")).toBe(false);
    expect(screen.getByLabelText("Stop snapshot 2").closest(".snapshot-row").classList.contains("snapshot-playing")).toBe(true);
    await user.click(screen.getByLabelText("Stop snapshot 2"));
    expect(screen.queryByLabelText("pause timed transport")).toBeNull();
    expect(document.querySelector(".snapshot-palette-body .snapshot-playing")).toBeNull();
    expect(keys.panic).not.toHaveBeenCalled();
    } finally {
      raf.mockRestore();
      caf.mockRestore();
    }
  });

  it("hands timed playback over to manual PLAY FROM buttons in both workspaces", async () => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [1, 2, 3].map((id) => ({
          id,
          length: 100,
          notes: [{ id: `note-${id}`, midicents: 60 + id, start: 0 }],
        })),
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [],
        repeats: [],
      }),
    );
    render(<App />);
    const user = userEvent.setup();
    const keys = { stopSnapshot: vi.fn(), playSnapshot: vi.fn() };
    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    for (const tab of ["SEQUENCER", "I/O"]) {
      await user.click(screen.getByRole("tab", { name: tab }));
      for (const label of [
        "next sequence step",
        "next sequence marker",
        "play current sequence position",
      ]) {
        // Each arrow now advances rather than replaying, so reset the origin
        // for each independent handoff assertion (including the second tab).
        fireEvent.click(screen.getByLabelText("move timed transport to start"));
        await user.click(await screen.findByLabelText("play timed transport"));
        expect(screen.getByLabelText("pause timed transport")).not.toBeNull();
        keys.stopSnapshot.mockClear();
        keys.playSnapshot.mockClear();
        // Dispatch synchronously so a pending timed cue cannot run during
        // userEvent's pointer-event delays before the actual click.
        fireEvent.click(screen.getByLabelText(label));
        expect(screen.queryByLabelText("pause timed transport")).toBeNull();
        expect(keys.playSnapshot).toHaveBeenCalled();
        if (label === "next sequence marker") {
          expect(keys.stopSnapshot).not.toHaveBeenCalled();
          expect(keys.playSnapshot.mock.calls.at(-1)[1]).toMatchObject({ legato: true });
        } else {
          expect(keys.stopSnapshot).toHaveBeenCalled();
          expect(keys.stopSnapshot.mock.invocationCallOrder[0]).toBeLessThan(
            keys.playSnapshot.mock.invocationCallOrder[0],
          );
        }
        await user.click(screen.getByLabelText("stop timed transport"));
      }
    }
  });

  it("keeps Calculator user data mounted while switching workspace tabs", async () => {
    render(<App />);
    const user = userEvent.setup();

    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    const pitch = await screen.findByLabelText("Calculator lookup ratio or cents");
    fireEvent.input(pitch, { target: { value: "5/4" } });
    fireEvent.blur(pitch);

    await user.click(screen.getByRole("tab", { name: "I/O" }));
    expect(pitch.isConnected).toBe(true);
    expect(pitch.closest(".calculator-tab").hidden).toBe(true);

    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    expect(screen.getByLabelText("Calculator lookup ratio or cents")).toBe(pitch);
    expect(pitch.value).toBe("5/4");
    expect(pitch.closest(".calculator-tab").hidden).toBe(false);
  });

  it("keeps both functional performance palettes outside Sequencer", async () => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [
          {
            id: 1,
            length: 1,
            notes: [{ id: "note", midicents: 60, start: 0, attackVelocity: 90 }],
          },
        ],
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [],
        repeats: [],
      }),
    );
    const { unmount } = render(<App />);
    const user = userEvent.setup();
    const keys = { stepModulationRoute: vi.fn(), stopSnapshot: vi.fn() };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));
    act(() => {
      lastKeyboardProps.onModulationStateChange({
        mode: "idle",
        history: [{ sourceDegree: 0, targetDegree: 1, count: 0 }],
      });
    });

    await user.click(screen.getByRole("tab", { name: "I/O" }));

    expect(document.querySelector("#snapshot-palette")).not.toBeNull();
    expect(document.querySelector("#modulation-palette")).not.toBeNull();

    await user.click(screen.getByRole("tab", { name: "CALCULATOR" }));
    expect(document.querySelector("#snapshot-palette")).not.toBeNull();
    expect(document.querySelector("#modulation-palette")).not.toBeNull();
    fireEvent.pointerDown(screen.getByLabelText("Step modulation forward"));
    expect(keys.stepModulationRoute).toHaveBeenCalledWith(0, 1);

    await user.click(screen.getByRole("tab", { name: "MANUAL" }));
    expect(document.querySelector("#snapshot-palette")).not.toBeNull();
    expect(document.querySelector("#modulation-palette")).not.toBeNull();

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(document.querySelector("#snapshot-palette")).toBeNull();
    expect(document.querySelector("#modulation-palette")).toBeNull();

    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));
    expect(document.querySelector("#snapshot-palette")).not.toBeNull();
    expect(document.querySelector("#modulation-palette")).not.toBeNull();

    unmount();
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it("stops timed playback before playing a snapshot from the palette", async () => {
    localStorage.setItem("hexatone_persist_on_reload", "true");
    sessionStorage.setItem(
      SEQUENCE_WORKSPACE_STORAGE_KEY,
      JSON.stringify({
        snapshots: [
          {
            id: 1,
            length: 1,
            notes: [{ id: "first", midicents: 60, start: 0, end: 1, attackVelocity: 90 }],
          },
          {
            id: 2,
            length: 1,
            notes: [{ id: "second", midicents: 67, start: 0, end: 1, attackVelocity: 90 }],
          },
        ],
        bars: [{ id: 1, position: 1, numerator: 4, denominator: 4 }],
        tempi: [
          { id: 1, position: 1, bpm: 30, beatNumerator: 1, beatDenominator: 4, beatLength: 1 },
        ],
        repeats: [],
      }),
    );
    const keys = {
      settings: { note_names: [], heji_names: [] },
      playSnapshot: vi.fn(),
      stopSnapshot: vi.fn(),
      beginSnapshotGesture: vi.fn(),
      attackSnapshotGestureNote: vi.fn((_gestureId, note) => ({ hex: { note } })),
      releaseSnapshotGestureNote: vi.fn(),
      stopSnapshotGesture: vi.fn(),
      panic: vi.fn(),
    };
    const { unmount } = render(<App />);
    const user = userEvent.setup();

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await user.click(await screen.findByLabelText("play timed transport"));
    await waitFor(() => expect(keys.playSnapshot).toHaveBeenCalledTimes(1));

    await user.click(screen.getByRole("tab", { name: "I/O" }));
    const stopCallsBeforePalettePlay = keys.stopSnapshot.mock.calls.length;
    await user.click(await screen.findByLabelText("Play snapshot 1"));

    expect(keys.stopSnapshot).toHaveBeenCalledTimes(stopCallsBeforePalettePlay + 1);
    expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
    expect(keys.playSnapshot.mock.calls[1][0][0].id).toBe("first");
    expect(keys.beginSnapshotGesture).not.toHaveBeenCalled();
    expect(keys.attackSnapshotGestureNote).not.toHaveBeenCalled();

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    expect(screen.getByLabelText("play timed transport")).not.toBeNull();

    unmount();
    localStorage.removeItem("hexatone_persist_on_reload");
    sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
  });

  it.each(["HEXATONE", "I/O", "CALCULATOR", "MANUAL"].flatMap(
    (destination) => ["snapshot", "cue"].map((target) => [destination, target]),
  ))(
    "handles a switch to %s after manual %s playback",
    async (destination, target) => {
      let rowTop = 250;
      const rect = vi.spyOn(HTMLElement.prototype, "getBoundingClientRect").mockImplementation(function () {
        const top = this.classList.contains("snapshot-palette-body") ? 100
          : this.dataset.snapshotId === "2" ? rowTop : 0;
        const height = this.classList.contains("snapshot-palette-body") ? 100 : 20;
        return { top, bottom: top + height, height, left: 0, right: 200, width: 200 };
      });
      const height = vi.spyOn(HTMLElement.prototype, "clientHeight", "get").mockImplementation(function () {
        return this.classList.contains("snapshot-palette-body") ? 100 : 0;
      });
      window.matchMedia = vi.fn().mockReturnValue({
        matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn(),
      });
      localStorage.setItem("hexatone_persist_on_reload", "true");
      sessionStorage.setItem(SEQUENCE_WORKSPACE_STORAGE_KEY, JSON.stringify({
        snapshots: [60, 64].map((midicents, index) => ({
          id: index + 1, length: 1,
          notes: [{ id: `note-${index}`, midicents, start: 0, end: 1 }],
        })),
        bars: [], tempi: [], repeats: [],
      }));
      const keys = {
        settings: { note_names: [], heji_names: [] },
        playSnapshot: vi.fn(), stopSnapshot: vi.fn(), panic: vi.fn(),
      };
      const view = render(<App />);
      try {
        await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
        act(() => lastKeyboardProps.onKeysReady(keys));
        fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
        const next = await screen.findByLabelText(
          target === "snapshot" ? "next sequence step" : "next sequence marker",
        );
        fireEvent.click(next);
        fireEvent.click(next);
        expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
        const stops = keys.stopSnapshot.mock.calls.length;
        // Switch before the 300 ms manual presentation commit.
        fireEvent.click(screen.getByRole("tab", { name: destination }));
        if (target === "cue") {
          expect(keys.stopSnapshot).toHaveBeenCalledTimes(stops + (destination === "I/O" ? 0 : 1));
          expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
          return;
        }
        expect(keys.stopSnapshot).toHaveBeenCalledTimes(stops);
        expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
        const stop = screen.getByLabelText("Stop snapshot 2");
        expect(stop.disabled).toBe(false);
        expect(stop.closest(".snapshot-row").classList.contains("snapshot-playing")).toBe(true);
        expect(screen.getByLabelText("Stop snapshot 1").disabled).toBe(true);
        expect(document.querySelector(".snapshot-palette-body").scrollTop).toBe(70);
        // Re-enter with the row already visible: leave the scroll position alone.
        fireEvent.click(screen.getByRole("tab", { name: "SEQUENCER" }));
        rowTop = 150;
        fireEvent.click(screen.getByRole("tab", { name: destination }));
        expect(document.querySelector(".snapshot-palette-body").scrollTop).toBe(0);
        expect(keys.playSnapshot).toHaveBeenCalledTimes(2);
        fireEvent.click(screen.getByLabelText("Stop snapshot 2"));
        expect(keys.stopSnapshot).toHaveBeenCalledTimes(stops + 1);
        expect(screen.getByLabelText("Stop snapshot 2").disabled).toBe(true);
      } finally {
        view.unmount();
        rect.mockRestore();
        height.mockRestore();
        localStorage.removeItem("hexatone_persist_on_reload");
        sessionStorage.removeItem(SEQUENCE_WORKSPACE_STORAGE_KEY);
      }
    },
  );

  it("stops sequencer playback when switching from I/O to Hexatone", async () => {
    render(<App />);
    const user = userEvent.setup();
    const keys = { stopSnapshot: vi.fn(), panic: vi.fn() };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => lastKeyboardProps.onKeysReady(keys));

    await user.click(screen.getByRole("tab", { name: "SEQUENCER" }));
    await user.click(screen.getByRole("tab", { name: "I/O" }));
    await user.click(screen.getByRole("tab", { name: "HEXATONE" }));

    expect(keys.stopSnapshot).toHaveBeenCalledTimes(1);
    expect(keys.panic).not.toHaveBeenCalled();
  });
});

// ── Full App rendering ────────────────────────────────────────────────────────
// Skipped: requires WebMidi, AudioContext, canvas and localStorage all stubbed.
// The original Enzyme tests for App were also mostly commented out for the
// same reason. Revisit once a more complete jsdom + WebMidi mock is in place.

describe.todo("App — settings panel toggle");
describe.todo("App — keyboard active/inactive state");
describe.todo("App — preset loading");

describe("App keyboard lifecycle", () => {
  beforeEach(() => {
    synthWiringState.loading = 0;
    synthWiringState.midiAccess = "none";
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
  });

  it("panics the live keyboard synchronously when the page reloads", async () => {
    render(<App />);
    const keys = { panic: vi.fn() };

    await waitFor(() => expect(lastKeyboardProps).not.toBeNull());
    act(() => {
      lastKeyboardProps.onKeysReady(keys);
    });
    window.dispatchEvent(new Event("beforeunload"));

    expect(keys.panic).toHaveBeenCalledTimes(1);
  });

  it("keeps the keyboard mounted while loading is nonzero", async () => {
    const { rerender } = render(<App />);
    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());

    synthWiringState.loading = 1;
    rerender(<App />);

    expect(screen.getByTestId("keyboard")).not.toBeNull();
    expect(screen.getByTestId("loading-icon")).not.toBeNull();
  });

  it("keeps the keyboard mounted when midi access upgrades to sysex", async () => {
    const { rerender } = render(<App />);
    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());

    synthWiringState.midiAccess = "basic";
    rerender(<App />);
    expect(screen.getByTestId("keyboard")).not.toBeNull();

    synthWiringState.midiAccess = "sysex";
    synthWiringState.loading = 1;
    rerender(<App />);

    expect(screen.getByTestId("keyboard")).not.toBeNull();
    expect(screen.getByTestId("loading-icon")).not.toBeNull();
  });

  it("clears the MOD button route summary when modulation is cancelled back to idle", async () => {
    render(<App />);
    await waitFor(() => expect(screen.getByTestId("keyboard")).not.toBeNull());

    act(() => {
      lastKeyboardProps.onModulationStateChange?.({
        mode: "awaiting_target",
        sourceDegree: 0,
        currentRoute: null,
        history: [{ sourceDegree: 0, targetDegree: 7, count: 1, transpositionDeltaCents: 500 }],
      });
    });

    expect(screen.getByText("1/1 →")).toBeTruthy();

    act(() => {
      lastKeyboardProps.onModulationStateChange?.({
        mode: "idle",
        sourceDegree: null,
        currentRoute: { sourceDegree: 0, targetDegree: 7, count: 1, transpositionDeltaCents: 500 },
        history: [{ sourceDegree: 0, targetDegree: 7, count: 1, transpositionDeltaCents: 500 }],
      });
    });

    expect(screen.queryByText("1/1 → 2/1[-1eq]")).toBeNull();
    expect(screen.queryByText("1/1 →")).toBeNull();
  });
});
