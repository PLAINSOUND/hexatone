// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (c) 2025-2026 Sam Aaron
// See EngineHost.h. Brought over from clockwork's former reference host, which is gone:
// this is SuperSonic's process, built on clockwork the library.
#include "EngineHost.h"

#include "EgressRouter.h"
#include "clockwork_client.h"
#include "clockwork_product.h"
#include "GuestConfigText.h"     // the guest's options, as name=value text
#include "scsynth_options.h"     // which options, which flags, which defaults
#include "native/LinkAudioBridge.h"
#ifdef __APPLE__
#  include "cocoa_event_pump.h"
#  include "MicPermission.h"
#  include <CoreFoundation/CoreFoundation.h>
#endif

#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <cctype>
#include <cstring>
#include <thread>
#ifdef _WIN32
#  include <windows.h>
#else
#  include <execinfo.h>
#  include <unistd.h>
#endif

namespace supersonic_host {

// ── The command line ─────────────────────────────────────────────────────────

// The guest's option for a command-line letter, from the one list of them
// (scsynth_options.h), or null for a letter that is not one of the guest's.
static const ScsynthOptionInfo* scsynthOptionForFlag(char flag) {
    for (uint32_t i = 0; i < scsynth_option_count(); ++i) {
        const ScsynthOptionInfo* opt = scsynth_option_info(i);
        if (opt->flag && opt->flag == flag) return opt;
    }
    return nullptr;
}

// The usage lines for those flags, in the list's order, with the defaults
// the list says — so --help cannot say one number while the engine uses
// another.
// The host's own choices for scsynth's options, on top of scsynth's defaults
// (scsynth_options.h): the parser sets them and the help shows them, from here.
// A native process has a filesystem, so the synthdef directory is loaded at
// boot, as scsynth does (the host reads the files: Options::loadDefinitionsAtBoot);
// -D 0 turns it off.
struct HostOptionDefault { const char* name; uint32_t value; };
constexpr HostOptionDefault kHostOptionDefaults[] = {
    { "loadGraphDefs", 1 },
};

static uint32_t hostDefault(const ScsynthOptionInfo& opt) {
    for (const auto& d : kHostOptionDefaults)
        if (std::strcmp(d.name, opt.name) == 0) return d.value;
    return opt.def;
}

static std::string scsynthOptionUsage() {
    std::string out;
    for (uint32_t i = 0; i < scsynth_option_count(); ++i) {
        const ScsynthOptionInfo* opt = scsynth_option_info(i);
        if (!opt->flag) continue;
        char line[200];
        std::snprintf(line, sizeof(line), "  -%c <num>     %s (default: %u)\n",
                      opt->flag, opt->doc, hostDefault(*opt));
        out += line;
    }
    return out;
}

std::string usage(const char* productName) {
    std::string p = productName ? productName : "clockwork";
    return
        p + " — audio runtime\n\n"
        "Usage: " + p + " [options]\n\n"
        "  -u <port>    UDP port (default: 57110; 0 = no UDP port and no SHM segment)\n"
        "  -S <rate>    Sample rate (default: 48000, or the device's own if it\n"
        "               does not offer that)\n"
        "  -Z <size>    Hardware buffer size (default: auto, the device's smallest\n"
        "               of 128 or more)\n"
        "  -z <size>    DSP control block size, 32-1024 (default: auto, the device\n"
        "               buffer when it is 32-128, else 128)\n"
        "  -i <num>     Input channels (default: device max; 0 = disable)\n"
        "  -o <num>     Output channels (default: device max)\n"
        + scsynthOptionUsage() +
        "  -B <addr>    Bind address (default: 127.0.0.1; 0.0.0.0 = every IPv4\n"
        "               interface)\n"
        "  -H <name>    Audio device, for output and input; -H <in> <out> names\n"
        "               each. The output is a fuzzy match on 'Driver : Device';\n"
        "               __system__ follows the system default output\n"
        "  -v           Print version and exit\n"
        "  -h, --help   Print this help and exit\n"
        "  --default-bpm <n>  Opening session tempo (default 120)\n"
        "  --app-name <name>  Name published to OS audio/MIDI registries\n"
        "                     (PipeWire, ALSA seq, Link; default: " + p + ")\n"
        "  --audio-driver <name>  Driver to boot on (e.g. CoreAudio, Windows Audio,\n"
        "                     ASIO, PipeWire, ALSA)\n"
        "  --list-devices     List audio devices and exit\n"
        "  -U -R -l -I -O <value>  scsynth's; accepted and ignored\n"
        "\n"
        "Command transport (pick exactly one). Every transport asks the client\n"
        "for the per-boot secret, which this process reads from its stdin at\n"
        "boot: 64 hex digits and a newline, written by whoever launched it.\n"
        "Nothing starts without it. The cue server and outbound OSC are\n"
        "unaffected. -u <port> names the SHM segment (and its attach endpoint);\n"
        "-u 0 means no segment:\n"
        "  --tcp <port>        TCP, OSC framed by a 4-byte big-endian length\n"
        "                      (respects -B); one client at a time\n"
        "  --uds <path>        Unix socket, stream (macOS/Linux; file 0600)\n"
        "  --pipe <name>       Named pipe (Windows; owner-only DACL)\n"
        "  --shm-commands      SHM segment's peer command plane (one trusted\n"
        "                      co-located peer; requires -u > 0)\n"
        "  --assets-mb <n>      The assets area lane a client loads samples and other\n"
        "                      assets into, in MB, 1-3072 (default 512). Address\n"
        "                      space, not memory: pages are committed as they are\n"
        "                      written.\n"
        "\n"
        "Shared memory (needs -u > 0). The segment is anonymous; readers get\n"
        "it from the attach endpoint, a Unix socket (macOS/Linux) or named\n"
        "pipe (Windows) serving this user only:\n"
        "  --shm-endpoint <path|pipe>  Where to serve it (default:\n"
        "                      clockwork-shm-<port>.sock in XDG_RUNTIME_DIR,\n"
        "                      else TMPDIR, else /tmp with the uid in the name;\n"
        "                      \\\\.\\pipe\\clockwork-shm-<port> on Windows)\n"
        "\n"
        "  --headless   No audio device; timer-driven render (CI/tests)\n"
        "\n"
        "An unknown flag is reported in the log and skipped.\n\n";
}

static const char* nextArg(int i, int argc, char* const argv[]) {
    return (i + 1 < argc) ? argv[i + 1] : nullptr;
}

// A whole number and nothing after it.
static bool wholeNumber(const char* s, long& out) {
    if (!s || !*s) return false;
    char* end = nullptr;
    errno = 0;
    out = std::strtol(s, &end, 10);
    return errno == 0 && end && *end == '\0';
}

bool readSecret(Options& o, FILE* in, std::string* err) {
    char line[80] = {};
    if (!in || !std::fgets(line, sizeof line, in)) {
        if (err) *err = "no secret on stdin: the launcher writes 64 hex digits and a newline";
        return false;
    }
    const size_t n = std::strlen(line);
    const bool shaped = (n == 65 && line[64] == '\n') || (n == 66 && line[64] == '\r' && line[65] == '\n');
    uint8_t bytes[32];
    for (int i = 0; shaped && i < 32; ++i) {
        unsigned v = 0;
        if (std::sscanf(line + 2 * i, "%2x", &v) != 1 || !std::isxdigit(static_cast<unsigned char>(line[2 * i]))
            || !std::isxdigit(static_cast<unsigned char>(line[2 * i + 1]))) {
            if (err) *err = "the secret on stdin is not 64 hex digits";
            return false;
        }
        bytes[i] = static_cast<uint8_t>(v);
    }
    if (!shaped) { if (err) *err = "the secret on stdin is not 64 hex digits and a newline"; return false; }
    o.secret.reset(clockwork_comms_secret_from_bytes(bytes));
    if (!o.secret) { if (err) *err = "the secret on stdin is all zeros"; return false; }
    return true;
}

bool parseArgs(int argc, char* const argv[], Options& o, std::string* err) {
    ClockworkEngine::Config& cfg = o.cfg;
    cfg.sampleRate       = 48000;
    cfg.bufferSize       = 0;
    o.shmPort            = 57110;
    // Recover automatically if the device's callback thread wedges (e.g. a
    // DirectSound cursor-poll spin), so a standalone process keeps running.
    cfg.callbackWatchdog = true;
    // The guest's options start from its defaults, with the host's choices on top.
    for (const auto& d : kHostOptionDefaults)
        clockwork::guest_config_text::set(cfg.guestConfig, d.name, std::to_string(d.value));
    long assetsMb = 512;   // the host's default: generous, because it is only address space

    // A mistake stops the boot, naming the flag: a value that went missing or
    // is not a number is configuration the caller believes they gave.
    const auto refuse = [err](const std::string& why) {
        if (err) *err = why;
        return false;
    };

    for (int i = 1; i < argc; ++i) {
        const char* arg = argv[i];
        const char* val = nextArg(i, argc, argv);
        const auto missing = [&] { return refuse(std::string(arg) + " needs a value"); };
        const auto notANumber = [&] { return refuse(std::string(arg) + " takes a whole number, not \"" + val + "\""); };
        long n = 0;

        if (std::strcmp(arg, "--default-bpm") == 0) {
            if (!val) return missing();
            char* end = nullptr;
            cfg.defaultBpm = std::strtod(val, &end);
            if (end == val || *end != '\0')
                return refuse(std::string(arg) + " takes a number, not \"" + val + "\"");
            ++i;
            continue;
        }
        // Name published to OS audio/MIDI registries (PipeWire nodes, ALSA seq
        // MIDI clients, macOS aggregate devices, Link peers).
        if (std::strcmp(arg, "--app-name") == 0)     { if (!val || !*val) return missing(); cfg.appName = val; ++i; continue; }
        // Driver (JUCE device type) to boot on; resolution rules live in resolveBootDriver.
        if (std::strcmp(arg, "--audio-driver") == 0) { if (!val || !*val) return missing(); cfg.audioDriver = val; ++i; continue; }
        if (std::strcmp(arg, "--tcp") == 0) {
            if (!val) return missing();
            if (!wholeNumber(val, n)) return notANumber();
            o.tcpPort = static_cast<int>(n);
            ++i;
            continue;
        }
        if (std::strcmp(arg, "--uds") == 0)          { if (!val) return missing(); o.udsStreamPath = val; ++i; continue; }
        if (std::strcmp(arg, "--pipe") == 0)         { if (!val) return missing(); o.pipeName = val; ++i; continue; }
        if (std::strcmp(arg, "--shm-commands") == 0) { o.shmCommands = true; continue; }
        if (std::strcmp(arg, "--shm-endpoint") == 0) { if (!val) return missing(); o.shmEndpoint = val; ++i; continue; }
        if (std::strcmp(arg, "--assets-mb") == 0) {
            if (!val) return missing();
            if (!wholeNumber(val, n)) return notANumber();
            // Header offsets are 32-bit: the lane and everything before it
            // must stay under 4 GB.
            assetsMb = n < 1 ? 1 : (n > 3072 ? 3072 : n);
            ++i;
            continue;
        }
        // No audio device: the HeadlessDriver renders on a timer thread, so
        // OSC still drains and replies flow — for CI and the transport harness.
        if (std::strcmp(arg, "--headless") == 0) { o.headless = true; continue; }

        // Every known long flag continues above, so a "--" arg reaching here
        // is unknown. Reported rather than skipped: a dropped option reads as
        // configuration applied when it wasn't. Likewise a word that is not a
        // flag, and a single-dash flag of more than one letter.
        if (arg[0] == '-' && arg[1] == '-') {
            o.warnings.push_back(std::string("unknown flag: ") + arg);
            continue;
        }
        if (arg[0] != '-' || arg[1] == '\0') {
            o.warnings.push_back(std::string("unexpected argument: ") + arg);
            continue;
        }
        if (arg[2] != '\0') {
            o.warnings.push_back(std::string("unknown flag: ") + arg);
            continue;
        }

        // Every single-letter flag takes a value.
        if (!val) return missing();
        const auto number = [&](int& field) {
            if (!wholeNumber(val, n)) return false;
            field = static_cast<int>(n);
            ++i;
            return true;
        };
        {
            switch (arg[1]) {
            case 'u': if (!number(o.shmPort))             return notANumber(); break;
            case 'i': if (!number(cfg.numInputChannels))  return notANumber(); break;
            case 'o': if (!number(cfg.numOutputChannels)) return notANumber(); break;
            case 'B': cfg.bindAddress = val; ++i; break;
            case 'S': if (!number(cfg.sampleRate))        return notANumber(); break;
            case 'Z': if (!number(cfg.bufferSize))        return notANumber(); break;
            case 'z': if (!number(cfg.blockSize))         return notANumber(); break;
            case 'H': {
                // scsynth's -H: "<in> <out>", or one name for both. The
                // sentinels keep to their direction: __none__ is an input
                // (inputs off), __system__ an output (follow the default).
                const char* second = nextArg(i + 1, argc, argv);
                if (second && second[0] != '\0' && second[0] != '-') {
                    cfg.inputDevice    = val;
                    cfg.hardwareDevice = second;
                    i += 2;
                } else {
                    const std::string name = val;
                    cfg.inputDevice    = name == "__system__" ? std::string() : name;
                    cfg.hardwareDevice = name == "__none__"   ? std::string() : name;
                    ++i;
                }
                if (cfg.inputDevice == "__none__") cfg.numInputChannels = 0;   // inputs off
                break;
            }
            // Accepted for scsynth compatibility (ignored):
            case 'U': case 'R': case 'l': case 'I': case 'O':
                ++i; break;
            default:
                // The guest's own flags — -n, -b, -a, -c, -m, -w, -d, -r, -D,
                // -V — are whatever scsynth_options.h says they are: the
                // value goes to the guest by NAME, and the guest, not this
                // host, decides whether it is acceptable.
                if (const ScsynthOptionInfo* opt = scsynthOptionForFlag(arg[1])) {
                    clockwork::guest_config_text::set(cfg.guestConfig, opt->name, val);
                    ++i;
                    break;
                }
                o.warnings.push_back(std::string("unknown flag: ") + arg);
                ++i;
                break;
            }
        }
    }

    o.desiredInputChannels = cfg.numInputChannels;

    const int transports = (o.tcpPort > 0 ? 1 : 0) + (o.udsStreamPath.empty() ? 0 : 1)
                         + (o.pipeName.empty() ? 0 : 1) + (o.shmCommands ? 1 : 0);
    if (transports > 1) {
        if (err) *err = "pick exactly one of --tcp / --uds / --pipe / --shm-commands";
        return false;
    }
    if (transports == 0) {
        if (err) *err = "no command transport: add --tcp, --uds, --pipe or --shm-commands";
        return false;
    }
    cfg.shmSegment = o.shmPort > 0;
    if (o.shmCommands && !cfg.shmSegment) {
        if (err) *err = "--shm-commands needs -u > 0 (-u > 0 is what creates the SHM segment)";
        return false;
    }
    if (!o.shmEndpoint.empty() && !cfg.shmSegment) {
        if (err) *err = "--shm-endpoint needs -u > 0 (-u > 0 is what creates the SHM segment)";
        return false;
    }
    if (cfg.shmSegment && o.shmEndpoint.empty())
        o.shmEndpoint = shm_attach::default_endpoint(static_cast<unsigned>(o.shmPort));
    cfg.headless    = o.headless;
    cfg.shmCommands = o.shmCommands;
    cfg.assetsBytes  = static_cast<size_t>(assetsMb) * 1024u * 1024u;

    // -D, as scsynth will read it (the guest's own parser). A config the guest
    // will refuse is left to it to refuse, with its line.
    ScsynthOptions guest;
    char refused[160];
    if (scsynth_options_parse(cfg.guestConfig.c_str(),
                              static_cast<uint32_t>(cfg.guestConfig.size()),
                              &guest, refused, sizeof(refused)) == 0)
        o.loadDefinitionsAtBoot = guest.loadGraphDefs != 0;
    return true;
}

// ── The command transports ───────────────────────────────────────────────────

IOscTransport* CommandTransports::select(const Options& o, std::atomic<ShmPeerPlaneHeader*>* peerPlaneSlot,
                                         Ingest ingest, std::string* err) {
    mIngest = std::move(ingest);
    const ClockworkEngine::Config& cfg = o.cfg;
    char desc[160];

    if (o.shmCommands) {
        // Ingest runs inside the engine (the NRT gateway drains the plane's
        // command ring directly), so there is no recv wiring here — only the
        // reply side. The plane exists once engine.init() has created the
        // segment; bind then.
        if (!peerPlaneSlot) { if (err) *err = "--shm-commands needs an engine's peer plane"; return nullptr; }
        mStart = [this, peerPlaneSlot] { mShm.bindPlaneSlot(peerPlaneSlot); return mShm.ready(); };
        snprintf(desc, sizeof desc, "SHM command plane (segment via %s)", o.shmEndpoint.c_str());
        mDesc = desc;
        mKind = "SHM command plane";
        return &mShm;
    }
    if (!(o.tcpPort > 0 || !o.udsStreamPath.empty() || !o.pipeName.empty())) {
        if (err) *err = "no command transport chosen";
        return nullptr;
    }
    if (!o.secret) { if (err) *err = "no secret: the command transport asks every client for it"; return nullptr; }
    mStream.setIngest(mIngest);
    mStream.setSecret(o.secret.get());
    const char* kind;
    if (o.tcpPort > 0) {
        mStream.initialiseTcp(o.tcpPort, cfg.bindAddress);
        snprintf(desc, sizeof desc, "TCP port %d", o.tcpPort);
        kind = "TCP";
    } else if (!o.udsStreamPath.empty()) {
        mStream.initialiseUds(o.udsStreamPath);
        snprintf(desc, sizeof desc, "UDS stream socket %s", o.udsStreamPath.c_str());
        kind = "UDS stream socket";
    } else {
        mStream.initialisePipe(o.pipeName);
        snprintf(desc, sizeof desc, "named pipe %s", o.pipeName.c_str());
        kind = "named pipe";
    }
    mStart = [this] { return mStream.start(); };
    mDesc = desc;
    mKind = std::string(kind) + " (one client)";
    return &mStream;
}

bool CommandTransports::start() { return mStart ? mStart() : false; }

void CommandTransports::stop() {
    // No recv thread is left feeding an engine that is coming down.
    mStream.stop();
}

// ── The egress pump ──────────────────────────────────────────────────────────

EgressPump::EgressPump(ClockworkEngine& engine, IOscTransport& transport,
                       std::function<void(const std::string&)> log)
    : mEngine(engine), mTransport(transport), mLog(std::move(log)) {}

EgressPump::~EgressPump() { stop(); }

void EgressPump::start() {
    if (mThread.joinable()) return;
    mStop.store(false);
    mThread = std::thread([this] { run(); });
}

void EgressPump::stop() {
    mStop.store(true);
    if (mThread.joinable()) mThread.join();
}

void EgressPump::run() {
    // One read, both rings, a batch at a time; the array is ours, which is
    // the ABI's rule. Nothing to take: wait a moment. The audio thread
    // answers every block (2.7 ms at 128/48k), so the wait is well under
    // that, and a reply is on the wire within a block of being framed.
    ClockworkClientMessage batch[64];
    while (!mStop.load(std::memory_order_relaxed)) {
        ClockworkClient* c = mEngine.egressClient();
        if (!c) { std::this_thread::sleep_for(std::chrono::milliseconds(1)); continue; }
        uint32_t taken = 0;
        for (;;) {
            const uint32_t n = clockwork_client_poll(c, batch, sizeof batch / sizeof batch[0]);
            // What the transport could not deliver is counted in the engine's
            // metrics, as the engine's own gateway counts it.
            for (uint32_t i = 0; i < n; ++i)
                clockwork_client_count_undelivered(c,
                    clockwork_route_egress(mTransport, batch[i].origin, batch[i].route,
                                           batch[i].bytes, batch[i].length, mLog));
            taken += n;
            if (n < sizeof batch / sizeof batch[0]) break;
        }
        if (taken) mRouted.fetch_add(taken, std::memory_order_relaxed);
        else       std::this_thread::sleep_for(std::chrono::microseconds(500));
    }
}

// ── The segment ──────────────────────────────────────────────────────────────

bool serveSegment(shm_attach::server& server, ClockworkEngine& engine, const Options& o,
                  const std::function<void(const std::string&)>& log) {
    if (!o.cfg.shmSegment) return false;
    std::string err;
    if (!detail_shm_segment::shm_handle_valid(engine.shmReaderHandle())) {
        log("no shared-memory segment; attach endpoint not started");
        return false;
    }
    // The published segment, read-only, to every reader; the command segment
    // to one peer at a time, where --shm-commands made one (docs/SEGMENTS.md
    // in clockwork).
    if (server.start(o.shmEndpoint, engine.shmReaderHandle(), engine.shmSegmentSize(),
                     engine.shmCommandHandle(), engine.shmCommandSize(), engine.shmCommandWakeEvent(),
                     o.secret.get(), &err)) {
        log("shared memory served at " + o.shmEndpoint
            + (detail_shm_segment::shm_handle_valid(engine.shmCommandHandle()) ? " (readers, and one command peer)" : " (readers)"));
        return true;
    }
    log("ERROR: shared-memory attach endpoint: " + err);
    return false;
}

// ── Signals ──────────────────────────────────────────────────────────────────

static std::atomic<bool> gShutdownRequested { false };
static const char*       gLogPrefix = "[clockwork] ";

bool shutdownRequested() { return gShutdownRequested.load(); }
void requestShutdown()   { gShutdownRequested.store(true); }

static void signalHandler(int) { gShutdownRequested.store(true); }

void installSignalHandlers() {
    std::signal(SIGINT,  signalHandler);
    std::signal(SIGTERM, signalHandler);
}

#ifndef _WIN32
// Async-signal-safe stderr writers. fprintf inside a signal handler can
// take a stdio lock the crashed thread already holds, or allocate — either
// turns a diagnosable fault into a silent death or a hang. write(2) is on
// the async-signal-safe list.
static void crashWrite(const char* s) {
    size_t n = 0;
    while (s[n]) ++n;
    const ssize_t r = write(STDERR_FILENO, s, n);
    (void)r;
}

static void crashWriteUnsigned(uintptr_t v, int base) {
    char buf[2 + sizeof(v) * 2 + 1];
    char* end = buf + sizeof(buf);
    char* p   = end;
    *--p = '\0';
    do {
        *--p = "0123456789abcdef"[v % static_cast<uintptr_t>(base)];
        v /= static_cast<uintptr_t>(base);
    } while (v != 0);
    if (base == 16) { *--p = 'x'; *--p = '0'; }
    crashWrite(p);
}

static void crashHandler(int sig, siginfo_t* info, void*) {
    const char* name = "UNKNOWN";
    switch (sig) {
        case SIGSEGV: name = "SIGSEGV"; break;
        case SIGBUS:  name = "SIGBUS";  break;
        case SIGABRT: name = "SIGABRT"; break;
        case SIGFPE:  name = "SIGFPE";  break;
        case SIGILL:  name = "SIGILL";  break;
        case SIGTRAP: name = "SIGTRAP"; break;
    }
    crashWrite("\n"); crashWrite(gLogPrefix); crashWrite("FATAL: ");
    crashWrite(name);
    crashWrite(" (signal ");
    crashWriteUnsigned(static_cast<uintptr_t>(sig), 10);
    crashWrite(") fault addr=");
    crashWriteUnsigned(info ? reinterpret_cast<uintptr_t>(info->si_addr) : 0, 16);
    crashWrite("\n"); crashWrite(gLogPrefix); crashWrite("Backtrace:\n");
    // backtrace_symbols_fd writes straight to the fd (no malloc). Not
    // formally async-signal-safe, but the essential FATAL line is already
    // out above; from here everything is best-effort bonus detail.
    void* frames[64];
    const int n = backtrace(frames, 64);
    backtrace_symbols_fd(frames, n, STDERR_FILENO);
    crashWrite(gLogPrefix); crashWrite("Exiting due to crash.\n");
    _exit(128 + sig);
}

void installCrashHandlers(const char* logPrefix) {
    if (logPrefix) gLogPrefix = logPrefix;
    // Dedicated signal stack: a stack-overflow SIGSEGV is delivered on the
    // stack that just overflowed, so without an alternate stack the handler
    // faults before its first instruction and the process dies with no
    // output at all. SIGSTKSZ stopped being a constant expression in glibc
    // 2.34, so use a generous fixed block.
    static char altStack[64 * 1024];
    stack_t ss = {};
    ss.ss_sp    = altStack;
    ss.ss_size  = sizeof(altStack);
    ss.ss_flags = 0;
    sigaltstack(&ss, nullptr);

    struct sigaction sa = {};
    sa.sa_sigaction = crashHandler;
    // SA_RESETHAND: a second fault inside the handler takes the default
    // action (die) instead of looping. SIGILL and SIGTRAP are included
    // because arm64 aborts frequently surface as brk/udf instructions.
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);
    for (int sig : { SIGSEGV, SIGBUS, SIGABRT, SIGFPE, SIGILL, SIGTRAP })
        sigaction(sig, &sa, nullptr);
}
#else
static void crashHandler(int sig) {
    const char* name = "UNKNOWN";
    if      (sig == SIGSEGV) name = "SIGSEGV";
    else if (sig == SIGABRT) name = "SIGABRT";
    else if (sig == SIGFPE)  name = "SIGFPE";
    else if (sig == SIGILL)  name = "SIGILL";
    fprintf(stderr, "\n%sFATAL: %s (signal %d)\n%sExiting due to crash.\n", gLogPrefix, name, sig, gLogPrefix);
    fflush(stderr);
    _exit(128 + sig);
}

void installCrashHandlers(const char* logPrefix) {
    if (logPrefix) gLogPrefix = logPrefix;
    std::signal(SIGSEGV, crashHandler);
    std::signal(SIGABRT, crashHandler);
    std::signal(SIGFPE,  crashHandler);
    std::signal(SIGILL,  crashHandler);
}
#endif

// ── The run loop ─────────────────────────────────────────────────────────────

void runUntilShutdown(ClockworkEngine& engine, const std::function<void(const std::string&)>& log,
                      const std::function<void()>& tick) {
    int ticks = 0;
    auto maybeTick = [&](int per) { if (tick && ++ticks >= per) { ticks = 0; tick(); } };
#ifdef __APPLE__
    // If the run loop is suppressed (an aggregate was created at boot), wait
    // for the client to finish initialising before pumping.
    if (engine.isRunLoopSuppressed()) {
        log("waiting for boot to settle before pumping CFRunLoop...");
        std::this_thread::sleep_for(std::chrono::seconds(5));
        engine.setRunLoopSuppressed(false);
        log("CFRunLoop pump started");
    }
    while (!gShutdownRequested.load()) {
        if (engine.isRunLoopSuppressed()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        } else {
            ClockworkAutoreleasePool pool;   // drained per turn; see cocoa_event_pump.h
            CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.1, false);
            // The run loop above is enough for a window to appear and redraw,
            // and NOT enough for it to be clicked: AppKit delivers input by
            // dequeuing from NSApplication and calling -sendEvent:.
            clockwork_pump_cocoa_events();
        }
        maybeTick(10);
    }
#elif defined(_WIN32)
    // Pump Win32 messages on the main thread so JUCE's hidden message windows
    // can dispatch what they receive (WM_DEVICECHANGE for hot-plug, and
    // MessageManager::callAsync). juce::MessageManager::runDispatchLoop would
    // do the same job but is gated by JUCE_MODAL_LOOPS_PERMITTED.
    (void)engine; (void)log;
    MSG msg;
    while (!gShutdownRequested.load()) {
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        Sleep(50);
        maybeTick(20);
    }
#else
    (void)engine; (void)log;
    while (!gShutdownRequested.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        maybeTick(10);
    }
#endif
}

// ── The banner and the device list ───────────────────────────────────────────

namespace {

std::string versionLine(const Identity& id) {
    return "  " + std::string(id.name) + " v" + id.version;
}

// What was compiled in, as the banner names it.
std::string compiledFeatures() {
    std::string s;
    const auto add = [&s](const char* feature) { s += s.empty() ? feature : std::string(" ") + feature; };
#if CLOCKWORK_SYNTH
    add("synth");
#endif
#if CLOCKWORK_LINK
    add("Link");
#endif
    // CLOCKWORK_LINK_AUDIO is LinkAudioBridge.h's, derived there from
    // CLOCKWORK_LINK + CLOCKWORK_WITH_LINK_AUDIO. Asking it rather than
    // re-deriving the condition here is the point: the banner used to carry its
    // own copy, spelled `CLOCKWORK_LINK && CLOCKWORK_SYNTH`, and kept claiming
    // Link-Audio for years after the bridge was corrected away from it.
#if CLOCKWORK_LINK_AUDIO
    add("Link-Audio");
#endif
#if CLOCKWORK_MIDI
    add("MIDI");
#endif
#if CLOCKWORK_GAMEPAD
    add("Gamepad");
#endif
    (void)add;
    return s;
}

} // namespace

std::string bannerSummary(const Identity& id) {
    return versionLine(id) + "\n  " + compiledFeatures();
}

void printBanner(const Identity& id, const CurrentDeviceInfo& dev, const std::string& transportKind) {
    std::string s = "\n" + std::string(id.banner) + "\n\n" + versionLine(id) + "\n\n  Compiled: "
                  + compiledFeatures() + "\n";
    if (!dev.name.empty()) {
        // "out A/M in B/N" — A channels currently routed / M available on the
        // device (likewise for inputs).
        const auto channels = [](int active, int max) {
            return max > 0 && max != active ? std::to_string(active) + "/" + std::to_string(max)
                                            : std::to_string(active);
        };
        s += "  " + dev.name + " (" + dev.typeName + ")\n  "
           + std::to_string(static_cast<int>(dev.activeSampleRate)) + " Hz | block "
           + std::to_string(dev.controlBlockSize) + " | buffer " + std::to_string(dev.activeBufferSize)
           + " | out " + channels(dev.activeOutputChannels, dev.maxOutputChannels)
           + " | in " + channels(dev.activeInputChannels, dev.maxInputChannels) + "\n";
    } else {
        s += "  headless (no audio device)\n";
    }
    s += "  " + transportKind + "\n\n";
    fprintf(stderr, "%s", s.c_str());
    fflush(stderr);
}

void printDeviceList(ClockworkEngine& engine) {
    auto devices = engine.listDevices();
    auto current = engine.currentDevice();
    fprintf(stdout, "\n  Audio Devices\n  ─────────────\n\n");
    for (auto& dev : devices) {
        if (dev.wireless) continue;
        const bool isCurrent = (dev.name == current.name && dev.typeName == current.typeName);
        fprintf(stdout, "  %s %s : %s\n", isCurrent ? "▸" : " ", dev.typeName.c_str(), dev.name.c_str());
        if (dev.maxOutputChannels > 0 || dev.maxInputChannels > 0)
            fprintf(stdout, "      channels: %d out, %d in\n", dev.maxOutputChannels, dev.maxInputChannels);
        if (!dev.availableSampleRates.empty()) {
            fprintf(stdout, "      rates:   ");
            for (size_t i = 0; i < dev.availableSampleRates.size(); ++i)
                fprintf(stdout, "%s%.0f", i ? ", " : "", dev.availableSampleRates[i]);
            fprintf(stdout, "\n");
        }
        if (!dev.availableBufferSizes.empty()) {
            fprintf(stdout, "      buffers: ");
            for (size_t i = 0; i < dev.availableBufferSizes.size(); ++i)
                fprintf(stdout, "%s%d", i ? ", " : "", dev.availableBufferSizes[i]);
            fprintf(stdout, "\n");
        }
        fprintf(stdout, "\n");
    }
    if (!current.name.empty())
        fprintf(stdout, "  Active: %s @ %.0f Hz, buffer %d\n\n", current.name.c_str(),
                current.activeSampleRate, current.activeBufferSize);
}

#ifdef __APPLE__
std::string micPermissionStatus() { return MicPermission::status(); }

std::string applyMicPermissionGuard(Options& o) {
    // DO NOT request access here — this process typically runs as a
    // background helper child of a GUI, and macOS auto-denies requests from
    // non-foreground processes without showing the prompt. The GUI requests
    // on our behalf; TCC attributes the permission to the responsible
    // process, so we inherit whatever the user granted.
    const std::string status = MicPermission::status();
    if (status == "denied") {
        fprintf(stderr, "[mic-permission] WARNING: mic access DENIED. live_audio will be silent. "
                "Grant access via System Settings > Privacy & Security > Microphone, "
                "for the app that launched this engine\n");
    } else if (status == "notDetermined") {
        fprintf(stderr, "[mic-permission] status notDetermined — GUI should request on our behalf\n");
    }
    // Unless authorized, boot output-only: AUHAL's AudioUnitInitialize blocks
    // indefinitely opening an input stream while TCC permission is pending.
    // != 0 rather than > 0: the auto-max sentinel is -1, which also means
    // "the user wants inputs".
    if (status != "authorized" && o.cfg.numInputChannels != 0) {
        fprintf(stderr, "[main] mic status='%s' — forcing numInputChannels=0 "
                "(user can enable inputs later after granting permission)\n", status.c_str());
        o.cfg.numInputChannels = 0;
    }
    fflush(stderr);
    return status;
}

bool inputsWaitForPermission(int desiredInputChannels, const std::string& status) {
    return desiredInputChannels != 0 && status != "authorized";
}
#endif

} // namespace supersonic_host
