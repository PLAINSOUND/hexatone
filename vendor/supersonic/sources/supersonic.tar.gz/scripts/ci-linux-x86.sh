#!/bin/bash

# Build and test SuperSonic for 32-bit x86 (i686).
#
# Expects to already be running *inside* a 32-bit Debian userland — CI launches
# that container; see the native-linux-x86 job in .github/workflows/native.yml.
#
# Why a container rather than multiarch on the normal runner: Ubuntu dropped
# i386 as a full architecture in 19.10 and keeps only a partial set of i386
# packages, where Debian still carries a complete i386 archive. Nothing is
# emulated — x86_64 CPUs run 32-bit code natively, so this costs about what
# the x64 job does.
#
# 32-bit is worth covering because it is the one desktop target where the
# engine's lock-free assumptions can actually break: on i686, 8-byte atomics
# lower to cmpxchg8b and may need libatomic, where x86_64 gets them for free.
# The bit-packed atomic<uint64_t> seen in TimeSource.h / LinkAudioInputRenderer
# exists for exactly this reason, and this job is what proves it holds.
#
# Usage:
#   scripts/ci-linux-x86.sh [phase]
#
# Phases (default `all` runs them in order):
#   deps       apt dependencies + Rust toolchain
#   configure  cmake configure with tests on
#   build      SuperSonic binary + native test suite
#   test       Catch2 suite (benchmarks excluded, as in the x64 job)
#   transport  end-to-end transport harness

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build/native-x86"

check_arch() {
    if [ "$(getconf LONG_BIT)" != "32" ]; then
        echo "ERROR: this script must run inside a 32-bit userland (getconf LONG_BIT = $(getconf LONG_BIT))." >&2
        exit 1
    fi
}

setup_paths() {
    if [ -f "${CARGO_HOME:-$HOME/.cargo}/env" ]; then
        # shellcheck disable=SC1091
        . "${CARGO_HOME:-$HOME/.cargo}/env"
    fi
    # CI runs the container as root against a workspace owned by the runner's
    # uid, which git otherwise refuses to touch. Scope it to the environment
    # rather than rewriting a global gitconfig.
    export GIT_CONFIG_COUNT=1
    export GIT_CONFIG_KEY_0=safe.directory
    export GIT_CONFIG_VALUE_0='*'
}

phase_deps() {
    echo "=== deps: apt + Rust ==="
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    # Mirrors the x64 job's dependency list. libjack-jackd2-dev rather than the
    # virtual libjack-dev: Debian has several providers, so apt can't resolve
    # the virtual name on its own.
    apt-get install -y \
        build-essential cmake pkg-config \
        ca-certificates curl git \
        libasound2-dev libudev-dev libjack-jackd2-dev libpipewire-0.3-dev

    # The Rust subsystems (clockwork's MIDI/gamepad/OSC) are one cargo-built
    # staticlib the native build links. i686-unknown-linux-gnu is a tier-1 target, but getting
    # it installed takes saying so: rustup-init infers the host triple from the
    # KERNEL, which is x86_64 even in a 32-bit userland, so left alone it
    # installs a 64-bit toolchain whose binaries cannot execute here. That
    # install "succeeds" (with a quiet "error reading rustc version") and the
    # failure only surfaces at build time as the shim reporting
    #   error: command failed: 'cargo': No such file or directory
    local triple=i686-unknown-linux-gnu
    setup_paths   # pick up a toolchain from an earlier run of this phase

    if ! cargo --version >/dev/null 2>&1; then
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \
            | sh -s -- -y --profile minimal \
                --default-host "$triple" --default-toolchain stable
    fi
    setup_paths

    # Correct the toolchain only if it isn't already the right host — an image
    # carrying a pre-existing ~/.rustup keeps the default from its own
    # settings.toml and ignores the inferred one entirely.
    #
    # --force-non-host is required for the same reason the triple has to be
    # pinned: rustup reads the kernel (x86_64) and calls an i686 toolchain
    # foreign, refusing with "may not be able to run on this system". Nothing is
    # emulated here — 32-bit binaries run natively on this CPU.
    if ! rustc -vV 2>/dev/null | grep -q "^host: $triple$"; then
        rustup set default-host "$triple"
        rustup toolchain install --force-non-host --profile minimal "stable-$triple"
        rustup default --force-non-host "stable-$triple"
    fi

    # Fail here, with the toolchain in view, rather than 200 lines into a build.
    cargo --version
    rustc --version
}

phase_configure() {
    echo "=== configure ==="
    setup_paths
    cmake -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTS=ON
}

phase_build() {
    echo "=== build: SuperSonic + tests ==="
    setup_paths
    cmake --build "$BUILD_DIR" --config Release --parallel --target SuperSonic
    # Capped at 2 parallel jobs to match the x64 job: the test target recompiles
    # JUCE alongside Catch2 and the test sources, and unbounded parallelism can
    # exhaust memory on heavy modules like juce_audio_devices.
    cmake --build "$BUILD_DIR" --config Release --parallel 2 --target SuperSonicNativeTests
}

phase_test() {
    echo "=== test: Catch2 suite ==="
    setup_paths
    # Twice, as the x64 job and for its reasons (native.yml): every
    # registered test with each Catch2 case in a process of its own, then the
    # binary with every case in one process, in a shuffled order.
    ctest --test-dir "$BUILD_DIR" --output-on-failure -j 2 --timeout 300
    "$BUILD_DIR/test/native/SuperSonicNativeTests" "~[benchmark]" --order rand ${GITHUB_RUN_NUMBER:+--rng-seed "$GITHUB_RUN_NUMBER"}
}

phase_transport() {
    echo "=== transport harness ==="
    setup_paths
    # run.sh defaults to build/native/...; pass the binary explicitly since this
    # job builds into a separate dir so it can't clash with a local x64 build.
    "$PROJECT_ROOT/test/transport-harness/run.sh" "$BUILD_DIR/SuperSonic"
}

main() {
    check_arch
    case "${1:-all}" in
        deps)      phase_deps ;;
        configure) phase_configure ;;
        build)     phase_build ;;
        test)      phase_test ;;
        transport) phase_transport ;;
        all)
            phase_deps
            phase_configure
            phase_build
            phase_test
            phase_transport
            ;;
        --help|-h)
            sed -n '3,30p' "${BASH_SOURCE[0]}"
            ;;
        *)
            echo "Unknown phase: $1" >&2
            echo "Valid: all deps configure build test transport" >&2
            exit 1
            ;;
    esac
}

main "$@"
