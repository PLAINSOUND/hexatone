#!/bin/bash
set -e

# SuperSonic Version Bump Script
#
# Sets the version everywhere a release names it:
#
#   - the version field in package.json and in each package's package.json
#     (core, synthdefs, samples and bundle)
#   - the bundle's dependencies on the other four
#   - the CDN URLs in the core, synthdefs and samples packages' index.js
#   - the versions pinned in docs/INSTALLATION_WEB.md and example/*.html
#   - CMakeLists.txt's project(SuperSonic VERSION x.y.z), which clockwork turns
#     into the banner, the -v output and the Windows version resource
#   - package-lock.json (through npm)
#   - a new entry in packaging/debian/changelog
#
# and then regenerates the manifests.
#
# READMEs and error messages say @latest, so they need nothing. A version in
# prose about an older release (js/supersonic.js, the specs) is history and is
# left alone.

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if version argument provided
if [ -z "$1" ]; then
    echo -e "${RED}Error: Version number required${NC}"
    echo "Usage: scripts/bump-version.sh <version>"
    echo "Example: scripts/bump-version.sh 0.1.2"
    exit 1
fi

NEW_VERSION=$1
shift || true
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# --yes: no prompt. --no-build: leave dist to `npm publish` (its prepublishOnly builds --release).
# --no-commit: edit and stage only, for a repository whose commits are made by hand.
# --no-synthdef-check: release without checking the synthdefs against Sonic Pi's (below). Say why in the commit.
ASSUME_YES=false; DO_BUILD=true; DO_COMMIT=true; CHECK_SYNTHDEFS=true
for arg in "$@"; do
    case "$arg" in
        --yes|-y)    ASSUME_YES=true ;;
        --no-build)  DO_BUILD=false ;;
        --no-commit) DO_COMMIT=false ;;
        --no-synthdef-check) CHECK_SYNTHDEFS=false ;;
        *) echo "unknown argument: $arg" >&2; exit 1 ;;
    esac
done

# in place, on BSD sed (macOS) as on GNU's: -i takes a suffix there, so one is given and the backup removed
sedi() { local script=$1; shift; sed -i.versionbak "$script" "$@" && rm -f "${@/%/.versionbak}"; }

# Validate version format (basic check)
if ! [[ "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${RED}Error: Invalid version format${NC}"
    echo "Version must be in format: X.Y.Z (e.g., 0.1.2)"
    exit 1
fi

# The synthdefs package is a copy of Sonic Pi's compiled set, and nothing else keeps it current: a release is refused
# while it differs from Sonic Pi's (scripts/sync-synthdefs.sh). SONIC_PI names the checkout to compare with.
if [ "$CHECK_SYNTHDEFS" = true ]; then
    if [ -z "$SONIC_PI" ]; then
        echo -e "${RED}Error: SONIC_PI is not set${NC}: the synthdefs are checked against Sonic Pi's before a release."
        echo "  SONIC_PI=<sonic-pi checkout> scripts/bump-version.sh $NEW_VERSION   (or --no-synthdef-check)"
        exit 1
    fi
    if ! "$PROJECT_ROOT/scripts/sync-synthdefs.sh" "$SONIC_PI" --check; then
        echo -e "${RED}Error: the synthdefs are out of date${NC}: sync them, commit, then bump."
        exit 1
    fi
    echo ""
fi

echo "========================================"
echo "  SuperSonic Version Bump"
echo "========================================"
echo ""
echo -e "${YELLOW}New version: $NEW_VERSION${NC}"
echo ""

# Get current version for reference
CURRENT_VERSION=$(node -p "require('./package.json').version")
echo "Current version: $CURRENT_VERSION"
echo ""

# Confirm
if [ "$ASSUME_YES" = false ]; then read -p "Continue with version bump? (y/n) " -n 1 -r; echo; else REPLY=y; fi
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "Step 1: Updating package.json files..."
echo "---------------------------------------"

# The five package.json version fields
sedi "s/\"version\": \"$CURRENT_VERSION\"/\"version\": \"$NEW_VERSION\"/" "$PROJECT_ROOT/package.json"
echo "✓ Updated package.json"

sedi "s/\"version\": \".*\"/\"version\": \"$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-core/package.json"
echo "✓ Updated packages/supersonic-scsynth-core/package.json"

sedi "s/\"version\": \"$CURRENT_VERSION\"/\"version\": \"$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-synthdefs/package.json"
echo "✓ Updated packages/supersonic-scsynth-synthdefs/package.json"

sedi "s/\"version\": \"$CURRENT_VERSION\"/\"version\": \"$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-samples/package.json"
echo "✓ Updated packages/supersonic-scsynth-samples/package.json"

sedi "s/\"version\": \"$CURRENT_VERSION\"/\"version\": \"$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-bundle/package.json"
echo "✓ Updated packages/supersonic-scsynth-bundle/package.json"

echo ""
echo "Step 2: Updating bundle dependencies..."
echo "----------------------------------------"

# The bundle's four dependencies, all caret ranges
sedi "s/\"supersonic-scsynth\": \"\\^$CURRENT_VERSION\"/\"supersonic-scsynth\": \"^$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-bundle/package.json"
echo "✓ Updated supersonic-scsynth dependency"

sedi "s/\"supersonic-scsynth-synthdefs\": \"\\^$CURRENT_VERSION\"/\"supersonic-scsynth-synthdefs\": \"^$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-bundle/package.json"
echo "✓ Updated supersonic-scsynth-synthdefs dependency"

sedi "s/\"supersonic-scsynth-samples\": \"\\^$CURRENT_VERSION\"/\"supersonic-scsynth-samples\": \"^$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-bundle/package.json"
echo "✓ Updated supersonic-scsynth-samples dependency"

sedi "s/\"supersonic-scsynth-core\": \"\\^$CURRENT_VERSION\"/\"supersonic-scsynth-core\": \"^$NEW_VERSION\"/" "$PROJECT_ROOT/packages/supersonic-scsynth-bundle/package.json"
echo "✓ Updated supersonic-scsynth-core dependency"

echo ""
echo "Step 3: Updating CDN constants and docs..."
echo "-------------------------------------------"

# Update CDN constants and docs
sedi "s|supersonic-scsynth-synthdefs@$CURRENT_VERSION|supersonic-scsynth-synthdefs@$NEW_VERSION|g" "$PROJECT_ROOT/packages/supersonic-scsynth-synthdefs/index.js"
echo "✓ Updated packages/supersonic-scsynth-synthdefs/index.js"

sedi "s|supersonic-scsynth-samples@$CURRENT_VERSION|supersonic-scsynth-samples@$NEW_VERSION|g" "$PROJECT_ROOT/packages/supersonic-scsynth-samples/index.js"
echo "✓ Updated packages/supersonic-scsynth-samples/index.js"

sedi "s|supersonic-scsynth-core@$CURRENT_VERSION|supersonic-scsynth-core@$NEW_VERSION|g" "$PROJECT_ROOT/packages/supersonic-scsynth-core/index.js"
echo "✓ Updated packages/supersonic-scsynth-core/index.js"

# every package the docs pin, not only the client: -core, -synthdefs and -samples too. A version in prose
# ("up to 0.81.0") has no @ before it and stays as the history it is.
sedi "s|@$CURRENT_VERSION|@$NEW_VERSION|g" "$PROJECT_ROOT/docs/INSTALLATION_WEB.md"
echo "✓ Updated docs/INSTALLATION_WEB.md"

echo ""
echo "Step 4: Updating C++ version constants..."
echo "------------------------------------------"

# Parse new version into components
IFS='.' read -r NEW_MAJOR NEW_MINOR NEW_PATCH <<< "$NEW_VERSION"

# The C++ side takes its version from CMake: project(SuperSonic VERSION x.y.z)
# in CMakeLists.txt, which clockwork turns into the boot banner, `-v`, and the
# Windows version resource.
sedi "s/^\(    VERSION \)$CURRENT_VERSION\$/\1$NEW_VERSION/" "$PROJECT_ROOT/CMakeLists.txt"
grep -q "VERSION $NEW_VERSION" "$PROJECT_ROOT/CMakeLists.txt" || { echo "ERROR: CMakeLists.txt VERSION was not $CURRENT_VERSION" >&2; exit 1; }
echo "✓ Updated CMakeLists.txt ($CURRENT_VERSION → $NEW_VERSION)"

echo ""
echo "Step 4b: Updating what else names the version..."
echo "-------------------------------------------------"

# The lock file's own version fields (npm keeps them in step with package.json)
npm install --package-lock-only --ignore-scripts --silent --prefix "$PROJECT_ROOT" >/dev/null
echo "✓ Updated package-lock.json"

# The examples pin a version in their CDN URLs, so they keep working against the release they were written for
for html in "$PROJECT_ROOT"/example/*.html; do
    [ -e "$html" ] || continue
    if grep -q "@$CURRENT_VERSION" "$html"; then
        sedi "s|@$CURRENT_VERSION|@$NEW_VERSION|g" "$html"
        echo "✓ Updated $(basename "$html")"
    fi
done

# Debian's changelog takes a new entry, not a rewritten one
CHANGELOG="$PROJECT_ROOT/packaging/debian/changelog"
if [ -f "$CHANGELOG" ] && ! head -1 "$CHANGELOG" | grep -q "($NEW_VERSION-1)"; then
    # signed as the package's own Maintainer, byte for byte: anything else and lintian reads the entry as a
    # non-maintainer upload and the Debian job fails (source-nmu-has-incorrect-version-number)
    MAINTAINER=$(sed -n 's/^Maintainer: //p' "$PROJECT_ROOT/packaging/debian/control" | head -1)
    { printf 'supersonic (%s-1) unstable; urgency=medium\n\n  * New upstream release.\n\n -- %s  %s\n\n' \
        "$NEW_VERSION" "$MAINTAINER" "$(date -R)"; cat "$CHANGELOG"; } > "$CHANGELOG.new"
    mv "$CHANGELOG.new" "$CHANGELOG"
    echo "✓ Added packaging/debian/changelog entry"
fi

# A version named in prose about what an older release did is history: left alone (js/supersonic.js, the specs).

echo ""
echo "Step 5: Regenerating manifests..."
echo "----------------------------------"

node "$PROJECT_ROOT/scripts/generate-manifests.mjs"
echo "✓ Manifests regenerated"

echo ""
echo "Step 6: Rebuilding distribution..."
echo "-----------------------------------"

if [ "$DO_BUILD" = true ]; then
    "$PROJECT_ROOT/scripts/build-web.sh" --release
    echo "✓ Build complete"
else
    echo "(skipped: npm publish builds --release itself)"
fi

echo ""
echo "Step 7: Committing changes..."
echo "------------------------------"

git add -u   # what the bump changed; untracked work in the tree is its owner's
if [ "$DO_COMMIT" = true ]; then
    git commit -m "Version - $NEW_VERSION"
    echo "✓ Changes committed"
    git tag "v$NEW_VERSION"
    echo "✓ Tagged v$NEW_VERSION"
else
    echo "✓ Changes staged (commit and tag v$NEW_VERSION by hand)"
fi

echo ""
echo -e "${GREEN}========================================"
echo "Version bump complete! 🎉"
echo "========================================${NC}"
echo ""
echo "New version: $NEW_VERSION"
echo ""
echo "Next steps:"
if [ "$DO_COMMIT" = true ]; then
    echo "  1. Review the commit: git show"
else
    echo "  1. Review what's staged, then commit and tag it:"
    echo "       git diff --cached"
    echo "       git commit -m \"Version - $NEW_VERSION\" && git tag v$NEW_VERSION"
fi
echo "  2. Push main, then the tag: git push && git push origin v$NEW_VERSION"
echo "     The tag runs .github/workflows/publish.yml. Once every other check on the"
echo "     commit is green, it publishes the npm packages and the GitHub release."
echo ""
