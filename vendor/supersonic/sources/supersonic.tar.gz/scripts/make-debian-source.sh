#!/bin/bash

# Assemble a real Debian source package (.dsc + orig + component tarballs)
# for SuperSonic, the way a Debian maintainer would.
#
# Layout produced (in build/debian/):
#   supersonic_<uv>.orig.tar.xz             git archive of HEAD with the
#                                           clockwork submodule archived into
#                                           clockwork/, minus the Files-Excluded
#                                           set in packaging/debian/copyright
#   supersonic_<uv>.orig-link.tar.xz        pristine Ableton Link 4.0 with its
#                                           asio-standalone submodule (the
#                                           GitHub tag tarball lacks
#                                           submodules, hence the clone)
#   supersonic_<uv>.orig-rust-vendor.tar.xz `cargo vendor` output for the
#                                           committed clockwork/rust/Cargo.lock
#   supersonic_<dv>.dsc + .debian.tar.xz    via dpkg-buildpackage -S
#
# The four Link patches are clockwork's (clockwork/external/*.patch); they are
# path-shifted under link/ into debian/patches here so dpkg-source applies
# them to the component tree.
#
# Versioning: releases (HEAD == tag v<version>) get <version>-1; anything else
# gets <version>+git<date>.<sha>-1~ci1 so snapshot packages sort below the
# eventual release.
#
# Needs network (Link clone + crates.io) — run it in the *networked* phase;
# the package build itself then proves it needs none. Archives HEAD, so
# uncommitted changes are not included.
#
# Usage: scripts/make-debian-source.sh [workdir]   (default: build/debian)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
WORK="${1:-$PROJECT_ROOT/build/debian}"

LINK_TAG="Link-4.1"
LINK_REPO="https://github.com/Ableton/link.git"

cd "$PROJECT_ROOT"

# ── Version ──────────────────────────────────────────────────────────────────
# package.json is the one place the version is written by hand;
# scripts/bump-version.sh carries it to CMakeLists.txt and the packages.
V="$(sed -n 's/^  "version": "\([0-9][0-9.]*\)",$/\1/p' package.json | head -1)"
[ -n "$V" ] || { echo "ERROR: no version in package.json" >&2; exit 1; }
SHA="$(git rev-parse --short HEAD)"

if git describe --tags --exact-match HEAD 2>/dev/null | grep -qx "v$V"; then
    UV="$V"
    DEBV="$V-1"
    SNAPSHOT=""
else
    UV="$V+git$(date -u +%Y%m%d).$SHA"
    DEBV="$UV-1~ci1"
    SNAPSHOT="yes"
fi
echo "=== supersonic $DEBV (upstream $UV) ==="

# Refuse to wipe a pre-existing directory this script didn't create (the
# sentinel guards against e.g. an accidental `make-debian-source.sh ~`).
if [ -e "$WORK" ] && [ ! -e "$WORK/.supersonic-debian-work" ]; then
    echo "ERROR: $WORK exists but was not created by this script; refusing to delete it." >&2
    exit 1
fi
rm -rf "$WORK"
mkdir -p "$WORK"
touch "$WORK/.supersonic-debian-work"
SRC="$WORK/supersonic-$UV"

# ── Main orig tarball: git archive minus Files-Excluded ─────────────────────
echo "=== orig tarball ==="
git archive --format=tar --prefix="supersonic-$UV/" HEAD | tar -x -C "$WORK"
# git archive stops at the submodule boundary: clockwork/ comes out as an
# empty directory. Archive the submodule's own HEAD into it, so the orig
# tarball is the whole program.
git -C clockwork archive --format=tar --prefix="supersonic-$UV/clockwork/" HEAD | tar -x -C "$WORK"
# Keep in sync with Files-Excluded in packaging/debian/copyright.
rm -rf "$SRC/clockwork/external/ASIOSDK2.3.4"
tar -C "$WORK" -cJf "$WORK/supersonic_$UV.orig.tar.xz" "supersonic-$UV"

# ── Link component: pristine upstream incl. submodules ──────────────────────
echo "=== orig-link tarball ($LINK_TAG) ==="
git clone --quiet --depth 1 --branch "$LINK_TAG" \
    --recurse-submodules --shallow-submodules "$LINK_REPO" "$WORK/link"
find "$WORK/link" -name .git -prune -exec rm -rf {} +
tar -C "$WORK" -cJf "$WORK/supersonic_$UV.orig-link.tar.xz" link

# ── Rust vendor component ───────────────────────────────────────────────────
echo "=== orig-rust-vendor tarball ==="
(cd clockwork/rust && cargo vendor "$WORK/rust-vendor")

# Sanitise the vendor tree so it survives Debian's source-package machinery and
# lintian. For each affected crate we delete the offending files AND strip their
# entries from .cargo-checksum.json, so cargo (which only checks listed files,
# and only for crates it actually builds) stays consistent. Two classes:
#
#   *.orig — newer cargo writes Cargo.toml.orig for crates whose manifest it
#     rewrites; dpkg-source's default tar-ignore drops *.orig as patch backups,
#     so cargo would abort the offline build on a checksummed-but-missing file.
#
#   Prebuilt Windows binaries — the winapi *-pc-windows-gnu crates ship prebuilt
#     import libraries (lib/*.a) and libloading ships Windows test DLLs. None are
#     compiled on a Linux target, but they trip lintian (ar-unreadable .a =
#     error; *.dll = source-contains-prebuilt-windows-binary warning) and would
#     be a DFSG smell in the source package. The Windows build uses crates.io
#     directly, so pruning them from the Linux vendor tarball costs nothing.
python3 - "$WORK/rust-vendor" <<'PY'
import json, os, sys
root = sys.argv[1]

def is_junk(crate, key):
    if key.endswith(".orig"):
        return True
    if key.endswith((".dll", ".dll.a")):
        return True
    # Prebuilt import/static libs only inside the Windows target crates, so a
    # legitimately source-shipped Linux .a (none known) is never touched.
    if "windows" in crate and key.endswith((".a", ".lib")):
        return True
    return False

for crate in sorted(os.listdir(root)):
    cksum = os.path.join(root, crate, ".cargo-checksum.json")
    if not os.path.isfile(cksum):
        continue
    with open(cksum) as f:
        data = json.load(f)
    files = data.get("files", {})
    removed = [k for k in files if is_junk(crate, k)]
    for k in removed:
        del files[k]
        p = os.path.join(root, crate, k)
        if os.path.exists(p):
            os.remove(p)
    if removed:
        with open(cksum, "w") as f:
            json.dump(data, f, separators=(",", ":"))
        print(f"  sanitised {crate}: dropped {len(removed)} file(s)")
PY
tar -C "$WORK" -cJf "$WORK/supersonic_$UV.orig-rust-vendor.tar.xz" rust-vendor

# ── Assemble the source tree ────────────────────────────────────────────────
echo "=== source tree ==="
cp -a "$WORK/link" "$SRC/link"
cp -a "$WORK/rust-vendor" "$SRC/rust-vendor"
cp -a packaging/debian "$SRC/debian"

# Path-shift the Link patches under the link/ component.
mkdir -p "$SRC/debian/patches"
: > "$SRC/debian/patches/series"
for p in clockwork/external/link-*.patch; do
    name="$(basename "$p")"
    sed -e 's|^--- a/|--- a/link/|' -e 's|^+++ b/|+++ b/link/|' \
        "$p" > "$SRC/debian/patches/$name"
    echo "$name" >> "$SRC/debian/patches/series"
done

# Reconcile the changelog with the computed version. Snapshots always need a
# new entry; releases need one too whenever the checked-in changelog hasn't
# caught up with a version bump (otherwise dpkg-buildpackage would look for an
# orig tarball named after the stale changelog version and fail).
CHANGELOG_V="$(dpkg-parsechangelog -l "$SRC/debian/changelog" -S Version)"
if [ "$CHANGELOG_V" != "$DEBV" ]; then
    if [ -n "$SNAPSHOT" ]; then
        entry="CI snapshot of git $SHA."
    else
        entry="New upstream release $V (auto-generated entry; see git history)."
    fi
    (cd "$SRC" && DEBEMAIL="sam@sonic-pi.net" DEBFULLNAME="Sam Aaron" \
        dch --newversion "$DEBV" --distribution unstable --force-distribution \
            "$entry")
fi

# ── Build the source package ────────────────────────────────────────────────
echo "=== dpkg-buildpackage -S ==="
(cd "$SRC" && dpkg-buildpackage -S -us -uc -d)

echo "=== done ==="
ls -l "$WORK"/*.dsc "$WORK"/*.tar.xz
