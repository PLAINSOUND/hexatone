# Sending OSC from Workers

## Avoiding the Main Thread

When you send OSC from the main thread, it has to compete with everything else happening there - DOM updates, event handlers, animations, your application logic. For simple cases this is fine, but if you're running a sequencer, processing MIDI input, or doing other timing-sensitive work, you can end up with jitter or UI stuttering.

Web Workers let you move work off the main thread. The challenge is getting OSC from a worker to the AudioWorklet efficiently. You could send messages back to the main thread and have it forward them - but that adds latency and defeats the purpose of using a worker in the first place.

SuperSonic solves this with `OscChannel` - a transferable object that gives workers a direct line to the AudioWorklet.

## OscChannel

Normally you'd just call `supersonic.send()` - but workers are separate threads with no access to your main thread's objects. The `supersonic` instance doesn't exist in the worker's world.

You could have the worker send messages back to the main thread via `postMessage`, and have the main thread forward them to scsynth. But that puts the main thread back in the middle of every message - defeating the purpose of using a worker.

The solution is to create a direct channel from the worker to the synth in the AudioWorklet. SuperSonic gives you an `OscChannel` for exactly this.

You create an `OscChannel` with `createOscChannel` (after `init()`) and then you need to **transfer** it to the worker.

Note: Transferring is critical because the core internal comms mechanisms cannot be copied to the worker with a standard `postMessage`, they must be explicitly transferred. This enables the worker to have full and unique ownership of the newly created `OscChannel`.

Here's how you create an `OscChannel` and transfer it to a worker:

```javascript
// Main thread - create and transfer
const channel = supersonic.createOscChannel();
worker.postMessage(
  { type: "init", channel: channel.transferable },
  channel.transferList
);
```

The second argument to `postMessage` is optional - when provided, it lists which objects to transfer rather than copy.

In your worker, handle this as an init message and reconstruct the channel. `OscChannel.fromTransferable()` returns a promise, so await it:

```javascript
// Worker thread
import { OscChannel } from "supersonic-scsynth";

let channel = null;

self.onmessage = async (event) => {
  if (event.data.type === "init") {
    channel = await OscChannel.fromTransferable(event.data.channel);

    // Now you can send OSC directly to the AudioWorklet
    channel.send(oscBytes);
  }
};
```

Using a `type` field lets you handle different message types cleanly - for example `init`, `start`, `stop` (see the [sequencer example](#example-sequencer-worker) below).


## Multiple Workers

Each call to `createOscChannel()` returns a new channel with a unique source ID. This means you can have multiple workers all sending OSC independently - they don't need to coordinate with each other, and their messages can be traced back to their source in metrics and logs.

```javascript
const sequencerChannel = supersonic.createOscChannel(); // sourceId: 1
const lfoChannel = supersonic.createOscChannel(); // sourceId: 2
const midiChannel = supersonic.createOscChannel(); // sourceId: 3

sequencerWorker.postMessage({ channel: sequencerChannel.transferable }, sequencerChannel.transferList);
lfoWorker.postMessage({ channel: lfoChannel.transferable }, lfoChannel.transferList);
midiWorker.postMessage({ channel: midiChannel.transferable }, midiChannel.transferList);
```

In SAB mode there is a limit. Each channel a worker reconstructs takes one of the engine's eight client slots, and the main thread, the reply worker and the traffic-logging worker hold three of them, which leaves five. `fromTransferable()` rejects when none is free.

## SAB vs PM Mode

`OscChannel` works identically in both modes - it detects the active mode and uses the appropriate communication method automatically. Your worker code doesn't need to know or care which mode is active.

See [Communication Modes](MODES.md) for details on choosing between SAB and postMessage modes.

## Message Routing

`OscChannel.send()` does no routing of its own. It hands the bytes to the engine - into the ring buffer in SAB mode, down a `MessagePort` in postMessage mode - and the engine's audio thread does the rest. Messages run as they arrive; a bundle with a future timetag waits in the engine's scheduler until its time.

`send()` returns `false` when the message could not be sent. In SAB mode that means the ring buffer was full: the message is dropped and counted in the `ringBufferDirectWriteFails` metric.

## OscChannel API

### Methods

| Method                 | Description                                |
| ---------------------- | ------------------------------------------ |
| `send(oscBytes)`       | Send OSC bytes to the engine; `false` if they could not be sent |
| `nextNodeId()`         | A unique node ID, from the same allocator as `supersonic.nextNodeId()` |
| `now()`                | The engine's clock in NTP seconds (`0` until it has rendered a block) |
| `getMetrics()`         | `{ messagesSent, bytesSent }`: in SAB mode the totals for every sender, in postMessage mode this channel's |
| `close()`              | Release resources                          |

### Properties

| Property        | Description                                                   |
| --------------- | ------------------------------------------------------------- |
| `mode`          | `'sab'` or `'postMessage'`                                    |
| `transferable`  | Data for `postMessage` transfer                               |
| `transferList`  | Transferable objects array                                    |

### Static Methods

| Method                              | Description                   |
| ----------------------------------- | ----------------------------- |
| `OscChannel.fromTransferable(data)` | Reconstruct channel in worker (returns a promise) |

## Example: Sequencer Worker

Here's a worker that runs a simple step sequencer:

```javascript
// sequencer-worker.js
import { OscChannel, osc } from "supersonic-scsynth";

let channel = null;
let running = false;
let step = 0;
let bpm = 120;

const pattern = [60, 62, 64, 65, 67, 65, 64, 62]; // Notes to play

self.onmessage = async (event) => {
  const { type, data } = event.data;

  if (type === "init") {
    channel = await OscChannel.fromTransferable(data.channel);
    self.postMessage({ type: "ready" });
  } else if (type === "start") {
    running = true;
    step = 0;
    tick();
  } else if (type === "stop") {
    running = false;
  } else if (type === "bpm") {
    bpm = data.bpm;
  }
};

function tick() {
  if (!running || !channel) return;

  const note = pattern[step % pattern.length];
  const msg = osc.encodeMessage("/s_new", [
    "sonic-pi-beep", -1, 0, 0,
    "note", note,
    "amp", 0.5
  ]);
  channel.send(msg);

  step++;
  const msPerBeat = 60000 / bpm;
  setTimeout(tick, msPerBeat / 4); // 16th notes
}
```

The main thread loads the synthdef, hands the worker its channel, and starts it once the worker says the channel is ready. Starting it straight away would race the `await` in the worker:

```javascript
await supersonic.loadSynthDef("sonic-pi-beep");

const worker = new Worker("sequencer-worker.js", { type: "module" });
worker.onmessage = (event) => {
  if (event.data.type === "ready") worker.postMessage({ type: "start" });
};

const channel = supersonic.createOscChannel();
worker.postMessage({ type: "init", data: { channel: channel.transferable } }, channel.transferList);
```

## Using OscChannel in an AudioWorklet

OscChannel can also be used inside an `AudioWorkletProcessor`, not just Web Workers. This lets custom AudioWorklet code send OSC directly to scsynth without routing through the main thread.

There are two things to know compared with worker usage:

**1. Import from the AudioWorklet-safe entry point**

The standard `supersonic-scsynth` entry point pulls in `TextDecoder`, `Worker`, and DOM APIs that aren't available in `AudioWorkletGlobalScope`. Use the slim entry point instead:

```javascript
import { OscChannel } from 'supersonic-scsynth/osc-channel';
```

This only exports `OscChannel` and what it needs (its ring buffer client, offsets and clock reader) — nothing that touches the DOM or spawns workers.

**2. Sending never calls `Atomics.wait()` (SAB mode)**

The audio rendering thread cannot call `Atomics.wait()`, and `send()` never does. If another producer holds the ring buffer's spinlock, `send()` spins until it is free - it is held only for a message header and a copy - and a full ring buffer makes `send()` return `false` rather than wait for room. No option is needed.

## Cleanup

When you're done with a worker, you may close its OSC channel:

```javascript
// In the worker
channel.close();
```
