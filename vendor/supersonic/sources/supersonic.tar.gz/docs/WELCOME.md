
```
░█▀▀░█░█░█▀█░█▀▀░█▀▄░█▀▀░█▀█░█▀█░▀█▀░█▀▀
░▀▀█░█░█░█▀▀░█▀▀░█▀▄░▀▀█░█░█░█░█░░█░░█░░
░▀▀▀░▀▀▀░▀░░░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀
```
>     Greetings friend,
>
>     I hear you're interested in combining the research-level
>     audio synthesis capabilities of the legendary SuperCollider
>     scsynth engine with the incredible reach of the web?

>     Welcome, you've come to the right place.

# A Legendary Audio Synth in your Browser

SuperCollider's scsynth is a legendary audio synthesis engine designed by James McCartney in the late 90s.

__Scsynth has been widely used for decades for audio research, algorithmic composition, live performance systems and instrument augmentation.__

SuperSonic brings scsynth into the browser as an AudioWorklet. This enables scsynth to maintain its incredible performance and sub-sample timing accuracy even within the constraints of a web browser.

The browser is not the only place it runs. The same engine also runs natively, as a server with its own audio device - see the [Native Guide](NATIVE.md) - and inside the Erlang VM as a NIF - see the [NIF Guide](NIF.md). The rest of this page is about the browser.

- **Real-time synthesis** - Create sounds from scratch using oscillators, filters, envelopes, and effects
- **Sample playback** - Load and manipulate audio samples with precise timing control
- **Modular routing** - Connect audio and control signals in any configuration
- **Low latency** - High-performance audio via WebAssembly and AudioWorklet
- **Sample-accurate scheduling** - Precise timing for musical events within the audio engine
- **700+ Unit Generators** - Oscillators, filters, delays, reverbs, granular synthesis, FFT processing, and more
- **OSC control** - Full programmatic control over every parameter in real-time

SuperSonic is perfect for building interactive audio experiences, music tools, live coding environments and experimental sound art.

Happy Coding!

## Hello World

```html
<button>play</button>
```

```javascript
import { SuperSonic } from 'https://unpkg.com/supersonic-scsynth@latest/dist/supersonic.js';

const supersonic = new SuperSonic({
  baseURL: 'https://unpkg.com/supersonic-scsynth@latest/dist/',
  coreBaseURL: 'https://unpkg.com/supersonic-scsynth-core@latest/',
  synthdefBaseURL: 'https://unpkg.com/supersonic-scsynth-synthdefs@latest/synthdefs/',
});

// Browsers start audio only after a click, tap or keypress
document.querySelector('button').onclick = async () => {
  await supersonic.init();
  await supersonic.loadSynthDef('sonic-pi-prophet');
  supersonic.send('/s_new', 'sonic-pi-prophet', -1, 0, 0, 'note', 60);
};
```

For other installation options including npm and self-hosting, see the [Installation Guide](INSTALLATION_WEB.md).

## Documentation

- **[Installation](INSTALLATION_WEB.md)** - CDN, npm, self-hosting options
- **[Quick Start](QUICKSTART.md)** - Boot and play your first synth
- **[Guide](GUIDE.md)** - Practical patterns and worked examples
- **[API Reference](API.md)** - The SuperSonic JavaScript API for initialising, controlling, and communicating with the scsynth Audioworklet
- **[Communication Modes](MODES.md)** - SAB vs postMessage, server configuration
- **[Workers](WORKERS.md)** - Send OSC directly from Web Workers

## Synthesis

- **[scsynth Command Reference](SCSYNTH_COMMAND_REFERENCE.md)** - The full scsynth OSC command reference for controlling synthesis

## Monitoring

- **[Metrics](METRICS.md)** - Performance metrics and monitoring
- **[Metrics Component](METRICS_COMPONENT.md)** - Ready-made metrics dashboard web component

## Beyond the Browser

- **[Native Guide](NATIVE.md)** - SuperSonic as a native server
- **[NIF Guide](NIF.md)** - SuperSonic inside the Erlang VM

## For Contributors

- **[Building](BUILDING.md)** - Building SuperSonic from source
