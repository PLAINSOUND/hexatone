# SuperSonic

SuperSonic is a port of SuperCollider's scsynth audio engine to work within the strict constraints of a web audioworklet. The goal is low latency and high reliability for long running sessions.

Since 0.80 SuperSonic runs on [clockwork](https://github.com/samaaron/clockwork), a git submodule at `clockwork/`. clockwork provides the audio device IO, MIDI, OSC, gamepad input, transport clock, Ableton Link, the shared-memory segment, the browser client (`clockwork/js`) and the workers; SuperSonic provides the scsynth guest (`dsp/scsynth`), the native process (`host/`, `front/`), the JavaScript on top of clockwork's client (`js/supersonic.js` extends `Clockwork`), the tests and the packages. Changes to clockwork go to the clockwork repository; this repository then moves the submodule pointer.

**See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for full architectural documentation including message flow diagrams and component relationships.**

## Key Reference Files

* `supersonic.d.ts` — The TypeScript type declarations are the canonical API reference. They document every `send()` overload, all OSC reply formats, event types, and the full public surface area. Read this early when working on any feature that touches the API or OSC messages.
* `example/demo.html` — Interactive demo with a BOOT button, OSC text input, and live debug/OSC in/out panels. Useful for understanding the system end-to-end.

## AudioWorklet Constraints

The WASM scsynth runs inside an AudioWorklet which has strict requirements:

* No thread spawning
* No malloc (memory must be pre-allocated)
* No IO
* No main() entry point
* No automatic C++ initialiser calls

It's a static library that gets called via process() from the audioworklet's high priority thread.

The original scsynth was multi-threaded - separate threads for IO vs audio graph calculations, coordinated via queues for passing OSC messages. We've had to bypass all of this. Instead we use SharedArrayBuffer memory that can be accessed by both the WASM audioworklet code and JS to ship OSC in and out.

## Components

There isn't just the scsynth C++ compiled to wasm - it's actually a number of components:

* The WASM audioworklet code (scsynth + scheduler + ringbuffer read/write code)
* clockwork's workers (OSC in, OSC out log) and its AudioWorklet processor
* The SuperSonic JS code

## Communication Modes

There are two distinct modes with which these components communicate:

1. SAB - via SharedArrayBuffer
2. postMessage - via postMessage calls and the periodic transfer of sections of memory (i.e. containing metrics and mirror-node-tree)

Both modes are first class citizens and are fully supported and tested. SAB mode needs extra headers from the server and requires the browser to have stricter security (so no CDN) however postMessage mode is possible to deploy via CDN.

## Building

Every target is one CMake tree (clockwork's, with `dsp/scsynth` as the guest),
configured for this machine, for the NIF, or under `emcmake` for the web.
`scripts/build-all.sh` builds all three.

The engine's options are listed once in `dsp/scsynth/scsynth_options.h`; the
native flags, the NIF's config map and the web client's `scsynthOptions` all
take them by name from there. After changing the header run
`node scripts/gen-scsynth-options.mjs` to regenerate the client's schema.

The guest reaches clockwork through `clockwork/src/dsp_api.h` and nothing
else; `scripts/check-guest-boundary.sh` (also a CTest) fails on any other
clockwork include or symbol in `dsp/scsynth`.

Build the web (WASM + JS) distribution:

```bash
scripts/build-web.sh
```

Build the native server (clockwork + scsynth):

```bash
scripts/build-native.sh          # Release
scripts/build-native.sh --debug  # Debug
scripts/build-native.sh --clean  # Clean rebuild
```

On Windows use `scripts\build-native.bat` with the same flags.

Debian packaging: CI builds a real Debian source package per push (offline build with clockwork archived into the orig tarball, system Catch2/zlib, full test suite, lintian, autopkgtest) via `.github/workflows/debian.yml` + `scripts/ci-debian-package.sh`. Needs Docker, so it cannot run on this machine — iterate via `workflow_dispatch`. See `docs/DEBIAN-PACKAGING.md`.

## Testing

Tests use Playwright. The full suite is ~1500 tests across SAB and postMessage modes and takes ~3 minutes. The native Catch2 suite (`test/native`, ~1000 cases) and the transport harness are separate; see docs/BUILDING.md.

**The output is very large and will truncate. Always use concise output:**

```bash
# Full suite (summary only)
npx playwright test --reporter=line 2>&1 | tail -10

# Full suite (with failure details)
npx playwright test --reporter=line 2>&1 | tail -30

# Single file
npx playwright test test/some.spec.mjs --reporter=line

# Single project
npx playwright test --project=SAB --reporter=line
```

Always set a 5-minute timeout when running the full suite (it takes ~3 min with 8 workers).

## Running

Start the test server from the example directory:

cd example && npx serve

## Example

We have a nice demo example in example/demo.html which has a BOOT button to initialise scsynth, a text area for writing ascii OSC (with initial timestamps) and three other boxes - Debug Info (showing debug output from scsynth), OSC In and OSC Out showing OSC in and out of scsynth.
