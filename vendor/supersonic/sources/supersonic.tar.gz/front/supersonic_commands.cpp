// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (c) 2026 Sam Aaron
// See supersonic_commands.h.
#include "supersonic_commands.h"

#include "IOscTransport.h"
#include "clockwork_client.h"
#include "clockwork_sys.h"
#include "clockwork_config.h"   // clockwork_log
#include "buffer_commands.h"
#include "clockwork_asset_pool.h"
#include "clockwork_audio_file.h"
#include "AudioFormats.h"
#include "AudioThreadWitness.h"
#include "dsp_api.h"
#include "osc/OscOutboundPacketStream.h"
#include "osc/OscReceivedElements.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <thread>


namespace {

namespace fs = std::filesystem;

bool isMessage(const uint8_t* data, uint32_t size, const char* address) {
    const size_t n = std::strlen(address) + 1;   // the NUL too: "/b_allocRead" is not "/b_allocReadChannel"
    return size >= n && std::memcmp(data, address, n) == 0;
}

// `*` and `?` in a file name, the way scsynth's glob read them.
bool wildcardMatch(const char* pat, const char* str) {
    for (; *pat; ++pat, ++str) {
        if (*pat == '*') {
            for (++pat; *pat == '*'; ++pat) {}
            if (!*pat) return true;
            for (; *str; ++str) if (wildcardMatch(pat, str)) return true;
            return false;
        }
        if (!*str || (*pat != '?' && *pat != *str)) return false;
    }
    return !*str;
}

bool readFile(const fs::path& p, std::vector<uint8_t>& out) {
    audio_thread_witness::fileWork();
    std::ifstream f(p, std::ios::binary);
    if (!f) return false;
    out.assign(std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>());
    return !out.empty();
}

std::vector<fs::path> synthDefFiles(const std::string& spec, bool directory) {
    std::vector<fs::path> files;
    std::error_code ec;
    if (directory) {
        if (!fs::is_directory(spec, ec)) return files;
        for (fs::recursive_directory_iterator it(spec, ec), end; it != end && !ec; it.increment(ec))
            if (it->is_regular_file(ec) && it->path().extension() == ".scsyndef") files.push_back(it->path());
    } else {
        const fs::path pattern(spec);
        const std::string leaf = pattern.filename().string();
        if (leaf.find_first_of("*?") == std::string::npos) {
            if (fs::is_regular_file(pattern, ec)) files.push_back(pattern);
        } else {
            const fs::path dir = pattern.parent_path().empty() ? fs::path(".") : pattern.parent_path();
            for (fs::directory_iterator it(dir, ec), end; it != end && !ec; it.increment(ec)) {
                if (!it->is_regular_file(ec) || it->path().extension() != ".scsyndef") continue;
                if (wildcardMatch(leaf.c_str(), it->path().filename().string().c_str())) files.push_back(it->path());
            }
        }
    }
    std::sort(files.begin(), files.end());
    return files;
}

// A decoded file, cut to the frames asked for and, when channels were
// named, to those channels in that order. False: nothing to load, and why.
struct Frames {
    std::vector<float> samples;
    uint32_t           channels = 0;
    int64_t            frames = 0;
    float              rate = 0.f;
};
bool decodeFor(const std::string& path, int32_t start, int32_t want, const std::vector<int32_t>& pick,
               Frames& out, std::string& why) {
    ClockworkAudioInfo info {};
    info.struct_bytes = sizeof info;
    float* decoded = nullptr;
    audio_thread_witness::fileWork();
    const ClockworkStatus st = clockwork_audio_decode_file(path.c_str(), &info, &decoded);
    if (st != CLOCKWORK_OK) {
        why = "File '" + path + "' could not be opened: " + std::to_string(st);
        return false;
    }
    const int64_t total = static_cast<int64_t>(info.frames);
    const uint32_t ch   = info.channels;
    int64_t s = start < 0 ? 0 : start;
    if (s > total) s = total;
    int64_t n = want;
    if (n <= 0 || s + n > total) n = total - s;
    for (int32_t c : pick) {
        if (c < 0 || static_cast<uint32_t>(c) >= ch) {
            clockwork_audio_free(decoded);
            why = "Channel " + std::to_string(c) + " is out of range: '" + path + "' has "
                + std::to_string(ch) + " channels";
            return false;
        }
    }
    out.rate     = static_cast<float>(info.sample_rate);
    out.frames   = n < 0 ? 0 : n;
    out.channels = pick.empty() ? ch : static_cast<uint32_t>(pick.size());
    out.samples.resize(static_cast<size_t>(out.frames) * out.channels);
    if (pick.empty()) {
        if (out.frames > 0)
            std::memcpy(out.samples.data(), decoded + static_cast<size_t>(s) * ch,
                        static_cast<size_t>(out.frames) * ch * sizeof(float));
    } else {
        for (int64_t f = 0; f < out.frames; ++f)
            for (size_t k = 0; k < pick.size(); ++k)
                out.samples[static_cast<size_t>(f) * pick.size() + k] =
                    decoded[static_cast<size_t>(s + f) * ch + static_cast<size_t>(pick[k])];
    }
    clockwork_audio_free(decoded);
    return true;
}

} // namespace

namespace supersonic {

Commands::Commands(ClockworkClient* client, IOscTransport* replies, Work work)
    : mClient(client), mOwner(client, &clockwork_client_close), mReplies(replies), mTokenless(replies == nullptr),
      mWork(work), mRecorder(client, work == Work::Own),
      mWorker(work == Work::Own ? std::thread([this] { run(); }) : std::thread()) {}

Commands::~Commands() {
    {
        std::lock_guard<std::mutex> lock(mQueueMut);
        mStop = true;
    }
    mQueueCv.notify_all();
    if (mWorker.joinable()) mWorker.join();
    std::lock_guard<std::mutex> lock(mMut);
    if (mPool) clockwork_asset_pool_close(mPool);
    if (mOutPool) clockwork_asset_pool_close(mOutPool);
    mPool = mOutPool = nullptr;
}

// ── Ingress: the file verbs are ours ─────────────────────────────────────────

bool Commands::ingress(const uint8_t* data, uint32_t size, uint32_t token) {
    if (recordVerb(data, size, token)) return true;
    if (mQuit && isMessage(data, size, "/quit")) {
        sendDoneCmd(token, "/quit");
        mQuit();
        return true;
    }
    if (!mSummary.empty() && isMessage(data, size, "/clockwork/summary")) {
        // Down the debug channel, where a GUI that tails it shows it in its
        // info pane. The leading \x01 tells it to show the lines as they are,
        // with no timestamp, under a logo of its own.
        clockwork_log("%s", ("\x01\n" + mSummary).c_str());
        return true;
    }
    Job job;
    job.token = token;
    if (isMessage(data, size, "/b_allocRead"))             job.kind = Kind::AllocRead;
    else if (isMessage(data, size, "/b_allocReadChannel")) job.kind = Kind::AllocReadChannel;
    else if (isMessage(data, size, "/b_read"))             job.kind = Kind::ReadInto;
    else if (isMessage(data, size, "/b_readChannel"))      job.kind = Kind::ReadIntoChannel;
    else if (isMessage(data, size, "/b_write"))            job.kind = Kind::Write;
    else if (isMessage(data, size, "/d_load"))             job.kind = Kind::SynthDefFile;
    else if (isMessage(data, size, "/d_loadDir"))          job.kind = Kind::SynthDefDir;
    else return false;
    try {
        osc::ReceivedMessage m(osc::ReceivedPacket(reinterpret_cast<const char*>(data),
                                                   static_cast<osc::osc_bundle_element_size_t>(size)));
        auto it = m.ArgumentsBegin();
        const auto end = m.ArgumentsEnd();
        auto geti = [&](int32_t dflt) { return (it != end && it->IsInt32()) ? (it++)->AsInt32Unchecked() : dflt; };
        auto gets = [&](const char* dflt) { return (it != end && it->IsString()) ? std::string((it++)->AsStringUnchecked()) : std::string(dflt); };
        switch (job.kind) {
        case Kind::SynthDefFile:
        case Kind::SynthDefDir:
            if (it == end || !it->IsString()) return false;
            job.path = gets("");
            break;
        case Kind::AllocRead:
        case Kind::AllocReadChannel:
            if (it == end || !it->IsInt32()) return false;
            job.bufnum = geti(0);
            if (it == end || !it->IsString()) return false;
            job.path   = gets("");
            job.start  = geti(0);
            job.frames = geti(0);
            break;
        case Kind::ReadInto:
        case Kind::ReadIntoChannel:
            if (it == end || !it->IsInt32()) return false;
            job.bufnum = geti(0);
            if (it == end || !it->IsString()) return false;
            job.path      = gets("");
            job.start     = geti(0);
            job.frames    = geti(-1);
            job.bufStart  = geti(0);
            job.leaveOpen = geti(0);
            break;
        case Kind::Write:
            if (it == end || !it->IsInt32()) return false;
            job.bufnum = geti(0);
            if (it == end || !it->IsString()) return false;
            job.path      = gets("");
            job.header    = gets("aiff");
            job.sample    = gets("int16");
            job.frames    = geti(-1);
            job.bufStart  = geti(0);
            job.leaveOpen = geti(0);
            break;
        case Kind::Encode: return false;
        }
        // The ...Channel verbs: the channels to keep, as many as are given.
        if (job.kind == Kind::AllocReadChannel || job.kind == Kind::ReadIntoChannel)
            while (it != end && it->IsInt32()) job.channels.push_back((it++)->AsInt32Unchecked());
        if (it != end && it->IsBlob()) {
            const void* blob = nullptr;
            osc::osc_bundle_element_size_t n = 0;
            it->AsBlobUnchecked(blob, n);
            if (blob && n > 0) job.completion.assign(static_cast<const uint8_t*>(blob),
                                                     static_cast<const uint8_t*>(blob) + n);
        }
    } catch (const osc::Exception&) {
        return false;   // malformed: the engine's refusal says what is wrong
    }
    enqueue(std::move(job));
    return true;
}

// ── The worker ───────────────────────────────────────────────────────────────

void Commands::enqueue(Job job) {
    {
        std::lock_guard<std::mutex> lock(mQueueMut);
        mQueue.push_back(std::move(job));
    }
    mQueueCv.notify_one();
}

void Commands::run() {
    for (;;) {
        {
            std::unique_lock<std::mutex> lock(mQueueMut);
            mQueueCv.wait(lock, [this] { return mStop || !mQueue.empty(); });
            if (mStop) return;
        }
        runJobs();
    }
}

void Commands::runPending() {
    if (mWork != Work::Host) return;
    runJobs();
    mRecorder.pull();
}

// Every job queued, in arrival order, on the calling thread: the one worker.
void Commands::runJobs() {
    for (;;) {
        Job job;
        {
            std::lock_guard<std::mutex> lock(mQueueMut);
            if (mStop || mQueue.empty()) return;
            job = std::move(mQueue.front());
            mQueue.pop_front();
        }
        switch (job.kind) {
        case Kind::AllocRead: case Kind::AllocReadChannel:
        case Kind::ReadInto:  case Kind::ReadIntoChannel:   loadSample(job); break;
        case Kind::Write:                                    startWrite(job); break;
        case Kind::Encode:                                   encode(job);     break;
        case Kind::SynthDefFile: case Kind::SynthDefDir:     loadDefs(job);   break;
        }
    }
}

bool Commands::ensurePools() {
    ClockworkRegion a {}, r {};
    const bool hasLane = clockwork_client_region(mClient, CLOCKWORK_REGION_ASSETS, &a) == CLOCKWORK_OK && a.base && a.bytes > 0;
    const uint32_t in  = hasLane ? a.bytes : 0;
    const uint32_t out = clockwork_client_region(mClient, CLOCKWORK_REGION_RETURNS, &r) == CLOCKWORK_OK ? r.bytes : 0;
    if (!hasLane) return false;
    if (!mPool || mPoolBytes != in) {
        if (mPool) clockwork_asset_pool_close(mPool);   // a different lane: start over
        mPool = clockwork_asset_pool_open(in);
        mPoolBytes = mPool ? in : 0;
        mLive.clear();
    }
    if (out > 0 && (!mOutPool || mOutPoolBytes != out)) {
        if (mOutPool) clockwork_asset_pool_close(mOutPool);
        mOutPool = clockwork_asset_pool_open(out);
        mOutPoolBytes = mOutPool ? out : 0;
    }
    return mPool != nullptr;
}

bool Commands::takePending(Pending::What what, uint32_t token, int32_t bufnum, Pending* out) {
    for (auto it = mPending.begin(); it != mPending.end(); ++it) {
        if (it->what != what || (!mTokenless && it->token != token) || it->bufnum != bufnum) continue;
        *out = std::move(*it);
        mPending.erase(it);
        return true;
    }
    return false;
}

// /b_allocRead, /b_allocReadChannel, /b_read, /b_readChannel: decode, stage in
// the lane, and hand over — as an asset that becomes the buffer, or as a range
// the guest copies into one.
void Commands::loadSample(const Job& job) {
    const bool alloc = job.kind == Kind::AllocRead || job.kind == Kind::AllocReadChannel;
    const char* cmd = job.kind == Kind::AllocRead        ? "/b_allocRead"
                    : job.kind == Kind::AllocReadChannel ? "/b_allocReadChannel"
                    : job.kind == Kind::ReadInto         ? "/b_read" : "/b_readChannel";
    if (!alloc && job.leaveOpen) {
        sendFail(job.token, cmd, std::string(cmd) + " leaveOpen is not available: this engine does not stream from disk", job.bufnum);
        return;
    }
    Frames fr;
    std::string why;
    if (!decodeFor(job.path, job.start, job.frames, job.channels, fr, why)) {
        sendFail(job.token, cmd, why, job.bufnum);
        return;
    }
    if (alloc && (fr.frames <= 0 || fr.channels == 0)) {
        sendFail(job.token, cmd, "File '" + job.path + "' has no frames in the requested range", job.bufnum);
        return;
    }

    const uint32_t guardBefore = alloc ? supersonic_buffer_guard_before() : 0;
    const uint32_t guardAfter  = alloc ? supersonic_buffer_guard_after()  : 0;
    const uint64_t frameBytes  = static_cast<uint64_t>(fr.channels) * sizeof(float);
    const uint64_t slotBytes64 = (guardBefore + static_cast<uint64_t>(fr.frames) + guardAfter) * frameBytes;
    const uint32_t need        = slotBytes64 < 16 ? 16 : static_cast<uint32_t>(slotBytes64);
    uint32_t slot = 0;
    {
        std::lock_guard<std::mutex> lock(mMut);
        if (!ensurePools()) {
            sendFail(job.token, cmd, "the engine has no assets lane to load into", job.bufnum);
            return;
        }
        if (slotBytes64 > 0xFFFFFFFFull || clockwork_asset_pool_alloc(mPool, need, &slot) != 0) {
            sendFail(job.token, cmd, "assets lane full: " + std::to_string(slotBytes64) + " bytes needed, "
                     + std::to_string(clockwork_asset_pool_free_bytes(mPool)) + " free", job.bufnum);
            return;
        }
        Pending p { alloc ? Pending::Commit : Pending::ReadInto, job.token, job.bufnum, cmd, slot, job.completion, {} };
        mPending.push_back(std::move(p));
    }

    auto* lane = assetsLane();
    const uint32_t payload = slot + static_cast<uint32_t>(guardBefore * frameBytes);
    if (alloc) std::memset(lane + slot, 0, static_cast<size_t>(slotBytes64));
    if (!fr.samples.empty()) std::memcpy(lane + payload, fr.samples.data(), fr.samples.size() * sizeof(float));

    char buf[256];
    if (alloc) {
        {
            osc::OutboundPacketStream p(buf, sizeof buf);
            // The buffer is replaced, as /b_allocRead always replaced: whatever
            // it held goes first, and the guest lets its asset go with it. Sent
            // as the front's own, so whatever is said back is the front's.
            p << osc::BeginMessage("/b_free") << job.bufnum << osc::EndMessage;
            if (mTokenless) {
                std::lock_guard<std::mutex> lock(mMut);
                mOwnFrees.insert(job.bufnum);
            }
            sendOn(reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()), kFreeToken);
        }
        osc::OutboundPacketStream p(buf, sizeof buf);
        p << osc::BeginMessage("/clockwork/asset/commit")
          << job.bufnum << static_cast<int32_t>(CLOCKWORK_ASSET_AUDIO_F32)
          << static_cast<int32_t>(payload) << static_cast<int32_t>(fr.frames * frameBytes)
          << static_cast<int32_t>(fr.channels) << static_cast<int32_t>(fr.frames) << fr.rate
          << osc::EndMessage;
        sendOn(reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()), job.token);
    } else {
        osc::OutboundPacketStream p(buf, sizeof buf);
        p << osc::BeginMessage("/supersonic/buffer/read")
          << job.bufnum << job.bufStart << static_cast<int32_t>(payload)
          << static_cast<int32_t>(fr.frames) << static_cast<int32_t>(fr.channels) << fr.rate
          << osc::EndMessage;
        sendOn(reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()), job.token);
    }
}

// /b_write, first half: the format is checked here at once (as it was checked
// at Init), then the buffer is asked about, and its /b_info carries on below.
void Commands::startWrite(const Job& job) {
    if (job.leaveOpen) {
        sendFail(job.token, "/b_write", "/b_write leaveOpen is not available: this engine does not stream to disk", job.bufnum);
        return;
    }
    Job carried = job;
    carried.format   = supersonic_formats::headerFormat(job.header);
    carried.encoding = supersonic_formats::sampleEncoding(job.sample);
    if (!clockwork_audio_can_write(carried.format, carried.encoding)) {
        sendFail(job.token, "/b_write", "Cannot write '" + job.path + "' as " + job.header + " " + job.sample, job.bufnum);
        return;
    }
    {
        std::lock_guard<std::mutex> lock(mMut);
        if (!ensurePools() || !mOutPool) {
            sendFail(job.token, "/b_write", "the engine has no returns lane to publish into", job.bufnum);
            return;
        }
        Pending p { Pending::WriteQuery, job.token, job.bufnum, "/b_write", 0, job.completion, carried };
        mPending.push_back(std::move(p));
    }
    char buf[64];
    osc::OutboundPacketStream p(buf, sizeof buf);
    p << osc::BeginMessage("/b_query") << job.bufnum << osc::EndMessage;
    sendOn(reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()), job.token);
}

// /b_write, last half: the frames are in the returns area; encode them to the file.
void Commands::encode(const Job& job) {
    ClockworkAudioWriterConfig cfg {};
    cfg.struct_bytes = sizeof cfg;
    cfg.format      = job.format;
    cfg.encoding    = job.encoding;
    cfg.channels    = job.outChannels;
    cfg.sample_rate = static_cast<uint32_t>(job.outRate + 0.5f);
    ClockworkStatus st = CLOCKWORK_OK;
    audio_thread_witness::fileWork();
    ClockworkAudioWriter* w = clockwork_audio_writer_open(job.path.c_str(), &cfg, &st);
    if (w) {
        if (job.outFrames > 0) {
            const auto* frames = reinterpret_cast<const float*>(returnsLane() + job.outSlot);
            st = clockwork_audio_writer_write(w, frames, job.outFrames);
        }
        const ClockworkStatus closed = clockwork_audio_writer_close(w, nullptr, nullptr);
        if (st == CLOCKWORK_OK) st = closed;
    }
    {
        std::lock_guard<std::mutex> lock(mMut);
        if (mOutPool && job.outFrames > 0) clockwork_asset_pool_free(mOutPool, job.outSlot);
    }
    if (!w) {
        sendFail(job.token, "/b_write", "File '" + job.path + "' could not be opened: " + std::to_string(st), job.bufnum);
        return;
    }
    if (st != CLOCKWORK_OK) {
        sendFail(job.token, "/b_write", "File '" + job.path + "' could not be written: " + std::to_string(st), job.bufnum);
        return;
    }
    finish(job.token, "/b_write", job.bufnum, job.completion);
}

// /d_load, /d_loadDir: read the synthdefs, hand them over as /d_recv a batch
// at a time, the next only once the engine has answered the last. The engine
// parses a definition on its audio thread (scsynth's stage 2, on the one
// thread there is), a batch all in the callback after it was handed over, and
// the answers come back at the pass that follows. So a batch is what one
// callback carries: as many definitions as fit its share, kDefBytesPerFrame
// for each frame the callback before took (measured, the engine's own block
// count, not assumed), and always at least one, so a definition bigger than
// the share goes alone. One a callback, whatever its size, made a big
// buffer's load as many callbacks long as there were definitions (Sonic Pi's
// 164 took 7 s at 2048 frames, past its boot's wait); a sleep guessed here
// before that stacked them into one block whenever the audio thread ran
// slower than the guess.
void Commands::loadDefs(const Job& job) {
    const char* cmd = job.kind == Kind::SynthDefDir ? "/d_loadDir" : "/d_load";
    std::vector<std::vector<uint8_t>> defs;
    for (const fs::path& p : synthDefFiles(job.path, job.kind == Kind::SynthDefDir)) {
        std::vector<uint8_t> bytes;
        if (readFile(p, bytes)) defs.push_back(std::move(bytes));
    }
    if (defs.empty()) {
        sendFailCmd(job.token, cmd, job.path);   // as the engine said it: the path, not a sentence
        return;
    }
    {
        std::lock_guard<std::mutex> lock(mMut);
        const auto n = static_cast<uint32_t>(defs.size());
        DefLoad load{ job.token, cmd, job.path, n, n, 0, job.completion, {} };
        for (auto& d : defs) load.pending.push_back(std::move(d));
        mDefLoads.push_back(std::move(load));
    }
    // The first batch goes now; egress() sends each next one on the last
    // answer to the one before. A load queued behind another for the same
    // token waits its turn.
    std::vector<std::vector<uint8_t>> batch;
    {
        std::lock_guard<std::mutex> lock(mMut);
        takeNextDefs(job.token, batch);
    }
    sendDefs(job.token, batch);
}

std::deque<Commands::DefLoad>::iterator Commands::defInFlight(uint32_t token) {
    return std::find_if(mDefLoads.begin(), mDefLoads.end(),
                        [this, token](const DefLoad& load) { return (mTokenless || load.token == token) && load.inFlight > 0; });
}

bool Commands::takeNextDefs(uint32_t token, std::vector<std::vector<uint8_t>>& out) {
    for (auto& load : mDefLoads) {
        if (!mTokenless && load.token != token) continue;
        if (load.inFlight) return false;          // the oldest's batch is out: wait for its answers
        if (load.pending.empty()) continue;       // fully handed over, answers outstanding
        // The share: the frames the engine rendered while the last batch was
        // with it — the callback it was parsed in — at kDefBytesPerFrame. A
        // load's first batch has no callback to go by, and goes as one.
        const PerformanceMetrics& m = *metrics();
        const uint32_t blocksNow = m.process_count.load(std::memory_order_relaxed);
        const uint64_t share = load.batches == 0 ? 0
            : uint64_t{ blocksNow - load.batchSentAt } * m.audio_block_size.load(std::memory_order_relaxed)
                  * kDefBytesPerFrame;
        uint64_t bytes = 0;
        do {
            bytes += load.pending.front().size();
            out.push_back(std::move(load.pending.front()));
            load.pending.pop_front();
        } while (!load.pending.empty() && bytes + load.pending.front().size() <= share);
        load.inFlight = static_cast<uint32_t>(out.size());
        load.batchSentAt = blocksNow;
        ++load.batches;
        const DefBatch batch{ load.inFlight, static_cast<uint32_t>(bytes),
                              static_cast<uint32_t>(std::min<uint64_t>(share, UINT32_MAX)) };
        if (batch.defs > 1 && bytes > share) ++mDefBatchesOverShare;
        if (batch.defs > mLargestDefBatch.defs) mLargestDefBatch = batch;
        return true;
    }
    return false;
}

void Commands::sendDefs(uint32_t token, const std::vector<std::vector<uint8_t>>& defs) {
    std::vector<char> buf;
    for (const auto& bytes : defs) {
        buf.resize(bytes.size() + 64);
        osc::OutboundPacketStream p(buf.data(), buf.size());
        p << osc::BeginMessage("/d_recv")
          << osc::Blob(bytes.data(), static_cast<osc::osc_bundle_element_size_t>(bytes.size()))
          << osc::EndMessage;
        sendOn(reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()), token);
    }
}

// ── Egress: the engine's replies to what the front sent ──────────────────────

bool Commands::egress(uint32_t token, const uint8_t* data, uint32_t size) {
    if (token == kFreeToken) return true;   // what is said to the front's own frees is the front's, and goes no further
    if (size < 8 || data[0] != '/') return false;
    enum { Committed, Refused, Released, Done, Fail, Info, Published, Error, None } kind = None;
    if      (isMessage(data, size, "/clockwork/asset/committed"))   kind = Committed;
    else if (isMessage(data, size, "/clockwork/asset/refused"))     kind = Refused;
    else if (isMessage(data, size, "/clockwork/asset/released"))    kind = Released;
    else if (isMessage(data, size, "/done"))                        kind = Done;
    else if (isMessage(data, size, "/fail"))                        kind = Fail;
    else if (isMessage(data, size, "/b_info"))                      kind = Info;
    else if (isMessage(data, size, "/supersonic/buffer/published")) kind = Published;
    else if (isMessage(data, size, "/clockwork/error"))             kind = Error;
    if (kind == None) return false;

    int32_t     id = -1, a1 = 0, a2 = 0;
    float       f3 = 0.f;
    std::string cmd, why;
    try {
        osc::ReceivedMessage m(osc::ReceivedPacket(reinterpret_cast<const char*>(data),
                                                   static_cast<osc::osc_bundle_element_size_t>(size)));
        auto it = m.ArgumentsBegin();
        const auto end = m.ArgumentsEnd();
        if (kind == Error) {
            // "/clockwork/error <address> <reason> <generation>": clockwork
            // refused something sent on a token — ours, when the address is
            // one we had in flight for it. A refusal between instances
            // ("rebuilding", "no instance", "stalled", clockwork's
            // docs/RESTARTS.md) is what a load caught by a rebuild hears
            // instead of the /done that will never come.
            if (it == end || !it->IsString()) return false;
            cmd = (it++)->AsStringUnchecked();
            if (it != end && it->IsString()) why = (it++)->AsStringUnchecked();
        } else if (kind == Done || kind == Fail) {
            if (it == end || !it->IsString()) return false;
            cmd = (it++)->AsStringUnchecked();
            if (kind == Fail && it != end && it->IsString()) why = (it++)->AsStringUnchecked();
            if (it != end && it->IsInt32()) id = it->AsInt32Unchecked();
        } else {
            if (it == end || !it->IsInt32()) return false;
            id = (it++)->AsInt32Unchecked();
            if (kind == Refused && it != end && it->IsString()) why = it->AsStringUnchecked();
            if (kind == Info || kind == Published) {
                if (it != end && it->IsInt32()) a1 = (it++)->AsInt32Unchecked();
                if (it != end && it->IsInt32()) a2 = (it++)->AsInt32Unchecked();
                if (it != end && it->IsFloat()) f3 = it->AsFloatUnchecked();
            }
        }
    } catch (const osc::Exception&) {
        return false;
    }

    // With one token for every reply, the front's own /b_free is told from an
    // asker's by count: so many answers to /b_free are the front's.
    if (mTokenless && (kind == Done || kind == Fail) && cmd == "/b_free") {
        std::lock_guard<std::mutex> lock(mMut);
        auto it = mOwnFrees.find(id);
        if (it != mOwnFrees.end()) {
            mOwnFrees.erase(it);
            return true;
        }
    }

    // A refusal of anything else we had in flight on this token — a sample's
    // commit, a read, a query, a publish — fails that ask to its asker, in
    // scsynth's words, and frees what the ask held: the oldest such ask, since
    // a refusal names the message and not which ask sent it, and clockwork
    // refuses what waited in the order it was sent. Not ours: left for
    // whoever is.
    if (kind == Error) {
        // A definition refused is not one scsynth skipped (its own /fail,
        // below, costs the load one definition): the World it was going into
        // is gone, with every definition already in it, and the rest have no
        // World to go to. The whole load fails to its asker, nothing more is
        // sent for it, and the next load queued for the token takes its turn
        // — to be refused in turn, until the new World is up.
        // The rest of its batch is answered too, refused or not, before the
        // next load takes its turn: swallowed (the /d_recv path below), so
        // none is taken for the next load's.
        if (cmd == "/d_recv") {
            std::string failCmd, failPath;
            std::vector<std::vector<uint8_t>> next;
            bool found = false, first = false;
            {
                std::lock_guard<std::mutex> lock(mMut);
                auto it = defInFlight(token);
                if (it != mDefLoads.end()) {
                    found = true;
                    token = it->token;   // the asker's, from here
                    if (!it->refused) {
                        it->refused = true;
                        it->pending.clear();
                        first = true;
                        failCmd = it->cmd;
                        failPath = it->path;
                    }
                    if (--it->inFlight == 0) {
                        mDefLoads.erase(it);
                        takeNextDefs(token, next);
                    }
                }
            }
            if (!found) return false;
            if (first)
                sendFailCmd(token, failCmd.c_str(),
                            "the engine was rebuilt while '" + failPath + "' was loading (" + why + ")");
            sendDefs(token, next);
            return true;
        }
        // The refusal names the message WE sent; a pending ask remembers the
        // verb its ASKER used. The kind of ask is what the two share.
        int what = -1;
        if      (cmd == "/clockwork/asset/commit")    what = Pending::Commit;
        else if (cmd == "/supersonic/buffer/read")    what = Pending::ReadInto;
        else if (cmd == "/b_query")                   what = Pending::WriteQuery;
        else if (cmd == "/supersonic/buffer/publish") what = Pending::WritePublish;
        if (what < 0) return false;
        Pending failed;
        {
            std::lock_guard<std::mutex> lock(mMut);
            auto it = std::find_if(mPending.begin(), mPending.end(),
                                   [&](const Pending& p) { return (mTokenless || p.token == token) && p.what == what; });
            if (it == mPending.end()) return false;
            if (mPool && (it->what == Pending::Commit || it->what == Pending::ReadInto))
                clockwork_asset_pool_free(mPool, it->slot);
            failed = std::move(*it);
            mPending.erase(it);
        }
        sendFail(failed.token, failed.cmd.c_str(), "the engine refused it: " + why, failed.bufnum);
        return true;
    }
    // /d_recv replies: the batch in flight for that token, oldest load first
    // — and the last answer to a batch is what sends the next one. An answer
    // for a load a rebuild has already failed to its asker is swallowed.
    if ((kind == Done || kind == Fail) && cmd == "/d_recv") {
        DefLoad finished;
        bool last = false;
        std::vector<std::vector<uint8_t>> next;
        {
            std::lock_guard<std::mutex> lock(mMut);
            auto it = defInFlight(token);
            if (it == mDefLoads.end()) return false;
            token = it->token;   // the asker's, from here
            --it->inFlight;
            if (it->refused) {
                if (it->inFlight == 0) mDefLoads.erase(it);
            } else {
                if (kind == Fail) ++it->failed;
                if (--it->remaining == 0) { finished = std::move(*it); mDefLoads.erase(it); last = true; }
            }
            takeNextDefs(token, next);
        }
        if (last) {
            if (finished.failed == finished.total) {
                sendFailCmd(token, finished.cmd.c_str(), finished.path);
            } else {
                if (!finished.completion.empty())
                    sendOn(finished.completion.data(), static_cast<uint32_t>(finished.completion.size()), token);
                sendDoneCmd(token, finished.cmd.c_str());
            }
        }
        sendDefs(token, next);
        return true;
    }

    // /supersonic/buffer/read replies: the /b_read or /b_readChannel they answer.
    if ((kind == Done || kind == Fail) && cmd == "/supersonic/buffer/read") {
        Pending p;
        {
            std::lock_guard<std::mutex> lock(mMut);
            if (!takePending(Pending::ReadInto, token, id, &p)) return false;
            if (mPool) clockwork_asset_pool_free(mPool, p.slot);   // copied: the lane range is free again
        }
        if (kind == Done) finish(token, p.cmd.c_str(), id, p.completion);
        else              sendFail(token, p.cmd.c_str(), why, id);
        return true;
    }

    // /supersonic/buffer/publish failed: the /b_write it answers.
    if (kind == Fail && cmd == "/supersonic/buffer/publish") {
        Pending p;
        {
            std::lock_guard<std::mutex> lock(mMut);
            if (!takePending(Pending::WritePublish, token, id, &p)) return false;
            if (mOutPool && p.job.outFrames > 0) clockwork_asset_pool_free(mOutPool, p.slot);
        }
        sendFail(p.token, "/b_write", why, id);
        return true;
    }
    if (kind == Done || kind == Fail) return false;

    if (kind == Released) {
        std::lock_guard<std::mutex> lock(mMut);
        auto it = mLive.find(id);
        if (it == mLive.end()) return false;   // not a buffer of ours
        if (mPool) clockwork_asset_pool_free(mPool, it->second);
        mLive.erase(it);
        return true;
    }

    if (kind == Committed || kind == Refused) {
        Pending p;
        {
            std::lock_guard<std::mutex> lock(mMut);
            if (!takePending(Pending::Commit, token, id, &p)) return false;
            if (kind == Committed) mLive[id] = p.slot;
            else if (mPool)        clockwork_asset_pool_free(mPool, p.slot);
        }
        if (kind == Committed) finish(p.token, p.cmd.c_str(), id, p.completion);
        else                   sendFail(p.token, p.cmd.c_str(), why.empty() ? "the engine refused the sample" : why, id);
        return true;
    }

    // /b_info for a /b_write in flight: now the range is known, ask the guest
    // to publish it into the returns area.
    if (kind == Info) {
        Pending p;
        uint32_t slot = 0;
        int32_t start = 0, n = 0;
        {
            std::lock_guard<std::mutex> lock(mMut);
            if (!takePending(Pending::WriteQuery, token, id, &p)) return false;
            const int32_t frames = a1, channels = a2;
            if (channels <= 0) {
                // Nothing to publish; fall through to an empty file below.
            }
            start = p.job.bufStart < 0 ? 0 : p.job.bufStart;
            int32_t toEnd = frames - start;
            if (toEnd < 0) toEnd = 0;
            n = p.job.frames < 0 || p.job.frames > toEnd ? toEnd : p.job.frames;
            p.job.outChannels = channels <= 0 ? 1 : static_cast<uint32_t>(channels);
            p.job.outFrames   = static_cast<uint32_t>(n);
            p.job.outRate     = f3;
            if (n > 0) {
                const uint64_t bytes = static_cast<uint64_t>(n) * p.job.outChannels * sizeof(float);
                if (!mOutPool || bytes > 0xFFFFFFFFull || clockwork_asset_pool_alloc(mOutPool, static_cast<uint32_t>(bytes), &slot) != 0) {
                    sendFail(p.token, "/b_write", "returns lane full: " + std::to_string(bytes) + " bytes needed", id);
                    return true;
                }
                p.job.outSlot = slot;
                p.what = Pending::WritePublish;
                p.slot = slot;
                mPending.push_back(p);
            }
        }
        if (n <= 0) {
            // An empty range writes an empty file, as /b_write did.
            Job enc = p.job;
            enc.kind = Kind::Encode;
            enqueue(std::move(enc));
            return true;
        }
        char buf[128];
        osc::OutboundPacketStream o(buf, sizeof buf);
        o << osc::BeginMessage("/supersonic/buffer/publish") << id << start << n << static_cast<int32_t>(slot)
          << osc::EndMessage;
        sendOn(reinterpret_cast<const uint8_t*>(o.Data()), static_cast<uint32_t>(o.Size()), p.token);
        return true;
    }

    if (kind == Published) {
        Pending p;
        {
            std::lock_guard<std::mutex> lock(mMut);
            if (!takePending(Pending::WritePublish, token, id, &p)) return false;
        }
        Job enc = p.job;
        enc.kind        = Kind::Encode;
        enc.outChannels = static_cast<uint32_t>(a1);
        enc.outFrames   = static_cast<uint32_t>(a2);
        enc.outRate     = f3;
        enqueue(std::move(enc));
        return true;
    }
    return false;
}

// ── Session recording: the master tap, pulled into a file here ──────────────
//
// /clockwork/record/start <path> [<format> [<bits>]] and /clockwork/record/stop,
// answered at once — opening a file is the receive thread's to do — in the
// shape the engine used to answer them: record/start.reply <ok> <path|error>.

bool Commands::recordVerb(const uint8_t* data, uint32_t size, uint32_t token) {
    const bool start = isMessage(data, size, "/clockwork/record/start");
    const bool stop  = isMessage(data, size, "/clockwork/record/stop");
    if (!start && !stop) return false;
    std::string path, header = "wav", err;
    int bits = 24;
    if (start) {
        try {
            osc::ReceivedMessage m(osc::ReceivedPacket(reinterpret_cast<const char*>(data),
                                                       static_cast<osc::osc_bundle_element_size_t>(size)));
            auto it = m.ArgumentsBegin();
            const auto end = m.ArgumentsEnd();
            if (it != end && it->IsString()) path = (it++)->AsStringUnchecked();
            if (it != end && it->IsString()) header = (it++)->AsStringUnchecked();
            if (it != end && it->IsInt32())  bits = it->AsInt32Unchecked();
        } catch (const osc::Exception&) {
            return false;
        }
    }
    const bool ok = start ? mRecorder.start(path, header, bits, &err) : mRecorder.stop(&path, &err);
    std::vector<char> buf(path.size() + err.size() + 128);
    osc::OutboundPacketStream p(buf.data(), buf.size());
    p << osc::BeginMessage(start ? "/clockwork/record/start.reply" : "/clockwork/record/stop.reply")
      << static_cast<int32_t>(ok ? 1 : 0) << (ok ? path.c_str() : err.c_str()) << osc::EndMessage;
    reply(token, reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()));
    if (ok) clockwork_log("[recording] %s: %s", start ? "started" : "stopped", path.c_str());
    return true;
}

// ── Replies, in scsynth's words ──────────────────────────────────────────────

void Commands::reply(uint32_t token, const uint8_t* data, uint32_t size) {
    if (token == kOwnToken) {   // loadDefinitions' answer: /done, or /fail and why
        std::string failure;
        if (isMessage(data, size, "/fail")) {
            failure = "the engine refused it";
            try {
                osc::ReceivedMessage m(osc::ReceivedPacket(reinterpret_cast<const char*>(data),
                                                           static_cast<osc::osc_bundle_element_size_t>(size)));
                auto it = m.ArgumentsBegin();
                if (it != m.ArgumentsEnd()) ++it;   // the verb
                if (it != m.ArgumentsEnd() && it->IsString()) failure = it->AsStringUnchecked();
            } catch (const osc::Exception&) {}
        }
        {
            std::lock_guard<std::mutex> lock(mOwnMut);
            mOwnFailure = std::move(failure);
            mOwnAnswered = true;
        }
        mOwnCv.notify_all();
        return;
    }
    if (mReplies) {
        mReplies->send(token, data, size, /*networkOnly*/ false);
        return;
    }
    std::lock_guard<std::mutex> lock(mAnswersMut);
    mAnswers.emplace_back(token, std::vector<uint8_t>(data, data + size));
}

bool Commands::loadDefinitions(const std::string& dir, std::string* why) {
    if (mWork == Work::Host) {
        if (why) *why = "this front's work is its host's: send /d_loadDir and run until the /done comes";
        return false;
    }
    {
        std::lock_guard<std::mutex> lock(mOwnMut);
        mOwnAnswered = false;
        mOwnFailure.clear();
    }
    Job job;
    job.kind  = Kind::SynthDefDir;
    job.token = kOwnToken;
    job.path  = dir;
    enqueue(std::move(job));

    // One definition per block, each answered before the next goes: a few
    // hundred take well under a second. A minute is an engine not answering.
    std::unique_lock<std::mutex> lock(mOwnMut);
    if (!mOwnCv.wait_for(lock, std::chrono::seconds(60), [this] { return mOwnAnswered; })) {
        if (why) *why = "the engine did not answer";
        return false;
    }
    if (!mOwnFailure.empty()) {
        if (why) *why = mOwnFailure;
        return false;
    }
    return true;
}

void Commands::finish(uint32_t token, const char* cmd, int32_t bufnum, const std::vector<uint8_t>& completion) {
    if (!completion.empty())
        sendOn(completion.data(), static_cast<uint32_t>(completion.size()), token);
    sendDone(token, cmd, bufnum);
}

void Commands::sendDone(uint32_t token, const char* cmd, int32_t bufnum) {
    char buf[128];
    osc::OutboundPacketStream p(buf, sizeof buf);
    p << osc::BeginMessage("/done") << cmd << bufnum << osc::EndMessage;
    reply(token, reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()));
}

void Commands::sendFail(uint32_t token, const char* cmd, const std::string& why, int32_t bufnum) {
    std::vector<char> buf(why.size() + 128);
    osc::OutboundPacketStream p(buf.data(), buf.size());
    p << osc::BeginMessage("/fail") << cmd << why.c_str() << bufnum << osc::EndMessage;
    reply(token, reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()));
}

void Commands::sendDoneCmd(uint32_t token, const char* cmd) {
    char buf[128];
    osc::OutboundPacketStream p(buf, sizeof buf);
    p << osc::BeginMessage("/done") << cmd << osc::EndMessage;
    reply(token, reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()));
}

void Commands::sendFailCmd(uint32_t token, const char* cmd, const std::string& what) {
    std::vector<char> buf(what.size() + 128);
    osc::OutboundPacketStream p(buf.data(), buf.size());
    p << osc::BeginMessage("/fail") << cmd << what.c_str() << osc::EndMessage;
    reply(token, reinterpret_cast<const uint8_t*>(p.Data()), static_cast<uint32_t>(p.Size()));
}

uint32_t Commands::laneBytes() {
    std::lock_guard<std::mutex> lock(mMut);
    return ensurePools() ? mPoolBytes : 0;
}

uint32_t Commands::laneFreeBytes() {
    std::lock_guard<std::mutex> lock(mMut);
    return ensurePools() ? clockwork_asset_pool_free_bytes(mPool) : 0;
}

uint32_t Commands::returnsFreeBytes() {
    std::lock_guard<std::mutex> lock(mMut);
    return (ensurePools() && mOutPool) ? clockwork_asset_pool_free_bytes(mOutPool) : 0;
}

bool Commands::send(const uint8_t* data, uint32_t size, uint32_t token) {
    if (ingress(data, size, token)) return true;
    sendOn(data, size, token);
    return false;
}

// ── The handle ───────────────────────────────────────────────────────────────

void Commands::sendOn(const uint8_t* data, uint32_t size, uint32_t token) {
    const ClockworkStatus st = clockwork_client_send(mClient, data, size, token);
    // The engine's own ingest refuses a message it has no instance for back to
    // its sender; a handle says so to its caller. Said here as the engine
    // would say it, so the asker hears the same refusal either way.
    if (st == CLOCKWORK_E_NO_INSTANCE)
        clockwork_sys_refuse(data, size, CLOCKWORK_REFUSED_NO_INSTANCE, 0,
                             [this, token](const uint8_t* d, uint32_t n) { egress(token, d, n); });
}

uint8_t* Commands::assetsLane() {
    ClockworkRegion r {};
    return clockwork_client_region(mClient, CLOCKWORK_REGION_ASSETS, &r) == CLOCKWORK_OK
               ? static_cast<uint8_t*>(r.base) : nullptr;
}

const uint8_t* Commands::returnsLane() {
    ClockworkRegion r {};
    return clockwork_client_region(mClient, CLOCKWORK_REGION_RETURNS, &r) == CLOCKWORK_OK
               ? static_cast<const uint8_t*>(r.base) : nullptr;
}

const PerformanceMetrics* Commands::metrics() {
    ClockworkRegion r {};
    if (clockwork_client_region(mClient, CLOCKWORK_REGION_METRICS, &r) != CLOCKWORK_OK) return nullptr;
    return static_cast<const PerformanceMetrics*>(r.base);
}

uint32_t Commands::poll(ClockworkClientMessage* out, uint32_t max) {
    if (!out || max == 0) return 0;
    // The handle's replies, copied: egress() below may answer, and the
    // ring's bytes are the handle's until its next poll, not ours.
    std::vector<ClockworkClientMessage> taken(max);
    const uint32_t n = clockwork_client_poll(mClient, taken.data(), max);
    std::vector<Polled> passed;
    for (uint32_t i = 0; i < n; ++i) {
        const auto& m = taken[i];
        if (egress(m.origin, m.bytes, m.length)) continue;
        passed.push_back({ std::vector<uint8_t>(m.bytes, m.bytes + m.length), m.origin, m.route, m.sequence });
    }
    {
        std::lock_guard<std::mutex> lock(mAnswersMut);
        while (!mAnswers.empty() && passed.size() < max) {
            passed.push_back({ std::move(mAnswers.front().second), mAnswers.front().first, CLOCKWORK_ROUTE_REPLY, 0 });
            mAnswers.pop_front();
        }
    }
    mPolled = std::move(passed);
    for (size_t i = 0; i < mPolled.size(); ++i) {
        out[i].bytes    = mPolled[i].bytes.data();
        out[i].length   = static_cast<uint32_t>(mPolled[i].bytes.size());
        out[i].origin   = mPolled[i].origin;
        out[i].route    = mPolled[i].route;
        out[i].sequence = mPolled[i].sequence;
    }
    return static_cast<uint32_t>(mPolled.size());
}

}  // namespace supersonic
