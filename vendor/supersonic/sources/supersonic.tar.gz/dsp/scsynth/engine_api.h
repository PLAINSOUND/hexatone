/*
 * engine_api.h — the seam between the dsp_api.h adapter and scsynth's server.
 *
 * scsynth_dsp.cpp reaches the server through a small surface: build a world,
 * run a block, hand it OSC, read its buffers. This header states that surface
 * in C. It dates from when a second engine stood behind it; that engine is
 * gone, and the header stays because the adapter is easier to read against a
 * dozen declarations than against the server's own headers.
 */
#ifndef CLOCKWORK_ENGINE_API_H
#define CLOCKWORK_ENGINE_API_H

#include <stdint.h>

struct World;
struct WorldOptions;
struct SndBuf;
struct ReplyAddress;
struct OSC_Packet;
struct SupersonicGuest;   /* the instance a World belongs to (guest_doors.h) */

#ifdef __cplusplus
extern "C" {
#endif

/* World lifecycle. The World and everything it owns come from the instance's
 * heap, and every door to the host finds the instance through the World. A
 * World_New that returns null says why in `outReason`, cut to `reasonBytes`. */
struct World* World_New(struct WorldOptions* options, struct SupersonicGuest* guest, char* outReason,
                        size_t reasonBytes);
void World_Cleanup(struct World* world, bool unload_plugins);
void World_Run(struct World* world);

/* World_SetSampleRate, PerformOSCMessage and PerformOSCBundle are absent on
 * purpose. The host's existing headers declare them with C++ linkage, so they
 * are carried across in engine_support.cpp; declaring them here as C would
 * silently give the definitions the wrong linkage, which is exactly what
 * happened the first time. */

/* Buffers. World_GetBuf and World_GetNRTBuf are not here: they are inline in
 * SC_World.h, which the ugens compile against, so they belong to the shared
 * plugin interface rather than to this contract. */
int World_CopySndBuf(struct World* world, uint32_t index, struct SndBuf* out,
                     bool onlyIfChanged, bool* didChange);

/* Self-driven bring-up and the per-block cycle. */
struct World* EngineCore_New(const struct WorldOptions* options, struct SupersonicGuest* guest, char* outError,
                             size_t errorBytes);
void EngineCore_BeginBlock(struct World* world);
void EngineCore_RunBlock(struct World* world, unsigned int activeInputChannels);
void EngineCore_FlushNotifications(struct World* world);

/* How many synthdefs are loaded — for the metrics the host publishes. */
uint32_t supersonic_engine_synthdef_count(void);

#ifdef __cplusplus
}
#endif

#endif /* CLOCKWORK_ENGINE_API_H */
