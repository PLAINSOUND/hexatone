/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    Copyright (c) 2013 Tim Blechmann

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/

#pragma once

#include <atomic>

/////////////////////////////////////////////////////////////////////

namespace SCMsgFifo {

using std::memory_order_relaxed;
using std::memory_order_release;

template <class MsgType, int N> class MsgFifo {
    // NextPos() indexes with `& (N - 1)`, so a non-power-of-two N aliases out of
    // bounds; usable capacity is N - 1, so N < 2 can never hold a message.
    static_assert(N >= 2 && (N & (N - 1)) == 0, "MsgFifo depth must be a power of two >= 2");

public:
    MsgFifo(): mReadHead(0), mWriteHead(0), mFreeHead(0) {}

    void MakeEmpty() {
        int writeHead = mWriteHead.load();
        mReadHead.store(writeHead, memory_order_relaxed);
        mFreeHead.store(writeHead, memory_order_release);
    }
    // The head the OTHER thread advances is loaded with acquire, so the item
    // it published is seen whole: the writer's mItems[next] = data must be
    // visible to Perform() once mWriteHead says so, and the reader's
    // Perform() must be finished with an item before Free() reclaims it.
    // Relaxed loads here are enough on x86, where stores are ordered, and
    // were latent on arm64 until the fifos carried live traffic (a stale
    // slot performed as a fresh message: a command freed twice, 2026-09-07).
    bool IsEmpty() { return mReadHead.load(memory_order_relaxed) == mWriteHead.load(std::memory_order_acquire); }
    bool HasData() { return mReadHead.load(memory_order_relaxed) != mWriteHead.load(std::memory_order_acquire); }
    bool NeedsFree() { return mFreeHead.load(memory_order_relaxed) != mReadHead.load(std::memory_order_acquire); }

    bool Write(MsgType& data) {
        unsigned int next = NextPos(mWriteHead.load(memory_order_relaxed));
        if (next == mFreeHead.load(std::memory_order_acquire))
            return false; // fifo is full
        mItems[next] = data;

        mWriteHead.store(next, memory_order_release);

        return true;
    }

    void Perform() // get next and advance
    {
        while (HasData()) {
            unsigned int next = NextPos(mReadHead.load(memory_order_relaxed));
            mItems[next].Perform();
            mReadHead.store(next, memory_order_release);
        }
    }
    void Free() // reclaim messages
    {
        while (NeedsFree()) {
            unsigned int next = NextPos(mFreeHead.load(memory_order_relaxed));
            mItems[next].Free();
            mFreeHead.store(next, memory_order_release);
        }
    }

private:
    int NextPos(int inPos) { return (inPos + 1) & (N - 1); }

    std::atomic<int> mReadHead, mWriteHead, mFreeHead;
    MsgType mItems[N];
};

/////////////////////////////////////////////////////////////////////

template <class MsgType, int N> class MsgFifoNoFree {
    // NextPos() indexes with `& (N - 1)`, so a non-power-of-two N aliases out of
    // bounds; usable capacity is N - 1, so N < 2 can never hold a message.
    static_assert(N >= 2 && (N & (N - 1)) == 0, "MsgFifoNoFree depth must be a power of two >= 2");

public:
    MsgFifoNoFree(): mReadHead(0), mWriteHead(0) {}

    void MakeEmpty() { mReadHead.store(mWriteHead.load()); }
    bool IsEmpty() { return mReadHead.load(memory_order_relaxed) == mWriteHead.load(memory_order_relaxed); }
    bool HasData() { return mReadHead.load(memory_order_relaxed) != mWriteHead.load(memory_order_relaxed); }

    bool Write(MsgType& data) {
        unsigned int next = NextPos(mWriteHead.load(memory_order_relaxed));
        if (next == mReadHead.load(memory_order_relaxed))
            return false; // fifo is full
        mItems[next] = data;

        mWriteHead.store(next, memory_order_release);

        return true;
    }

    void Perform() // get next and advance
    {
        while (HasData()) {
            unsigned int next = NextPos(mReadHead.load(memory_order_relaxed));
            mItems[next].Perform();
            mReadHead.store(next, memory_order_release);
        }
    }

private:
    int NextPos(int inPos) { return (inPos + 1) & (N - 1); }

    std::atomic<int> mReadHead, mWriteHead;
    MsgType mItems[N];
};

}

using SCMsgFifo::MsgFifo;
using SCMsgFifo::MsgFifoNoFree;

/////////////////////////////////////////////////////////////////////
