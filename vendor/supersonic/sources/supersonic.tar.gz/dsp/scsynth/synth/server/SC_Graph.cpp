/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


#include "SC_FloatToInt.h"
#include "SC_Win32Utils.h"
#include "SC_Graph.h"
#include "SC_GraphDef.h"
#include "SC_Unit.h"
#include "SC_UnitSpec.h"
#include "SC_UnitDef.h"
#include "SC_HiddenWorld.h"
#include "SC_WorldOptions.h"
#include "SC_Wire.h"
#include "SC_WireSpec.h"
#include <stdio.h>
#include <string.h>
#include <cmath>
#include "SC_Prototypes.h"
#include "SC_Errors.h"
#include "Unroll.h"
#include "SC_ReplyImpl.hpp"
#include "clz.h"

// =============================================================================
// TAU MODIFICATIONS
// =============================================================================
// This file has the following changes from upstream SuperCollider:
//
// 1. scprintf declaration: For WASM debugging output
// 2. Graph_CalcTrace: Uses scprintf instead of scprintf
// 3. Graph_New error logging: Added scprintf call on error
// =============================================================================

#ifdef CLOCKWORK_GUEST
extern "C" {
}
#endif

void Unit_ChooseMulAddFunc(Unit* unit);

struct QueuedCmd {
    struct QueuedCmd* mNext;
    ReplyAddress mReplyAddress;
    int mSize;
    char mData[1];
};

////////////////////////////////////////////////////////////////////////////////

void Graph_FirstCalc(Graph* inGraph);
void Graph_NullFirstCalc(Graph* inGraph);

static void Graph_Dtor(Graph* inGraph) {
    // scprintf("->Graph_Dtor %d\n", inGraph->mNode.mID);
    World* world = inGraph->mNode.mWorld;
    uint32 numUnits = inGraph->mNumUnits;
    Unit** graphUnits = inGraph->mUnits;
    if (inGraph->mNode.mCalcFunc != (NodeCalcFunc)Graph_FirstCalc
        && inGraph->mNode.mCalcFunc != (NodeCalcFunc)(Graph_NullFirstCalc)) {
        // the above test insures that dtors are not called if ctors have not been called.
        for (uint32 i = 0; i < numUnits; ++i) {
            Unit* unit = graphUnits[i];
            UnitDtorFunc dtor = unit->mUnitDef->mUnitDtorFunc;
            if (dtor)
                (dtor)(unit);
        }
    }

    // NOTE: mBufRate is allocated as part of mFullRate, see Graph_Ctor()!
    if (inGraph->mFullRate != &world->mFullRate)
        World_Free(world, inGraph->mFullRate);

    // free queued Unit commands
    // AFAICT this can only happen if a Graph is created, Unit commands are sent and
    // the Graph is deleted all at in the same control block.
    QueuedCmd* cmd = (QueuedCmd*)inGraph->mPrivate;
    while (cmd) {
        QueuedCmd* next = cmd->mNext;
        World_Free(inGraph->mNode.mWorld, cmd);
        cmd = next;
    }
    world->mNumUnits -= numUnits;
    world->mNumGraphs--;

    GraphDef_Release(world, GRAPHDEF(inGraph));

    Node_Dtor(&inGraph->mNode);
    // scprintf("<-Graph_Dtor\n");
}

// This is called by asynchronous unit commands to prevent the Graph
// from being destroyed while the command is still pending.
void Graph_AddRef(Graph* inGraph) {
    // this should only be called on Graphs that are still alive!
    assert(inGraph->mRefCount > 0);
    inGraph->mRefCount++;
}

// This is called by asynchronous unit commands after they have finished.
// If the reference count reaches zero, the Graph will finally be destroyed.
void Graph_Release(Graph* inGraph) {
    assert(inGraph->mRefCount > 0);
    if (--inGraph->mRefCount == 0) {
        Graph_Dtor(inGraph);
    }
}

// This is called when a Graph resp. one of its parent Nodes is freed by the user.
void Graph_Delete(Graph* inGraph) {
    assert(inGraph->mRefCount > 0);
    int newRefCount = --inGraph->mRefCount;
    if (newRefCount > 0) {
        // the Graph is being referenced by one or more asynchronous unit commands.
        // We keep it alive, but remove it from the Node tree. Async unit commands
        // can call Graph_HasParent() to check whether the Graph has been removed.
        Node_Remove(&inGraph->mNode);
        // Also remove the Node from the World so that the ID becomes free again.
        // This also prevents users from (accidentally) re-adding the Graph to
        // the Server tree.
        World_RemoveNode(inGraph->mNode.mWorld, &inGraph->mNode);
    } else {
        // Nobody else is referencing the Graph, so we can immediately destroy it.
        Graph_Dtor(inGraph);
    }
}

// This is called by asynchronous unit commands to check whether the
// owning Graph has been removed.
bool Graph_HasParent(const Graph* inGraph) { return inGraph->mNode.mParent != nullptr; }

////////////////////////////////////////////////////////////////////////////////

static void Graph_Ctor(World* inWorld, GraphDef* inGraphDef, Graph* graph, sc_msg_iter* msg, bool argtype);

// The largest resample factor. A factor multiplies the passes a graph makes
// each server block, and comes from a SynthDef or a control.
constexpr int32 kMaxResampleFactor = 64;

// 'argtype' is true for normal args, false for setn type args
int Graph_New(World* inWorld, GraphDef* inGraphDef, int32 inID, sc_msg_iter* args, Graph** outGraph, bool argtype) {
    Graph* graph;
    int err = Node_New(inWorld, &inGraphDef->mNodeDef, inID, (Node**)&graph);
    if (err) {
        scprintf("[Graph_New] ERROR: Node_New failed with error code %d", err);
        return err;
    }

    Graph_Ctor(inWorld, inGraphDef, graph, args, argtype);
    *outGraph = graph;
    return err;
}

// 'argtype' is true for normal args, false for setn type args
static void Graph_Ctor(World* inWorld, GraphDef* inGraphDef, Graph* graph, sc_msg_iter* msg, bool argtype) {
    // scprintf("->Graph_Ctor\n");

    // hit the memory allocator only once.
    char* memory = (char*)graph + kSCGraphHeaderSize;

    // allocate space for children
    uint32 numUnits = inGraphDef->mNumUnitSpecs;
    graph->mNumUnits = numUnits;
    inWorld->mNumUnits += numUnits;
    inWorld->mNumGraphs++;
    graph->mUnits = (Unit**)memory;
    memory += inGraphDef->mUnitsAllocSize;

    // set calc func
    graph->mNode.mCalcFunc = (NodeCalcFunc)&Graph_FirstCalc;

    // allocate wires
    graph->mNumWires = inGraphDef->mNumWires;
    graph->mWire = (Wire*)memory;
    memory += inGraphDef->mWiresAllocSize;

    graph->mNumCalcUnits = inGraphDef->mNumCalcUnits;
    graph->mCalcUnits = (Unit**)memory;
    memory += inGraphDef->mCalcUnitsAllocSize;

    // initialize controls
    uint32 numControls = inGraphDef->mNumControls;
    graph->mNumControls = numControls;
    graph->mControls = (float*)memory;
    memory += inGraphDef->mControlAllocSize;

    graph->mAudioBusOffsets = (int32*)memory;
    memory += inGraphDef->mAudioMapBusOffsetSize;

    graph->mMapControls = (float**)memory;
    memory += inGraphDef->mMapControlsAllocSize;

    graph->mControlRates = (int*)memory;
    memory += inGraphDef->mMapControlRatesAllocSize;

    {
        float* graphControls = graph->mControls;
        float* initialControlValues = inGraphDef->mInitialControlValues;
        float** graphMapControls = graph->mMapControls;
        /* add */
        int* graphControlRates = graph->mControlRates;
        for (uint32 i = 0; i < numControls; ++i, ++graphControls) {
            *graphControls = initialControlValues[i];
            graphMapControls[i] = graphControls;
            /* add */
            graphControlRates[i] = 0; // init to 0 for now... control bus is 1, audio is 2
            graph->mAudioBusOffsets[i] = -1;
        }
    }

    // set controls
    // if argtype == true -> normal args as always
    // if argtype == false -> setn type args
    if (argtype) {
        while (msg->remain() >= 8) {
            int i = 0;
            int loop = 0;
            if (msg->nextTag('i') == 's') {
                int32* name = msg->gets4();
                int32 hash = Hash(name);
                do {
                    switch (msg->nextTag('f')) {
                    case 'f':
                    case 'i': {
                        float32 value = msg->getf();
                        Graph_SetControl(graph, hash, name, i, value);
                        break;
                    }
                    case 's': {
                        const char* string = msg->gets();
                        if (*string == 'c') {
                            int bus = sc_atoi(string + 1);
                            Graph_MapControl(graph, hash, name, i, bus);
                        } else {
                            if (*string == 'a') {
                                int bus = sc_atoi(string + 1);
                                Graph_MapAudioControl(graph, hash, name, i, bus);
                            }
                        }
                        break;
                    }
                    case ']':
                        msg->count++;
                        loop -= 1;
                        break;
                    case '[':
                        msg->count++;
                        loop += 1;
                        i -= 1;
                        break;
                    default:
                        // A type no control takes: read past it.
                        msg->getf();
                        break;
                    }
                    ++i;
                } while (loop && msg->remain());
            } else {
                int32 index = msg->geti();
                do {
                    switch (msg->nextTag('f')) {
                    case 'f':
                    case 'i': {
                        float32 value = msg->getf();
                        Graph_SetControl(graph, index + i, value);
                        break;
                    }
                    case 's': {
                        const char* string = msg->gets();
                        if (*string == 'c') {
                            int bus = sc_atoi(string + 1);
                            Graph_MapControl(graph, index + i, bus);
                        } else {
                            if (*string == 'a') {
                                int bus = sc_atoi(string + 1);
                                Graph_MapAudioControl(graph, index + i, bus);
                            }
                        }
                        break;
                    }
                    case ']':
                        msg->count++;
                        loop -= 1;
                        break;
                    case '[':
                        msg->count++;
                        loop += 1;
                        i -= 1;
                        break;
                    default:
                        // A type no control takes: read past it.
                        msg->getf();
                        break;
                    }
                    ++i;
                } while (loop && msg->remain());
            }
        }
    }


    //{
    //	    while( msg->remain()>=8) {
    //		int i = 0;
    //		int loop = 0;
    //		if (msg->nextTag('i') == 's') {
    //		    int32* name = msg->gets4();
    //		    int32 hash = Hash(name);
    //		    if (msg->nextTag('f') == '[' ) {
    //			    msg->count++;
    //			    loop = 1;
    //		    }
    //		    do {
    //			if (msg->nextTag('f') == 's' ) {
    //			    const char* string = msg->gets();
    //			    if ( *string == 'c') {
    //				int bus = sc_atoi(string+1);
    //				Graph_MapControl(graph, hash, name, i, bus);
    //			    }
    //			} else {
    //			    if (msg->nextTag('f') == ']' ) {
    //				msg->count++;
    //				loop = 0;
    //			    } else {
    //				float32 value = msg->getf();
    //				Graph_SetControl(graph, hash, name, i, value);
    //			    }
    //			}
    //			++i;
    //		    }
    //		    while (loop);
    //		} else {
    //		    int32 index = msg->geti();
    //		    if (msg->nextTag('f') == '[' ) {
    //			msg->count++;
    //			loop = 1;
    //		    }
    //		    do {
    //			if (msg->nextTag('f') == 's') {
    //			    const char* string = msg->gets();
    //			    if (*string == 'c') {
    //				int bus = sc_atoi(string+1);
    //				Graph_MapControl(graph, index + i, bus);
    //			    }
    //			} else {
    //			    if (msg->nextTag('f') == ']' ) {
    //				msg->count++;
    //				loop = 0;
    //			    } else {
    //				float32 value = msg->getf();
    //				Graph_SetControl(graph, index + i, value);
    //			    }
    //			}
    //			++i;
    //		    }
    //		    while (loop);
    //		}
    //	    }
    //
    //	}
    else {
        while (msg->remain()) {
            if (msg->nextTag('i') == 's') {
                int32* name = msg->gets4();
                int32 hash = Hash(name);
                int32 n = msg->geti();
                for (int i = 0; msg->remain() && i < n; ++i) {
                    if (msg->nextTag('f') == 's') {
                        const char* string = msg->gets();
                        if (*string == 'c') {
                            int bus = sc_atoi(string + 1);
                            Graph_MapControl(graph, hash, name, i, bus);
                            // Node_MapControl(node, hash, name, i, bus);
                        } else {
                            if (*string == 'a') {
                                int bus = sc_atoi(string + 1);
                                Graph_MapAudioControl(graph, hash, name, i, bus);
                            }
                        }
                    } else {
                        float32 value = msg->getf();
                        Graph_SetControl(graph, hash, name, i, value);
                        // Node_SetControl(node, hash, name, i, value);
                    }
                }
            } else {
                int32 index = msg->geti();
                int32 n = msg->geti();
                for (int i = 0; msg->remain() && i < n; ++i) {
                    if (msg->nextTag('f') == 's') {
                        const char* string = msg->gets();
                        if (*string == 'c') {
                            int bus = sc_atoi(string + 1);
                            Graph_MapControl(graph, index + i, bus);
                            // Node_MapControl(node, index+i, bus);
                        } else {
                            if (*string == 'a') {
                                int bus = sc_atoi(string + 1);
                                Graph_MapAudioControl(graph, index + i, bus);
                            }
                        }
                    } else {
                        float32 value = msg->getf();
                        Graph_SetControl(graph, index + i, value);
                        // Node_SetControl(node, index+i, value);
                    }
                }
            }
        }
    }

    // set up scalar values
    Wire* graphWires = graph->mWire;
    int numConstants = inGraphDef->mNumConstants;
    {
        float* constants = inGraphDef->mConstants;
        Wire* wire = graphWires;
        for (int i = 0; i < numConstants; ++i, ++wire) {
            wire->mFromUnit = nullptr;
            wire->mCalcRate = calc_ScalarRate;
            wire->mBuffer = &wire->mScalarValue;
            wire->mScalarValue = constants[i];
        }
    }

    graph->mSampleOffset = inWorld->mSampleOffset;
    graph->mSubsampleOffset = inWorld->mSubsampleOffset;
    graph->mRGen = inWorld->mRGen; // defaults to rgen zero.

    graph->mLocalAudioBusUnit = nullptr;
    graph->mLocalControlBusUnit = nullptr;

    graph->mLocalSndBufs = nullptr;
    graph->localBufNum = 0;
    graph->localMaxBufNum = 0; // this is set from synth

    graph->mFlags = 0;

    int32 blockSize = inGraphDef->mBlockSize;
    if (blockSize < 0) {
        // get block size from Synth Control
        uint32 index = inGraphDef->mBlockSizeIndex;
        if (index < graph->mNumControls) {
            blockSize = sc_float_to_int32(graph->mMapControls[index][0]);
        } else {
            scprintf("ERROR: block size control index %d out of range!\n", index);
            blockSize = 0;
        }
    }
    // note: 0 means no reblocking.

    float upsample = inGraphDef->mResampleFactor;
    if (upsample < 0.0) {
        // get resample factor from Synth Control
        uint32 index = inGraphDef->mResampleIndex;
        if (index < graph->mNumControls) {
            upsample = graph->mMapControls[index][0];
        } else {
            scprintf("ERROR: resample control index %d out of range!\n", index);
            upsample = 1.0;
        }
    }
    // treat 0.0 as no resampling
    if (upsample == 0.0) {
        upsample = 1.0;
    }
    // A factor can come from a control, so it can be anything.
    if (!std::isfinite(upsample)) {
        scprintf("WARNING: Synth: bad resample factor (%f)\n", upsample);
        upsample = 1.0;
    }

    if (blockSize == 0 && upsample == 1.0) {
        // no reblocking and no upsampling -> use the global rates
        graph->mNumTicks = 1;
        graph->mTickCounter = 0;
        graph->mFullRate = &inWorld->mFullRate;
        graph->mBufRate = &inWorld->mBufRate;
        blockSize = inWorld->mBufLength;
    } else {
        // reblocking or upsampling
        if (upsample > 1.0) {
            // make sure that 'upsample' is a power of two!
            if (ISPOWEROFTWO(sc_float_to_int32(upsample))) {
                upsample = sc_float_to_int32(upsample);
                if (upsample > kMaxResampleFactor) {
                    scprintf("WARNING: Synth: upsample factor (%f) above %d, using %d\n", upsample,
                             kMaxResampleFactor, kMaxResampleFactor);
                    upsample = kMaxResampleFactor;
                }
                graph->mFlags |= kGraph_Resample; // ok
            } else {
                scprintf("WARNING: Synth: upsample factor (%f) not a power of two\n", upsample);
                upsample = 1.0;
            }
        } else if (upsample < 0.0) {
            scprintf("WARNING: Synth: bad resample factor (%f)\n", upsample);
            upsample = 1.0;
        } else if (upsample < 1.0) {
            scprintf("WARNING: Synth: downsampling (%f) not supported (yet)\n", upsample);
            upsample = 1.0;
        }

        if (blockSize != 0) {
            if (!ISPOWEROFTWO(blockSize)) {
                scprintf("WARNING: Synth: block size (%d) not a power of two\n", blockSize);
                // use Server block size
                blockSize = inWorld->mBufLength;
            }

            const int32_t effectiveBlockSize = blockSize / sc_float_to_int32(upsample);
            if (effectiveBlockSize > inWorld->mBufLength) {
                // The effective block size cannot be larger than the Server block size.
                // For now, let's keep the upsample factor and adjust the block size accordingly.
                const int32_t originalBlockSize = blockSize;
                blockSize = inWorld->mBufLength * sc_float_to_int32(upsample);
                scprintf("WARNING: Synth: block size (%d) too large for resample factor (%f). "
                         "Adjusting block size to %d samples.\n",
                         originalBlockSize, upsample, blockSize);
            }

            // Make sure we have enough wire buffer space!
            // This is necessary so that we can later safely set the wire buffer pointers.
            if (blockSize > inWorld->mBufLength) {
                const int32_t availableBufferSpace = inWorld->hw->mMaxWireBufs * inWorld->mBufLength;
                const int32_t requiredBufferSpace = inGraphDef->mNumWireBufs * blockSize;
                if (requiredBufferSpace > availableBufferSpace) {
                    const int32_t originalBlockSize = blockSize;
                    blockSize = availableBufferSpace / inGraphDef->mNumWireBufs;
                    assert(blockSize >= inWorld->mBufLength);
                    const int32_t minNumWireBufs = requiredBufferSpace / inWorld->mBufLength;
                    scprintf("WARNING: Synth: too little wire buffer space for block size (%d) and "
                             "resample factor (%f). Adjusting block size to %d samples. Please increase "
                             "the number of wire buffers in the Server Options to at least %d. \n",
                             originalBlockSize, upsample, blockSize, minNumWireBufs);
                }
            }

            if (blockSize != inWorld->mBufLength) {
                graph->mFlags |= kGraph_Reblock; // ok
            }
        } else {
            // use Server block size
            blockSize = inWorld->mBufLength;
        }

        graph->mNumTicks = sc_float_to<uint32>((inWorld->mBufLength * upsample) / blockSize);
        graph->mTickCounter = 0;
        double sampleRate = inWorld->mSampleRate * upsample;

        // Hit allocator only once, see Graph_Dtor().
        // (Ideally the rates should be allocated as part of the Synth itself.
        // This means we would have to detect potential reblocking/resampling
        // already in the SynthDef and increase mAllocSize accordingly.)
        Rate* chunk = (Rate*)World_Alloc(inWorld, sizeof(Rate) * 2);

        graph->mFullRate = chunk;
        Rate_Init(graph->mFullRate, sampleRate, blockSize);

        graph->mBufRate = chunk + 1;
        Rate_Init(graph->mBufRate, sampleRate / blockSize, 1);
    }

    //  scprintf("Graph_Ctor: block size: %d, upsample: %f, ticks: %d\n",
    //           blockSize, upsample, graph->mNumTicks);

    // so far mPrivate is only used for queued unit commands,
    // i.e. it just points to the head of the list.
    graph->mPrivate = nullptr;

    // initialize units
    // scprintf("initialize units\n");
    Unit** calcUnits = graph->mCalcUnits;
    Unit** graphUnits = graph->mUnits;
    int calcCtr = 0;

    float* bufspace = inWorld->hw->mWireBufSpace;
    uint32 wireCtr = numConstants; // never more than numConstants + numOutputs
    UnitSpec* unitSpec = inGraphDef->mUnitSpecs;
    for (uint32 i = 0; i < numUnits; ++i, ++unitSpec) {
        // construct unit from spec
        Unit* unit = Unit_New(inWorld, graph, unitSpec, memory);

        // set parent
        unit->mParent = graph;
        unit->mParentIndex = i;

        graphUnits[i] = unit;

        {
            // hook up unit inputs
            // scprintf("hook up unit inputs\n");
            InputSpec* inputSpec = unitSpec->mInputSpec;
            Wire** unitInput = unit->mInput;
            float** unitInBuf = unit->mInBuf;
            uint32 numInputs = unitSpec->mNumInputs;
            for (uint32 j = 0; j < numInputs; ++j, ++inputSpec) {
                Wire* wire = graphWires + inputSpec->mWireIndex;
                unitInput[j] = wire;
                unitInBuf[j] = wire->mBuffer;
            }
        }

        {
            // hook up unit outputs
            // scprintf("hook up unit outputs\n");
            Wire** unitOutput = unit->mOutput;
            float** unitOutBuf = unit->mOutBuf;
            uint32 numOutputs = unitSpec->mNumOutputs;
            Wire* wire = graphWires + wireCtr;
            wireCtr += numOutputs;
            int unitCalcRate = unit->mCalcRate;
            if (unitCalcRate == calc_FullRate) {
                OutputSpec* outputSpec = unitSpec->mOutputSpec;
                for (uint32 j = 0; j < numOutputs; ++j, ++wire, ++outputSpec) {
                    wire->mFromUnit = unit;
                    wire->mCalcRate = calc_FullRate;
                    // In a normal Graph, wire buffers have the same size as the Server block size.
                    // A reblocked Graph, however, needs a different buffer size, especially when
                    // its own block size is *larger* than the Server block size. (Otherwise we would
                    // overwrite subsequent buffers.) Since the wire buffer space is a single large
                    // array, we can simply multiply the wire buffer index by the Graph block size.
                    wire->mBuffer = bufspace + outputSpec->mBufferIndex * blockSize;
                    unitOutput[j] = wire;
                    unitOutBuf[j] = wire->mBuffer;
                }
                calcUnits[calcCtr++] = unit;
            } else {
                for (uint32 j = 0; j < numOutputs; ++j, ++wire) {
                    wire->mFromUnit = unit;
                    wire->mCalcRate = unitCalcRate;
                    wire->mBuffer = &wire->mScalarValue;
                    unitOutput[j] = wire;
                    unitOutBuf[j] = wire->mBuffer;
                }
                if (unitCalcRate == calc_BufRate) {
                    calcUnits[calcCtr++] = unit;
                }
            }
        }
    }

    graph->mRefCount = 1;

    inGraphDef->mRefCount++;
}

void Graph_QueueUnitCmd(Graph* inGraph, int inSize, const char* inData, const ReplyAddress* inReplyAddress) {
    // put the unit command on a queue and dispatch it right after the first
    // calc function, i.e. after calling the unit constructors.
    // scprintf("->Graph_QueueUnitCmd\n");
    QueuedCmd* cmd = (QueuedCmd*)World_Alloc(inGraph->mNode.mWorld, sizeof(QueuedCmd) + inSize);
    cmd->mNext = nullptr;
    if (inReplyAddress)
        cmd->mReplyAddress = *inReplyAddress;
    else
        cmd->mReplyAddress.mReplyFunc = null_reply_func;
    cmd->mSize = inSize;
    memcpy(cmd->mData, inData, inSize);
    if (inGraph->mPrivate) {
        // add to tail
        QueuedCmd* ptr = (QueuedCmd*)inGraph->mPrivate;
        while (ptr->mNext)
            ptr = ptr->mNext;
        ptr->mNext = cmd;
    } else {
        inGraph->mPrivate = cmd;
    }
}

static void Graph_DispatchUnitCmds(Graph* inGraph) {
    QueuedCmd* item = (QueuedCmd*)inGraph->mPrivate;
    while (item) {
        QueuedCmd* next = item->mNext;

        sc_msg_iter msg(item->mSize, item->mData);

        // error checking has already be done in Unit_DoCmd()
        int nodeID = msg.geti();
        assert(nodeID == inGraph->mNode.mID);

        uint32 unitID = msg.geti();
        Unit* unit = inGraph->mUnits[unitID];
        UnitDef* unitDef = unit->mUnitDef;

        int32* cmdName = msg.gets4();
        UnitCmd* cmd = unitDef->mCmds->Get(cmdName);

        Unit_RunCommand(cmd, unit, &msg, &item->mReplyAddress);

        World_Free(inGraph->mNode.mWorld, item);

        item = next;
    }
    inGraph->mPrivate = nullptr;
}

// [SuperSonic] Run UGen constructors, zombie-check, install Graph_Calc, and
// dispatch any queued unit commands. Returns true if the graph is now ready
// to compute audio; false if all units failed construction (zombie — Node_End
// has been called) so callers should skip the compute step.
//
// Split out of Graph_FirstCalc so /s_new can initialise UGens synchronously
// (see SC_MiscCmds.cpp: eager init in meth_s_new / meth_s_newargs). Eager
// initialisation makes intra-bundle /n_set target the post-init UGen state,
// which is what callers intuitively expect when they place /n_set after
// /s_new in a bundle.
bool Graph_InitUnits(Graph* inGraph) {
    // Already initialised (e.g. meth_s_new ran us, then the audio loop's
    // first mCalcFunc call landed here again through Graph_FirstCalc). No-op.
    if (inGraph->mNode.mCalcFunc != (NodeCalcFunc)&Graph_FirstCalc
        && inGraph->mNode.mCalcFunc != (NodeCalcFunc)&Graph_NullFirstCalc) {
        return true;
    }

    uint32 numUnits = inGraph->mNumUnits;
    Unit** units = inGraph->mUnits;
    for (uint32 i = 0; i < numUnits; ++i) {
        Unit* unit = units[i];
        // call constructor
        (*unit->mUnitDef->mUnitCtorFunc)(unit);
    }

    // [SuperSonic] Prevent zombie synth nodes when RT memory is exhausted.
    //
    // When RTAlloc fails, UGen constructors (via ClearUnitOnMemFailed) set
    // unit->mDone = true and replace the calc function with ClearUnitOutputs.
    // If ALL units are done after construction, this synth will never produce
    // audio and — critically — will never trigger a DoneAction to free itself.
    // It becomes a zombie: consuming RT memory, accumulating indefinitely,
    // and preventing all future synth creation.
    //
    // Node_End() safely schedules deletion for the next calc cycle (the same
    // mechanism used by DoneAction=2 / freeSelf). This is a no-op when any
    // unit survived construction, preserving upstream behavior exactly.
    {
        bool allDone = true;
        for (uint32 i = 0; i < numUnits; ++i) {
            if (!units[i]->mDone) {
                allDone = false;
                break;
            }
        }
        if (allDone && numUnits > 0) {
            Node_End(&inGraph->mNode);
            return false;
        }
    }

    inGraph->mNode.mCalcFunc = (NodeCalcFunc)&Graph_Calc;
    // after setting the calc function!
    Graph_DispatchUnitCmds(inGraph);
    return true;
}

void Graph_FirstCalc(Graph* inGraph) {
    if (!Graph_InitUnits(inGraph))
        return;
    // now do actual graph calculation
    Graph_Calc(inGraph);
}

void Node_NullCalc(struct Node* /*inNode*/);

void Graph_NullFirstCalc(Graph* inGraph) {
    // scprintf("->Graph_FirstCalc\n");
    uint32 numUnits = inGraph->mNumUnits;
    Unit** units = inGraph->mUnits;
    for (uint32 i = 0; i < numUnits; ++i) {
        Unit* unit = units[i];
        // call constructor
        (*unit->mUnitDef->mUnitCtorFunc)(unit);
    }
    // scprintf("<-Graph_FirstCalc\n");

    inGraph->mNode.mCalcFunc = &Node_NullCalc;
    // after setting the calc function!
    Graph_DispatchUnitCmds(inGraph);
}

inline void Graph_Calc_unit(Unit* unit) { (unit->mCalcFunc)(unit, unit->mBufLength); }

void Graph_Calc(Graph* inGraph) {
    // scprintf("->Graph_Calc\n");
    uint32 numCalcUnits = inGraph->mNumCalcUnits;
    Unit** calcUnits = inGraph->mCalcUnits;

    int unroll8 = numCalcUnits / 8;
    int remain8 = numCalcUnits % 8;
    int unroll4 = remain8 / 4;
    int remain4 = remain8 % 4;
    int unroll2 = remain4 / 2;
    int remain2 = remain4 % 2;

    int numTicks = inGraph->mNumTicks;

    for (int k = 0; k < numTicks; ++k) {
        // set before calling Graph_Calc_unit()!
        inGraph->mTickCounter = k;

        int i = 0;

        for (int j = 0; j != unroll8; i += 8, ++j) {
            Graph_Calc_unit(calcUnits[i]);
            Graph_Calc_unit(calcUnits[i + 1]);
            Graph_Calc_unit(calcUnits[i + 2]);
            Graph_Calc_unit(calcUnits[i + 3]);
            Graph_Calc_unit(calcUnits[i + 4]);
            Graph_Calc_unit(calcUnits[i + 5]);
            Graph_Calc_unit(calcUnits[i + 6]);
            Graph_Calc_unit(calcUnits[i + 7]);
        }

        if (unroll4) {
            Graph_Calc_unit(calcUnits[i]);
            Graph_Calc_unit(calcUnits[i + 1]);
            Graph_Calc_unit(calcUnits[i + 2]);
            Graph_Calc_unit(calcUnits[i + 3]);
            i += 4;
        }

        if (unroll2) {
            Graph_Calc_unit(calcUnits[i]);
            Graph_Calc_unit(calcUnits[i + 1]);
            i += 2;
        }

        if (remain2)
            Graph_Calc_unit(calcUnits[i]);
    }

    // scprintf("<-Graph_Calc\n");
}

void Graph_CalcTrace(Graph* inGraph);
void Graph_CalcTrace(Graph* inGraph) {
    uint32 numCalcUnits = inGraph->mNumCalcUnits;
    Unit** calcUnits = inGraph->mCalcUnits;

    if (inGraph->mFlags & kGraph_ReblockOrResample) {
        scprintf("\nTRACE %d  %s    #units: %d, block size: %d, sr: %d\n", inGraph->mNode.mID,
                      inGraph->mNode.mDef->mName, numCalcUnits, inGraph->mFullRate->mBufLength,
                      sc_float_to_int32(inGraph->mFullRate->mSampleRate));
    } else {
        scprintf("\nTRACE %d  %s    #units: %d\n", inGraph->mNode.mID, inGraph->mNode.mDef->mName, numCalcUnits);
    }

    int numTicks = inGraph->mNumTicks;

    for (int k = 0; k < numTicks; ++k) {
        if (numTicks > 1)
            scprintf("tick %d of %d:\n", k + 1, numTicks);

        inGraph->mTickCounter = k;

        for (uint32 i = 0; i < numCalcUnits; ++i) {
            Unit* unit = calcUnits[i];
            scprintf("  unit %d %s\n    in ", i, (char*)unit->mUnitDef->mUnitDefName);
            for (uint32 j = 0; j < unit->mNumInputs; ++j) {
                scprintf(" %g", ZIN0(j));
            }
            scprintf("\n");
            (unit->mCalcFunc)(unit, unit->mBufLength);
            scprintf("    out");
            for (uint32 j = 0; j < unit->mNumOutputs; ++j) {
                scprintf(" %g", ZOUT0(j));
            }
            scprintf("\n");
        }
    }

    inGraph->mNode.mCalcFunc = (NodeCalcFunc)&Graph_Calc;
}

void Graph_Trace(Graph* inGraph) {
    if (inGraph->mNode.mCalcFunc == (NodeCalcFunc)&Graph_Calc) {
        inGraph->mNode.mCalcFunc = (NodeCalcFunc)&Graph_CalcTrace;
    }
}


int Graph_GetControl(Graph* inGraph, uint32 inIndex, float& outValue) {
    if (inIndex >= GRAPHDEF(inGraph)->mNumControls)
        return kSCErr_IndexOutOfRange;
    outValue = inGraph->mControls[inIndex];
    return kSCErr_None;
}

int Graph_GetControl(Graph* inGraph, int32 inHash, int32* inName, uint32 inIndex, float& outValue) {
    ParamSpecTable* table = GRAPH_PARAM_TABLE(inGraph);
    ParamSpec* spec = table->Get(inHash, inName);
    if (!spec || inIndex >= spec->mNumChannels)
        return kSCErr_IndexOutOfRange;
    return Graph_GetControl(inGraph, spec->mIndex + inIndex, outValue);
}

void Graph_SetControl(Graph* inGraph, uint32 inIndex, float inValue) {
    if (inIndex >= GRAPHDEF(inGraph)->mNumControls)
        return;
    inGraph->mControlRates[inIndex] = 0;
    float* ptr = inGraph->mControls + inIndex;
    inGraph->mMapControls[inIndex] = ptr; // unmap the control
    *ptr = inValue;
}

void Graph_SetControl(Graph* inGraph, int32 inHash, int32* inName, uint32 inIndex, float inValue) {
    ParamSpecTable* table = GRAPH_PARAM_TABLE(inGraph);
    ParamSpec* spec = table->Get(inHash, inName);
    if (!spec || inIndex >= spec->mNumChannels)
        return;
    // printf("setting: %s: to value %f\n", spec->mName, inValue);
    Graph_SetControl(inGraph, spec->mIndex + inIndex, inValue);
}


void Graph_MapControl(Graph* inGraph, int32 inHash, int32* inName, uint32 inIndex, uint32 inBus) {
    ParamSpecTable* table = GRAPH_PARAM_TABLE(inGraph);
    ParamSpec* spec = table->Get(inHash, inName);
    if (!spec || inIndex >= spec->mNumChannels)
        return;
    // printf("mapping: %s: to bus index %i\n", spec->mName, inBus);
    Graph_MapControl(inGraph, spec->mIndex + inIndex, inBus);
}

void Graph_MapControl(Graph* inGraph, uint32 inIndex, uint32 inBus) {
    if (inIndex >= GRAPHDEF(inGraph)->mNumControls)
        return;
    World* world = inGraph->mNode.mWorld;
    if (inBus >= 0x80000000) {
        inGraph->mControlRates[inIndex] = 0;
        inGraph->mMapControls[inIndex] = inGraph->mControls + inIndex;
    } else if (inBus < world->mNumControlBusChannels) {
        inGraph->mControlRates[inIndex] = 1;
        inGraph->mMapControls[inIndex] = world->mControlBus + inBus;
    }
}

void Graph_MapAudioControl(Graph* inGraph, int32 inHash, int32* inName, uint32 inIndex, uint32 inBus) {
    ParamSpecTable* table = GRAPH_PARAM_TABLE(inGraph);
    ParamSpec* spec = table->Get(inHash, inName);
    if (!spec || inIndex >= spec->mNumChannels)
        return;
    // printf("mapping: %s: to bus index %i\n", spec->mName, inBus);
    if (spec)
        Graph_MapAudioControl(inGraph, spec->mIndex + inIndex, inBus);
}

void Graph_MapAudioControl(Graph* inGraph, uint32 inIndex, uint32 inBus) {
    if (inIndex >= GRAPHDEF(inGraph)->mNumControls)
        return;
    World* world = inGraph->mNode.mWorld;
    /* what is the below doing??? it is unmapping by looking for negative ints */
    if (inBus >= 0x80000000) {
        inGraph->mControlRates[inIndex] = 0;
        inGraph->mMapControls[inIndex] = inGraph->mControls + inIndex;
    } else if (inBus < world->mNumAudioBusChannels) {
        inGraph->mControlRates[inIndex] = 2;
        inGraph->mAudioBusOffsets[inIndex] = inBus;
        inGraph->mMapControls[inIndex] = world->mAudioBus + (inBus * world->mBufLength);
    }
}
