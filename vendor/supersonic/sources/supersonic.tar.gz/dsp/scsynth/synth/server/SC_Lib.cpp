/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


#include "SC_Lib.h"
#include "SC_Lib_Cintf.h"
#include "SC_SequencedCommand.h"
#include "scsynthsend.h"
#include <string.h>
#include <ctype.h>
#include "SC_Prototypes.h"
#include "SC_Str4.h"
#include "SC_WorldOptions.h"
#include "SC_HiddenWorld.h"

#ifdef CLOCKWORK_GUEST
extern "C" {
}
#endif

const size_t PATH_BUF_SIZE(256);

void SendDone(ReplyAddress* inReply, const char* inCommandName) {
    small_scpacket packet;
    packet.adds("/done");
    packet.maketags(2);
    packet.addtag(',');
    packet.addtag('s');
    packet.adds(inCommandName);
    SendReply(inReply, packet.data(), packet.size());
}

void SendDoneWithIntValue(ReplyAddress* inReply, const char* inCommandName, int value) {
    small_scpacket packet;
    packet.adds("/done");
    packet.maketags(3);
    packet.addtag(',');
    packet.addtag('s');
    packet.adds(inCommandName);
    packet.addtag('i');
    packet.addi(value);
    SendReply(inReply, packet.data(), packet.size());
}

static void appendVarArgs(small_scpacket& packet, const char* oscFormat, va_list args) {
    // support all the types the server currently does
    while (*oscFormat != '\0') {
        if (*oscFormat == 'i') {
            int32 i = va_arg(args, int32);
            packet.addtag('i');
            packet.addi(i);
        } else if (*oscFormat == 'h') {
            int64 h = va_arg(args, int64);
            packet.addtag('h');
            packet.addii(h);
        } else if (*oscFormat == 'f') {
            float32 f = (float32)va_arg(args, double);
            packet.addtag('f');
            packet.addf(f);
        } else if (*oscFormat == 'd') {
            double d = va_arg(args, double);
            packet.addtag('d');
            packet.addd(d);
        } else if (*oscFormat == 's') {
            const char* s = va_arg(args, char*);
            packet.addtag('s');
            packet.adds(s);
        } else if (*oscFormat == 'b') {
            size_t len = va_arg(args, size_t);
            ++oscFormat;
            uint8* b = va_arg(args, uint8*);
            packet.addtag('b');
            packet.addb(b, len);
        }

        ++oscFormat;
    }
}

void SendDoneWithVarArgs(struct ReplyAddress* inReply, const char* inCommandName, const char* oscFormat, ...) {
    small_scpacket packet;
    int numArgs = strlen(oscFormat);
    packet.adds("/done");
    packet.maketags(2 + numArgs);
    packet.addtag(',');
    packet.addtag('s');
    packet.adds(inCommandName);

    va_list args;
    va_start(args, oscFormat);
    appendVarArgs(packet, oscFormat, args);
    va_end(args);

    SendReply(inReply, packet.data(), packet.size());
}

void SendFailure(ReplyAddress* inReply, const char* inCommandName, const char* errString) {
    small_scpacket packet;
    packet.adds("/fail");
    packet.maketags(3);
    packet.addtag(',');
    packet.addtag('s');
    packet.addtag('s');
    packet.adds(inCommandName);
    packet.adds(errString);
    SendReply(inReply, packet.data(), packet.size());
}

void SendFailureWithIntValue(ReplyAddress* inReply, const char* inCommandName, const char* errString, uint32 index) {
    small_scpacket packet;
    packet.adds("/fail");
    packet.maketags(4);
    packet.addtag(',');
    packet.addtag('s');
    packet.addtag('s');
    packet.addtag('i');
    packet.adds(inCommandName);
    packet.adds(errString);
    packet.addi((int)index);
    SendReply(inReply, packet.data(), packet.size());
}

void SendFailureWithVarArgs(struct ReplyAddress* inReply, const char* inCommandName, const char* errString,
                            const char* oscFormat, ...) {
    small_scpacket packet;
    int numArgs = strlen(oscFormat);
    packet.adds("/fail");
    packet.maketags(3 + numArgs);
    packet.addtag(',');
    packet.addtag('s');
    packet.addtag('s');
    packet.adds(inCommandName);
    packet.adds(errString);

    va_list args;
    va_start(args, oscFormat);
    appendVarArgs(packet, oscFormat, args);
    va_end(args);

    SendReply(inReply, packet.data(), packet.size());
}

void ReportLateness(ReplyAddress* inReply, float32 seconds) {
    small_scpacket packet;
    packet.adds("/late");
    packet.maketags(2);
    packet.addtag(',');
    packet.addtag('f');
    packet.addf(seconds);
    SendReply(inReply, packet.data(), packet.size());
}

SC_NamedObj::SC_NamedObj() { SetName("?"); }

void SC_NamedObj::SetName(const int32* inName) {
    if (str4len(inName) > (int)kSCNameLen)
        return;
    str4cpy(mName, inName);
    mHash = Hash(mName);
}

void SC_NamedObj::SetName(const char* inName) {
    if (str4len(inName) > (int)kSCNameLen)
        return;
    str4cpy(mName, inName);
    mHash = Hash(mName);
}

SC_LibCmd::SC_LibCmd(SC_CommandFunc inFunc): mFunc(inFunc) {}

SCErr SC_LibCmd::Perform(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    SCErr err;
    //	int kSendError = 1;		// i.e., 0x01 | 0x02;
    try {
        err = (mFunc)(inWorld, inSize, inData, inReply);
    } catch (int iexc) {
        err = iexc;
        scprintf(inWorld, "ERROR: %s threw int exception: %d", (char*)Name(), iexc);
    } catch (std::exception& exc) {
        scprintf(inWorld, "ERROR: %s threw std::exception: %s", (char*)Name(), exc.what());
        if (inWorld->mLocalErrorNotification <= 0 && inWorld->mErrorNotification) {
#ifdef CLOCKWORK_GUEST
            // Direct synchronous error reporting — SuperSonic runs NRT (single-threaded)
            SendFailure(inReply, (char*)Name(), exc.what());
            scprintf(inWorld, "FAILURE IN SERVER %s %s", (char*)Name(), exc.what());
#else
            CallSendFailureCommand(inWorld, (char*)Name(), exc.what(), inReply);
            scprintf(inWorld, "FAILURE IN SERVER %s %s\n", (char*)Name(), exc.what());
#endif
        }
        return kSCErr_Failed;
    } catch (...) { err = kSCErr_Failed; }
    if (err && (inWorld->mLocalErrorNotification <= 0 && inWorld->mErrorNotification)) {
        char errstr[128];
        SC_ErrorString(err, errstr, inWorld->hw->mMissingNodeID);
#ifdef CLOCKWORK_GUEST
        SendFailure(inReply, (char*)Name(), errstr);
        // An SCErr from a command usually means a stale client reference
        // (e.g. freeing a node that already ended), not server distress —
        // log a warning, unlike the exception path above. The /fail wire
        // reply is unchanged either way. /n_free on a missing node is
        // routine (scheduled frees land after the containing group is
        // freed on stop) and a no-op, so it isn't flagged as a warning —
        // but the server can't tell that apart from a bad id, so the log
        // states only what it knows.
        if (err == kSCErr_NodeNotFound && strcmp((char*)Name(), "/n_free") == 0)
            scprintf(inWorld, "/n_free: %s - nothing to free", errstr);
        else
            scprintf(inWorld, "WARNING: %s failed - %s", (char*)Name(), errstr);
#else
        CallSendFailureCommand(inWorld, (char*)Name(), errstr, inReply);
        scprintf(inWorld, "FAILURE IN SERVER %s %s\n", (char*)Name(), errstr);
#endif
    }
    return err;
}

SCErr NewCommand(World* inWorld, const char* inPath, uint32 inCommandNumber, SC_CommandFunc inFunc) {
    char path[PATH_BUF_SIZE];
    snprintf(path, PATH_BUF_SIZE, "/%s", inPath);
    HiddenWorld* hw = inWorld->hw;

    SC_LibCmd* cmd = guest_new<SC_LibCmd>(inWorld, inFunc);
    cmd->SetName(path);
    hw->mCmdLib->Add(cmd);

    // support OSC commands without the leading slash
    SC_LibCmd* cmd2 = guest_new<SC_LibCmd>(inWorld, inFunc);
    cmd2->SetName(inPath);
    hw->mCmdLib->Add(cmd2);

    // support integer OSC commands
    hw->mCmdArray[inCommandNumber] = cmd;

    return kSCErr_None;
}
