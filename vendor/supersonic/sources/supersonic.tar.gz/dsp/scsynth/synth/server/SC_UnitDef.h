/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/

#pragma once

#include "SC_Types.h"
#include "SC_Unit.h"
#include "SC_Reply.h"
#include "SC_Command.h"
#include "HashTable.h"
#include "guest_heap.h"   // GuestMalloc: a unit's commands are on its World's heap

struct PlugInCmd {
    int32 mCmdName[kSCNameLen];
    int32 mHash;
    PlugInCmdFunc mFunc;
    void* mUserData;
};

struct UnitCmd {
    int32 mCmdName[kSCNameLen];
    int32 mHash;
    union {
        UnitCmdFunc mFunc;
        UnitCmdFuncEx mFuncEx;
    };
    bool mHasFuncEx;
};

struct UnitDef {
    int32 mUnitDefName[kSCNameLen];
    int32 mHash;

    size_t mAllocSize;
    UnitCtorFunc mUnitCtorFunc;
    UnitDtorFunc mUnitDtorFunc;

    HashTable<UnitCmd, GuestMalloc>* mCmds;   // SuperSonic (plural guest): on the World's heap
    uint32 mFlags;
};

// SuperSonic (plural guest): each registers into the World whose table
// `inTable` is (InterfaceTable::mWorld).
extern "C" {
bool UnitDef_Create(struct InterfaceTable* inTable, const char* inName, size_t inAllocSize, UnitCtorFunc inCtor,
                    UnitDtorFunc inDtor, uint32 inFlags);
bool UnitDef_AddCmd(struct InterfaceTable* inTable, const char* inUnitDefName, const char* inCmdName,
                    UnitCmdFunc inFunc);
SCBool UnitDef_AddCmdEx(struct InterfaceTable* inTable, const char* inUnitDefName, const char* inCmdName,
                        UnitCmdFuncEx inFunc);
bool PlugIn_DefineCmd(struct InterfaceTable* inTable, const char* inCmdName, PlugInCmdFunc inFunc, void* inUserData);
}

SCErr Unit_DoCmd(World* inWorld, int inSize, const char* inData, ReplyAddress* inReplyAddr);
void Unit_RunCommand(const UnitCmd* cmd, Unit* unit, sc_msg_iter* msg, ReplyAddress* inReplyAddr);

inline int32* GetKey(UnitCmd* inCmd) { return inCmd->mCmdName; }
inline int32 GetHash(UnitCmd* inCmd) { return inCmd->mHash; }
