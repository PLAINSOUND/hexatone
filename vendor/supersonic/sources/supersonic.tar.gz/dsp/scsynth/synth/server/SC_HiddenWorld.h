/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


#pragma once

#include "SC_Types.h"
#include "scsynth_config.h"
#include "SC_Rate.h"
#include "SC_SndBuf.h"
#include "SC_RGen.h"
#include "HashTable.h"
#include "SC_World.h"
#include "SC_Wire.h"
#include "SC_Reply.h"
#include "MsgFifo.h"
#include "guest_heap.h"
#include <map>
#include <deque>
#include <set>

#ifndef SC_LEAN_TARGET
#include "SC_QuitSemaphore.hpp"
#endif

#ifndef NO_LIBSNDFILE
#    include <SC_SndFileHelpers.hpp> // includes sndfile.h with appropriate configuration
#endif

extern HashTable<struct UnitDef, Malloc>* gUnitDefLib;


struct TriggerMsg {
    World* mWorld;
    int32 mNodeID;
    int32 mTriggerID;
    float mValue;

    void Perform();
};


struct NodeReplyMsg {
    World* mWorld;
    int32 mNodeID;
    int32 mID;
    int32 mNumArgs;
    float* mValues;
    int32 mCmdNameSize;
    char* mCmdName;
    void* mRTMemory;
    void Perform();
};


struct NodeEndMsg {
    World* mWorld;
    int32 mNodeID;
    int32 mGroupID;
    int32 mPrevNodeID;
    int32 mNextNodeID;
    int32 mIsGroup;
    int32 mHeadID;
    int32 mTailID;
    int32 mState;

    void Perform();
};

// Frees a list of GraphDefs (linked by mNext) and sends /d_removed for each
// to every registered client. Upstream sends it to the NRT thread through a
// FIFO in real-time mode; here every stage runs on one thread, so the release
// performs it directly and there is no FIFO.
struct DeleteGraphDefMsg {
    World* mWorld;
    struct GraphDef* mDefList;

    void Perform();
};

// Fixed-capacity notification FIFOs, allocated inline in HiddenWorld. At the
// default depths they dominate sizeof(HiddenWorld) (~120 KiB on 64-bit); the
// depths come from memory_profile.h and default to upstream scsynth's fixed
// sizes. MsgFifo enforces the power-of-two / minimum-depth invariant itself.
typedef MsgFifoNoFree<TriggerMsg, SC_TRIGGERS_FIFO_SIZE> TriggersFifo;
typedef MsgFifoNoFree<NodeReplyMsg, SC_NODE_REPLY_FIFO_SIZE> NodeReplyFifo;
typedef MsgFifoNoFree<NodeEndMsg, SC_NODE_ENDS_FIFO_SIZE> NodeEndsFifo;
// The instance's tables and client lists, in the guest's own memory
// (guest_heap.h): upstream's are on the system allocator.
typedef HashTable<struct GraphDef, GuestMalloc> GrafDefTable;

typedef std::map<struct ReplyAddress, uint32, std::less<struct ReplyAddress>,
                 GuestAllocator<std::pair<const struct ReplyAddress, uint32>>> ClientIDDict;
typedef std::deque<int, GuestAllocator<int>> ClientIDs;
typedef std::set<ReplyAddress, std::less<ReplyAddress>, GuestAllocator<ReplyAddress>> Clients;

struct HiddenWorld {
    class AllocPool* mAllocPool;
    IntHashTable<struct Node, AllocPool>* mNodeLib;
    GrafDefTable* mGraphDefLib;
    uint32 mMaxUsers;
    Clients* mUsers;
    ClientIDs* mAvailableClientIDs;
    ClientIDDict* mClientIDdict;

    class SC_AudioDriver* mAudioDriver;
    char mPassword[32];

    uint32 mMaxWireBufs;
    float* mWireBufSpace;
    Wire mMissingInputWire;

    TriggersFifo mTriggers;
    NodeReplyFifo mNodeMsgs;
    NodeEndsFifo mNodeEnds;

#ifndef SC_LEAN_TARGET
    sc::sync::semaphore* mQuitProgram;
#endif
    bool mTerminating;

#ifndef NO_LIBSNDFILE
    SNDFILE* mNRTInputFile;
    SNDFILE* mNRTOutputFile;
    FILE* mNRTCmdFile;
#endif

    int32 mHiddenID;
    int32 mRecentID;

#ifdef __APPLE__
    const char* mInputStreamsEnabled;
    const char* mOutputStreamsEnabled;
#endif

#ifdef SC_BELA
    uint32 mBelaAnalogInputChannels;
    uint32 mBelaAnalogOutputChannels;
    uint32 mBelaDigitalChannels;
    float mBelaHeadphoneLevel;
    float mBelaPgaGainLeft;
    float mBelaPgaGainRight;
    bool mBelaSpeakerMuted;
    float mBelaDacLevel;
    float mBelaAdcLevel;
    uint32 mBelaNumMuxChannels;
    uint32 mBelaPru;
#endif

    const char* mInDeviceName;
    const char* mOutDeviceName;
};

typedef struct HiddenWorld HiddenWorld;

inline SC_AudioDriver* AudioDriver(World* inWorld) { return inWorld->hw->mAudioDriver; }
