/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


#include "SC_Lib.h"
#include "SC_CoreAudio.h"
#include "SC_HiddenWorld.h"
#include "SC_Graph.h"
#include "SC_GraphDef.h"
#include "SC_Group.h"
#include "SC_UnitDef.h"
#include <stdexcept>
#include "SC_Lib_Cintf.h"
#include "SC_SequencedCommand.h"
#include <new>
#include "SC_Prototypes.h"
#include "scsynthsend.h"
#include "SC_WorldOptions.h"
#include <cstdlib>

extern int gMissingNodeID;

// =============================================================================
// TAU MODIFICATION START - Direct SAB tree update for /n_order
// When nodes are reordered within the same group, SuperCollider doesn't send
// kNode_Move (no OSC notification). But we need to update the SAB tree.
// This helper updates the SAB tree directly without triggering OSC messages.
// =============================================================================
#include "../../node_tree.h"

static void NodeTree_UpdateDirect(Node* node) {
    if (!node) return;

    NodeTreeHeader* tree_header  = supersonic_node_tree_header();
    NodeEntry*      tree_entries = supersonic_node_tree_entries();
    if (!tree_header || !tree_entries) return;

    NodeTree_Update(node, tree_header, tree_entries);
}
// =============================================================================
// TAU MODIFICATION END
// =============================================================================

// returns number of bytes in an OSC string.
int OSCstrlen(char* strin);

Node* Msg_GetNode(World* inWorld, sc_msg_iter& msg) {
    Node* node;
    if (msg.nextTag('i') == 's') {
        const char* loc = msg.gets();
        int32 nodeID = msg.geti();
        gMissingNodeID = nodeID;
        node = World_GetNode(inWorld, nodeID);
        while (*loc) {
            if (!node)
                return nullptr;
            switch (*loc) {
            case 'h':
                if (!node->mIsGroup)
                    return nullptr;
                node = ((Group*)node)->mHead;
                break;
            case 't':
                if (!node->mIsGroup)
                    return nullptr;
                node = ((Group*)node)->mTail;
                break;
            case 'u':
                // SuperSonic: the root group has no parent.
                node = node->mParent ? &node->mParent->mNode : nullptr;
                break;
            case 'p':
                node = node->mPrev;
                break;
            case 'n':
                node = node->mNext;
                break;
            }
            loc++;
        }
    } else {
        int32 nodeID = msg.geti();
        gMissingNodeID = nodeID;
        node = World_GetNode(inWorld, nodeID);
    }
    return node;
}

Group* Msg_GetGroup(World* inWorld, sc_msg_iter& msg) {
    Node* node = Msg_GetNode(inWorld, msg);
    return node && node->mIsGroup ? (Group*)node : nullptr;
}

Graph* Msg_GetGraph(World* inWorld, sc_msg_iter& msg) {
    Node* node = Msg_GetNode(inWorld, msg);
    return !node || node->mIsGroup ? nullptr : (Graph*)node;
}

// SuperSonic: where a node may be moved. Calculating, freeing and querying all
// walk each group's children, so a group moved into itself or a group inside
// it would be walked for ever. The root group has no parent and does not move,
// and a node does not move beside itself or beside the root.
static bool Node_CanMoveInto(const Node* node, const Group* group) {
    if (!node->mParent)
        return false;
    for (const Group* g = group; g; g = g->mNode.mParent)
        if (&g->mNode == node)
            return false;
    return true;
}

static bool Node_CanMoveBeside(const Node* node, const Node* target) {
    return node != target && target->mParent && Node_CanMoveInto(node, target->mParent);
}

SCErr meth_none(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) { return kSCErr_None; }

SCErr meth_sync(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(SyncCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}

SCErr meth_b_alloc(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufAllocCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}

SCErr meth_b_free(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufFreeCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_close(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufCloseCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_allocRead(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufAllocReadCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}

SCErr meth_b_read(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufReadCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_allocReadChannel(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufAllocReadChannelCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_readChannel(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufReadChannelCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_write(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufWriteCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_b_zero(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufZeroCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}

// A sample reaches a buffer as an ASSET (clockwork dsp_api.h): the client
// writes the frames into the assets area and commits them, and dsp_asset binds the
// buffer to them where they lie (buffer_commands.cpp). There is no verb for
// it here; /b_allocPtr, the web client's own spelling of the hand-off, went
// with the one binding on every platform.
#include "buffer_commands.h"
#include "piano_wavetable.h"

// /supersonic/buffer/read bufnum bufOffset assetsOffset numFrames numChannels sampleRate
//
// Frames from the assets area lane into an ALLOCATED buffer, in place of what
// /b_read did with a file: the client decoded them (clockwork_audio_file.h
// is a client API) and laid them out at assetsOffset, interleaved, with no
// guard frames — the buffer keeps its own. Clamped to the buffer's end, as
// /b_read clamped; refused when the channel counts differ, as /b_read
// refused; the rate, if given, becomes the buffer's, as /b_read set it.
SCErr meth_supersonic_buffer_read(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    static const char* kName = "/supersonic/buffer/read";
    sc_msg_iter msg(inSize, inData);
    const int bufnum      = msg.geti();
    const int bufOffset   = msg.geti();
    const int assetsOffset = msg.geti();
    const int numFrames   = msg.geti();
    const int numChannels = msg.geti();
    const float rate      = msg.getf();

    if (bufnum < 0 || (uint32)bufnum >= inWorld->mNumSndBufs) {
        SendFailureWithIntValue(inReply, kName, "buffer number out of range", bufnum);
        return kSCErr_None;
    }
    SndBuf* buf = World_GetNRTBuf(inWorld, bufnum);
    if (!buf->data || buf->channels <= 0) {
        SendFailureWithIntValue(inReply, kName, "buffer is not allocated", bufnum);
        return kSCErr_None;
    }
    if (numChannels != buf->channels) {
        char str[256];
        snprintf(str, sizeof str, "Channel mismatch. Lane has %d channels. Buffer has %d channels.\n",
                 numChannels, buf->channels);
        SendFailureWithIntValue(inReply, kName, str, bufnum);
        return kSCErr_None;
    }
    const uint8_t* assets = supersonic_assets_base();
    const uint64_t bytes = (uint64_t)(numFrames > 0 ? numFrames : 0) * (uint64_t)numChannels * sizeof(float);
    if (!assets || assetsOffset < 0 || numFrames < 0
        || (uint64_t)assetsOffset + bytes > (uint64_t)supersonic_assets_bytes()) {
        SendFailureWithIntValue(inReply, kName, "range is not inside the assets area", bufnum);
        return kSCErr_None;
    }
    const int framesToEnd = buf->frames - (bufOffset < 0 ? 0 : bufOffset);
    const int n = framesToEnd <= 0 ? 0 : (numFrames < framesToEnd ? numFrames : framesToEnd);
    if (n > 0 && bufOffset >= 0)
        memcpy(buf->data + (size_t)bufOffset * buf->channels, assets + assetsOffset,
               (size_t)n * buf->channels * sizeof(float));
    if (rate > 0.f) {
        buf->samplerate = rate;
        World_GetBuf(inWorld, bufnum)->samplerate = rate;
    }
    inWorld->mSndBufUpdates[bufnum].writes++;
    SendDoneWithIntValue(inReply, kName, bufnum);
    return kSCErr_None;
}

// /supersonic/buffer/publish bufnum bufOffset numFrames returnsOffset
//
// A buffer's frames into the returns area lane, for a client to encode — in place
// of what /b_write did with a file. Clamped to the buffer's end (numFrames
// < 0: to the end), as /b_write clamped. The reply says what landed:
// /supersonic/buffer/published bufnum channels frames rate.
SCErr meth_supersonic_buffer_publish(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    static const char* kName = "/supersonic/buffer/publish";
    sc_msg_iter msg(inSize, inData);
    const int bufnum       = msg.geti();
    const int bufOffset    = msg.geti();
    const int numFrames    = msg.geti(-1);
    const int returnsOffset = msg.geti();

    if (bufnum < 0 || (uint32)bufnum >= inWorld->mNumSndBufs) {
        SendFailureWithIntValue(inReply, kName, "buffer number out of range", bufnum);
        return kSCErr_None;
    }
    const SndBuf* buf = World_GetBuf(inWorld, bufnum);
    if (!buf->data || buf->channels <= 0) {
        SendFailureWithIntValue(inReply, kName, "buffer is not allocated", bufnum);
        return kSCErr_None;
    }
    const int start = bufOffset < 0 ? 0 : bufOffset;
    int framesToEnd = buf->frames - start;
    if (framesToEnd < 0) framesToEnd = 0;
    const int n = numFrames < 0 || numFrames > framesToEnd ? framesToEnd : numFrames;
    uint8_t* returns = supersonic_returns_base();
    const uint64_t bytes = (uint64_t)n * (uint64_t)buf->channels * sizeof(float);
    if (!returns || returnsOffset < 0 || (uint64_t)returnsOffset + bytes > (uint64_t)supersonic_returns_bytes()) {
        SendFailureWithIntValue(inReply, kName, "range is not inside the returns area", bufnum);
        return kSCErr_None;
    }
    if (n > 0)
        memcpy(returns + returnsOffset, buf->data + (size_t)start * buf->channels, (size_t)bytes);

    small_scpacket packet;
    packet.adds("/supersonic/buffer/published");
    packet.maketags(5);
    packet.addtag(',');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('f');
    packet.addi(bufnum);
    packet.addi(buf->channels);
    packet.addi(n);
    packet.addf((float)buf->samplerate);
    SendReply(inReply, packet.data(), packet.size());
    return kSCErr_None;
}

SCErr meth_u_cmd(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    return Unit_DoCmd(inWorld, inSize, inData, inReply);
};

SCErr meth_cmd(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    return PlugIn_DoCmd(inWorld, inSize, inData, inReply);
};


/*
SCErr meth_n_cmd(World *inWorld, int inSize, const char *inData, ReplyAddress *inReply)
{
    sc_msg_iter msg(inSize, inData);
    Node *node = Msg_GetNode(inWorld, msg);
    if (!node) return kSCErr_NodeNotFound;

    char *args = msg.rdpos;
    int arglen = msg.remain();

//!!	(node->mDef->fNodeCmd)(node, arglen, args);

    return kSCErr_None;
}
*/

SCErr meth_n_trace(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;

        Node_Trace(node);
    }

    return kSCErr_None;
}

SCErr meth_g_dumpTree(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        int32 flag = msg.geti();
        if (flag) {
            Group_DumpTreeAndControls(group);
        } else {
            Group_DumpTree(group);
        }
    }

    return kSCErr_None;
}

// SCErr meth_g_queryTree(World *inWorld, int inSize, char *inData, ReplyAddress* inReply)
//{
//	sc_msg_iter msg(inSize, inData);
//	while (msg.remain()) {
//		Group *group = Msg_GetGroup(inWorld, msg);
//		if (!group) return kSCErr_GroupNotFound;
//
//		// first count the total number of nodes to know how many tags the packet should have
//		int numNodes = 1; // include this one
//
//		Group_CountNodes(group, &numNodes);
//
//		big_scpacket packet;
//		packet.adds("/g_queryTree.reply");
//		packet.maketags(numNodes * 3 + 1);
//		packet.addtag(',');
//
//		Group_QueryTree(group, &packet);
//
//		if (packet.size()) {
//			CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
//		}
//	}
//	return kSCErr_None;
//}

SCErr meth_g_queryTree(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        big_scpacket packet;
        packet.adds("/g_queryTree.reply");
        int32 flag = msg.geti();
        if (flag) {
            // first count the total number of nodes to know how many tags the packet should have
            int numNodes = 1; // include this one
            int numControlsAndDefs = 0;
            Group_CountNodeAndControlTags(group, &numNodes, &numControlsAndDefs);
            // nodeID and numChildren + numControlsAndDefs + controlFlag
            packet.maketags(numNodes * 2 + numControlsAndDefs + 2);
            packet.addtag(',');
            packet.addtag('i');
            packet.addi(1); // include controls flag
            Group_QueryTreeAndControls(group, &packet);
        } else {
            // first count the total number of nodes to know how many tags the packet should have
            int numNodeTags = 2; // include this one
            Group_CountNodeTags(group, &numNodeTags);
            packet.maketags(numNodeTags + 2); // nodeID and numChildren
            packet.addtag(',');
            packet.addtag('i');
            packet.addi(0); // include controls flag
            Group_QueryTree(group, &packet);
        }

        if (packet.size()) {
            CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
        }
    }
    return kSCErr_None;
}


SCErr meth_n_run(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;

        int32 run = msg.geti();

        Node_SetRun(node, run);
    }

    return kSCErr_None;
}

SCErr meth_n_map(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain() >= 8) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int bus = msg.geti();
            Node_MapControl(node, Hash(name), name, 0, bus);
        } else {
            int32 index = msg.geti();
            int32 bus = msg.geti();
            Node_MapControl(node, index, bus);
        }
    }
    return kSCErr_None;
}

// SuperSonic: a client's count is bounded before a handler loops on it.

// start + n - 1, held to int32's range.
static int32 LastIndex(int32 start, int32 n) {
    const int64 last = (int64)start + n - 1;
    return last > INT32_MAX ? INT32_MAX : last < INT32_MIN ? INT32_MIN : (int32)last;
}

// bus + i for consecutive mappings: -1 (unmap) stays -1, and a bus past
// int32's range becomes INT32_MAX, which no World has.
static int32 BusPlus(int32 bus, int32 i) {
    if (bus == -1)
        return -1;
    const int64 b = (int64)bus + i;
    return b > INT32_MAX ? INT32_MAX : (int32)b;
}

// The most controls any synth at or under inNode has: a control index or a
// channel past it sets and maps nothing.
static uint32 Node_MaxControls(Node* inNode) {
    uint32 most = 0;
    Node* node = inNode;
    while (node) {
        if (node->mIsGroup && ((Group*)node)->mHead) {
            node = ((Group*)node)->mHead;
            continue;
        }
        if (!node->mIsGroup)
            most = sc_max(most, GRAPHDEF((Graph*)node)->mNumControls);
        while (node != inNode && !node->mNext)
            node = (Node*)node->mParent;
        if (node == inNode)
            break;
        node = node->mNext;
    }
    return most;
}

// How many of the n controls from index exist under a node with `limit`
// controls at most: the loop over i in [first, end) stays in [0, limit).
static void ControlRange(int32 index, int32 n, uint32 limit, int32& first, int32& end) {
    const int64 lo = index < 0 ? -(int64)index : 0;
    const int64 hi = sc_min((int64)n, (int64)limit - index);
    first = (int32)sc_min(lo, (int64)INT32_MAX);
    end = hi > lo ? (int32)hi : first;
}

SCErr meth_n_mapn(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain() >= 12) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            int bus = msg.geti();
            const int n = sc_min(msg.geti(), (int32)sc_min(Node_MaxControls(node), (uint32)INT32_MAX));
            for (int i = 0; i < n; ++i) {
                Node_MapControl(node, hash, name, i, BusPlus(bus, i));
            }
        } else {
            int32 index = msg.geti();
            int32 bus = msg.geti();
            int32 first, end;
            ControlRange(index, msg.geti(), Node_MaxControls(node), first, end);
            for (int i = first; i < end; ++i) {
                Node_MapControl(node, index + i, BusPlus(bus, i));
            }
        }
    }
    return kSCErr_None;
}

SCErr meth_n_mapa(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain() >= 8) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int bus = msg.geti();
            Node_MapAudioControl(node, Hash(name), name, 0, bus);
        } else {
            int32 index = msg.geti();
            int32 bus = msg.geti();
            Node_MapAudioControl(node, index, bus);
        }
    }
    return kSCErr_None;
}

SCErr meth_n_mapan(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain() >= 12) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            int bus = msg.geti();
            const int n = sc_min(msg.geti(), (int32)sc_min(Node_MaxControls(node), (uint32)INT32_MAX));
            for (int i = 0; i < n; ++i) {
                Node_MapAudioControl(node, hash, name, i, BusPlus(bus, i));
            }
        } else {
            int32 index = msg.geti();
            int32 bus = msg.geti();
            int32 first, end;
            ControlRange(index, msg.geti(), Node_MaxControls(node), first, end);
            for (int i = first; i < end; ++i) {
                Node_MapAudioControl(node, index + i, BusPlus(bus, i));
            }
        }
    }
    return kSCErr_None;
}

SCErr meth_n_set(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;
    while (msg.remain() >= 8) {
        int i = 0;
        int loop = 0;
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            do {
                switch (msg.nextTag('f')) {
                case 'f':
                case 'i': {
                    float32 value = msg.getf();
                    Node_SetControl(node, hash, name, i, value);
                    ++i;
                    break;
                }
                case 's': {
                    const char* string = msg.gets();
                    if (*string == 'c') {
                        int bus = sc_atoi(string + 1);
                        Node_MapControl(node, hash, name, i, bus);
                        ++i;
                    }
                    if (*string == 'a') {
                        int bus = sc_atoi(string + 1);
                        Node_MapAudioControl(node, hash, name, i, bus);
                        ++i;
                    }
                    break;
                }
                case ']':
                    msg.count++;
                    loop--;
                    break;
                case '[':
                    msg.count++;
                    loop++;
                    break;
                default:
                    // A type no control takes: read past it.
                    msg.getf();
                    break;
                }
            } while (loop && msg.remain());
        } else {
            int32 index = msg.geti();
            do {
                switch (msg.nextTag('f')) {
                case 'f':
                case 'i': {
                    float32 value = msg.getf();
                    Node_SetControl(node, index + i, value);
                    ++i;
                    break;
                }
                case 's': {
                    const char* string = msg.gets();
                    if (*string == 'c') {
                        int bus = sc_atoi(string + 1);
                        Node_MapControl(node, index + i, bus);
                        ++i;
                    }
                    if (*string == 'a') {
                        int bus = sc_atoi(string + 1);
                        Node_MapAudioControl(node, index + i, bus);
                        ++i;
                    }
                    break;
                }
                case ']':
                    msg.count++;
                    loop--;
                    break;
                case '[':
                    msg.count++;
                    loop++;
                    break;
                default:
                    // A type no control takes: read past it.
                    msg.getf();
                    break;
                }
            } while (loop && msg.remain());
        }
    }

    //{
    //	int i = 0;
    //	int loop = 0;
    //	if (msg.nextTag('i') == 's') {
    //	    int32* name = msg.gets4();
    //	    int32 hash = Hash(name);
    //	    if (msg.nextTag('f') == '[' ) {
    //		msg.count++;
    //		loop = 1;
    //	    }
    //	    do {
    //		if (msg.nextTag('f') == 's' ) {
    //		    const char* string = msg.gets();
    //		    if ( *string == 'c') {
    //			int bus = sc_atoi(string+1);
    //			Node_MapControl(node, hash, name, i, bus);
    //		    }
    //		} else {
    //		    if (msg.nextTag('f') == ']' ) {
    //			msg.count++;
    //			loop = 0;
    //		    } else {
    //			float32 value = msg.getf();
    //			Node_SetControl(node, hash, name, i, value);
    //		    }
    //		}
    //		++i;
    //	    } while (loop);
    //	} else {
    //	    int32 index = msg.geti();
    //	    if (msg.nextTag('f') == '[' ) {
    //		msg.count++;
    //		loop = 1;
    //	    }
    //	    do {
    //		if (msg.nextTag('f') == 's') {
    //		    const char* string = msg.gets();
    //		    if (*string == 'c') {
    //			int bus = sc_atoi(string+1);
    //			Node_MapControl(node, index + i, bus);
    //		    }
    //		} else {
    //		    if (msg.nextTag('f') == ']' ) {
    //			msg.count++;
    //			loop = 0;
    //		    } else {
    //			float32 value = msg.getf();
    //			Node_SetControl(node, index + i, value);
    //		    }
    //		}
    //		++i;
    //	    } while (loop);
    //	}
    //    }
    return kSCErr_None;
}

SCErr meth_n_setn(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain()) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            int32 n = msg.geti();
            for (int i = 0; msg.remain() && i < n; ++i) {
                if (msg.nextTag('f') == 's') {
                    const char* string = msg.gets();
                    if (*string == 'c') {
                        int bus = sc_atoi(string + 1);
                        Node_MapControl(node, hash, name, i, bus);
                    }
                    if (*string == 'a') {
                        int bus = sc_atoi(string + 1);
                        Node_MapAudioControl(node, hash, name, i, bus);
                    }

                } else {
                    float32 value = msg.getf();
                    Node_SetControl(node, hash, name, i, value);
                }
            }
        } else {
            int32 index = msg.geti();
            int32 n = msg.geti();
            for (int i = 0; msg.remain() && i < n; ++i) {
                if (msg.nextTag('f') == 's') {
                    const char* string = msg.gets();
                    if (*string == 'c') {
                        int bus = sc_atoi(string + 1);
                        Node_MapControl(node, index + i, bus);
                    }
                    if (*string == 'a') {
                        int bus = sc_atoi(string + 1);
                        Node_MapAudioControl(node, index + i, bus);
                    }
                } else {
                    float32 value = msg.getf();
                    Node_SetControl(node, index + i, value);
                }
            }
        }
    }
    return kSCErr_None;
}

SCErr meth_n_fill(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    Node* node = Msg_GetNode(inWorld, msg);
    if (!node)
        return kSCErr_NodeNotFound;

    while (msg.remain() >= 12) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            const int32 n = sc_min(msg.geti(), (int32)sc_min(Node_MaxControls(node), (uint32)INT32_MAX));
            float32 value = msg.getf();

            for (int i = 0; i < n; ++i) {
                Node_SetControl(node, hash, name, i, value);
            }

            // =============================================================================
            // TAU BUG FIX: Removed erroneous else block from upstream
            // The upstream code had an else block that called msg.getf() to read another
            // value after the bus mapping check. But per the OSC spec, /n_fill only takes
            // [controlIndex, numControls, value] - there's no second value to read.
            // The else block would read garbage/undefined data and overwrite the correct
            // values that were just set. This was likely a copy-paste error from /n_set
            // which has a similar bus-mapping else pattern.
            // Test: test/osc_semantic.spec.mjs "/n_fill semantic tests"
            // =============================================================================
            if (msg.nextTag('f') == 's') {
                const char* string = msg.gets();
                if (*string == 'c') {
                    int bus = sc_atoi(string + 1);
                    for (int i = 0; i < n; ++i) {
                        Node_MapControl(node, hash, name, i, BusPlus(bus, i));
                    }
                }
            }
            // No else block - if no bus mapping string, the value was already set above
        } else {
            int32 index = msg.geti();
            int32 first, end;
            ControlRange(index, msg.geti(), Node_MaxControls(node), first, end);
            float32 value = msg.getf();

            for (int i = first; i < end; ++i) {
                Node_SetControl(node, index + i, value);
            }
            // =============================================================================
            // TAU BUG FIX: Same fix as above for index-based path
            // =============================================================================
            if (msg.nextTag('f') == 's') {
                const char* string = msg.gets();
                if (*string == 'c') {
                    int bus = sc_atoi(string + 1);
                    for (int i = first; i < end; ++i) {
                        Node_MapControl(node, index + i, BusPlus(bus, i));
                    }
                }
            }
            // No else block - if no bus mapping string, the value was already set above
        }
    }

    return kSCErr_None;
}

SCErr meth_n_query(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;

        Node_StateMsg(node, kNode_Info);
    }
    return kSCErr_None;
}

SCErr meth_b_query(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    small_scpacket packet;

    int numbufs = msg.remain() >> 2;
    packet.adds("/b_info");
    packet.maketags(numbufs * 4 + 1);
    packet.addtag(',');

    while (msg.remain()) {
        int bufindex = msg.geti();
        SndBuf* buf = World_GetBuf(inWorld, bufindex);

        packet.addtag('i');
        packet.addtag('i');
        packet.addtag('i');
        packet.addtag('f');
        packet.addi(bufindex);
        packet.addi(buf->frames);
        packet.addi(buf->channels);
        packet.addf(buf->samplerate);
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}


#ifdef CLOCKWORK_GUEST
// The engine reads no files, on any platform: a definition reaches it as
// bytes, in /d_recv. supersonic::Commands, which the native server and the NIF
// send through, answers /d_load and /d_loadDir itself before they get here. The
// refusal is the /fail: an error returned here would send a second.
#    ifdef SC_LEAN_TARGET
static const char* const kNoDefinitionFiles =
    "the engine does not read files: send the definition's bytes with /d_recv";
#    else
static const char* const kNoDefinitionFiles =
    "the engine does not read files: send each definition's bytes with /d_recv, "
    "or send this through supersonic::Commands, which reads the files";
#    endif

SCErr meth_d_load(World* /*inWorld*/, int /*inSize*/, const char* /*inData*/, ReplyAddress* inReply) {
    SendFailure(inReply, "/d_load", kNoDefinitionFiles);
    return kSCErr_None;
}

SCErr meth_d_loadDir(World* /*inWorld*/, int /*inSize*/, const char* /*inData*/, ReplyAddress* inReply) {
    SendFailure(inReply, "/d_loadDir", kNoDefinitionFiles);
    return kSCErr_None;
}
#elif !defined(SC_LEAN_TARGET)
SCErr meth_d_load(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(LoadSynthDefCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_d_loadDir(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(LoadSynthDefDirCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}
#endif

SCErr meth_d_recv(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(RecvSynthDefCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}

SCErr meth_d_freeAll(World* inWorld, int /*inSize*/, const char* /*inData*/, ReplyAddress* /*inReply*/) {
    World_FreeAllGraphDefs(inWorld);
    return kSCErr_None;
}

SCErr meth_d_free(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        int32* defname = msg.gets4();
        if (!defname)
            return kSCErr_SynthDefNotFound;
        SCErr err = GraphDef_Remove(inWorld, defname);
        if (err != kSCErr_None)
            return err;
    }
    return kSCErr_None;
}


// [SuperSonic] Declared in SC_Graph.cpp. Runs UGen constructors + zombie check
// synchronously so /n_set (and siblings) later in the same bundle mutate the
// post-init graph state instead of racing the constructors.
bool Graph_InitUnits(Graph* inGraph);

// 'argtype' is false for setn type args
SCErr meth_s_do_new(World* inWorld, int inSize, const char* inData, bool argtype) {
    SCErr err;
    sc_msg_iter msg(inSize, inData);
    int32* defname = msg.gets4();
    if (!defname)
        return kSCErr_WrongArgType;

    int32 nodeID = msg.geti();
    int32 addAction = msg.geti();

    GraphDef* def = World_GetGraphDef(inWorld, defname);
    if (!def) {
        scprintf("*** ERROR: SynthDef %s not found\n", (char*)defname);
        return kSCErr_SynthDefNotFound;
    }

    Graph* graph = nullptr;
    switch (addAction) {
    case 0: {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        err = Graph_New(inWorld, def, nodeID, &msg, &graph, argtype);
        if (err)
            return err;
        if (!graph)
            return kSCErr_Failed;
        Group_AddHead(group, &graph->mNode);
    } break;
    case 1: {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        err = Graph_New(inWorld, def, nodeID, &msg, &graph, argtype);
        if (err)
            return err;
        Group_AddTail(group, &graph->mNode);
    } break;
    case 2: {
        Node* beforeThisNode = Msg_GetNode(inWorld, msg);
        if (!beforeThisNode)
            return kSCErr_NodeNotFound;
        err = Graph_New(inWorld, def, nodeID, &msg, &graph, argtype);
        if (err)
            return err;
        Node_AddBefore(&graph->mNode, beforeThisNode);
    } break;
    case 3: {
        Node* afterThisNode = Msg_GetNode(inWorld, msg);
        if (!afterThisNode)
            return kSCErr_NodeNotFound;
        err = Graph_New(inWorld, def, nodeID, &msg, &graph, argtype);
        if (err)
            return err;
        Node_AddAfter(&graph->mNode, afterThisNode);
    } break;
    case 4: {
        Node* replaceThisNode = Msg_GetNode(inWorld, msg);
        if (!replaceThisNode)
            return kSCErr_NodeNotFound;
        err = Graph_New(inWorld, def, nodeID, &msg, &graph, argtype);
        if (err)
            return err;
        Node_Replace(&graph->mNode, replaceThisNode);
    } break;
    default:
        return kSCErr_Failed;
    }
    Node_StateMsg(&graph->mNode, kNode_Go);
    // [SuperSonic] Eager UGen construction — makes intra-bundle /n_set after
    // /s_new target the post-init state (fixes slides that would otherwise
    // see the /n_set value clobber the /s_new's initial args before VarLag
    // et al. get to capture them in their Ctors).
    Graph_InitUnits(graph);
    return kSCErr_None;
}

SCErr meth_s_new(World* inWorld, int inSize, const char* inData, ReplyAddress*) {
    return meth_s_do_new(inWorld, inSize, inData, true);
}

SCErr meth_s_newargs(World* inWorld, int inSize, const char* inData, ReplyAddress*) {
    return meth_s_do_new(inWorld, inSize, inData, false);
}

SCErr meth_g_new(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    SCErr err;

    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        int32 newGroupID = msg.geti();
        int32 addAction = msg.geti();

        Group* newGroup = nullptr;
        switch (addAction) {
        case 0: {
            Group* group = Msg_GetGroup(inWorld, msg);
            if (!group)
                return kSCErr_GroupNotFound;
            err = Group_New(inWorld, newGroupID, &newGroup);
            if (err)
                return err;
            Group_AddHead(group, &newGroup->mNode);
        } break;
        case 1: {
            Group* group = Msg_GetGroup(inWorld, msg);
            if (!group)
                return kSCErr_GroupNotFound;
            err = Group_New(inWorld, newGroupID, &newGroup);
            if (err)
                return err;
            Group_AddTail(group, &newGroup->mNode);
        } break;
        case 2: {
            Node* beforeThisNode = Msg_GetNode(inWorld, msg);
            if (!beforeThisNode)
                return kSCErr_TargetNodeNotFound;
            err = Group_New(inWorld, newGroupID, &newGroup);
            if (err)
                return err;
            Node_AddBefore(&newGroup->mNode, beforeThisNode);
        } break;
        case 3: {
            Node* afterThisNode = Msg_GetNode(inWorld, msg);
            if (!afterThisNode)
                return kSCErr_TargetNodeNotFound;
            err = Group_New(inWorld, newGroupID, &newGroup);
            if (err)
                return err;
            Node_AddAfter(&newGroup->mNode, afterThisNode);
        } break;
        case 4: {
            Node* replaceThisNode = Msg_GetNode(inWorld, msg);
            if (!replaceThisNode)
                return kSCErr_TargetNodeNotFound;
            if (replaceThisNode->mID == 0)
                return kSCErr_ReplaceRootGroup;
            err = Group_New(inWorld, newGroupID, &newGroup);
            if (err)
                return err;
            Node_Replace(&newGroup->mNode, replaceThisNode);
        } break;
        default:
            return kSCErr_Failed;
        }

        Node_StateMsg(&newGroup->mNode, kNode_Go);
    }

    return kSCErr_None;
}

SCErr meth_p_new(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    /* we emulate the concept of parallel groups by using sequential groups */
    return meth_g_new(inWorld, inSize, inData, inReply);
}

SCErr meth_n_free(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;

        Node_Delete(node);
    }

    return kSCErr_None;
}

SCErr meth_n_before(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    Node* prevNode = nullptr;
    Node* prevTarget = nullptr;
    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        Node* target = Msg_GetNode(inWorld, msg);

        if (!node || !target || !Node_CanMoveBeside(node, target))
            continue; // tolerate failure

        if (prevNode && prevNode != node) {
            // move the last pair that succeeded
            Node_Remove(prevNode);
            Node_AddBefore(prevNode, prevTarget);
            Node_StateMsg(prevNode, kNode_Move);
        }

        prevNode = node;
        prevTarget = target;
    }
    if (prevNode && prevNode != prevTarget) {
        // move the last pair that succeeded
        Node_Remove(prevNode);
        Node_AddBefore(prevNode, prevTarget);
        Node_StateMsg(prevNode, kNode_Move);
    }

    return kSCErr_None;
}

SCErr meth_n_after(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    Node* prevNode = nullptr;
    Node* prevTarget = nullptr;
    while (msg.remain()) {
        Node* node = Msg_GetNode(inWorld, msg);
        Node* target = Msg_GetNode(inWorld, msg);

        if (!node || !target || !Node_CanMoveBeside(node, target))
            continue; // tolerate failure

        if (prevNode && prevNode != node) {
            // move the last pair that succeeded
            Node_Remove(prevNode);
            Node_AddAfter(prevNode, prevTarget);
            Node_StateMsg(prevNode, kNode_Move);
        }

        prevNode = node;
        prevTarget = target;
    }
    if (prevNode) {
        // move the last pair that succeeded
        Node_Remove(prevNode);
        Node_AddAfter(prevNode, prevTarget);
        Node_StateMsg(prevNode, kNode_Move);
    }

    return kSCErr_None;
}

SCErr meth_n_order(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    Node* prevNode = nullptr;
    Node* node = nullptr;

    sc_msg_iter msg(inSize, inData);
    int32 addAction = msg.geti();

    // place the first node in the list based on target and addAction
    switch (addAction) {
    case 0: {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        while (!node && msg.remain()) {
            node = Msg_GetNode(inWorld, msg);
        }
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveInto(node, group))
            return kSCErr_Failed;

        Group* prevGroup = node->mParent;

        Node_Remove(node);

        Group_AddHead(group, node);

        if (group != prevGroup) {
            Node_StateMsg(node, kNode_Move);
        } else {
            // TAU: Update SAB tree for same-group reorder (no OSC notification)
            NodeTree_UpdateDirect(node);
        }

        prevNode = node;

    } break;
    case 1: {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;
        while (!node && msg.remain()) {
            node = Msg_GetNode(inWorld, msg);
        }
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveInto(node, group))
            return kSCErr_Failed;

        Group* prevGroup = node->mParent;

        Node_Remove(node);

        Group_AddTail(group, node);

        if (group != prevGroup) {
            Node_StateMsg(node, kNode_Move);
        } else {
            // TAU: Update SAB tree for same-group reorder (no OSC notification)
            NodeTree_UpdateDirect(node);
        }

        prevNode = node;

    } break;
    case 2: {
        Node* beforeNode = Msg_GetNode(inWorld, msg);
        if (!beforeNode)
            return kSCErr_TargetNodeNotFound;
        while (!node && msg.remain()) {
            node = Msg_GetNode(inWorld, msg);
        }
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveBeside(node, beforeNode))
            return kSCErr_Failed;

        Node_Remove(node);
        Node_AddBefore(node, beforeNode);
        Node_StateMsg(node, kNode_Move);

        prevNode = node;
    } break;
    case 3: {
        Node* afterNode = Msg_GetNode(inWorld, msg);
        if (!afterNode)
            return kSCErr_TargetNodeNotFound;
        while (!node && msg.remain()) {
            node = Msg_GetNode(inWorld, msg);
        }
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveBeside(node, afterNode))
            return kSCErr_Failed;

        Node_Remove(node);
        Node_AddAfter(node, afterNode);
        Node_StateMsg(node, kNode_Move);

        prevNode = node;
    } break;
    default:
        return kSCErr_Failed;
    }

    // now iterate through in order
    while (msg.remain()) {
        node = Msg_GetNode(inWorld, msg);
        if (!node || !Node_CanMoveBeside(node, prevNode))
            continue;
        Node_Remove(node);
        Node_AddAfter(node, prevNode);
        Node_StateMsg(node, kNode_Move);

        prevNode = node;
    }

    return kSCErr_None;
}

SCErr meth_g_head(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;

        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveInto(node, group))
            return kSCErr_Failed;

        Node_Remove(node);
        Group_AddHead(group, node);

        Node_StateMsg(node, kNode_Move);
    }
    return kSCErr_None;
}

SCErr meth_g_tail(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;

        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveInto(node, group))
            return kSCErr_Failed;

        Node_Remove(node);
        Group_AddTail(group, node);

        Node_StateMsg(node, kNode_Move);
    }
    return kSCErr_None;
}

SCErr meth_g_insert(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;

        Node* node = Msg_GetNode(inWorld, msg);
        if (!node)
            return kSCErr_NodeNotFound;
        if (!Node_CanMoveInto(node, group))
            return kSCErr_Failed;

        Group* prevGroup = node->mParent;

        int index = msg.geti();

        Node_Remove(node);
        Group_Insert(group, node, index);

        if (group != prevGroup) {
            Node_StateMsg(node, kNode_Move);
        }
    }
    return kSCErr_None;
}

SCErr meth_g_freeAll(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;

        Group_DeleteAll(group);
    }
    return kSCErr_None;
}

SCErr meth_g_deepFree(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Group* group = Msg_GetGroup(inWorld, msg);
        if (!group)
            return kSCErr_GroupNotFound;

        Group_DeepFreeGraphs(group);
    }
    return kSCErr_None;
}


SCErr meth_status(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    // we stop replying to status requests after receiving /quit
    if (inWorld->hw->mTerminating)
        return false;

    small_scpacket packet;

    packet.adds("/status.reply");
    packet.maketags(10);
    packet.addtag(',');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('i');
    packet.addtag('f');
    packet.addtag('f');
    packet.addtag('d');
    packet.addtag('d');

    packet.addi(1); // audio is always active now.
    packet.addi(inWorld->mNumUnits);
    packet.addi(inWorld->mNumGraphs);
    packet.addi(inWorld->mNumGroups);
    packet.addi(inWorld->hw->mGraphDefLib->NumItems());

    // SuperSonic: no scsynth audio driver (mRealTime is false), so the CPU
    // figures are 0 and the rates are the World's.
    SC_AudioDriver* driver = inWorld->hw->mAudioDriver;
    packet.addf(driver ? driver->GetAvgCPU() : 0.f);
    packet.addf(driver ? driver->GetPeakCPU() : 0.f);
    packet.addd(driver ? driver->GetSampleRate() : (double)inWorld->mSampleRate);
    packet.addd(driver ? driver->GetActualSampleRate() : (double)inWorld->mSampleRate);

    CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);

    return kSCErr_None;
}

SCErr meth_rtMemoryStatus(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    // we stop replying to status requests after receiving /quit
    if (inWorld->hw->mTerminating)
        return false;

    small_scpacket packet;

    packet.adds("/rtMemoryStatus.reply");
    packet.maketags(3);
    packet.addtag(',');
    packet.addtag('i');
    packet.addtag('i');

    packet.addi(World_TotalFree(inWorld));
    packet.addi(World_LargestFreeChunk(inWorld));

    CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);

    return kSCErr_None;
}

#ifdef CLOCKWORK_GUEST
// The engine cannot end the process it runs in. The native server answers
// /quit itself (supersonic::Commands) and shuts down; an embedder stops the
// engine its own way. The refusal is the /fail: an error returned here would
// send a second.
SCErr meth_quit(World* /*inWorld*/, int /*inSize*/, const char* /*inData*/, ReplyAddress* inReply) {
#    ifdef SC_LEAN_TARGET
    SendFailure(inReply, "/quit", "not supported in SuperSonic - use destroy() instead");
#    else
    SendFailure(inReply, "/quit",
                "the engine cannot end its host: the native server answers /quit itself, "
                "and the NIF stops with clockwork:stop/0");
#    endif
    return kSCErr_None;
}
#else
SCErr meth_quit(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(AudioQuitCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}
#endif

// SuperSonic: the world is not scsynth's real-time one (mRealTime is false:
// clockwork drives it), and the bundles sent ahead are clockwork's to hold, so
// clearing the schedule asks the host (scsynth_dsp.cpp, DspHost::flush_schedule).
extern "C" void supersonic_flush_schedule(void);
SCErr meth_clearSched(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    if (inWorld->mRealTime && inWorld->hw->mAudioDriver) {
        inWorld->hw->mAudioDriver->ClearSched();
    }
    supersonic_flush_schedule();
    return kSCErr_None;
}

SCErr meth_dumpOSC(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    inWorld->mDumpOSC = msg.geti();
    return kSCErr_None;
}

// SuperSonic: /version.reply keeps scsynth's format (program name, major,
// minor, the rest of the version, branch, commit) and reports SuperSonic and
// its version (package.json's, from the build). Branch and commit are empty.
SCErr meth_version(World* inWorld, int /*inSize*/, const char* /*inData*/, ReplyAddress* inReply) {
    const char* version = SUPERSONIC_VERSION_STRING;
    char* rest = nullptr;
    const long major = std::strtol(version, &rest, 10);
    const long minor = *rest == '.' ? std::strtol(rest + 1, &rest, 10) : 0;

    small_scpacket packet;

    packet.adds("/version.reply");
    packet.maketags(7);
    packet.addtag(',');
    packet.addtag('s');
    packet.adds(SUPERSONIC_NAME_STRING);
    packet.addtag('i');
    packet.addi((int)major);
    packet.addtag('i');
    packet.addi((int)minor);
    packet.addtag('s');
    packet.adds(rest);
    packet.addtag('s');
    packet.adds("");
    packet.addtag('s');
    packet.adds("");

    CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);

    return kSCErr_None;
}

SCErr meth_b_set(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    int bufindex = msg.geti();
    SndBuf* buf = World_GetBuf(inWorld, bufindex);
    if (!buf)
        return kSCErr_Failed;

    float* data = buf->data;
    uint32 numSamples = buf->samples;

    while (msg.remain() >= 8) {
        uint32 sampleIndex = msg.geti();
        float32 value = msg.getf();
        if (sampleIndex < numSamples) {
            data[sampleIndex] = value;
        } else
            return kSCErr_IndexOutOfRange;
    }
    return kSCErr_None;
}

SCErr meth_b_setn(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    int bufindex = msg.geti();
    SndBuf* buf = World_GetBuf(inWorld, bufindex);
    if (!buf)
        return kSCErr_Failed;

    float* data = buf->data;
    int numSamples = buf->samples;
    // SuperSonic: a range is clipped to the buffer's samples, and a buffer
    // never allocated has none to clip it to.
    if (numSamples <= 0)
        return kSCErr_None;

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);

        if (end < 0 || start >= numSamples)
            continue;

        start = sc_clip(start, 0, numSamples - 1);
        end = sc_clip(end, 0, numSamples - 1);

        for (int i = start; msg.remain() && i <= end; ++i) {
            float32 value = msg.getf();
            data[i] = value;
        }
    }

    return kSCErr_None;
}


SCErr meth_b_fill(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    int bufindex = msg.geti();
    SndBuf* buf = World_GetBuf(inWorld, bufindex);
    if (!buf)
        return kSCErr_Failed;

    float* data = buf->data;
    int numSamples = buf->samples;
    // SuperSonic: as /b_setn.
    if (numSamples <= 0)
        return kSCErr_None;

    while (msg.remain() >= 12) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        float32 value = msg.getf();
        int32 end = LastIndex(start, n);

        if (end < 0 || start >= numSamples)
            continue;

        start = sc_clip(start, 0, numSamples - 1);
        end = sc_clip(end, 0, numSamples - 1);

        for (int i = start; i <= end; ++i)
            data[i] = value;
    }

    return kSCErr_None;
}

SCErr meth_b_gen(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(BufGenCmd, inWorld, inSize, inData, inReply);

    return kSCErr_None;
}


SCErr meth_c_set(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    float* data = inWorld->mControlBus;
    int32* touched = inWorld->mControlBusTouched;
    int32 bufCounter = inWorld->mBufCounter;
    uint32 maxIndex = inWorld->mNumControlBusChannels;

    while (msg.remain() >= 8) {
        uint32 index = msg.geti();
        float32 value = msg.getf();
        if (index < maxIndex) {
            data[index] = value;
            touched[index] = bufCounter;
        } else
            return kSCErr_IndexOutOfRange;
    }
    return kSCErr_None;
}

SCErr meth_c_setn(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    float* data = inWorld->mControlBus;
    int32* touched = inWorld->mControlBusTouched;
    int32 bufCounter = inWorld->mBufCounter;
    int maxIndex = inWorld->mNumControlBusChannels;

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);

        if (start < 0 || end >= maxIndex || start > end)
            return kSCErr_IndexOutOfRange;

        for (int i = start; msg.remain() && i <= end; ++i) {
            float32 value = msg.getf();
            data[i] = value;
            touched[i] = bufCounter;
        }
    }

    return kSCErr_None;
}


SCErr meth_c_get(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    float* data = inWorld->mControlBus;
    uint32 maxIndex = inWorld->mNumControlBusChannels;

    int numheads = msg.remain() >> 2;

    big_scpacket packet;
    packet.adds("/c_set");
    packet.maketags(numheads * 2 + 1);
    packet.addtag(',');

    while (msg.remain() >= 4) {
        uint32 index = msg.geti();
        if (index >= maxIndex)
            return kSCErr_IndexOutOfRange;
        packet.addtag('i');
        packet.addtag('f');
        packet.addi(index);
        packet.addf(data[index]);
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}

SCErr meth_c_getn(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    float* data = inWorld->mControlBus;
    int maxIndex = inWorld->mNumControlBusChannels;

    // figure out how many tags to allocate, checking every range before the
    // tags are reserved from the counts
    int64 numcontrols = 0;
    int numheads = msg.remain() >> 3;

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);
        if (start < 0 || end >= maxIndex || start > end)
            return kSCErr_IndexOutOfRange;
        numcontrols += n;
    }
    if (numcontrols > INT32_MAX / 2)
        return kSCErr_Failed;

    big_scpacket packet;
    packet.adds("/c_setn");
    packet.maketags(numheads * 2 + (int)numcontrols + 1);
    packet.addtag(',');

    // start over at beginning of message
    msg.init(inSize, inData);

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);

        if (start < 0 || end >= maxIndex || start > end)
            return kSCErr_IndexOutOfRange;

        packet.addtag('i');
        packet.addtag('i');
        packet.addi(start);
        packet.addi(n);

        for (int i = start; i <= end; ++i) {
            packet.addtag('f');
            packet.addf(data[i]);
        }
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}


SCErr meth_c_fill(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);

    float* data = inWorld->mControlBus;
    int32* touched = inWorld->mControlBusTouched;
    int32 bufCounter = inWorld->mBufCounter;
    int maxIndex = inWorld->mNumControlBusChannels;

    while (msg.remain() >= 12) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        float32 value = msg.getf();
        int32 end = LastIndex(start, n);

        if (end < 0 || start >= maxIndex)
            continue;

        start = sc_clip(start, 0, maxIndex - 1);
        end = sc_clip(end, 0, maxIndex - 1);

        for (int i = start; i <= end; ++i) {
            data[i] = value;
            touched[i] = bufCounter;
        }
    }

    return kSCErr_None;
}


SCErr meth_b_get(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    int bufindex = msg.geti();
    SndBuf* buf = World_GetBuf(inWorld, bufindex);
    if (!buf)
        return kSCErr_Failed;

    float* data = buf->data;
    uint32 maxIndex = buf->samples;

    int numheads = msg.remain() >> 2;

    big_scpacket packet;
    packet.adds("/b_set");
    packet.maketags(numheads * 2 + 2);
    packet.addtag(',');
    packet.addtag('i');
    packet.addi(bufindex);

    while (msg.remain() >= 4) {
        uint32 index = msg.geti();
        if (index >= maxIndex)
            return kSCErr_IndexOutOfRange;
        packet.addtag('i');
        packet.addtag('f');
        packet.addi(index);
        packet.addf(data[index]);
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}

SCErr meth_b_getn(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    int bufindex = msg.geti();
    SndBuf* buf = World_GetBuf(inWorld, bufindex);
    if (!buf)
        return kSCErr_Failed;

    float* data = buf->data;
    int32 maxIndex = buf->samples;

    // figure out how many tags to allocate, checking every range before the
    // tags are reserved from the counts
    int64 numcontrols = 0;
    int numheads = msg.remain() >> 3;

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);
        if (start < 0 || end >= maxIndex || start > end)
            return kSCErr_IndexOutOfRange;
        numcontrols += n;
    }
    if (numcontrols > INT32_MAX / 2)
        return kSCErr_Failed;

    big_scpacket packet;
    packet.adds("/b_setn");
    packet.maketags(numheads * 2 + (int)numcontrols + 2);
    packet.addtag(',');

    // start over at beginning of message
    msg.init(inSize, inData);
    msg.geti(); // skip buf index

    packet.addtag('i');
    packet.addi(bufindex);

    while (msg.remain()) {
        int32 start = msg.geti();
        int32 n = msg.geti();
        int32 end = LastIndex(start, n);

        if (start < 0 || end >= maxIndex || start > end)
            return kSCErr_IndexOutOfRange;

        packet.addtag('i');
        packet.addtag('i');
        packet.addi(start);
        packet.addi(n);

        for (int i = start; i <= end; ++i) {
            packet.addtag('f');
            packet.addf(data[i]);
        }
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}


SCErr meth_s_get(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    Graph* graph = Msg_GetGraph(inWorld, msg);
    if (!graph)
        return kSCErr_NodeNotFound;

    int numheads = msg.tags ? strlen(msg.tags) - 1 : msg.remain() >> 2;

    big_scpacket packet;
    packet.adds("/n_set");
    packet.maketags(numheads * 2 + 2);
    packet.addtag(',');
    packet.addtag('i');
    packet.addi(graph->mNode.mID);

    while (msg.remain() >= 4) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            float32 value = 0.f;
            Graph_GetControl(graph, hash, name, 0, value);
            packet.addtag('s');
            packet.addtag('f');
            packet.adds((char*)name);
            packet.addf(value);
        } else {
            int32 index = msg.geti();
            float32 value = 0.f;
            Graph_GetControl(graph, index, value);
            packet.addtag('i');
            packet.addtag('f');
            packet.addi(index);
            packet.addf(value);
        }
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}

SCErr meth_s_getn(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);

    Graph* graph = Msg_GetGraph(inWorld, msg);
    if (!graph)
        return kSCErr_NodeNotFound;

    // figure out how many tags to allocate, checking every count against the
    // synth's controls before the tags are reserved from them
    const uint32 limit = GRAPHDEF(graph)->mNumControls;
    int64 numcontrols = 0;
    int numheads = msg.tags ? (msg.numTags - 1) >> 1 : msg.remain() >> 3;

    while (msg.remain()) {
        msg.geti(); // skip start
        int32 n = msg.geti();
        if (n < 0 || (uint32)n > limit)
            return kSCErr_IndexOutOfRange;
        numcontrols += n;
    }
    if (numcontrols > INT32_MAX / 2)
        return kSCErr_Failed;

    big_scpacket packet;
    packet.adds("/n_setn");
    packet.maketags(numheads * 2 + (int)numcontrols + 2);
    packet.addtag(',');

    // start over at beginning of message
    msg.init(inSize, inData);
    msg.geti(); // skip buf index

    packet.addtag('i');
    packet.addi(graph->mNode.mID);

    while (msg.remain()) {
        if (msg.nextTag('i') == 's') {
            int32* name = msg.gets4();
            int32 hash = Hash(name);
            int32 n = msg.geti();
            packet.addtag('s');
            packet.addtag('i');
            packet.adds((char*)name);
            packet.addi(n);
            for (int i = 0; i < n; ++i) {
                float32 value = 0.f;
                Graph_GetControl(graph, hash, name, i, value);
                packet.addtag('f');
                packet.addf(value);
            }
        } else {
            int32 index = msg.geti();
            int32 n = msg.geti();
            packet.addtag('i');
            packet.addtag('i');
            packet.addi(index);
            packet.addi(n);
            for (int i = 0; i < n; ++i) {
                float32 value = 0.f;
                Graph_GetControl(graph, index + i, value);
                packet.addtag('f');
                packet.addf(value);
            }
        }
    }

    if (packet.size()) {
        CallSequencedCommand(SendReplyCmd, inWorld, packet.size(), packet.data(), inReply);
    }

    return kSCErr_None;
}


SCErr meth_s_noid(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    sc_msg_iter msg(inSize, inData);
    while (msg.remain()) {
        Graph* graph = Msg_GetGraph(inWorld, msg);
        if (!graph)
            continue;

        Node_RemoveID(&graph->mNode);
    }

    return kSCErr_None;
}


SCErr meth_notify(World* inWorld, int inSize, const char* inData, ReplyAddress* inReply) {
    CallSequencedCommand(NotifyCmd, inWorld, inSize, inData, inReply);
    return kSCErr_None;
}

SCErr meth_error(World* inWorld, int inSize, const char* inData, ReplyAddress* /*inReply*/) {
    sc_msg_iter msg(inSize, inData);
    int mode = msg.geti();

    //	inWorld->mLocalErrorNotification = mode;
    //		// if non-zero, new state should be saved permanently
    //	if(mode) { inWorld->mErrorNotification = mode; };

    // -1 = bundle off, -2 = bundle on, 0 = permanent off, 1 = permanent on
    switch (mode) {
    case -1:
        inWorld->mLocalErrorNotification += 1;
        break;
    case -2:
        inWorld->mLocalErrorNotification -= 1;
        break;
    case 0:
        inWorld->mErrorNotification = 0;
        break;
    case 1:
        inWorld->mErrorNotification = 1;
    };
    return kSCErr_None;
}

#define NEW_COMMAND(name) NewCommand(#name, cmd_##name, meth_##name)

void initMiscCommands() {
    // nrt
    NEW_COMMAND(none);
    NEW_COMMAND(notify);
    NEW_COMMAND(status);
    NEW_COMMAND(quit);
    NEW_COMMAND(clearSched);
    NEW_COMMAND(version);
    NEW_COMMAND(rtMemoryStatus);

    NEW_COMMAND(d_recv);
#if defined(CLOCKWORK_GUEST) || !defined(SC_LEAN_TARGET)
    NEW_COMMAND(d_load);
    NEW_COMMAND(d_loadDir);
#endif
    NEW_COMMAND(d_freeAll);
    NEW_COMMAND(d_free);

    NEW_COMMAND(s_new);
    NEW_COMMAND(s_newargs);

    NEW_COMMAND(n_trace);
    NEW_COMMAND(n_free);
    NEW_COMMAND(n_run);

    NEW_COMMAND(u_cmd);
    NEW_COMMAND(cmd);

    // NEW_COMMAND(n_cmd);
    NEW_COMMAND(n_map);
    NEW_COMMAND(n_mapn);
    NEW_COMMAND(n_mapa);
    NEW_COMMAND(n_mapan);
    NEW_COMMAND(n_set);
    NEW_COMMAND(n_setn);
    NEW_COMMAND(n_fill);

    NEW_COMMAND(n_before);
    NEW_COMMAND(n_after);
    NEW_COMMAND(n_order);

    NEW_COMMAND(g_new);
    NEW_COMMAND(g_head);
    NEW_COMMAND(g_tail);
    NEW_COMMAND(g_freeAll);
    NEW_COMMAND(g_deepFree);

    NEW_COMMAND(p_new);

    NEW_COMMAND(b_alloc);
    NEW_COMMAND(b_allocRead);
    NEW_COMMAND(b_allocReadChannel);

    NEW_COMMAND(b_read);
    NEW_COMMAND(b_readChannel);
    NEW_COMMAND(b_write);

    NEW_COMMAND(b_free);
    NEW_COMMAND(b_close);

    NEW_COMMAND(b_zero);
    NEW_COMMAND(b_set);
    NEW_COMMAND(b_setn);
    // =============================================================================
    // TAU: /b_setSampleRate intentionally not implemented
    // In WebAudio, the sample rate is fixed by the AudioContext, so all buffers
    // already have the correct sample rate. Setting buffer sample rate metadata
    // would have no useful effect in our context.
    // =============================================================================
    NEW_COMMAND(b_fill);
    NEW_COMMAND(b_gen);

    // The guest's own verbs, implemented beside the guest (piano_wavetable.cpp).
    NewCommand("supersonic/piano/wavetable", cmd_supersonic_piano_wavetable, supersonic_meth_piano_wavetable);
    NewCommand("supersonic/buffer/read", cmd_supersonic_buffer_read, meth_supersonic_buffer_read);
    NewCommand("supersonic/buffer/publish", cmd_supersonic_buffer_publish, meth_supersonic_buffer_publish);

    NEW_COMMAND(c_set);
    NEW_COMMAND(c_setn);
    NEW_COMMAND(c_fill);

    NEW_COMMAND(dumpOSC);

    NEW_COMMAND(c_get);
    NEW_COMMAND(c_getn);
    NEW_COMMAND(b_get);
    NEW_COMMAND(b_getn);
    NEW_COMMAND(s_get);
    NEW_COMMAND(s_getn);

    NEW_COMMAND(n_query);
    NEW_COMMAND(b_query);

    NEW_COMMAND(s_noid);
    NEW_COMMAND(sync);
    NEW_COMMAND(g_dumpTree);
    NEW_COMMAND(g_queryTree);

    NEW_COMMAND(error);
}
