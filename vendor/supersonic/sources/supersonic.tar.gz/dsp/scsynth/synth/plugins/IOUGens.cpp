/*
    SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
    http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


#include "SC_PlugIn.h"

#ifdef SC_IPHONE
#    include "SC_VFP11.h"
#endif

#ifdef SUPERNOVA
#    include "nova-tt/spin_lock.hpp"
#    include "nova-tt/rw_spinlock.hpp"
#endif

#ifdef NOVA_SIMD
#    include "simd_memory.hpp"
#    include "simd_mix.hpp"
#    include "simd_binary_arithmetic.hpp"

#    include "function_attributes.h"
using nova::slope_argument;

#endif


static const InterfaceTable* const ft = &gInterfaceTable;   // SuperSonic (plural guest): the one constant table

//////////////////////////////////////////////////////////////////////////////////////////////////

struct Control : Unit {};

struct AudioControl : Unit {
    float* m_prevVal;
    float* m_prevBus;
    bool* m_busUsedInPrevCycle;
    int32* m_busTouchedCache; // for reblocking
};

struct TrigControl : Unit {};

struct LagControl : Unit {
    float* m_b1;
    float* m_y1;
};

struct IOUnit : public Unit {
    int32* m_busTouched;
    float* m_bus;
    float m_fbusChannel;
};

struct InTrig : IOUnit {};

struct In : IOUnit {
    int32* m_busTouchedCache; // for reblocking
};

struct InFeedback : public In {
    static constexpr int smallVecSize = 8;

    bool* m_busUsedInPrevCycle;
    // for small vector optimization, see InFeedback_Ctor()
    bool m_smallVec[smallVecSize];
};

const int kMaxLags = 16;

struct LagIn : public IOUnit {
    float m_b1;
    float m_y1[kMaxLags];
};

struct Out : IOUnit {};

struct XOut : public IOUnit {
    float m_xfade;
};

struct ReplaceOut : IOUnit {};

struct OffsetOut : public IOUnit {
    float* m_saved;
    // QUESTION: why don't we just zero the save buffer in
    // OffsetOut_Ctor instead of checking 'm_empty'?
    bool m_empty;
};

struct LocalIn : public Unit {
    float* m_bus;
    // IMPORTANT: use a 64-bit counter to prevent
    // overflow in case we need to reblock/resample!
    int64* m_busTouched;
    float* m_realData;
};

struct LocalOut : Unit {
    float* m_bus;
    // IMPORTANT: use a 64-bit counter to prevent
    // overflow in case we need to reblock/resample!
    int64* m_busTouched;
};

struct SharedOut : Unit {
    float* m_bus;
    float m_fbusChannel;
};

struct SharedIn : Unit {
    float* m_bus;
    float m_fbusChannel;
};

extern "C" {
void Control_Ctor(Control* inUnit);
void Control_next_k(Control* unit, int inNumSamples);
void Control_next_1(Control* unit, int inNumSamples);

void AudioControl_Ctor(AudioControl* inUnit);
void AudioControl_Dtor(AudioControl* inUnit);
void AudioControl_next_a_reblock(AudioControl* unit, int inNumSamples);
void AudioControl_next_a(AudioControl* unit, int inNumSamples);
void AudioControl_next_1(AudioControl* unit, int inNumSamples);

void TrigControl_Ctor(TrigControl* inUnit);
void TrigControl_next_k(TrigControl* unit, int inNumSamples);
void TrigControl_next_1(TrigControl* unit, int inNumSamples);

void LagControl_Ctor(LagControl* inUnit);
void LagControl_Dtor(LagControl* inUnit);
void LagControl_next_k(LagControl* unit, int inNumSamples);
void LagControl_next_k_reblock(LagControl* unit, int inNumSamples);
void LagControl_next_1(LagControl* unit, int inNumSamples);
void LagControl_next_1_reblock(LagControl* unit, int inNumSamples);

void In_Ctor(In* unit);
void In_Dtor(In* unit);
void In_next_a_reblock(In* unit, int inNumSamples);
void In_next_a(In* unit, int inNumSamples);
void In_next_k(In* unit, int inNumSamples);

void LagIn_Ctor(LagIn* unit);
void LagIn_next_0(LagIn* unit, int inNumSamples);
void LagIn_next_k(LagIn* unit, int inNumSamples);
void LagIn_next_k_reblock(LagIn* unit, int inNumSamples);

void InFeedback_Ctor(InFeedback* unit);
void InFeedback_Dtor(InFeedback* unit);
void InFeedback_next_a_reblock(InFeedback* unit, int inNumSamples);
void InFeedback_next_a(InFeedback* unit, int inNumSamples);

void InTrig_Ctor(InTrig* unit);
void InTrig_next_k_reblock(InTrig* unit, int inNumSamples);
void InTrig_next_k(InTrig* unit, int inNumSamples);

void ReplaceOut_Ctor(ReplaceOut* unit);
void ReplaceOut_next_a_reblock(ReplaceOut* unit, int inNumSamples);
void ReplaceOut_next_a(ReplaceOut* unit, int inNumSamples);
void ReplaceOut_next_k_reblock(ReplaceOut* unit, int inNumSamples);
void ReplaceOut_next_k(ReplaceOut* unit, int inNumSamples);

void Out_Ctor(Out* unit);
void Out_next_a_reblock(Out* unit, int inNumSamples);
void Out_next_a(Out* unit, int inNumSamples);
void Out_next_k_reblock(Out* unit, int inNumSamples);
void Out_next_k(Out* unit, int inNumSamples);

void XOut_Ctor(XOut* unit);
void XOut_next_a_reblock(XOut* unit, int inNumSamples);
void XOut_next_a(XOut* unit, int inNumSamples);
void XOut_next_k_reblock(XOut* unit, int inNumSamples);
void XOut_next_k(XOut* unit, int inNumSamples);

void OffsetOut_Ctor(OffsetOut* unit);
void OffsetOut_Dtor(OffsetOut* unit);
void OffsetOut_next_a_reblock(OffsetOut* unit, int inNumSamples);
void OffsetOut_next_a(OffsetOut* unit, int inNumSamples);

void SharedIn_Ctor(SharedIn* unit);
void SharedIn_next_k(SharedIn* unit, int inNumSamples);

void SharedOut_Ctor(SharedOut* unit);
void SharedOut_next_k(SharedOut* unit, int inNumSamples);

void LocalIn_Ctor(LocalIn* unit);
void LocalIn_Dtor(LocalIn* unit);
void LocalIn_next_a_reblock(LocalIn* unit, int inNumSamples);
void LocalIn_next_a(LocalIn* unit, int inNumSamples);
void LocalIn_next_k_reblock(LocalIn* unit, int inNumSamples);
void LocalIn_next_k(LocalIn* unit, int inNumSamples);

void LocalOut_Ctor(LocalOut* unit);
void LocalOut_next_a_reblock(LocalOut* unit, int inNumSamples);
void LocalOut_next_a(LocalOut* unit, int inNumSamples);
void LocalOut_next_k_reblock(LocalOut* unit, int inNumSamples);
void LocalOut_next_k(LocalOut* unit, int inNumSamples);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

// This RAII helper class is like std::lock_guard, but for audio busses.
// If LockShared is true, the bus is locked for read access, otherwise
// it is locked for write access. In addition, the constructor checks
// whether the given bus number is indeed valid.
template <bool LockShared> struct AudioBusGuard {
    // The channel is a bus control plus an offset, as a float: any value a
    // control can hold is either a valid channel or refused.
    AudioBusGuard(const Unit* unit, float currentChannel, int32 maxChannel):
        unit(unit),
        mCurrentChannel(sc_float_to_int32(currentChannel)),
        mIsValid(currentChannel >= 0.f && currentChannel < (float)maxChannel) {
        if (mIsValid)
            lock();
    }

    ~AudioBusGuard() {
        if (mIsValid)
            unlock();
    }

    bool isValid() const { return mIsValid; }

private:
    void lock() {
        if (LockShared)
            ACQUIRE_BUS_AUDIO_SHARED(mCurrentChannel);
        else
            ACQUIRE_BUS_AUDIO(mCurrentChannel);
    }

    void unlock() {
        if (LockShared)
            RELEASE_BUS_AUDIO_SHARED(mCurrentChannel);
        else
            RELEASE_BUS_AUDIO(mCurrentChannel);
    }


    const Unit* unit; // for macros
    const int32 mCurrentChannel;
    const bool mIsValid;
};

static inline float readControlBus(const float* bus, int64 channelIndex, int maxChannel) {
    if (channelIndex < maxChannel) {
        return *bus;
    } else {
        return 0;
    }
}

// Update the relevant IOUnit instance members if the audio bus number has changed
static inline void IO_a_update_channels(IOUnit* unit, const World* world, float fbusChannel, int numChannels,
                                        int bufLength) {
    if (fbusChannel != unit->m_fbusChannel) {
        unit->m_fbusChannel = fbusChannel;
        const int64 busChannel = sc_float_to_int32(fbusChannel);
        const int64 lastChannel = busChannel + numChannels;

        if (!(busChannel < 0 || lastChannel > (int64)world->mNumAudioBusChannels)) {
            unit->m_bus = world->mAudioBus + (busChannel * bufLength);
            unit->m_busTouched = world->mAudioBusTouched + busChannel;
        }
    }
}

// Update the relevant IOUnit instance members if the control bus number has changed.
// As a small optimization, UpdateTouched tells whether we actually need to
// update the m_busTouched member.
template <bool UpdateTouched>
static inline void IO_k_update_channels(IOUnit* unit, const World* world, float fbusChannel, int numChannels) {
    if (fbusChannel != unit->m_fbusChannel) {
        unit->m_fbusChannel = fbusChannel;
        const int64 busChannel = sc_float_to_int32(fbusChannel);
        const int64 lastChannel = busChannel + numChannels;

        if (!(busChannel < 0 || lastChannel > (int64)world->mNumControlBusChannels)) {
            unit->m_bus = world->mControlBus + busChannel;
            if (UpdateTouched)
                unit->m_busTouched = world->mControlBusTouched + busChannel;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void Control_next_k(Control* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    for (uint32 i = 0; i < numChannels; ++i) {
        OUT0(i) = mapin[i][0];
    }
}

void Control_next_1(Control* unit, int inNumSamples) {
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    OUT0(0) = mapin[0][0];
}

// A control unit reads `count` of the synth's controls from mSpecialIndex on,
// and the SynthDef gives both.
static bool controlsInRange(const Unit* unit, uint32 count) {
    return unit->mSpecialIndex >= 0 && (uint32)unit->mSpecialIndex + count <= unit->mParent->mNumControls;
}

void Control_Ctor(Control* unit) {
    ClearUnitIfMissing(controlsInRange(unit, unit->mNumOutputs), "controls");
    // There is no need for dedicated reblocking calc functions.
    if (unit->mNumOutputs == 1) {
        SETCALC(Control_next_1);
        Control_next_1(unit, 1);
    } else {
        SETCALC(Control_next_k);
        Control_next_k(unit, 1);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////

// This is the reblocking version of AudioControl_next_channel().
inline void AudioControl_next_channel_reblock(AudioControl* unit, int i, float* mapin, int mapRate, double resample,
                                              int inNumSamples) {
    float* out = OUT(i);

    switch (mapRate) {
    case calc_ScalarRate: {
        for (int j = 0; j < inNumSamples; j++) {
            out[j] = mapin[0];
        }
    } break;
    case calc_BufRate: {
        float nextVal = mapin[0];
        float curVal = unit->m_prevVal[i];
        const int32 tick = unit->mParent->mTickCounter;
        const int32 numTicks = unit->mParent->mNumTicks;
        // Output the slope segment for the current tick.
        // In the case of upsampling, the slope values will be sampled with zero-order-hold,
        // just like regular audio signals. This means that we must use the *global* slope factor!
        float valSlope = (nextVal - curVal) * unit->mWorld->mFullRate.mSlopeFactor;
        int offset = tick * inNumSamples;
        for (int j = 0; j < inNumSamples; j++) {
            int index = sc_float_to_int32((offset + j) * resample);
            out[j] = curVal + valSlope * index;
        }
        // only update on last tick
        if (tick == numTicks - 1)
            unit->m_prevVal[i] = nextVal;
    } break;
    case calc_FullRate: {
        // see comment in AudioControl_next_channel()
        World* world = unit->mWorld;
        const int32 tick = unit->mParent->mTickCounter;
        const int32 numTicks = unit->mParent->mNumTicks;
        int32* channelOffsets = unit->mParent->mAudioBusOffsets;
        int thisChannelOffset = channelOffsets[unit->mSpecialIndex + i];
        if (thisChannelOffset >= 0) {
            int offset = sc_float_to_int32(tick * inNumSamples * resample);
            float* in = mapin + offset;

            AudioBusGuard<true> guard(unit, thisChannelOffset, world->mNumAudioBusChannels);

            // cache current bus touching values on first tick
            if (tick == 0) {
                unit->m_busTouchedCache[i] = world->mAudioBusTouched[thisChannelOffset];
            }

            int diff = world->mBufCounter - unit->m_busTouchedCache[i];

            if (guard.isValid() && diff == 0) {
                // copy with reblocking/resampling
                for (int i = 0; i < inNumSamples; ++i) {
                    int index = sc_float_to_int32(i * resample);
                    out[i] = in[index];
                }
                unit->m_busUsedInPrevCycle[i] = true;
            } else if (guard.isValid() && diff == 1) {
                if (unit->m_busUsedInPrevCycle[i]) {
                    Clear(inNumSamples, out);
                    // only update on last tick!!
                    if (tick == numTicks - 1)
                        unit->m_busUsedInPrevCycle[i] = false;
                } else {
                    // copy with reblocking/resampling
                    for (int i = 0; i < inNumSamples; ++i) {
                        int index = sc_float_to_int32(i * resample);
                        out[i] = in[index];
                    }
                }
            } else {
                Clear(inNumSamples, out);
                unit->m_busUsedInPrevCycle[i] = false;
            }
        } else {
            Clear(inNumSamples, out);
            unit->m_busUsedInPrevCycle[i] = false;
        }
    } break;
    }
}

void AudioControl_next_a_reblock(AudioControl* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    int* mapRates = unit->mParent->mControlRates + unit->mSpecialIndex;

    if (mapin[0] != unit->m_prevBus) {
        for (uint32 i = 0; i < numChannels; ++i) {
            unit->m_busUsedInPrevCycle[i] = false;
        }
        unit->m_prevBus = mapin[0];
    }

    double resample = unit->mWorld->mSampleRate / SAMPLERATE;

    for (uint32 i = 0; i < numChannels; ++i) {
        AudioControl_next_channel_reblock(unit, i, mapin[i], mapRates[i], resample, inNumSamples);
    }
}

// This is a helper function that processes a single channel of an AudioControl.
// It is called by AudioControl_next_k() and AudioControl_next_1().
inline void AudioControl_next_channel(AudioControl* unit, int i, float* mapin, int mapRate, int inNumSamples) {
    float* out = OUT(i);

    switch (mapRate) {
    case calc_ScalarRate: {
        for (int j = 0; j < inNumSamples; j++) {
            out[j] = mapin[0];
        }
    } break;
    case calc_BufRate: {
        float nextVal = mapin[0];
        float curVal = unit->m_prevVal[i];
        float valSlope = CALCSLOPE(nextVal, curVal);
        for (int j = 0; j < inNumSamples; j++) {
            out[j] = curVal; // should be prevVal
            curVal += valSlope;
        }
        unit->m_prevVal[i] = curVal;
    } break;
    case calc_FullRate: {
        /*
            the graph / unit stores which controls (based on special index) are mapped
            to which audio buses. This is needed to access the touched values for when
            an audio bus has been written to last. mBufCounter is the current value for the
            control period (basically, the number of control periods that have elapsed
            since the server started). We check the touched value for the mapped audio
            bus to see if it has been written to in the current control period or the
            previous control period (to enable an InFeedback type of mapping)...
        */
        World* world = unit->mWorld;
        int32* channelOffsets = unit->mParent->mAudioBusOffsets;
        int thisChannelOffset = channelOffsets[unit->mSpecialIndex + i];
        if (thisChannelOffset >= 0) {
            AudioBusGuard<true> guard(unit, thisChannelOffset, world->mNumAudioBusChannels);

            int diff = world->mBufCounter - world->mAudioBusTouched[thisChannelOffset];

            if (guard.isValid() && diff == 0) {
                Copy(inNumSamples, out, mapin);
                unit->m_busUsedInPrevCycle[i] = true;
            } else if (guard.isValid() && diff == 1) {
                if (unit->m_busUsedInPrevCycle[i]) {
                    Clear(inNumSamples, out);
                    unit->m_busUsedInPrevCycle[i] = false;
                } else {
                    Copy(inNumSamples, out, mapin);
                }
            } else {
                Clear(inNumSamples, out);
                unit->m_busUsedInPrevCycle[i] = false;
            }
        } else {
            Clear(inNumSamples, out);
            unit->m_busUsedInPrevCycle[i] = false;
        }
    } break;
    }
}

void AudioControl_next_a(AudioControl* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    int* mapRates = unit->mParent->mControlRates + unit->mSpecialIndex;

    if (mapin[0] != unit->m_prevBus) {
        for (uint32 i = 0; i < numChannels; ++i) {
            unit->m_busUsedInPrevCycle[i] = false;
        }
        unit->m_prevBus = mapin[0];
    }

    for (uint32 i = 0; i < numChannels; ++i) {
        AudioControl_next_channel(unit, i, mapin[i], mapRates[i], inNumSamples);
    }
}

void AudioControl_next_1(AudioControl* unit, int inNumSamples) {
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    int* mapRates = unit->mParent->mControlRates + unit->mSpecialIndex;

    if (*mapin != unit->m_prevBus) {
        unit->m_busUsedInPrevCycle[0] = false;
        unit->m_prevBus = *mapin;
    }

    AudioControl_next_channel(unit, 0, mapin[0], mapRates[0], inNumSamples);
}

void AudioControl_Ctor(AudioControl* unit) {
    unit->m_prevVal = nullptr;
    ClearUnitIfMissing(controlsInRange(unit, unit->mNumOutputs), "controls");
    World* world = unit->mWorld;
    float** mapControls = unit->mParent->mMapControls + unit->mSpecialIndex;
    int numChannels = unit->mNumOutputs;

    unit->m_prevBus = nullptr;
    unit->m_prevVal = nullptr;

    // We allocate the m_prevVal, m_busTouchedCache and m_busUsedinPrevCycle arrays
    // as a single memory chunk to reduce pressure on the RT memory allocator.
    // Note that we start with the float and int32 arrays to ensure proper alignment.
    // m_prevVal points to the start of the chunk and thus owns the memory, so we
    // have to pass it RTFree() in AudioControl_Dtor().
    if (REBLOCK_OR_RESAMPLE) {
        size_t memSize = numChannels * (sizeof(float) + sizeof(int32) + sizeof(bool));
        char* mem = (char*)RTAlloc(world, memSize);
        ClearUnitIfMemFailed(mem);

        unit->m_prevVal = (float*)mem; // see AudioControl_Dtor()!
        mem += numChannels * sizeof(float);
        for (int i = 0; i < numChannels; ++i) {
            unit->m_prevVal[i] = mapControls[i][0];
        }

        unit->m_busTouchedCache = (int32*)mem;
        mem += numChannels * sizeof(int32);
        std::fill_n(unit->m_busTouchedCache, numChannels, -1);

        unit->m_busUsedInPrevCycle = (bool*)mem;
        std::fill_n(unit->m_busUsedInPrevCycle, numChannels, false);

        SETCALC(AudioControl_next_a_reblock);
        AudioControl_next_a_reblock(unit, 1);
    } else {
        size_t memSize = numChannels * (sizeof(float) + sizeof(bool));
        char* mem = (char*)RTAlloc(world, memSize);
        ClearUnitIfMemFailed(mem);

        unit->m_prevVal = (float*)mem; // see AudioControl_Dtor()!
        mem += numChannels * sizeof(float);
        for (int i = 0; i < numChannels; ++i) {
            unit->m_prevVal[i] = mapControls[i][0];
        }

        unit->m_busUsedInPrevCycle = (bool*)mem;
        std::fill_n(unit->m_busUsedInPrevCycle, numChannels, false);

        unit->m_busTouchedCache = nullptr;

        if (unit->mNumOutputs == 1) {
            SETCALC(AudioControl_next_1);
            AudioControl_next_1(unit, 1);
        } else {
            SETCALC(AudioControl_next_a);
            AudioControl_next_a(unit, 1);
        }
    }
}

void AudioControl_Dtor(AudioControl* unit) {
    // see AudioControl_Ctor()!
    RTFree(unit->mWorld, unit->m_prevVal);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void TrigControl_next_k(TrigControl* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    int specialIndex = unit->mSpecialIndex;
    Graph* parent = unit->mParent;
    float** mapin = parent->mMapControls + specialIndex;
    float* control = parent->mControls + specialIndex;
    for (uint32 i = 0; i < numChannels; ++i) {
        OUT0(i) = mapin[i][0];
        // must zero the control even if mapped - otherwise it triggers on unmap
        control[i] = 0.f;
    }
}

void TrigControl_next_1(TrigControl* unit, int inNumSamples) {
    int specialIndex = unit->mSpecialIndex;
    Graph* parent = unit->mParent;
    float** mapin = parent->mMapControls + specialIndex;
    float* control = parent->mControls + specialIndex;
    OUT0(0) = mapin[0][0];
    // must zero the control even if mapped - otherwise it triggers on unmap
    control[0] = 0.f;
}

void TrigControl_Ctor(TrigControl* unit) {
    ClearUnitIfMissing(controlsInRange(unit, unit->mNumOutputs), "controls");
    // There is no need for dedicated reblocking calc functions.
    if (unit->mNumOutputs == 1) {
        SETCALC(TrigControl_next_1);
    } else {
        SETCALC(TrigControl_next_k);
    }
    ClearUnitOutputs(unit, 1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void LagControl_next_k(LagControl* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    for (uint32 i = 0; i < numChannels; ++i) {
        float z = mapin[i][0];
        float x = z + unit->m_b1[i] * (unit->m_y1[i] - z);
        OUT0(i) = unit->m_y1[i] = zapgremlins(x);
    }
}

void LagControl_next_k_reblock(LagControl* unit, int inNumSamples) {
    // only compute the lagged value on the first tick!
    if (unit->mParent->mTickCounter == 0) {
        LagControl_next_k(unit, inNumSamples);
    } else {
        for (int i = 0; i < unit->mNumOutputs; ++i) {
            OUT0(i) = unit->m_y1[i];
        }
    }
}

void LagControl_next_1(LagControl* unit, int inNumSamples) {
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;
    float z = mapin[0][0];
    float x = z + unit->m_b1[0] * (unit->m_y1[0] - z);
    OUT0(0) = unit->m_y1[0] = zapgremlins(x);
}

void LagControl_next_1_reblock(LagControl* unit, int inNumSamples) {
    // only compute the lagged value on the first tick!
    if (unit->mParent->mTickCounter == 0) {
        LagControl_next_k(unit, inNumSamples);
    } else {
        OUT0(0) = unit->m_y1[0];
    }
}

void LagControl_Ctor(LagControl* unit) {
    unit->m_y1 = nullptr;
    // One lag time in, and one control read and one value out, per channel.
    ClearUnitIfMissing(unit->mNumInputs == unit->mNumOutputs && controlsInRange(unit, unit->mNumInputs), "controls");
    int numChannels = unit->mNumInputs;
    float** mapin = unit->mParent->mMapControls + unit->mSpecialIndex;

    float* chunk = (float*)RTAlloc(unit->mWorld, numChannels * 2 * sizeof(float));
    ClearUnitIfMemFailed(chunk);
    unit->m_y1 = chunk;
    unit->m_b1 = chunk + numChannels;

    // NOTE: we only compute the lagged value once per control block, which means
    // that the coefficient must be computed from the *global* sample rate!
    double sr = unit->mWorld->mBufRate.mSampleRate;
    for (int i = 0; i < numChannels; ++i) {
        unit->m_y1[i] = mapin[i][0];
        float lag = IN0(i);
        unit->m_b1[i] = lag == 0.f ? 0.f : (float)exp(log001 / (lag * sr));
    }

    if (unit->mNumOutputs == 1) {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LagControl_next_1_reblock);
        else
            SETCALC(LagControl_next_1);
        LagControl_next_1(unit, 1);
    } else {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LagControl_next_k_reblock);
        else
            SETCALC(LagControl_next_k);
        LagControl_next_k(unit, 1);
    }
}

void LagControl_Dtor(LagControl* unit) { RTFree(unit->mWorld, unit->m_y1); }

//////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef NOVA_SIMD
FLATTEN void In_next_a_nova(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        float* out = OUT(i);

        if (guard.isValid() && (touched[i] == bufCounter))
            nova::copyvec_simd(out, in, inNumSamples);
        else
            nova::zerovec_simd(out, inNumSamples);
    }
}

FLATTEN void In_next_a_nova_64(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        float* out = OUT(i);
        if (guard.isValid() && (touched[i] == bufCounter))
            nova::copyvec_simd<64>(out, in);
        else
            nova::zerovec_simd<64>(out);
    }
}

#endif

void In_next_a(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        float* out = OUT(i);
        if (guard.isValid() && (touched[i] == bufCounter))
            Copy(inNumSamples, out, in);
        else
            Clear(inNumSamples, out);
    }
}

void In_next_a_reblock(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    double resample = world->mSampleRate / SAMPLERATE;
    int offset = sc_float_to_int32(unit->mParent->mTickCounter * inNumSamples * resample);
    float* in = unit->m_bus + offset;
    int32* touched = unit->m_busTouchedCache;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;
    const bool firstTick = unit->mParent->mTickCounter == 0;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        // cache current bus touching values on the first graph tick!
        if (firstTick) {
            touched[i] = unit->m_busTouched[i];
        }

        float* out = OUT(i);
        if (guard.isValid() && (touched[i] == bufCounter)) {
            // copy with reblocking/resampling
            for (int j = 0; j < inNumSamples; ++j) {
                int index = sc_float_to_int32(j * resample);
                out[j] = in[index];
            }
        } else {
            Clear(inNumSamples, out);
        }
    }
}

#ifdef IPHONE_VEC
void vIn_next_a(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        float* out = OUT(i);
        if (guard.isValid() && (touched[i] == bufCounter))
            vcopy(out, in, inNumSamples);
        else
            vfill(out, 0.f, inNumSamples);
    }
}
#endif

void In_next_k(In* unit, int inNumSamples) {
    World* world = unit->mWorld;
    uint32 numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<false>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    const float* bus = unit->m_bus;
    for (uint32 i = 0; i < numChannels; ++i) {
        ACQUIRE_BUS_CONTROL(firstOutputChannel + i);
        OUT0(i) = readControlBus(bus + i, firstOutputChannel + i, maxChannel);
        RELEASE_BUS_CONTROL(firstOutputChannel + i);
    }
}

void In_Ctor(In* unit) {
    // Print("->In_Ctor\n");
    World* world = unit->mWorld;
    unit->m_fbusChannel = std::numeric_limits<float>::quiet_NaN();
    unit->m_busTouchedCache = nullptr;

    if (unit->mCalcRate == calc_FullRate) {
        if (REBLOCK_OR_RESAMPLE) {
            int numChannels = unit->mNumOutputs;
            unit->m_busTouchedCache = (int32*)RTAlloc(world, numChannels * sizeof(int32));
            ClearUnitIfMemFailed(unit->m_busTouchedCache);
            std::fill_n(unit->m_busTouchedCache, numChannels, -1);

            SETCALC(In_next_a_reblock);
        }
#ifdef NOVA_SIMD
        else if (BUFLENGTH == 64)
            SETCALC(In_next_a_nova_64);
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(In_next_a_nova);
#endif
        else
            SETCALC(In_next_a);
        unit->m_bus = world->mAudioBus;
        unit->m_busTouched = world->mAudioBusTouched;
        In_next_a(unit, 1);
    } else {
        // There is no need for a dedicated reblocking calc function.
        SETCALC(In_next_k);
        unit->m_bus = world->mControlBus;
        // unit->m_busTouched = world->mControlBusTouched;
        In_next_k(unit, 1);
    }
    // Print("<-In_Ctor\n");
}

void In_Dtor(In* unit) { RTFree(unit->mWorld, unit->m_busTouchedCache); }

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

void LagIn_next_k(LagIn* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<false>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    const float* bus = unit->m_bus;
    float b1 = unit->m_b1;
    float* y1 = unit->m_y1;

    for (int i = 0; i < numChannels; ++i) {
        if (i < kMaxLags) {
            ACQUIRE_BUS_CONTROL(firstOutputChannel + i);
            float z = readControlBus(bus + i, firstOutputChannel + i, maxChannel);
            RELEASE_BUS_CONTROL(firstOutputChannel + i);
            float x = z + b1 * (y1[i] - z);
            OUT0(i) = y1[i] = zapgremlins(x);
        } else {
            OUT0(i) = 0.0;
        }
    }
}

void LagIn_next_k_reblock(LagIn* unit, int inNumSamples) {
    // only compute the lagged value on the first tick!
    if (unit->mParent->mTickCounter == 0) {
        LagIn_next_k(unit, inNumSamples);
    } else {
        for (int i = 0; i < unit->mNumOutputs; ++i) {
            if (i < kMaxLags) {
                OUT0(i) = unit->m_y1[i];
            } else {
                OUT0(i) = 0.0;
            }
        }
    }
}

void LagIn_next_0(LagIn* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<false>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    const float* bus = unit->m_bus;
    float* y1 = unit->m_y1;
    for (int i = 0; i < numChannels; ++i) {
        if (i < kMaxLags) {
            ACQUIRE_BUS_CONTROL(firstOutputChannel + i);
            OUT0(i) = y1[i] = readControlBus(bus + i, firstOutputChannel + i, maxChannel);
            RELEASE_BUS_CONTROL(firstOutputChannel + i);
        } else {
            OUT0(i) = 0.0;
        }
    }
}

void LagIn_Ctor(LagIn* unit) {
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    float lag = ZIN0(1);
    // NOTE: we only compute the lagged value once per control block, which means
    // that the coefficient must be computed from the *global* sample rate!
    double sr = world->mBufRate.mSampleRate;
    unit->m_b1 = lag == 0.f ? 0.f : (float)exp(log001 / (lag * sr));
    if (REBLOCK_OR_RESAMPLE)
        SETCALC(LagIn_next_k_reblock);
    else
        SETCALC(LagIn_next_k);
    unit->m_bus = world->mControlBus;
    LagIn_next_0(unit, 1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void InFeedback_next_a_reblock(InFeedback* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    if (fbusChannel != unit->m_fbusChannel) {
        std::fill_n(unit->m_busUsedInPrevCycle, numChannels, false);
    }
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    double resample = world->mSampleRate / SAMPLERATE;
    const int32 tick = unit->mParent->mTickCounter;
    const int32 numTicks = unit->mParent->mNumTicks;
    const int offset = sc_float_to_int32(tick * inNumSamples * resample);
    float* in = unit->m_bus + offset;
    int32* touched = unit->m_busTouchedCache;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        float* out = OUT(i);

        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        // cache current bus touching values on the first graph tick!
        if (tick == 0) {
            touched[i] = unit->m_busTouched[i];
        }
        int diff = bufCounter - touched[i];

        if (guard.isValid() && diff == 0) {
            // copy with reblocking/resampling
            for (int j = 0; j < inNumSamples; ++j) {
                int index = sc_float_to_int32(j * resample);
                out[j] = in[index];
            }
            unit->m_busUsedInPrevCycle[i] = true;
        } else if (guard.isValid() && diff == 1) {
            if (unit->m_busUsedInPrevCycle[i]) {
                Clear(inNumSamples, out);
                // only update on last tick!!
                if (tick == numTicks - 1)
                    unit->m_busUsedInPrevCycle[i] = false;
            } else {
                // copy with reblocking/resampling
                for (int j = 0; j < inNumSamples; ++j) {
                    int index = sc_float_to_int32(j * resample);
                    out[j] = in[index];
                }
            }
        } else {
            Clear(inNumSamples, out);
            unit->m_busUsedInPrevCycle[i] = false;
        }
    }
}

void InFeedback_next_a(InFeedback* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    if (fbusChannel != unit->m_fbusChannel) {
        std::fill_n(unit->m_busUsedInPrevCycle, numChannels, false);
    }
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        AudioBusGuard<true> guard(unit, fbusChannel + i, maxChannel);

        float* out = OUT(i);
        int diff = bufCounter - touched[i];

        if (guard.isValid() && diff == 0) {
            Copy(inNumSamples, out, in);
            unit->m_busUsedInPrevCycle[i] = true;
        } else if (guard.isValid() && diff == 1) {
            if (unit->m_busUsedInPrevCycle[i]) {
                Clear(inNumSamples, out);
                unit->m_busUsedInPrevCycle[i] = false;
            } else
                Copy(inNumSamples, out, in);
        } else {
            Clear(inNumSamples, out);
            unit->m_busUsedInPrevCycle[i] = false;
        }
    }
}

void InFeedback_Ctor(InFeedback* unit) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumOutputs;

    unit->m_fbusChannel = -1.;
    unit->m_bus = world->mAudioBus;
    unit->m_busTouched = world->mAudioBusTouched;
    unit->m_busTouchedCache = nullptr;

    if (numChannels > InFeedback::smallVecSize) {
        unit->m_busUsedInPrevCycle = (bool*)RTAlloc(world, numChannels * sizeof(bool));
        ClearUnitIfMemFailed(unit->m_busUsedInPrevCycle);
    } else {
        // small vector optimization
        unit->m_busUsedInPrevCycle = unit->m_smallVec;
    }

    std::fill_n(unit->m_busUsedInPrevCycle, numChannels, false);

    if (REBLOCK_OR_RESAMPLE) {
        unit->m_busTouchedCache = (int32*)RTAlloc(world, numChannels * sizeof(int32));
        ClearUnitIfMemFailed(unit->m_busTouchedCache);
        std::fill_n(unit->m_busTouchedCache, numChannels, -1);

        SETCALC(InFeedback_next_a_reblock);
        InFeedback_next_a_reblock(unit, 1);
    } else {
        SETCALC(InFeedback_next_a);
        InFeedback_next_a(unit, 1);
    }
}

void InFeedback_Dtor(InFeedback* unit) {
    // small vector optimization, see InFeedback_Ctor()
    if (unit->m_busUsedInPrevCycle != unit->m_smallVec)
        RTFree(unit->mWorld, unit->m_busUsedInPrevCycle);
    RTFree(unit->mWorld, unit->m_busTouchedCache);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void InTrig_next_k(InTrig* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<true>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    const float* in = unit->m_bus;
    int32* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;

    for (int i = 0; i < numChannels; ++i, in++) {
        ACQUIRE_BUS_CONTROL(firstOutputChannel + i);
        if (touched[i] == bufCounter)
            OUT0(i) = readControlBus(in, firstOutputChannel + i, maxChannel);
        else
            OUT0(i) = 0.f;
        RELEASE_BUS_CONTROL(firstOutputChannel + i);
    }
}

void InTrig_next_k_reblock(InTrig* unit, int inNumSamples) {
    // only trigger on the first tick!
    // NB: we do not need to cache the buffer touch value because we only read it on the first tick.
    if (unit->mParent->mTickCounter == 0) {
        InTrig_next_k(unit, inNumSamples);
    } else {
        for (int i = 0; i < unit->mNumOutputs; ++i)
            OUT0(i) = 0.f;
    }
}

void InTrig_Ctor(InTrig* unit) {
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    if (unit->mCalcRate == calc_FullRate) {
        SETCALC(ClearUnitOutputs);
        ClearUnitOutputs(unit, 1);
        return;
    }

    unit->m_bus = world->mControlBus;
    unit->m_busTouched = world->mControlBusTouched;

    if (REBLOCK_OR_RESAMPLE)
        SETCALC(InTrig_next_k_reblock);
    else
        SETCALC(InTrig_next_k);
    InTrig_next_k(unit, 1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void ReplaceOut_next_a_reblock(ReplaceOut* unit, int inNumSamples) {
    const World* world = unit->mWorld;
    const int bufLength = world->mBufLength;
    const int numChannels = unit->mNumInputs - 1;

    const float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    const float resample = SAMPLERATE / world->mSampleRate;
    if (resample < 1.f) {
        // downsampling not supported (yet)
        Print("ERROR: ReplaceOut: bad resample factor (%f)\n", resample);
        return;
    }

    // in case of upsampling, we only write every N samples (N = resample factor)
    const int tick = unit->mParent->mTickCounter;
    const int upsample = sc_float_to_int32(resample);
    assert(ISPOWEROFTWO(upsample));
    const int inputOffset = tick * inNumSamples;
    if (inputOffset & (upsample - 1)) {
        // All samples in this block would be skipped by downsampling, so we can return early.
        // This also ensures that the code below works for the case where inNumSamples < upsample.
        return;
    }

    const uint32_t shift = LOG2CEIL(upsample);
    const int outSamples = std::max<int>(inNumSamples >> shift, 1);
    float* out = unit->m_bus + (inputOffset >> shift);
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            for (int j = 0; j < outSamples; ++j) {
                out[j] = in[j << shift];
            }

            touched[i] = bufCounter;
        }
    }
}

void ReplaceOut_next_a(ReplaceOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            Copy(inNumSamples, out, in);
            touched[i] = bufCounter;
        }
    }
}

#ifdef NOVA_SIMD
FLATTEN void ReplaceOut_next_a_nova(ReplaceOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            nova::copyvec_simd(out, in, inNumSamples);
            touched[i] = bufCounter;
        }
    }
}

FLATTEN void ReplaceOut_next_a_nova_64(ReplaceOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            nova::copyvec_simd<64>(out, in);
            touched[i] = bufCounter;
        }
    }
}

#endif /* NOVA_SIMD */

void ReplaceOut_next_k(ReplaceOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<true>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out++) {
        if (firstOutputChannel + i < maxChannel) {
            float* in = IN(i + 1);
            ACQUIRE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
            *out = *in;
            touched[i] = bufCounter;
            RELEASE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
        }
    }
}

void ReplaceOut_next_k_reblock(ReplaceOut* unit, int inNumSamples) {
    // only output on first tick!
    if (unit->mParent->mTickCounter == 0)
        ReplaceOut_next_k(unit, inNumSamples);
}

void ReplaceOut_Ctor(ReplaceOut* unit) {
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    if (unit->mCalcRate == calc_FullRate) {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(ReplaceOut_next_a_reblock);
#ifdef NOVA_SIMD
        else if (BUFLENGTH == 64)
            SETCALC(ReplaceOut_next_a_nova_64);
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(ReplaceOut_next_a_nova);
#endif
        else
            SETCALC(ReplaceOut_next_a);
        unit->m_bus = world->mAudioBus;
        unit->m_busTouched = world->mAudioBusTouched;
    } else {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(ReplaceOut_next_k_reblock);
        else
            SETCALC(ReplaceOut_next_k);
        unit->m_bus = world->mControlBus;
        unit->m_busTouched = world->mControlBusTouched;
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void Out_next_a_reblock(Out* unit, int inNumSamples) {
    const World* world = unit->mWorld;
    const int bufLength = world->mBufLength;
    const int numChannels = unit->mNumInputs - 1;

    const float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    const float resample = SAMPLERATE / world->mSampleRate;
    if (resample < 1.f) {
        // downsampling not supported (yet)
        Print("ERROR: Out: bad resample factor (%f)\n", resample);
        return;
    }

    // in case of upsampling, we only write every N samples (N = resample factor)
    const int tick = unit->mParent->mTickCounter;
    const int upsample = sc_float_to_int32(resample);
    assert(ISPOWEROFTWO(upsample));
    const int inputOffset = tick * inNumSamples;
    if (inputOffset & (upsample - 1)) {
        // All samples in this block would be skipped by downsampling, so we can return early.
        // This also ensures that the code below works for the case where inNumSamples < upsample.
        return;
    }

    const uint32_t shift = LOG2CEIL(upsample);
    const int outSamples = std::max<int>(inNumSamples >> shift, 1);
    float* out = unit->m_bus + (inputOffset >> shift);
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            // If this is the first tick, check if we are the first one touching the bus.
            // If yes, zero the *whole* channel so every tick can simply accumulate.
            // This way we don't have to cache the bus touch values. (This also works
            // in ParGroups because only one UGen gets to update mBufTouched!)
            if (tick == 0 && touched[i] != bufCounter) {
                touched[i] = bufCounter;
                Clear(bufLength, unit->m_bus + bufLength * i);
            }

            // accumulate
            float* in = IN(i + 1);
            for (int j = 0; j < outSamples; ++j) {
                out[j] += in[j << shift];
            }
        }
    }
}

void Out_next_a(Out* unit, int inNumSamples) {
    // Print("Out_next_a %d\n", unit->mNumInputs);
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            if (touched[i] == bufCounter)
                Accum(inNumSamples, out, in);
            else {
                Copy(inNumSamples, out, in);
                touched[i] = bufCounter;
            }
        }
    }
}


#ifdef IPHONE_VEC
void vOut_next_a(Out* unit, int inNumSamples) {
    // Print("Out_next_a %d\n", unit->mNumInputs);
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            if (touched[i] == bufCounter) {
                vadd(out, out, in, inNumSamples);
            } else {
                vcopy(out, in, inNumSamples);
                touched[i] = bufCounter;
            }
        }
    }
}
#endif


#ifdef NOVA_SIMD
FLATTEN void Out_next_a_nova(Out* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            if (touched[i] == bufCounter)
                nova::addvec_simd(out, in, inNumSamples);
            else {
                nova::copyvec_simd(out, in, inNumSamples);
                touched[i] = bufCounter;
            }
        }
    }
}

FLATTEN void Out_next_a_nova_64(Out* unit, int inNumSamples) {
    // Print("Out_next_a %d\n", unit->mNumInputs);
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        if (guard.isValid()) {
            float* in = IN(i + 1);
            if (touched[i] == bufCounter)
                nova::addvec_simd<64>(out, in);
            else {
                nova::copyvec_simd<64>(out, in);
                touched[i] = bufCounter;
            }
        }
    }
}
#endif

void Out_next_k(Out* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<true>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out++) {
        if (firstOutputChannel + i < maxChannel) {
            float* in = IN(i + 1);
            ACQUIRE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
            if (touched[i] == bufCounter)
                *out += *in;
            else {
                *out = *in;
                touched[i] = bufCounter;
            }
            RELEASE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
        }
    }
}

void Out_next_k_reblock(Out* unit, int inNumSamples) {
    // only output on first tick!
    if (unit->mParent->mTickCounter == 0)
        Out_next_k(unit, inNumSamples);
}

void Out_Ctor(Out* unit) {
    // Print("->Out_Ctor\n");
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    if (unit->mCalcRate == calc_FullRate) {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(Out_next_a_reblock);
#if defined(NOVA_SIMD)
        else if (BUFLENGTH == 64)
            SETCALC(Out_next_a_nova_64);
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(Out_next_a_nova);
        else
            SETCALC(Out_next_a);
#else
        else
#    ifdef IPHONE_VEC
            SETCALC(vOut_next_a);
#    else
            SETCALC(Out_next_a);
#    endif
#endif
        unit->m_bus = world->mAudioBus;
        unit->m_busTouched = world->mAudioBusTouched;
    } else {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(Out_next_k_reblock);
        else
            SETCALC(Out_next_k);
        unit->m_bus = world->mControlBus;
        unit->m_busTouched = world->mControlBusTouched;
    }
    // Print("<-Out_Ctor\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

void XOut_next_a_reblock(XOut* unit, int inNumSamples) {
    const World* world = unit->mWorld;
    const int bufLength = world->mBufLength;
    const int numChannels = unit->mNumInputs - 2;

    const float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    const float resample = SAMPLERATE / world->mSampleRate;
    if (resample < 1.f) {
        // downsampling not supported (yet)
        Print("ERROR: XOut: bad resample factor (%f)\n", resample);
        return;
    }

    // in case of upsampling, we only write every N samples (N = resample factor)
    const int tick = unit->mParent->mTickCounter;
    const int upsample = sc_float_to_int32(resample);
    assert(ISPOWEROFTWO(upsample));
    const int inputOffset = tick * inNumSamples;
    if (inputOffset & (upsample - 1)) {
        // All samples in this block would be skipped by downsampling, so we can return early.
        // This also ensures that the code below works for the case where inNumSamples < upsample.
        return;
    }

    const float next_xfade = ZIN0(1);
    const float xfade0 = unit->m_xfade;
    const uint32_t shift = LOG2CEIL(upsample);
    const int outSamples = std::max<int>(inNumSamples >> shift, 1);
    float* out = unit->m_bus + (inputOffset >> shift);
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    if (xfade0 != next_xfade) {
        // new crossfade level -> ramp from new to old value while crossfading with previous bus content.
        //
        // NOTE: We must adjust the slope for the resample factor!
        // Example: with 2x upsampling the output has only half the size of the input,
        // so we would have to double the slope.
        float slope = CALCSLOPE(next_xfade, xfade0) * resample;
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                // If this is the first tick, check if we are the first one touching the bus.
                // If yes, zero the *whole* channel so every tick can simply accumulate.
                // This way we don't have to cache the bus touch values.
                // (This also works in ParGroups because only one Ugen gets to update mBufTouched!)
                if (tick == 0 && touched[i] != bufCounter) {
                    touched[i] = bufCounter;
                    Clear(bufLength, unit->m_bus + bufLength * i);
                }

                // accumulate
                float xfade = xfade0;
                float* in = IN(i + 2);
                for (int j = 0; j < outSamples; ++j, xfade += slope) {
                    float zout = out[j];
                    out[j] = zout + xfade * (in[j << shift] - zout);
                }
            }
        }
    } else if (xfade0 == 1.f) {
        // replace bus content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float* in = IN(i + 2);
                for (int j = 0; j < outSamples; ++j) {
                    out[j] += in[j << shift];
                }
                touched[i] = bufCounter;
            }
        }
    } else if (xfade0 == 0.f) {
        // do nothing.
    } else {
        // crossfade with previous content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                // see comment in xfade0 != next_xfade branch.
                if (tick == 0 && touched[i] != bufCounter) {
                    touched[i] = bufCounter;
                    Clear(bufLength, unit->m_bus + bufLength * i);
                }

                // accumulate
                float* in = IN(i + 2);
                for (int j = 0; j < outSamples; ++j) {
                    float zout = out[j];
                    out[j] = zout + xfade0 * (in[j << shift] - zout);
                }
            }
        }
    }
    unit->m_xfade = next_xfade;
}

void XOut_next_a(XOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 2;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float next_xfade = ZIN0(1);
    float xfade0 = unit->m_xfade;
    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    if (xfade0 != next_xfade) {
        // new crossfade level -> ramp from new to old value
        // while crossfading with previous bus content.
        float slope = CALCSLOPE(next_xfade, xfade0);
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float xfade = xfade0;
                float* in = IN(i + 2);
                if (touched[i] == bufCounter) {
                    for (int j = 0; j < inNumSamples; ++j, xfade += slope) {
                        float zout = out[j];
                        out[j] = zout + xfade * (in[j] - zout);
                    }
                } else {
                    for (int j = 0; j < inNumSamples; ++j, xfade += slope) {
                        out[j] = in[j] * xfade;
                    }
                    touched[i] = bufCounter;
                }
            }
        }
    } else if (xfade0 == 1.f) {
        // replace bus content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float* in = IN(i + 2);
                Copy(inNumSamples, out, in);
                touched[i] = bufCounter;
            }
        }
    } else if (xfade0 == 0.f) {
        // do nothing.
    } else {
        // crossfade with previous content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float* in = IN(i + 2);
                if (touched[i] == bufCounter) {
                    for (int j = 0; j < inNumSamples; ++j) {
                        float zout = out[j];
                        out[j] = zout + xfade0 * (in[j] - zout);
                    }
                } else {
                    for (int j = 0; j < inNumSamples; ++j) {
                        out[j] = in[j] * xfade0;
                    }
                    touched[i] = bufCounter;
                }
            }
        }
    }
    unit->m_xfade = next_xfade;
}

#ifdef NOVA_SIMD
FLATTEN void XOut_next_a_nova(XOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 2;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    float next_xfade = ZIN0(1);
    float xfade0 = unit->m_xfade;
    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    if (xfade0 != next_xfade) {
        // new crossfade level -> ramp from new to old value
        // while crossfading with previous bus content.
        float slope = CALCSLOPE(next_xfade, xfade0);
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float xfade = xfade0;
                float* in = IN(i + 2);
                if (touched[i] == bufCounter)
                    nova::mix_vec_simd(out, out, slope_argument(1 - xfade0, -slope), in, slope_argument(xfade0, slope),
                                       inNumSamples);
                else {
                    nova::times_vec_simd(out, in, slope_argument(xfade, slope), inNumSamples);
                    touched[i] = bufCounter;
                }
            }
        }
        unit->m_xfade = next_xfade;
    } else if (xfade0 == 1.f) {
        // replace content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float* in = IN(i + 2);
                nova::copyvec_simd(out, in, inNumSamples);
                touched[i] = bufCounter;
            }
        }
    } else if (xfade0 == 0.f) {
        // do nothing.
    } else {
        // crossfade with previous content
        for (int i = 0; i < numChannels; ++i, out += bufLength) {
            AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

            if (guard.isValid()) {
                float* in = IN(i + 2);
                if (touched[i] == bufCounter)
                    nova::mix_vec_simd(out, out, 1 - xfade0, in, xfade0, inNumSamples);
                else {
                    nova::times_vec_simd(out, in, xfade0, inNumSamples);
                    touched[i] = bufCounter;
                }
            }
        }
    }
}

#endif

void XOut_next_k(XOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int numChannels = unit->mNumInputs - 2;

    float fbusChannel = ZIN0(0);
    IO_k_update_channels<true>(unit, world, fbusChannel, numChannels);
    const int32 maxChannel = world->mNumControlBusChannels;
    const int64 firstOutputChannel = sc_float_to_int32(fbusChannel);

    float xfade = ZIN0(1);
    float* out = unit->m_bus;
    int32* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out++) {
        if (firstOutputChannel + i < maxChannel) {
            float* in = IN(i + 2);
            ACQUIRE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
            if (touched[i] == bufCounter) {
                float zin = *in;
                float zout = *out;
                *out = zout + xfade * (zin - zout);
            } else {
                *out = xfade * *in;
                touched[i] = bufCounter;
            }
            RELEASE_BUS_CONTROL(sc_float_to_int32(fbusChannel) + i);
        }
    }
}

void XOut_next_k_reblock(XOut* unit, int inNumSamples) {
    // only output on first tick!
    if (unit->mParent->mTickCounter == 0)
        XOut_next_k(unit, inNumSamples);
}

void XOut_Ctor(XOut* unit) {
    // Print("->Out_Ctor\n");
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;
    unit->m_xfade = ZIN0(1);
    if (unit->mCalcRate == calc_FullRate) {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(XOut_next_a_reblock);
#ifdef NOVA_SIMD
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(XOut_next_a_nova);
#endif
        else
            SETCALC(XOut_next_a);
        unit->m_bus = world->mAudioBus;
        unit->m_busTouched = world->mAudioBusTouched;
    } else {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(XOut_next_k_reblock);
        else
            SETCALC(XOut_next_k);
        unit->m_bus = world->mControlBus;
        unit->m_busTouched = world->mControlBusTouched;
    }
    // Print("<-Out_Ctor\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void OffsetOut_next_a_reblock(OffsetOut* unit, int inNumSamples) {
    const World* world = unit->mWorld;
    const int bufLength = world->mBufLength;
    const int numChannels = unit->mNumInputs - 1;

    const float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    const float resample = SAMPLERATE / world->mSampleRate;
    if (resample < 1.f) {
        // downsampling not supported (yet)
        Print("ERROR: OffsetOut: bad resample factor (%f)\n", resample);
        return;
    }

    // in case of upsampling, we only write every N samples (N = resample factor)
    const int tick = unit->mParent->mTickCounter;
    const int numTicks = unit->mParent->mNumTicks;
    const int upsample = sc_float_to_int32(resample);
    assert(ISPOWEROFTWO(upsample));
    const int inPhase = tick * inNumSamples;
    if (inPhase & (upsample - 1)) {
        // All samples in this block would be skipped by downsampling, so we can return early.
        // This also ensures that the code below works for the case where inNumSamples < upsample.
        return;
    }

    const int32 offset = unit->mParent->mSampleOffset;
    const int32 remain = bufLength - offset;

    const uint32_t shift = LOG2CEIL(upsample);
    const int outSamples = std::max<int>(inNumSamples >> shift, 1);
    const int outPhase = inPhase >> shift;
    float* out = unit->m_bus;
    float* saved = unit->m_saved;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    // This one is a bit tricky, but the following example might help understand it:
    //
    // Server block size = 64 samples, graph block size = 16 samples (= 4 ticks),
    // sample offset = 48 samples
    //
    //           ┌―――――――――――――――――――――――――――――――――――――――┐
    //           ▼                                       │
    //    saved: █        ← offset →        █            │
    //           │                                       │
    //           │                                       │
    //           │                      in: █ ← remain → ║       ← offset →         █
    //           │                 inPhase: █---------|---------|---------|---------█
    //           │                          │
    //           ▼                          ▼
    //      out: █        ← offset →        ║ ← remain → █
    // outPhase: █---------|---------|---------|---------█

    for (int i = 0; i < numChannels; ++i, out += bufLength, saved += offset) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        const float* in = IN(i + 1);
        const int diff1 = remain - outPhase;

        if (guard.isValid()) {
            if (tick == 0) {
                // copy/accumulate the saved input from the previous control period.
                if (touched[i] != bufCounter) {
                    // If we are the first one touching the bus, clear the remaining channel
                    // so that every tick can simply accumulate. (This also works in ParGroups
                    // because only one Ugen gets to update mBufTouched!)
                    if (unit->m_empty) {
                        // clear whole channel
                        Clear(bufLength, out);
                        // Print("untouched offset %d\n", offset);
                    } else {
                        if (saved)
                            Copy(offset, out, saved);
                        Clear(remain, out + offset);
                    }
                    touched[i] = bufCounter;
                } else {
                    if (unit->m_empty) {
                        // just keep bus content
                        // Print("touched offset %d\n", offset);
                    } else {
                        if (saved)
                            Accum(offset, out, saved);
                    }
                }
            }

            if (diff1 > 0) {
                // accumulate the current input (up to 'remain' samples)
                // into the bus, shifted by 'offset' samples.
                const int n = std::min<int>(diff1, outSamples);
                for (int j = 0; j < n; ++j) {
                    const int outIndex = offset + outPhase + j;
                    out[outIndex] += in[j << shift];
                }
            }
        }

        const int diff2 = outSamples - diff1;
        if (diff2 > 0) {
            // save remaining input samples (with downsampling),
            // even if the buf channel was out-of-range.
            const int n = std::min<int>(diff2, outSamples);
            // j starts at the input block offset
            for (int j = outSamples - n; j < outSamples; ++j) {
                const int outIndex = j - diff1;
                saved[outIndex] = in[j << shift];
            }
        }
    }

    unit->m_empty = false;
}

void OffsetOut_next_a(OffsetOut* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = world->mBufLength;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    IO_a_update_channels(unit, world, fbusChannel, numChannels, bufLength);

    int32 offset = unit->mParent->mSampleOffset;
    int32 remain = bufLength - offset;

    float* out = unit->m_bus;
    float* saved = unit->m_saved;
    int32* touched = unit->m_busTouched;
    const int32 bufCounter = unit->mWorld->mBufCounter;
    const int32 maxChannel = world->mNumAudioBusChannels;

    for (int i = 0; i < numChannels; ++i, out += bufLength, saved += offset) {
        AudioBusGuard<false> guard(unit, fbusChannel + i, maxChannel);

        float* in = IN(i + 1);
        // Print("out %d  %d %d  %d %d\n",
        //	i, touched[i] == bufCounter, unit->m_empty,
        //	offset, remain);

        if (guard.isValid()) {
            if (touched[i] != bufCounter) {
                // we are the first to touch the bus
                if (unit->m_empty) {
                    // clear the first bus section
                    Clear(offset, out);
                    // Print("untouched offset %d\n", offset);
                } else {
                    // copy the saved content into the first bus section
                    if (saved)
                        Copy(offset, out, saved);
                }
                // copy the input into the second bus section
                Copy(remain, out + offset, in);
                touched[i] = bufCounter;
            } else {
                if (unit->m_empty) {
                    // just keep the existing bus content
                    // Print("touched offset %d\n", offset);
                } else {
                    // accumulate the saved content into the first bus section
                    if (saved)
                        Accum(offset, out, saved);
                }
                // accumulate the input into the second bus section
                Accum(remain, out + offset, in);
            }
        }

        // always save the remaining input, even if the buf channel was out-of-range.
        if (saved)
            Copy(offset, saved, in + remain);

        // Print("out %d %d %d  %g %g\n", i, in[0], out[0]);
    }

    unit->m_empty = false;
}

void OffsetOut_Ctor(OffsetOut* unit) {
    // Print("->Out_Ctor\n");
    const World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    if (REBLOCK_OR_RESAMPLE) {
        SETCALC(OffsetOut_next_a_reblock);
    } else {
        SETCALC(OffsetOut_next_a);
    }
    unit->m_bus = world->mAudioBus;
    unit->m_busTouched = world->mAudioBusTouched;
    // NB: if mSampleOffset is 0, RTAlloc() might return a nullptr and
    // trigger ClearUnitIfMemFailed(), so we have to handle it specially.
    const int32 offset = unit->mParent->mSampleOffset;
    if (offset > 0) {
        const int numChannels = unit->mNumInputs - 1;
        unit->m_saved = (float*)RTAlloc(unit->mWorld, offset * numChannels * sizeof(float));
        ClearUnitIfMemFailed(unit->m_saved);
    } else {
        unit->m_saved = nullptr;
    }
    unit->m_empty = true;
    // Print("<-Out_Ctor\n");
}

void OffsetOut_Dtor(OffsetOut* unit) {
    // Write remaining samples (if any)
    if (unit->m_saved) {
        const World* world = unit->mWorld;
        const int bufLength = world->mBufLength;
        const int numChannels = unit->mNumInputs - 1;

        const int32 offset = unit->mParent->mSampleOffset;
        const int32 remain = bufLength - offset; // Do not use BUFLENGTH!

        float* out = unit->m_bus;
        float* saved = unit->m_saved;
        int32* touched = unit->m_busTouched;
        const int32 bufCounter = unit->mWorld->mBufCounter;
        const int32 bufChannel = sc_float_to_int32(unit->m_fbusChannel);
        const int32 maxChannel = world->mNumAudioBusChannels;

        for (int i = 0; i < numChannels; ++i, out += bufLength, saved += offset) {
            if ((bufChannel + i) < maxChannel) {
                // Print("out %d  %d %d  %d %d\n",
                //	i, touched[i] == bufCounter, unit->m_empty,
                //	offset, remain);
                if (!unit->m_empty) {
                    if (touched[i] != bufCounter) {
                        Copy(offset, out, saved);
                        Clear(remain, out + offset);
                        touched[i] = bufCounter;
                    } else {
                        Accum(offset, out, saved);
                    }
                }
                // Print("out %d %d %d  %g %g\n", i, in[0], out[0]);
            }
        }

        RTFree(unit->mWorld, unit->m_saved);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void SharedIn_next_k(SharedIn* unit, int inNumSamples) {
    // Print("->SharedIn_next_k\n");
    World* world = unit->mWorld;
    int numChannels = unit->mNumOutputs;

    float fbusChannel = ZIN0(0);
    if (fbusChannel != unit->m_fbusChannel) {
        unit->m_fbusChannel = fbusChannel;
        uint32 busChannel = sc_float_to<uint32>(fbusChannel);
        uint32 lastChannel = busChannel + numChannels;

        if (!(lastChannel > world->mNumSharedControls)) {
            unit->m_bus = world->mSharedControls + busChannel;
        }
    }

    float* in = unit->m_bus;
    if (in) {
        for (int i = 0; i < numChannels; ++i) {
            OUT0(i) = in[i];
        }
    } else {
        ClearUnitOutputs(unit, 1);
    }
    // Print("<-SharedIn_next_k\n");
}

void SharedIn_Ctor(SharedIn* unit) {
    // Print("->SharedIn_Ctor\n");
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    // There is no need for a dedicated reblocking calc function.
    SETCALC(SharedIn_next_k);
    unit->m_bus = world->mSharedControls;
    SharedIn_next_k(unit, 1);

    // Print("<-SharedIn_Ctor\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

void SharedOut_next_k(SharedOut* unit, int inNumSamples) {
    // Print("->SharedOut_next_k\n");
    World* world = unit->mWorld;
    int numChannels = unit->mNumInputs - 1;

    float fbusChannel = ZIN0(0);
    if (fbusChannel != unit->m_fbusChannel) {
        unit->m_fbusChannel = fbusChannel;
        uint32 busChannel = sc_float_to<uint32>(fbusChannel);
        uint32 lastChannel = busChannel + numChannels;

        if (!(lastChannel > world->mNumSharedControls)) {
            unit->m_bus = world->mSharedControls + busChannel;
        }
    }

    float* out = unit->m_bus;
    if (out) {
        for (int i = 0; i < numChannels; ++i) {
            out[i] = IN0(i + 1);
        }
    }
    // Print("<-SharedOut_next_k\n");
}

void SharedOut_Ctor(SharedOut* unit) {
    // Print("->SharedOut_Ctor\n");
    World* world = unit->mWorld;
    unit->m_fbusChannel = -1.;

    // There is no need for a dedicated reblocking calc function.
    SETCALC(SharedOut_next_k);
    unit->m_bus = world->mSharedControls;
    SharedOut_next_k(unit, 1);

    // Print("<-SharedOut_Ctor\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void LocalIn_next_a_reblock(LocalIn* unit, int inNumSamples) {
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumOutputs;

    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    // This keeps track of buffer touching for every subtick.
    // NOTE: the values are local to this Graph!
    int64 bufCounter = unit->mWorld->mBufCounter;
    int64 tickCounter = unit->mParent->mTickCounter;
    int64 numTicks = unit->mParent->mNumTicks;
    int64 counter = bufCounter * numTicks + tickCounter;
    // Print("LocalIn_next_a_reblock: counter: %d\n", counter);

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        float* out = OUT(i);
        int64 diff = counter - touched[i];
        // Print("LocalIn  %d  %d  %g\n", i, diff, in[0]);
        if (diff == 1 || diff == 0)
            Copy(inNumSamples, out, in);
        else // get default value from UGen input
            Fill(inNumSamples, out, IN0(i));
    }
}

void LocalIn_next_a(LocalIn* unit, int inNumSamples) {
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumOutputs;

    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        float* out = OUT(i);
        int diff = bufCounter - touched[i];
        // Print("LocalIn  %d  %d  %g\n", i, diff, in[0]);
        if (diff == 1 || diff == 0)
            Copy(inNumSamples, out, in);
        else // get default value from UGen input
            Fill(inNumSamples, out, IN0(i));
    }
}

#ifdef NOVA_SIMD
FLATTEN void LocalIn_next_a_nova(LocalIn* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumOutputs;

    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;

    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        float* out = OUT(i);
        int diff = bufCounter - touched[i];
        // Print("LocalIn  %d  %d  %g\n", i, diff, in[0]);
        if (diff == 1 || diff == 0)
            nova::copyvec_simd(out, in, inNumSamples);
        else // get default value from UGen input
            Fill(inNumSamples, out, IN0(i));
    }
}

FLATTEN void LocalIn_next_a_nova_64(LocalIn* unit, int inNumSamples) {
    World* world = unit->mWorld;
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumOutputs;

    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, in += bufLength) {
        float* out = OUT(i);
        int diff = bufCounter - touched[i];
        // Print("LocalIn  %d  %d  %g\n", i, diff, in[0]);
        if (diff == 1 || diff == 0)
            nova::copyvec_simd<64>(out, in);
        else // get default value from UGen input
            Fill(inNumSamples, out, IN0(i));
    }
}
#endif


void LocalIn_next_k_reblock(LocalIn* unit, int inNumSamples) {
    int numChannels = unit->mNumOutputs;
    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    // This keeps track of buffer touching for every subtick.
    // NOTE: the values are local to this Graph!
    int64 bufCounter = unit->mWorld->mBufCounter;
    int64 tickCounter = unit->mParent->mTickCounter;
    int64 numTicks = unit->mParent->mNumTicks;
    int64 counter = bufCounter * numTicks + tickCounter;

    for (int i = 0; i < numChannels; ++i) {
        int64 diff = counter - touched[i];
        if (diff == 1 || diff == 0)
            OUT0(i) = in[i];
        else // get default value from UGen input
            OUT0(i) = IN0(i);
    }
}

void LocalIn_next_k(LocalIn* unit, int inNumSamples) {
    uint32 numChannels = unit->mNumOutputs;
    float* in = unit->m_bus;
    int64* touched = unit->m_busTouched;
    int32 bufCounter = unit->mWorld->mBufCounter;
    for (uint32 i = 0; i < numChannels; ++i) {
        int diff = bufCounter - touched[i];
        if (diff == 1 || diff == 0)
            OUT0(i) = in[i];
        else // get default value from UGen input
            OUT0(i) = IN0(i);
    }
}

void LocalIn_Ctor(LocalIn* unit) {
    // Print("->LocalIn_Ctor\n");
    int numChannels = unit->mNumOutputs;

    World* world = unit->mWorld;

    int busDataSize = numChannels * BUFLENGTH;
    // The touched flags follow the bus data, on an int64 boundary.
    const size_t touchedOffset = sc_align_up(busDataSize * sizeof(float), alignof(int64));

    // align the buffer to 32 bytes so that we can use avx instructions
    unit->m_realData = (float*)RTAlloc(world, touchedOffset + numChannels * sizeof(int64) + 32 * sizeof(float));
    ClearUnitIfMemFailed(unit->m_realData);
    size_t alignment = (uintptr_t)unit->m_realData & 31;

    unit->m_bus = alignment ? (float*)(((uintptr_t)unit->m_realData + 32) & ~31) : unit->m_realData;

    unit->m_busTouched = (int64*)((char*)unit->m_bus + touchedOffset);
    std::fill_n(unit->m_busTouched, numChannels, -1);

    if (unit->mCalcRate == calc_FullRate) {
        if (unit->mParent->mLocalAudioBusUnit) {
            SETCALC(ClearUnitOutputs);
            ClearUnitOutputs(unit, 1);
            return;
        }
        unit->mParent->mLocalAudioBusUnit = unit;
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LocalIn_next_a_reblock);
#ifdef NOVA_SIMD
        else if (BUFLENGTH == 64)
            SETCALC(LocalIn_next_a_nova_64);
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(LocalIn_next_a_nova);
#endif
        else
            SETCALC(LocalIn_next_a);
        LocalIn_next_a(unit, 1);
    } else {
        if (unit->mParent->mLocalControlBusUnit) {
            SETCALC(ClearUnitOutputs);
            ClearUnitOutputs(unit, 1);
            return;
        }
        unit->mParent->mLocalControlBusUnit = unit;
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LocalIn_next_k_reblock);
        else
            SETCALC(LocalIn_next_k);
        LocalIn_next_k(unit, 1);
    }
    // Print("<-LocalIn_Ctor\n");
}

void LocalIn_Dtor(LocalIn* unit) { RTFree(unit->mWorld, unit->m_realData); }

//////////////////////////////////////////////////////////////////////////////////////////////////

void LocalOut_next_a_reblock(LocalOut* unit, int inNumSamples) {
    // Print("LocalOut_next_a_reblock %d\n", unit->mNumInputs);
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalAudioBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;
    int64 bufCounter = unit->mWorld->mBufCounter;
    int64 tickCounter = unit->mParent->mTickCounter;
    int64 numTicks = unit->mParent->mNumTicks;
    int64 counter = bufCounter * numTicks + tickCounter;
    // Print("LocalOut_next_a_reblock: counter: %d\n", counter);

    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        float* in = IN(i);
        if (touched[i] == counter)
            Accum(inNumSamples, out, in);
        else {
            Copy(inNumSamples, out, in);
            touched[i] = counter;
        }
        // Print("LocalOut %d %g %g\n", i, in[0], out[0]);
    }
}

void LocalOut_next_a(LocalOut* unit, int inNumSamples) {
    // Print("LocalOut_next_a %d\n", unit->mNumInputs);
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalAudioBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;

    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        float* in = IN(i);
        if (touched[i] == bufCounter)
            Accum(inNumSamples, out, in);
        else {
            Copy(inNumSamples, out, in);
            touched[i] = bufCounter;
        }
        // Print("LocalOut %d %g %g\n", i, in[0], out[0]);
    }
}

#ifdef NOVA_SIMD
FLATTEN void LocalOut_next_a_nova(LocalOut* unit, int inNumSamples) {
    // Print("LocalOut_next_a %d\n", unit->mNumInputs);
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalAudioBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;

    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        float* in = IN(i);
        if (touched[i] == bufCounter)
            nova::addvec_simd(out, in, inNumSamples);
        else {
            nova::copyvec_simd(out, in, inNumSamples);
            touched[i] = bufCounter;
        }
        // Print("LocalOut %d %g %g\n", i, in[0], out[0]);
    }
}

FLATTEN void LocalOut_next_a_nova_64(LocalOut* unit, int inNumSamples) {
    // Print("LocalOut_next_a %d\n", unit->mNumInputs);
    int bufLength = unit->mBufLength;
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalAudioBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;

    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i, out += bufLength) {
        float* in = IN(i);
        if (touched[i] == bufCounter)
            nova::addvec_simd<64>(out, in);
        else {
            nova::copyvec_simd<64>(out, in);
            touched[i] = bufCounter;
        }
        // Print("LocalOut %d %g %g\n", i, in[0], out[0]);
    }
}
#endif

void LocalOut_next_k_reblock(LocalOut* unit, int inNumSamples) {
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalControlBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;
    int64 bufCounter = unit->mWorld->mBufCounter;
    int64 tickCounter = unit->mParent->mTickCounter;
    int64 numTicks = unit->mParent->mNumTicks;
    int64 counter = bufCounter * numTicks + tickCounter;

    for (int i = 0; i < numChannels; ++i) {
        if (touched[i] == counter)
            out[i] += IN0(i);
        else {
            out[i] = IN0(i);
            touched[i] = counter;
        }
    }
}

void LocalOut_next_k(LocalOut* unit, int inNumSamples) {
    int numChannels = unit->mNumInputs;

    LocalIn* localIn = (LocalIn*)unit->mParent->mLocalControlBusUnit;
    if (!localIn)
        return;

    float* out = localIn->m_bus;
    if ((out == nullptr) || (numChannels != localIn->mNumOutputs))
        return;

    int64* touched = localIn->m_busTouched;

    int32 bufCounter = unit->mWorld->mBufCounter;
    for (int i = 0; i < numChannels; ++i) {
        if (touched[i] == bufCounter)
            out[i] += IN0(i);
        else {
            out[i] = IN0(i);
            touched[i] = bufCounter;
        }
    }
}

void LocalOut_Ctor(LocalOut* unit) {
    // Print("->LocalOut_Ctor\n");

    if (unit->mCalcRate == calc_FullRate) {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LocalOut_next_a_reblock);
#ifdef NOVA_SIMD
        else if (BUFLENGTH == 64)
            SETCALC(LocalOut_next_a_nova_64);
        else if (((BUFLENGTH & 15) == 0))
            SETCALC(LocalOut_next_a_nova);
#endif
        else
            SETCALC(LocalOut_next_a);
    } else {
        if (REBLOCK_OR_RESAMPLE)
            SETCALC(LocalOut_next_k_reblock);
        else
            SETCALC(LocalOut_next_k);
    }
    // Print("<-LocalOut_Ctor\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

extern "C"
PluginLoad(IO) {

    DefineDtorUnit(OffsetOut);
    DefineDtorUnit(LocalIn);
    DefineSimpleUnit(XOut);
    DefineDtorUnit(LagControl);
    DefineDtorUnit(AudioControl);
    DefineSimpleUnit(Control);
    DefineSimpleUnit(TrigControl);
    DefineSimpleUnit(ReplaceOut);
    DefineSimpleUnit(Out);
    DefineSimpleUnit(LocalOut);
    DefineDtorUnit(In);
    DefineSimpleUnit(LagIn);
    DefineDtorUnit(InFeedback);
    DefineSimpleUnit(InTrig);

    DefineSimpleUnit(SharedOut);
    DefineSimpleUnit(SharedIn);
}
