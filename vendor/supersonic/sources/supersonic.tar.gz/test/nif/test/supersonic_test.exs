defmodule TauTest do
  use ExUnit.Case

  # The clock verbs live under /clockwork/, the prefix clockwork keeps for
  # itself (see clockwork_sys.h — the trailing slash is the whole rule, so /clockwork-sys
  # and /clockwork-system-status are NOT claimed). These tests were written before
  # that namespace existed and addressed /clock/... directly.
  #
  # The completion atoms are {:clockwork_started, _} / {:clockwork_stopped, _}, not
  # {:supersonic_started, _} / {:supersonic_stopped, _}. They were renamed with
  # the rest of clockwork's vocabulary during the extraction; these tests came
  # across from upstream unchanged and had never been run against the renamed
  # NIF, because no build rule for it came across either.

  # When SUPERSONIC_HEADLESS=1 is set (e.g. Windows CI with no audio device),
  # tests boot in headless mode. The HeadlessDriver inside the engine handles
  # audio processing automatically — no manual ticking needed.
  @headless System.get_env("SUPERSONIC_HEADLESS") == "1"

  # Tests share a single global NIF engine — ensure clean state between tests.
  # start/stop are async (they message the caller on completion), so block on
  # the completion here to guarantee the engine is actually down before each test.
  setup do
    stop_sync()
    on_exit(fn -> :clockwork.stop() end)
    :ok
  end

  # ── Helpers ──────────────────────────────────────────────────────────────

  # start/1 and stop/0 are asynchronous: they return :ok immediately and deliver
  # the outcome as a message to the caller. These helpers re-synchronise for the
  # tests that want the engine up/down before proceeding.
  defp start_sync(config) do
    assert :ok = :clockwork.start(config)
    receive do
      {:clockwork_started, result} -> result
    after
      5000 -> flunk("start did not report completion")
    end
  end

  defp stop_sync do
    assert :ok = :clockwork.stop()
    receive do
      {:clockwork_stopped, result} -> result
    after
      5000 -> flunk("stop did not report completion")
    end
  end

  defp start_config(overrides \\ %{}) do
    if @headless do
      Map.merge(%{headless: true}, overrides)
    else
      overrides
    end
  end

  # Build a minimal OSC message from an address string.
  # OSC format: null-terminated string padded to 4-byte boundary + type tag ","
  defp osc_message(address) do
    osc_string(address) <> osc_string(",")
  end

  # Build an OSC message with a single int32 argument.
  defp osc_message(address, int_arg) when is_integer(int_arg) do
    osc_string(address) <> osc_string(",i") <> <<int_arg::signed-big-32>>
  end

  # Build an OSC message with a single float32 argument.
  defp osc_message(address, float_arg) when is_float(float_arg) do
    osc_string(address) <> osc_string(",f") <> <<float_arg::float-big-32>>
  end

  defp osc_string(str) do
    bytes = str <> <<0>>
    pad_len = case rem(byte_size(bytes), 4) do
      0 -> 0
      n -> 4 - n
    end
    bytes <> <<0::size(pad_len * 8)>>
  end

  defp wait_for_reply(timeout \\ 2000) do
    receive do
      {:osc_reply, bin} when is_binary(bin) -> {:ok, bin}
    after
      timeout -> :timeout
    end
  end

  # Wait for an OSC reply whose address starts with `prefix`, ignoring any other
  # replies / debug messages that arrive first.
  defp wait_for_reply_matching(prefix, timeout \\ 2000) do
    deadline = System.monotonic_time(:millisecond) + timeout
    do_wait_matching(prefix, deadline)
  end

  defp do_wait_matching(prefix, deadline) do
    remaining = deadline - System.monotonic_time(:millisecond)

    if remaining <= 0 do
      :timeout
    else
      receive do
        {:osc_reply, bin} when is_binary(bin) ->
          if String.starts_with?(bin, prefix),
            do: {:ok, bin},
            else: do_wait_matching(prefix, deadline)

        {:debug, _} ->
          do_wait_matching(prefix, deadline)
      after
        remaining -> :timeout
      end
    end
  end

  # Extract the trailing float64 arg from a single-double OSC reply. (getBpm()
  # returns a double, which oscpack encodes as an 8-byte OSC ',d' arg.)
  defp trailing_double(bin) do
    <<_::binary-size(byte_size(bin) - 8), d::float-big-64>> = bin
    d
  end

  # ── NIF loading ──────────────────────────────────────────────────────────

  test "NIF is loaded" do
    assert :clockwork.is_nif_loaded() == true
  end

  # ── Lifecycle ────────────────────────────────────────────────────────────

  test "start and stop" do
    assert :ok = start_sync(start_config())
    assert :ok = stop_sync()
  end

  test "start is asynchronous: returns :ok immediately, reports completion by message" do
    # The NIF returns before the engine is booted; completion arrives separately.
    assert :ok = :clockwork.start(start_config())
    assert_receive {:clockwork_started, :ok}, 5000
  end

  test "stop is asynchronous: returns :ok immediately, reports completion by message" do
    assert :ok = start_sync(start_config())
    assert :ok = :clockwork.stop()
    assert_receive {:clockwork_stopped, :ok}, 5000
  end

  test "double start reports already_running via the completion message" do
    assert :ok = start_sync(start_config())
    assert :ok = :clockwork.start(start_config())
    assert_receive {:clockwork_started, {:error, :already_running}}, 5000
  end

  test "stop when not running is ok" do
    assert :ok = stop_sync()
  end

  # ── OSC send ─────────────────────────────────────────────────────────────

  test "send_osc when not running returns error" do
    assert {:error, :not_running} = :clockwork.send_osc(osc_message("/status"))
  end

  test "send_osc with valid message returns ok" do
    :ok = start_sync(start_config())
    assert :ok = :clockwork.send_osc(osc_message("/status"))
  end

  test "send_osc with non-binary returns badarg" do
    :ok = start_sync(start_config())
    assert_raise ArgumentError, fn -> :clockwork.send_osc(:not_a_binary) end
  end

  # ── Notifications ────────────────────────────────────────────────────────

  test "set and clear notification pid" do
    assert :ok = :clockwork.set_notification_pid()
    assert :ok = :clockwork.clear_notification_pid()
  end

  test "multiple registered processes each receive replies" do
    :ok = start_sync(start_config())
    test_pid = self()

    # A second process registers itself and relays the first reply it sees.
    relay = spawn(fn ->
      :clockwork.set_notification_pid()
      send(test_pid, :relay_registered)

      receive do
        {:osc_reply, bin} -> send(test_pid, {:relay, bin})
      after
        2000 -> send(test_pid, :relay_timeout)
      end
    end)

    assert_receive :relay_registered, 2000

    # This process registers too, then triggers a reply.
    :ok = :clockwork.set_notification_pid()
    :ok = :clockwork.send_osc(osc_message("/version"))

    # Both audiences receive it — the registry fans out, it isn't single-pid.
    assert {:ok, _} = wait_for_reply_matching("/version.reply")
    assert_receive {:relay, bin} when is_binary(bin), 2000

    Process.exit(relay, :kill)
  end

  # ── Link notify (parity with the UDP transport) ──────────────────────────
  #
  # /clock/notify/subscribe immediately pushes a tempo + peers snapshot via the
  # networkOnly SEND_TO_CALLER route. CallbackTransport drops networkOnly (an
  # in-process observer reads engine state directly); the NIF transport, being a
  # real out-of-process peer, delivers it — proving the Link path now works from
  # BEAM exactly as it does over UDP.

  test "subscribing to Link notify pushes an immediate snapshot to the registered pid" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()

    :ok = :clockwork.send_osc(osc_message("/clockwork/clock/notify/subscribe"))

    assert {:ok, _} = wait_for_reply_matching("/clockwork/clock/notify/tempo")
    assert {:ok, _} = wait_for_reply_matching("/clockwork/clock/notify/peers")
  end

  test "receive /version.reply" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    :ok = :clockwork.send_osc(osc_message("/version"))

    assert {:ok, reply} = wait_for_reply()
    assert is_binary(reply)
    assert String.starts_with?(reply, "/version.reply")
  end

  test "receive /g_queryTree.reply" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    :ok = :clockwork.send_osc(osc_message("/g_queryTree", 0))

    assert {:ok, reply} = wait_for_reply()
    assert is_binary(reply)
    assert String.starts_with?(reply, "/g_queryTree.reply")
  end

  # ── Link / clock queries (travel the NRT plane, not the RT OUT ring) ──────
  #
  # A /clock query is forwarded to the NRT command ring, processed on the gateway
  # thread (EngineControl/TauClock), and its reply is framed into the NRT-out
  # ring. The gateway merges that with the RT OUT ring and the reply reaches the
  # registered pid as an {:osc_reply, binary} message — exactly the same sink as
  # scsynth's own replies, proving the unified egress works for the NRT plane.

  test "clock tempo query round-trips via the NRT egress ring" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()

    :ok = :clockwork.send_osc(osc_message("/clockwork/clock/tempo/set", 142.5))
    :ok = :clockwork.send_osc(osc_message("/clockwork/clock/tempo/get"))

    # /clock/tempo.reply travels the NRT command ring → gateway → NRT-out ring →
    # the registered pid, and the tempo value round-trips (read from the shared
    # TauClock state mirror, same as the web build).
    assert {:ok, reply} = wait_for_reply_matching("/clockwork/clock/tempo.reply")
    assert_in_delta trailing_double(reply), 142.5, 0.5
  end

  test "clock visibility query replies to the registered pid via the NRT ring" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()

    :ok = :clockwork.send_osc(osc_message("/clockwork/clock/visibility/get"))

    assert {:ok, reply} = wait_for_reply_matching("/clockwork/clock/visibility.reply")
    assert is_binary(reply)
  end

  test "RT (scsynth) and NRT (clock) replies both reach the same pid" do
    :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()

    # /version → scsynth reply on the RT OUT ring.
    :ok = :clockwork.send_osc(osc_message("/version"))
    assert {:ok, _} = wait_for_reply_matching("/version.reply")

    # /clock/tempo/get → reply on the NRT-out ring. Same registered pid.
    :ok = :clockwork.send_osc(osc_message("/clockwork/clock/tempo/get"))
    assert {:ok, _} = wait_for_reply_matching("/clockwork/clock/tempo.reply")
  end

  # ── Config options ───────────────────────────────────────────────────────

  # ── Files: answered as the server answers them ──────────────────────────
  #
  # The engine reads no files. The NIF sends through supersonic::Commands, as the
  # native server does, which reads them on a thread of its own and hands the
  # engine bytes: a BEAM client says /d_load and /b_allocRead as any scsynth
  # client does, and nothing is read on the audio thread.

  @synthdefs Path.expand("../../../packages/supersonic-scsynth-synthdefs/synthdefs", __DIR__)
  @samples Path.expand("../../../packages/supersonic-scsynth-samples/samples", __DIR__)

  defp osc_message_s(address, str) do
    osc_string(address) <> osc_string(",s") <> osc_string(str)
  end

  defp osc_message_is(address, int_arg, str) do
    osc_string(address) <> osc_string(",is") <> <<int_arg::signed-big-32>> <> osc_string(str)
  end

  test "/d_load reads a definition and answers /done, as the server does" do
    assert :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    path = Path.join(@synthdefs, "sonic-pi-beep.scsyndef")
    assert File.exists?(path)
    assert :ok = :clockwork.send_osc(osc_message_s("/d_load", path))
    assert {:ok, reply} = wait_for_reply_matching("/done", 5000)
    assert String.contains?(reply, "/d_load")
  end

  test "/b_allocRead reads a sample into a buffer and answers /done, as the server does" do
    assert :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    path = Path.join(@samples, "bd_haus.flac")
    assert File.exists?(path)
    assert :ok = :clockwork.send_osc(osc_message_is("/b_allocRead", 0, path))
    assert {:ok, reply} = wait_for_reply_matching("/done", 5000)
    assert String.contains?(reply, "/b_allocRead")
  end

  test "/clockwork/record/start and /stop record the main output to a file, as the server does" do
    assert :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    path = Path.join(System.tmp_dir!(), "supersonic-nif-rec-#{System.unique_integer([:positive])}.wav")
    on_exit(fn -> File.rm(path) end)
    assert :ok = :clockwork.send_osc(osc_message_s("/clockwork/record/start", path))
    assert {:ok, started} = wait_for_reply_matching("/clockwork/record/start.reply", 5000)
    assert String.contains?(started, path)
    assert :ok = :clockwork.send_osc(osc_message("/clockwork/record/stop"))
    assert {:ok, stopped} = wait_for_reply_matching("/clockwork/record/stop.reply", 5000)
    assert String.contains?(stopped, path)
    assert File.exists?(path)
    assert {:ok, <<"RIFF", _::binary>>} = File.read(path)
  end

  test "/quit is refused: the NIF's engine is stopped with stop/0" do
    assert :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    assert :ok = :clockwork.send_osc(osc_message("/quit"))
    assert {:ok, reply} = wait_for_reply_matching("/fail")
    assert String.contains?(reply, "stop/0")
    # And the engine carries on.
    assert :ok = :clockwork.send_osc(osc_message("/version"))
    assert {:ok, _} = wait_for_reply_matching("/version.reply")
  end

  # scsynth says what heap its pool needs and the engine takes one that holds
  # it, here as on the server: a pool past the default heap boots.
  test "a real-time pool larger than the default heap boots and answers" do
    assert :ok = start_sync(start_config(%{real_time_memory_size: 65536}))
    :ok = :clockwork.set_notification_pid()
    assert :ok = :clockwork.send_osc(osc_message("/status"))
    assert {:ok, _} = wait_for_reply_matching("/status.reply")
  end

  # ── What start/1 and send_osc/1 say when they cannot do what was asked ──

  # A boot scsynth refuses — an option it does not know, a value it will not
  # take — is an error naming it, and leaves no engine running.
  test "a boot scsynth refuses reports why, and leaves the engine stopped" do
    for {config, named} <- [{%{no_such_option: 1}, "no_such_option"}, {%{max_nodes: 1.5}, "max_nodes"}] do
      assert {:error, reason} = start_sync(start_config(config))
      assert to_string(reason) =~ named
      assert {:error, :not_running} = :clockwork.send_osc(osc_message("/status"))
    end
  end

  # A key or value the NIF cannot read is refused, naming it, rather than
  # left out of the boot.
  test "start options the NIF cannot read are refused, naming the key" do
    for {config, named} <- [
          {Map.merge(start_config(), %{"max_nodes" => 512}), "max_nodes"},
          {Map.merge(start_config(), %{max_nodes: ~c"abc"}), "max_nodes"},
          {Map.merge(start_config(), %{sample_rate: 44100.0}), "sample_rate"},
          {%{headless: "true"}, "headless"}
        ] do
      assert {:error, reason} = start_sync(config)
      assert to_string(reason) =~ named
      assert {:error, :not_running} = :clockwork.send_osc(osc_message("/status"))
    end
  end

  test "start/1 takes a map" do
    assert_raise ArgumentError, fn -> :clockwork.start(:not_a_map) end
  end

  test "a packet too big for the engine's ring at any moment is refused" do
    assert :ok = start_sync(start_config())
    blob = :binary.copy(<<0>>, 4 * 1024 * 1024)
    packet = osc_string("/big") <> osc_string(",b") <> <<byte_size(blob)::big-32>> <> blob
    assert {:error, :too_big} = :clockwork.send_osc(packet)
    assert :ok = :clockwork.send_osc(osc_message("/status"))
  end

  defp osc_message_iii(address, a, b, c) do
    osc_string(address) <> osc_string(",iii") <> <<a::signed-big-32, b::signed-big-32, c::signed-big-32>>
  end

  # The cue server hears OSC from the network, and a subscribed process gets
  # each message as /external-osc-cue, as a socket client does.
  test "an OSC cue reaches a subscribed process" do
    assert :ok = start_sync(start_config())
    :ok = :clockwork.set_notification_pid()
    {:ok, probe} = :gen_udp.open(0, [:binary])
    {:ok, port} = :inet.port(probe)
    :ok = :gen_udp.close(probe)
    assert :ok = :clockwork.send_osc(osc_message_iii("/clockwork/osc/cue-server/config", port, 1, 1))
    assert :ok = :clockwork.send_osc(osc_message("/clockwork/osc/notify/subscribe"))

    {:ok, sock} = :gen_udp.open(0, [:binary])
    cue = osc_message("/hello", 42)
    heard =
      Enum.find_value(1..40, fn _ ->
        :ok = :gen_udp.send(sock, {127, 0, 0, 1}, port, cue)
        case wait_for_reply_matching("/external-osc-cue", 100) do
          {:ok, reply} -> reply
          :timeout -> nil
        end
      end)
    :gen_udp.close(sock)
    assert heard, "no /external-osc-cue arrived"
    assert String.contains?(heard, "/hello")
  end

  test "start with custom config" do
    config = start_config(%{
      sample_rate: 44100,
      num_output_channels: 2,
      num_input_channels: 0,
      max_nodes: 512,
      num_buffers: 256
    })
    assert :ok = start_sync(config)
  end
end
