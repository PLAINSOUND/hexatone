// Contract test: js/lib/metrics_offsets.js must mirror the authoritative C++
// PerformanceMetrics layout in src/shared_memory.h.
//
// shared_memory.h is the source of truth: its CLOCKWORK_ASSERT_METRIC(field, idx)
// static_asserts enforce, at compile time, that each struct field sits at its
// declared index. This test enforces the other half of the contract — that the
// JS offset constants the workers/readers use match those same indices — so a
// renumber on one side can never silently drift from the other (the failure that
// otherwise only surfaces as a wrong metric value at runtime).
//
// If you add a C++ metric, add its JS mapping here; the test fails until you do.
import { test, expect } from '@playwright/test';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

// C++ PerformanceMetrics field  →  metrics_offsets.js constant.
const CPP_TO_JS = {
  process_count:                 'ENGINE_PROCESS_COUNT',
  messages_processed:            'ENGINE_MESSAGES_PROCESSED',
  messages_dropped:              'ENGINE_MESSAGES_DROPPED',
  scheduler_queue_depth:         'ENGINE_SCHEDULER_DEPTH',
  scheduler_queue_max:           'ENGINE_SCHEDULER_PEAK_DEPTH',
  scheduler_queue_dropped:       'ENGINE_SCHEDULER_DROPPED',
  messages_sequence_gaps:        'ENGINE_SEQUENCE_GAPS',
  wasm_errors:                   'ENGINE_WASM_ERRORS',
  scheduler_lates:               'ENGINE_SCHEDULER_LATES',
  clockwork_commit:              'CLOCKWORK_COMMIT',
  scheduler_capacity:            'SCHEDULER_CAPACITY',
  scheduler_pool_bytes:          'SCHEDULER_POOL_BYTES',
  osc_out_messages_sent:         'OSC_OUT_MESSAGES_SENT',
  osc_out_bytes_sent:            'OSC_OUT_BYTES_SENT',
  osc_in_messages_received:      'OSC_IN_MESSAGES_RECEIVED',
  osc_in_bytes_received:         'OSC_IN_BYTES_RECEIVED',
  osc_in_dropped_messages:       'OSC_IN_DROPPED_MESSAGES',
  osc_in_corrupted:              'OSC_IN_CORRUPTED',
  debug_messages_received:       'DEBUG_MESSAGES_RECEIVED',
  debug_bytes_received:          'DEBUG_BYTES_RECEIVED',
  in_buffer_used_bytes:          'IN_BUFFER_USED_BYTES',
  out_buffer_used_bytes:         'OUT_BUFFER_USED_BYTES',
  nrt_out_buffer_used_bytes:       'NRT_OUT_BUFFER_USED_BYTES',
  in_buffer_peak_bytes:          'IN_BUFFER_PEAK_BYTES',
  out_buffer_peak_bytes:         'OUT_BUFFER_PEAK_BYTES',
  nrt_out_buffer_peak_bytes:       'NRT_OUT_BUFFER_PEAK_BYTES',
  scheduler_max_late_ms:         'ENGINE_SCHEDULER_MAX_LATE_MS',
  scheduler_last_late_ms:        'ENGINE_SCHEDULER_LAST_LATE_MS',
  scheduler_last_late_tick:      'ENGINE_SCHEDULER_LAST_LATE_TICK',
  ring_buffer_direct_write_fails:'RING_BUFFER_DIRECT_WRITE_FAILS',
  supersonic_version_major:      'SUPERSONIC_VERSION_MAJOR',
  supersonic_version_minor:      'SUPERSONIC_VERSION_MINOR',
  supersonic_version_patch:      'SUPERSONIC_VERSION_PATCH',
  audio_sample_rate:             'AUDIO_SAMPLE_RATE',
  audio_block_size:              'AUDIO_BLOCK_SIZE',
  audio_output_channels:         'AUDIO_OUTPUT_CHANNELS',
  audio_input_channels:          'AUDIO_INPUT_CHANNELS',
  clock_tempo_mbpm:              'CLOCK_TEMPO_MBPM',
  clock_beat_centi:              'CLOCK_BEAT_CENTI',
  clock_phase_centi:             'CLOCK_PHASE_CENTI',
  clock_playing:                 'CLOCK_PLAYING',
  guest_pool_used_bytes:         'GUEST_POOL_USED_BYTES',
  guest_pool_peak_bytes:         'GUEST_POOL_PEAK_BYTES',
  egress_frames_refused:         'EGRESS_FRAMES_REFUSED',
  rust_heap_used_bytes:          'RUST_HEAP_USED_BYTES',
  rust_heap_fallbacks:           'RUST_HEAP_FALLBACKS',
  guest_malloc_bytes:            'GUEST_MALLOC_BYTES',
  guest_mallocs_processing:      'GUEST_MALLOCS_PROCESSING',
  mallocs_after_boot:            'MALLOCS_AFTER_BOOT',
  malloc_bytes_after_boot:       'MALLOC_BYTES_AFTER_BOOT',
  egress_frames_undelivered:     'EGRESS_FRAMES_UNDELIVERED',
  params_live:                   'PARAMS_LIVE',
  params_generation:             'PARAMS_GENERATION',
  param_moves:                   'PARAM_MOVES',
  params_refused:                'PARAMS_REFUSED',
  subsystems:                    'SUBSYSTEMS',
  clock_drift_us:                'CLOCK_DRIFT_US',
  clock_anchors:                 'CLOCK_ANCHORS',
  scheduler_late_dropped: 'SCHEDULER_LATE_DROPPED',
  cues_dropped:           'CUES_DROPPED',
  device_missed_cycles:     'DEVICE_MISSED_CYCLES',
  device_clock_jumps:       'DEVICE_CLOCK_JUMPS',
  device_clock_jump_frames: 'DEVICE_CLOCK_JUMP_FRAMES',
  silent_callbacks:         'SILENT_CALLBACKS',
  callback_gap_recent_us:   'CALLBACK_GAP_RECENT_US',
  callback_gap_max_us:      'CALLBACK_GAP_MAX_US',
};

// Pure padding slots — asserted in C++ for alignment but have no JS counterpart.
const CPP_PADDING = new Set(['_metrics_reserved2', '_client_side']);

test('metrics_offsets.js mirrors the authoritative C++ PerformanceMetrics layout', () => {
  const hdr = readFileSync(join(ROOT, 'clockwork/src/shared_memory.h'), 'utf8');
  const js  = readFileSync(join(ROOT, 'clockwork/js/lib/metrics_offsets.js'), 'utf8');

  const cpp = {};
  for (const m of hdr.matchAll(/CLOCKWORK_ASSERT_METRIC\(\s*(\w+)\s*,\s*(\d+)\s*\)/g))
    cpp[m[1]] = Number(m[2]);

  const jsOff = {};
  for (const m of js.matchAll(/export const (\w+)\s*=\s*(\d+)\s*;/g))
    jsOff[m[1]] = Number(m[2]);

  expect(Object.keys(cpp).length, 'no CLOCKWORK_ASSERT_METRIC lines parsed').toBeGreaterThan(10);

  const unmapped = [];
  const mismatches = [];
  for (const [field, idx] of Object.entries(cpp)) {
    if (CPP_PADDING.has(field)) continue;
    const jsName = CPP_TO_JS[field];
    if (!jsName) { unmapped.push(`${field} (C++ @${idx})`); continue; }
    if (jsOff[jsName] === undefined) mismatches.push(`${field}: JS const ${jsName} not found`);
    else if (jsOff[jsName] !== idx)
      mismatches.push(`${field}: C++ @${idx} but ${jsName} @${jsOff[jsName]}`);
  }

  // A new/renamed C++ metric with no JS mapping must be added to CPP_TO_JS.
  expect(unmapped, 'C++ metrics with no JS mapping — add them to CPP_TO_JS').toEqual([]);
  // The core invariant: every mapped offset agrees.
  expect(mismatches, 'C++/JS metric offset drift').toEqual([]);
});
