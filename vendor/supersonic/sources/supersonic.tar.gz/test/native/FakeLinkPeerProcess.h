// FakeLinkPeerProcess — RAII wrapper around the supersonic_test_link_peer
// binary. Spawns it as a child process with the requested options, blocks
// until the child writes its "ready" line on stdout, and terminates +
// reaps on destruction.
//
// POSIX:   fork + execv + waitpid + SIGTERM (then SIGKILL on timeout).
// Windows: CreateProcess + anonymous pipe + TerminateProcess +
//          WaitForSingleObject.
//
// Only available on builds with CLOCKWORK_LINK; the peer binary itself
// is gated on CLOCKWORK_ENABLE_LINK in CMakeLists.txt.

#pragma once

#ifdef CLOCKWORK_LINK

#include <chrono>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

class FakeLinkPeerProcess {
public:
    struct Channel {
        std::string name;
        int         numChannels = 2;
        std::string generator   = "silence";
    };

    struct Options {
        std::string name         = "TestPeer";
        bool        loopbackOnly = true;
        double      bpm          = 120.0;
        int         blockSize    = 1024;
        int         sampleRate   = 48000;
        // How long the peer's callback stops for when stall() is called
        // (0: it can't): the frames are never made, and the stream resumes
        // stamped at the present.
        std::chrono::milliseconds stallFor{0};
        // Whether the peer keeps its own timing, for timing().
        bool reportTiming = false;
        std::vector<Channel> channels;
        std::chrono::milliseconds readyTimeout{5000};
    };

    // What the peer saw of its own timing, in slots from t0 on the steady
    // clock every process on the machine shares: in each, how late its
    // publishing woke, how long Link's thread, which sends what it publishes,
    // kept a task waiting, and the blocks it could not publish for a full
    // queue to that thread.
    struct Timing {
        std::chrono::steady_clock::time_point t0;
        std::chrono::steady_clock::duration   slot = std::chrono::milliseconds(10);
        std::vector<int32_t> lateUs, waitUs, skipped;
    };

    explicit FakeLinkPeerProcess(const Options& opts);
    ~FakeLinkPeerProcess();

    FakeLinkPeerProcess(const FakeLinkPeerProcess&) = delete;
    FakeLinkPeerProcess& operator=(const FakeLinkPeerProcess&) = delete;

    // True if spawn succeeded and the child printed "ready" before
    // readyTimeout. False otherwise — caller should treat as a failed
    // fixture (the destructor still cleans up safely).
    bool ready() const { return mReady; }

    const Options& options() const { return mOptions; }

    // Stall the peer's callback now, for Options::stallFor. The signal is a
    // file the peer looks for once a block, the one signal every platform
    // can send a child; it takes effect within a block.
    void stall();

    // The peer's timing (Options::reportTiming) as it stood once it had
    // written past `after`, which it does every 100 ms: nothing if it had
    // not within a second.
    std::optional<Timing> timing(std::chrono::steady_clock::time_point after) const;

    // The peer process, for a failure to say: running, exited (with its
    // status) or killed (with the signal), and the Link peers and the
    // session's channels it last saw, which it writes every 100 ms.
    std::string account() const;

private:
    Options     mOptions;
    std::string mStallFlag;   // the file that says stall
    std::string mReport;      // the file the peer keeps its timing in
    std::string mView;        // the file the peer keeps what it sees in
    // Opaque process handle. On POSIX this is a pid_t; on Windows a
    // HANDLE cast to intptr_t (-1 / 0 = invalid). The .cpp casts back
    // as needed under platform #ifdefs.
    intptr_t mProcess     = -1;
    intptr_t mWinThread   = 0;   // Windows only: the thread handle
                                 // returned by CreateProcess; needs its
                                 // own CloseHandle.
    bool    mReady        = false;
    // POSIX: the child's wait status once account() has reaped it. A reaped
    // pid can be reused, so the destructor signals only an unreaped child.
    mutable bool mReaped     = false;
    mutable int  mWaitStatus = 0;
};

#endif  // CLOCKWORK_LINK
