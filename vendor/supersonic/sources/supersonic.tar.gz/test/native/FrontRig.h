// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Sam Aaron
/*
 * FrontRig.h — supersonic::Commands around an in-process engine, wired as the
 * server wires it (SuperSonicMain.cpp): the engine's transport is clockwork's
 * FrontedTransport, so every reply is offered to the front first, in the
 * order the engine delivers them, and a recording sink stands in for the
 * socket.
 *
 * When the test is the host (EngineFixture::testIsTheHost, the default), the
 * front starts no threads (Commands::Work::Host): its file jobs and a
 * recording's copying are the fixture's host work, run after each block's
 * control pass. The test thread is then the one thing that moves, and a wait
 * here is a count of blocks. With a driver rendering, the front has its own
 * threads, as in the server.
 */
#pragma once

#include "CallbackTransport.h"
#include "EngineFixture.h"
#include "IOscTransport.h"
#include "OscFront.h"
#include "OscTestUtils.h"
#include "supersonic_commands.h"

#include <chrono>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

// The socket: everything delivered to the client is kept, in order, each with
// its token. That is the front's own answers and what the engine said that
// the front let pass.
struct RecordingSink final : IOscTransport {
    struct Sent { uint32_t token; OscReply reply; };
    std::mutex        mu;
    std::vector<Sent> sent;
    // Where a delivery goes on to: the fixture's own reply log.
    IOscTransport*    next = nullptr;

    bool deliver(const uint8_t* d, uint32_t n, uint32_t token) override {
        {
            std::lock_guard<std::mutex> lock(mu);
            sent.push_back({ token, OscReply{ osc_test::parseAddress(d, n), std::vector<uint8_t>(d, d + n), token } });
        }
        return next ? next->deliver(d, n, token) : true;
    }

    // The first reply at `addr` for `token`, and with `cmd`, the first whose
    // first string argument is `cmd` (scsynth's /done and /fail name the
    // command).
    bool find(const char* addr, uint32_t token, const char* cmd, OscReply* out) {
        std::lock_guard<std::mutex> lock(mu);
        for (const auto& s : sent) {
            if (s.token != token || s.reply.address != addr) continue;
            if (cmd && (s.reply.parsed().argCount() < 1 || s.reply.parsed().argString(0) != cmd)) continue;
            if (out) *out = s.reply;
            return true;
        }
        return false;
    }
    size_t count(const char* addr, uint32_t token) {
        std::lock_guard<std::mutex> lock(mu);
        size_t n = 0;
        for (const auto& s : sent) if (s.token == token && s.reply.address == addr) ++n;
        return n;
    }
    void clear() {
        std::lock_guard<std::mutex> lock(mu);
        sent.clear();
    }
};

struct FrontRig {
    using Work = supersonic::Commands::Work;

    RecordingSink    sink;
    FrontedTransport fronted;
    const Work       work;
private:
    // The transport the engine's replies leave by is in place before it
    // boots, as the server's is; the front is made after, over the handle the
    // booted engine hands out, as the server makes it.
    std::unique_ptr<CallbackTransport>    mSocket;   // after the sink: the fixture's own reply log
public:
    EngineFixture         fx;
private:
    std::unique_ptr<supersonic::Commands> mFront;
public:
    supersonic::Commands& front;

    // Host work when the test is the host; the front's own threads otherwise.
    explicit FrontRig(const ClockworkEngine::Config& cfg = EngineFixture::defaultConfig())
        : FrontRig(cfg, cfg.manualAudioPump && cfg.hostDrivesControl ? Work::Host : Work::Own) {}
    // A case that needs the front on threads of its own whoever renders: one
    // timing its blocks, which must not include the front's work.
    FrontRig(const ClockworkEngine::Config& cfg, Work w)
        : work(w),
          fx(cfg, [this](ClockworkEngine& engine) {
              mSocket = std::make_unique<CallbackTransport>(&engine.onReply);
              sink.next = mSocket.get();
              fronted.attach(&sink, nullptr);
              engine.setTransport(&fronted);
          }),
          mFront(std::make_unique<supersonic::Commands>(fx.engine().newClient(), &sink, work)),
          front(*mFront) {
        // What passes the front reaches the sink, as the front's own answers do.
        fronted.attach(&sink, mFront.get());
        if (work == Work::Host) fx.setHostWork([this] { front.runPending(); });
    }
    ~FrontRig() {
        fx.setHostWork(nullptr);
        // The engine stops calling into the front, then the front goes, then
        // the engine (the fixture's own shutdown): a client goes before its
        // core, as EmbeddedHost::shutdown orders them, so a recording in
        // progress drains its last frames from a core that is still there.
        fronted.detachFront();
        mFront.reset();
    }
    FrontRig(const FrontRig&) = delete;
    FrontRig& operator=(const FrontRig&) = delete;

    // Whether this thread moves everything a wait waits for: the engine's
    // blocks and passes, and the front's work.
    bool testMovesAll() const { return work == Work::Host && fx.testIsTheHost(); }

    // The first reply at `addr` for `token` (RecordingSink::find) within
    // `timeoutMs`: of audio, a block a turn, when the test moves everything;
    // of wall clock otherwise. `turn`, given, is what a turn does instead: a
    // case timing its blocks pumps them itself.
    bool waitFor(const char* addr, uint32_t token, const char* cmd, OscReply* out,
                 int timeoutMs = 5000, const std::function<void()>& turn = {}) {
        if (testMovesAll()) {
            for (uint32_t owed = fx.blocksOfAudio(timeoutMs);; --owed) {
                if (sink.find(addr, token, cmd, out)) return true;
                if (!owed) return false;
                if (turn) turn(); else fx.pumpBlock();
            }
        }
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
        while (std::chrono::steady_clock::now() < deadline) {
            if (sink.find(addr, token, cmd, out)) return true;
            if (turn) turn(); else idle();
        }
        return sink.find(addr, token, cmd, out);
    }

    // A wait's pause between looks: a block (with its control pass and the
    // host work) when the test pumps, and a moment for the other threads when
    // they move things too.
    void idle() {
        if (fx.manualPump()) fx.pumpBlock();
        if (!testMovesAll()) std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
};
