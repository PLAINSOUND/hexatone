/*
 * test_multichannel.cpp — Multichannel input/output and recording tests
 *
 * Verifies that the engine boots and processes audio correctly with
 * various channel configurations (mono, stereo, 4ch, 8ch, 16ch).
 * Also tests the recording start/stop API.
 */
#include "EngineFixture.h"

#include <thread>
#include <chrono>
#include "clock/clock_math.h"   // wallClockNTP
#include <filesystem>
#include <cstring>
#include <algorithm>
#include <cmath>

extern "C" {
    bool process_audio(double current_time, uint32_t active_output_channels,
                       uint32_t active_input_channels);
    uintptr_t get_audio_output_bus();
    uintptr_t get_audio_input_bus();
}

// ── Helper: boot engine with given channel config ────────────────────────────

static void bootAndVerify(int outCh, int inCh) {
    ClockworkEngine engine;
    engine.onReply = [](const uint8_t*, uint32_t) {};

    ClockworkEngine::Config cfg;
    cfg.headless          = true;
    cfg.udpPort           = 0;
    cfg.numOutputChannels = outCh;
    cfg.numInputChannels  = inCh;
    engine.init(cfg);

    // init() blocks until HeadlessDriver fires at least one audio
    // block — if the channel config would crash process_audio(), we'd
    // already know by this point.
    REQUIRE(engine.isRunning());

    engine.shutdown();
    CHECK_FALSE(engine.isRunning());
}

// ── 1. Boot with various output channel counts ──────────────────────────────

TEST_CASE("Engine boots with 1 output channel", "[multichannel]") {
    bootAndVerify(1, 0);
}

TEST_CASE("Engine boots with 2 output channels (stereo)", "[multichannel]") {
    bootAndVerify(2, 2);
}

TEST_CASE("Engine boots with 4 output channels", "[multichannel]") {
    bootAndVerify(4, 0);
}

TEST_CASE("Engine boots with 8 output channels", "[multichannel]") {
    bootAndVerify(8, 0);
}

TEST_CASE("Engine boots with 16 output channels", "[multichannel]") {
    bootAndVerify(16, 0);
}

TEST_CASE("Engine boots with 32 output channels", "[multichannel]") {
    bootAndVerify(32, 0);
}

// ── 2. Boot with various input channel counts ───────────────────────────────

TEST_CASE("Engine boots with 1 input channel", "[multichannel]") {
    bootAndVerify(2, 1);
}

TEST_CASE("Engine boots with 4 input channels", "[multichannel]") {
    bootAndVerify(2, 4);
}

TEST_CASE("Engine boots with 8 input channels", "[multichannel]") {
    bootAndVerify(2, 8);
}

TEST_CASE("Engine boots with 16 input channels", "[multichannel]") {
    bootAndVerify(2, 16);
}

// ── 3. Symmetric multichannel (same in/out) ─────────────────────────────────

TEST_CASE("Engine boots with 4in/4out", "[multichannel]") {
    bootAndVerify(4, 4);
}

TEST_CASE("Engine boots with 8in/8out", "[multichannel]") {
    bootAndVerify(8, 8);
}

// ── 4. Output bus has correct layout for multichannel ────────────────────────

TEST_CASE("Output bus has correct channel-major layout", "[multichannel]") {
    int outCh = 4;
    int inCh  = 2;

    ClockworkEngine engine;
    bool gotReply = false;
    engine.onReply = [&](const uint8_t*, uint32_t) { gotReply = true; };

    ClockworkEngine::Config cfg;
    cfg.headless          = true;
    cfg.udpPort           = 0;
    // Manual pump: this test drives process_audio() directly on the test
    // thread, so the engine must NOT start its own headless driver thread —
    // otherwise both threads call process_audio() concurrently (data race).
    cfg.manualAudioPump   = true;
    cfg.numOutputChannels = outCh;
    cfg.numInputChannels  = inCh;
    engine.init(cfg);

    REQUIRE(engine.isRunning());

    auto* outputBus = reinterpret_cast<float*>(get_audio_output_bus());
    REQUIRE(outputBus != nullptr);

    // Poison the entire channel-major output region with a sentinel. A
    // correctly-striding process_audio() must overwrite every channel's full
    // 128-sample (QUANTUM_SIZE) span; with no synths running it produces exact
    // silence, so any surviving sentinel would expose a clearing/layout gap.
    // Exact equality is sound here: this thread is the only process_audio()
    // caller, so nothing races writes to the bus.
    constexpr float kSentinel = 1234.5f;
    for (int i = 0; i < outCh * 128; ++i) outputBus[i] = kSentinel;

    // Pump one block (this thread is the sole caller of process_audio).
    double baseNTP = wallClockNTP();
    process_audio(baseNTP, static_cast<uint32_t>(outCh), static_cast<uint32_t>(inCh));

    // Every channel's full span must read exact silence.
    for (int ch = 0; ch < outCh; ++ch) {
        float maxAbs = 0.0f;
        for (int s = 0; s < 128; ++s)
            maxAbs = std::max(maxAbs, std::fabs(outputBus[ch * 128 + s]));
        INFO("output channel " << ch << " maxAbs=" << maxAbs);
        CHECK(maxAbs == 0.0f);
    }

    engine.shutdown();
}

// ── 5. Input bus has correct layout for multichannel ─────────────────────────

TEST_CASE("Input bus has correct channel-major layout", "[multichannel]") {
    int outCh = 2;
    int inCh  = 4;

    ClockworkEngine engine;
    engine.onReply = [](const uint8_t*, uint32_t) {};

    ClockworkEngine::Config cfg;
    cfg.headless          = true;
    cfg.udpPort           = 0;
    // Manual pump: this test drives process_audio() directly on the test
    // thread, so the engine must NOT start its own headless driver thread —
    // otherwise both threads call process_audio() concurrently (data race).
    cfg.manualAudioPump   = true;
    cfg.numOutputChannels = outCh;
    cfg.numInputChannels  = inCh;
    engine.init(cfg);

    REQUIRE(engine.isRunning());

    auto* inputBus = reinterpret_cast<float*>(get_audio_input_bus());
    REQUIRE(inputBus != nullptr);
    auto* outputBus = reinterpret_cast<float*>(get_audio_output_bus());
    REQUIRE(outputBus != nullptr);

    // Distinct per-channel pattern in the input region (simulating JUCE's
    // input copy), so a channel-major layout error would surface as a wrong
    // or zero value in the readback below.
    auto inVal = [](int ch) { return static_cast<float>(ch + 1) * 0.1f; };
    for (int ch = 0; ch < inCh; ++ch)
        for (int s = 0; s < 128; ++s)
            inputBus[ch * 128 + s] = inVal(ch);

    // Poison the output region: no synth routes input->output, so the block
    // must leave exact silence.
    constexpr float kSentinel = 1234.5f;
    for (int i = 0; i < outCh * 128; ++i) outputBus[i] = kSentinel;

    // Pump one block (this thread is the sole caller of process_audio).
    double baseNTP = wallClockNTP();
    process_audio(baseNTP, static_cast<uint32_t>(outCh), static_cast<uint32_t>(inCh));

    // Output is exact silence across every channel.
    for (int ch = 0; ch < outCh; ++ch) {
        float maxAbs = 0.0f;
        for (int s = 0; s < 128; ++s)
            maxAbs = std::max(maxAbs, std::fabs(outputBus[ch * 128 + s]));
        INFO("output channel " << ch << " maxAbs=" << maxAbs);
        CHECK(maxAbs == 0.0f);
    }

    // Input region is read but not clobbered: each channel still holds its
    // distinct value across its full contiguous span (channel-major).
    for (int ch = 0; ch < inCh; ++ch) {
        bool intact = true;
        for (int s = 0; s < 128; ++s)
            if (inputBus[ch * 128 + s] != inVal(ch)) { intact = false; break; }
        INFO("input channel " << ch << " expected " << inVal(ch));
        CHECK(intact);
    }

    engine.shutdown();
}

// ── 6. Prefetch buffer is correctly sized ────────────────────────────────────

TEST_CASE("Prefetch buffer resizes for channel count", "[multichannel]") {
    // Boot with 8 output channels — prefetch should be 8 * 128 = 1024 floats
    ClockworkEngine engine;
    engine.onReply = [](const uint8_t*, uint32_t) {};

    ClockworkEngine::Config cfg;
    cfg.headless          = true;
    cfg.udpPort           = 0;
    cfg.numOutputChannels = 8;
    cfg.numInputChannels  = 0;
    engine.init(cfg);

    REQUIRE(engine.isRunning());

    // If prefetch was still hardcoded to kMaxChannels=8, this would have worked
    // previously. But with 16 channels it would have crashed. Boot with 16 to
    // verify dynamic sizing works.
    engine.shutdown();

    ClockworkEngine engine2;
    engine2.onReply = [](const uint8_t*, uint32_t) {};

    ClockworkEngine::Config cfg2;
    cfg2.headless          = true;
    cfg2.udpPort           = 0;
    cfg2.numOutputChannels = 16;
    cfg2.numInputChannels  = 0;
    engine2.init(cfg2);
    REQUIRE(engine2.isRunning());

    // HeadlessDriver is already processing with 16 channels —
    // if the prefetch buffer were too small, init() would have crashed.

    engine2.shutdown();
}

// ── 7. Recording start/stop API ─────────────────────────────────────────────

// The engine's recording API is gone: the engine opens no files. Session
// recording is the front's (front/Recorder.h; test_front_recording.cpp).
