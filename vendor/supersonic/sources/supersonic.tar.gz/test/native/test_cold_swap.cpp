/*
 * test_cold_swap.cpp — Cold swap (destroy world + rebuild) tests
 *
 * Exercises switchDevice() in headless mode, covering:
 *   - Successful cold swap (rate change)
 *   - Failed cold swap (rollback)
 *   - State machine transitions
 *   - Event emission
 *   - Hot swap (same rate)
 *   - Concurrent rejection
 *   - Round-trip cold swaps
 */
#include <catch2/catch_test_macros.hpp>
#include "EngineFixture.h"
#include "OscBuilder.h"
#include <thread>
#include <chrono>
#include <atomic>

// ── Successful cold swap ─────────────────────────────────────────────────────

TEST_CASE("ColdSwap: successful rate change 48000 -> 44100", "[ColdSwap]") {
    EngineFixture fix;

    // Verify engine is alive at 48000
    OscReply reply;
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));

    // Track swap events
    std::vector<std::string> events;
    fix.engine().onSwapEvent = [&](const std::string& event, const SwapResult&) {
        events.push_back(event);
    };

    // Cold swap to 44100
    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE(result.success);
    REQUIRE(result.type == SwapType::Cold);
    REQUIRE(static_cast<int>(result.sampleRate) == 44100);

    // Engine state should be Running after swap
    REQUIRE(fix.engine().engineState() == EngineState::Running);

    // Engine should respond to OSC at new rate
    fix.clearReplies();
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));

    // Verify events
    REQUIRE(events.size() == 2);
    REQUIRE(events[0] == "swap:start");
    REQUIRE(events[1] == "swap:complete");
}

// ── Failed cold swap (rollback) ──────────────────────────────────────────────

TEST_CASE("ColdSwap: failed swap rolls back to original rate", "[ColdSwap]") {
    EngineFixture fix;

    // Verify engine is alive
    OscReply reply;
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));

    // Track swap events
    std::vector<std::string> events;
    fix.engine().onSwapEvent = [&](const std::string& event, const SwapResult&) {
        events.push_back(event);
    };

    // Inject failure
    fix.engine().testSwapFailure = [](bool) -> std::string {
        return "simulated device error";
    };

    // Attempt cold swap — should fail and rollback
    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE_FALSE(result.success);
    REQUIRE(result.error == "simulated device error");

    // Engine state should be Running (rolled back)
    REQUIRE(fix.engine().engineState() == EngineState::Running);

    // Engine should still respond to OSC (alive at original rate)
    fix.clearReplies();
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));

    // Verify events: start then failed
    REQUIRE(events.size() == 2);
    REQUIRE(events[0] == "swap:start");
    REQUIRE(events[1] == "swap:failed");
}

// ── State transitions ────────────────────────────────────────────────────────

TEST_CASE("ColdSwap: state transitions Running -> Restarting -> Running on success",
          "[ColdSwap]") {
    EngineFixture fix;

    std::vector<EngineState> states;
    fix.engine().onSwapEvent = [&](const std::string&, const SwapResult&) {
        states.push_back(fix.engine().engineState());
    };

    REQUIRE(fix.engine().engineState() == EngineState::Running);

    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE(result.success);

    // At swap:start, state should have been Restarting
    REQUIRE(states.size() == 2);
    REQUIRE(states[0] == EngineState::Restarting);
    // At swap:complete, state is already Running (set before the event fires)
    REQUIRE(states[1] == EngineState::Running);

    // Final state should be Running
    REQUIRE(fix.engine().engineState() == EngineState::Running);
}

TEST_CASE("ColdSwap: state transitions Running -> Restarting -> Running on failure",
          "[ColdSwap]") {
    EngineFixture fix;

    std::vector<EngineState> states;
    fix.engine().onSwapEvent = [&](const std::string&, const SwapResult&) {
        states.push_back(fix.engine().engineState());
    };

    fix.engine().testSwapFailure = [](bool) -> std::string {
        return "test failure";
    };

    REQUIRE(fix.engine().engineState() == EngineState::Running);

    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE_FALSE(result.success);

    // At swap:start, state should be Restarting
    REQUIRE(states.size() == 2);
    REQUIRE(states[0] == EngineState::Restarting);
    // At swap:failed, state is already Running (rollback set before the event fires)
    REQUIRE(states[1] == EngineState::Running);

    // Final state should be Running (rolled back)
    REQUIRE(fix.engine().engineState() == EngineState::Running);
}

// ── Hot swap (same rate) ─────────────────────────────────────────────────────

TEST_CASE("ColdSwap: same rate triggers hot swap", "[ColdSwap]") {
    EngineFixture fix;

    std::vector<std::string> events;
    fix.engine().onSwapEvent = [&](const std::string& event, const SwapResult&) {
        events.push_back(event);
    };

    // Switch to same rate (48000) — should be hot swap
    auto result = fix.engine().switchDevice("", 48000);
    REQUIRE(result.success);
    REQUIRE(result.type == SwapType::Hot);

    // Engine should still work
    OscReply reply;
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));

    REQUIRE(events.size() == 2);
    REQUIRE(events[0] == "swap:start");
    REQUIRE(events[1] == "swap:complete");
}

TEST_CASE("ColdSwap: no rate specified triggers hot swap", "[ColdSwap]") {
    EngineFixture fix;

    // No rate specified (0) = keep current rate = hot swap
    auto result = fix.engine().switchDevice("");
    REQUIRE(result.success);
    REQUIRE(result.type == SwapType::Hot);

    OscReply reply;
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));
}

// ── Concurrent rejection ─────────────────────────────────────────────────────

TEST_CASE("ColdSwap: concurrent swap is rejected", "[ColdSwap]") {
    EngineFixture fix;

    // Slow failure hook that signals once it holds mSwapMutex.
    std::atomic<bool> swapEntered{false};
    fix.engine().testSwapFailure = [&swapEntered](bool) -> std::string {
        swapEntered.store(true, std::memory_order_release);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        return "slow failure";
    };

    // Launch first swap in a background thread
    SwapResult firstResult;
    std::thread t1([&]() {
        firstResult = fix.engine().switchDevice("", 44100);
    });

    // Wait until the first swap holds mSwapMutex before issuing the competing
    // swap — a fixed sleep races the lock acquisition on a loaded runner.
    REQUIRE(fix.pollUntil([&] { return swapEntered.load(std::memory_order_acquire); }));

    // Second swap should be rejected immediately
    auto secondResult = fix.engine().switchDevice("", 22050);
    REQUIRE_FALSE(secondResult.success);
    REQUIRE(secondResult.error == "swap already in progress");

    t1.join();

    // First swap should have completed (with failure from the hook)
    REQUIRE_FALSE(firstResult.success);
    REQUIRE(firstResult.error == "slow failure");

    // Engine should still be running after all that
    OscReply reply;
    fix.clearReplies();
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));
}

// ── State cache is called during cold swap — REMOVED ────────────────────────
//
// Two cases asserted StateCache::captureAll() ran before destroy on a cold
// swap, and again on a failed one. StateCache has been deleted: a guest that
// must survive its own destruction now writes into DspConfig::persistent,
// which clockwork carries across the rebuild without reading it. What the
// swap itself must still do is covered by the cases above and below, and by
// clockwork/test/test_rebuild_contract.cpp.

// ── Round-trip cold swaps ────────────────────────────────────────────────────

TEST_CASE("ColdSwap: round-trip 48000 -> 44100 -> 48000", "[ColdSwap]") {
    EngineFixture fix;

    // Swap to 44100
    auto r1 = fix.engine().switchDevice("", 44100);
    REQUIRE(r1.success);
    REQUIRE(r1.type == SwapType::Cold);
    REQUIRE(static_cast<int>(r1.sampleRate) == 44100);

    // Verify engine works
    OscReply reply;
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));
    fix.clearReplies();

    // Swap back to 48000
    auto r2 = fix.engine().switchDevice("", 48000);
    REQUIRE(r2.success);
    REQUIRE(r2.type == SwapType::Cold);
    REQUIRE(static_cast<int>(r2.sampleRate) == 48000);

    // Verify engine still works
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));
}

TEST_CASE("ColdSwap: engine processes OSC after cold swap", "[ColdSwap]") {
    EngineFixture fix;

    // Load synthdef before swap
    REQUIRE(fix.loadSynthDef("sonic-pi-beep"));

    // Cold swap
    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE(result.success);

    // Reload synthdef at new rate (cold swap destroys world)
    fix.clearReplies();
    REQUIRE(fix.loadSynthDef("sonic-pi-beep"));

    // Create default group again (world was rebuilt)
    fix.send(osc_test::message("/g_new", 1, 0, 0));
    OscReply reply;
    auto syncPkt = osc_test::message("/sync", 99);
    fix.engine().sendOSC(syncPkt.ptr(), syncPkt.size());
    REQUIRE(fix.waitForReply("/synced", reply));
    fix.clearReplies();

    // Create and free a synth at the new rate
    {
        osc_test::Builder b;
        auto& s = b.begin("/s_new");
        s << "sonic-pi-beep" << (int32_t)1000 << (int32_t)0 << (int32_t)1
          << "note" << 60.0f << "out_bus" << 0.0f;
        fix.send(b.end());
    }
    fix.send(osc_test::message("/n_free", 1000));

    // Verify engine is still processing
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply));
}

// ── Client re-registration after cold swap ───────────────────────────────────
// After a cold swap the world is rebuilt from scratch. A client must be able to
// re-register for notifications, clear the root group, and create new groups —
// all getting correct replies from the new world.

TEST_CASE("ColdSwap: notify + group clear + group create work after cold swap", "[ColdSwap]") {
    EngineFixture fix;

    // Cold swap 48000 -> 44100 (like switching to AirPlay)
    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE(result.success);
    REQUIRE(result.type == SwapType::Cold);
    fix.clearReplies();

    // Step 1: /notify 1 (Spider re-registers for notifications)
    fix.send(osc_test::message("/notify", 1));
    OscReply reply;
    REQUIRE(fix.waitForReply("/done", reply, 5000));
    fix.clearReplies();

    // Step 2: /g_freeAll 0 + /sync (Spider clears root group)
    fix.send(osc_test::message("/g_freeAll", 0));
    auto syncPkt = osc_test::message("/sync", 42);
    fix.engine().sendOSC(syncPkt.ptr(), syncPkt.size());
    REQUIRE(fix.waitForReply("/synced", reply, 5000));
    fix.clearReplies();

    // Step 3: /g_new (Spider creates groups)
    fix.send(osc_test::message("/g_new", 2, 0, 0));  // STUDIO-MIXER
    REQUIRE(fix.waitForReply("/n_go", reply, 5000));
    fix.clearReplies();

    fix.send(osc_test::message("/g_new", 3, 2, 0));  // STUDIO-FX
    REQUIRE(fix.waitForReply("/n_go", reply, 5000));
    fix.clearReplies();

    // Step 4: Verify engine is still alive
    fix.send(osc_test::message("/status"));
    REQUIRE(fix.waitForReply("/status.reply", reply, 5000));
}

TEST_CASE("ColdSwap: commands work after 1s delay post cold swap", "[ColdSwap]") {
    EngineFixture fix;

    // Cold swap
    auto result = fix.engine().switchDevice("", 44100);
    REQUIRE(result.success);
    fix.clearReplies();

    // Simulate Spider's 1-second debounce delay
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    // Now send commands — they must still work
    fix.send(osc_test::message("/notify", 1));
    OscReply reply;
    REQUIRE(fix.waitForReply("/done", reply, 5000));
    fix.clearReplies();

    fix.send(osc_test::message("/g_freeAll", 0));
    auto syncPkt = osc_test::message("/sync", 99);
    fix.engine().sendOSC(syncPkt.ptr(), syncPkt.size());
    REQUIRE(fix.waitForReply("/synced", reply, 5000));
}

// ── Hot swap does NOT trigger state transitions ──────────────────────────────

TEST_CASE("ColdSwap: hot swap does not transition to Restarting", "[ColdSwap]") {
    EngineFixture fix;

    std::vector<EngineState> states;
    fix.engine().onSwapEvent = [&](const std::string&, const SwapResult&) {
        states.push_back(fix.engine().engineState());
    };

    auto result = fix.engine().switchDevice("", 48000);  // same rate = hot
    REQUIRE(result.success);
    REQUIRE(result.type == SwapType::Hot);

    // State should have been Running throughout (hot swap doesn't go to Restarting)
    for (auto s : states) {
        REQUIRE(s == EngineState::Running);
    }
}
