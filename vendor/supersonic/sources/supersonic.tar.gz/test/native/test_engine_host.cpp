// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Sam Aaron
/*
 * test_engine_host.cpp — the pieces SuperSonic's main is composed from
 * (host/EngineHost.h): the scsynth-shaped command line, and the command
 * transports with their boot queue. No engine: the transports talk to a
 * recorded ingest, exactly as the main wires them to the front and the
 * engine. The process itself is pinned in test_supersonic_binary.cpp.
 */
#include <catch2/catch_test_macros.hpp>

#include "EngineHost.h"
#include "EngineFixture.h"
#include "OscTestUtils.h"
#include "TestSecret.h"

#include <chrono>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#ifndef _WIN32
#  include <arpa/inet.h>
#  include <netinet/in.h>
#  include <sys/socket.h>
#  include <unistd.h>
#endif

namespace {

using supersonic_host::Options;
using supersonic_host::parseArgs;
using supersonic_host::CommandTransports;

Options parse(std::vector<std::string> args, std::string* err = nullptr, bool* ok = nullptr) {
    std::vector<char*> argv;
    static std::string prog = "host";
    argv.push_back(prog.data());
    for (auto& a : args) argv.push_back(a.data());
    Options o;
    std::string e;
    const bool r = parseArgs(static_cast<int>(argv.size()), argv.data(), o, &e);
    if (err) *err = e;
    if (ok) *ok = r;
    return o;
}

} // namespace

TEST_CASE("host args: the scsynth-shaped flags land in the engine's config", "[host][args]") {
    bool ok = false;
    std::string err;
    const Options o = parse({ "-u", "4000", "-a", "512", "-m", "65536", "-Z", "128", "-z", "64",
                              "-B", "127.0.0.1", "-b", "2048", "-n", "4096", "-i", "0", "-o", "2",
                              "-S", "44100", "-w", "128", "-c", "8192",
                              "--default-bpm", "60", "--app-name", "Probe", "--audio-driver", "CoreAudio",
                              "--assets-mb", "64", "--headless", "--tcp", "4100",
                              "-D", "0", "-R", "0", "-l", "1" }, &err, &ok);
    INFO(err);
    REQUIRE(ok);
    CHECK(o.shmPort == 4000);
    CHECK(o.cfg.shmSegment);
    CHECK(guestOption(o.cfg, "numAudioBusChannels") == "512");
    CHECK(guestOption(o.cfg, "realTimeMemorySize") == "65536");
    CHECK(o.cfg.bufferSize == 128);
    CHECK(o.cfg.blockSize == 64);
    CHECK(o.cfg.bindAddress == "127.0.0.1");
    CHECK(guestOption(o.cfg, "numBuffers") == "2048");
    CHECK(guestOption(o.cfg, "maxNodes") == "4096");
    CHECK(o.cfg.numInputChannels == 0);
    CHECK(o.cfg.numOutputChannels == 2);
    CHECK(o.cfg.sampleRate == 44100);
    CHECK(guestOption(o.cfg, "maxWireBufs") == "128");
    CHECK(guestOption(o.cfg, "numControlBusChannels") == "8192");
    CHECK(o.cfg.defaultBpm == 60.0);
    CHECK(o.cfg.appName == "Probe");
    CHECK(o.cfg.audioDriver == "CoreAudio");
    CHECK(o.cfg.assetsBytes == 64u * 1024u * 1024u);
    CHECK(o.cfg.headless);
    CHECK(o.headless);
    // scsynth's own flags that mean nothing here are accepted, not warned about.
    CHECK(o.warnings.empty());
    // -u > 0 derives the segment's endpoint.
    CHECK(o.shmEndpoint.find("4000") != std::string::npos);
    CHECK(o.desiredInputChannels == 0);
}

TEST_CASE("host args: defaults, and what the host derives", "[host][args]") {
    const Options o = parse({ "--tcp", "4009" });
    CHECK(o.shmPort == 57110);
    CHECK(o.cfg.shmSegment);
    CHECK(o.cfg.sampleRate == 48000);
    CHECK(o.cfg.bufferSize == 0);
    CHECK(o.cfg.callbackWatchdog);
    CHECK(o.cfg.assetsBytes == 512u * 1024u * 1024u);   // address space, not memory
    CHECK_FALSE(o.headless);
    CHECK(o.desiredInputChannels == ClockworkEngine::kAutoChannelCount);
    CHECK_FALSE(o.shmEndpoint.empty());

    // -u 0: no segment, no endpoint.
    const Options none = parse({ "-u", "0", "--tcp", "4010" });
    CHECK_FALSE(none.cfg.shmSegment);
    CHECK(none.shmEndpoint.empty());

    // Clamp: a lane past the header's reach is refused quietly.
    const Options big = parse({ "--assets-mb", "99999", "--tcp", "4011" });
    CHECK(big.cfg.assetsBytes == 3072u * 1024u * 1024u);
}

TEST_CASE("host args: an unknown flag is reported, not silently applied", "[host][args]") {
    // An unknown long flag may or may not take a value, so the word after it
    // is reported too; an unknown single-letter flag takes one, as all of
    // scsynth's do.
    const Options o = parse({ "--no-such-flag", "7", "-q", "3", "-u", "4001", "--tcp", "4012" });
    REQUIRE(o.warnings.size() == 3);
    CHECK(o.warnings[0].find("--no-such-flag") != std::string::npos);
    CHECK(o.warnings[1].find("7") != std::string::npos);
    CHECK(o.warnings[2].find("-q") != std::string::npos);
    CHECK(o.shmPort == 4001);   // parsing carried on past them
}

TEST_CASE("host args: -H names the devices, scsynth's way", "[host][args]") {
    const Options one = parse({ "-H", "MacBook Pro Speakers", "--tcp", "4013" });
    CHECK(one.cfg.hardwareDevice == "MacBook Pro Speakers");
    CHECK(one.cfg.inputDevice == "MacBook Pro Speakers");
    const Options two = parse({ "-H", "Mic In", "Speakers Out", "-u", "4002", "--tcp", "4014" });
    CHECK(two.cfg.inputDevice == "Mic In");
    CHECK(two.cfg.hardwareDevice == "Speakers Out");
    CHECK(two.shmPort == 4002);

    // A flag after one name is a flag, not the output.
    const Options flagged = parse({ "-H", "MOTU M4", "-u", "4003", "--tcp", "4015" });
    CHECK(flagged.cfg.inputDevice == "MOTU M4");
    CHECK(flagged.cfg.hardwareDevice == "MOTU M4");
    CHECK(flagged.shmPort == 4003);

    // The sentinels keep to their direction.
    const Options noInputs = parse({ "-H", "__none__", "--tcp", "4016" });
    CHECK(noInputs.cfg.inputDevice == "__none__");
    CHECK(noInputs.cfg.hardwareDevice.empty());
    CHECK(noInputs.cfg.numInputChannels == 0);   // inputs off, as it says
    CHECK(noInputs.desiredInputChannels == 0);
    const Options followDefault = parse({ "-H", "__system__", "--tcp", "4017" });
    CHECK(followDefault.cfg.hardwareDevice == "__system__");
    CHECK(followDefault.cfg.inputDevice.empty());
    const Options both = parse({ "-H", "__none__", "MacBook Pro Speakers", "--tcp", "4018" });
    CHECK(both.cfg.inputDevice == "__none__");
    CHECK(both.cfg.hardwareDevice == "MacBook Pro Speakers");
    CHECK(both.cfg.numInputChannels == 0);
}

// A mistake on the command line stops the boot, naming the flag: a value that
// went missing or is not a number is configuration the caller thinks it gave.
TEST_CASE("host args: a flag missing its value, or a number that is not one, stops the boot", "[host][args]") {
    for (const auto& args : std::vector<std::vector<std::string>>{
             { "-u" }, { "-u", "abc" }, { "-S", "48k" }, { "-i", "two" }, { "-Z" },
             { "--tcp" }, { "--tcp", "x" }, { "--assets-mb" },
             { "--default-bpm", "fast" }, { "-m" }, { "-H" } }) {
        std::string err;
        bool ok = true;
        parse(args, &err, &ok);
        INFO(args[0] << (args.size() > 1 ? " " + args[1] : ""));
        CHECK_FALSE(ok);
        CHECK(err.find(args[0]) != std::string::npos);
    }
}

TEST_CASE("host args: a word that is not a flag, or a long single-dash flag, is reported", "[host][args]") {
    const Options o = parse({ "stray", "-foo", "-u", "4006", "--tcp", "4019" });
    REQUIRE(o.warnings.size() == 2);
    CHECK(o.warnings[0].find("stray") != std::string::npos);
    CHECK(o.warnings[1].find("-foo") != std::string::npos);
    CHECK(o.shmPort == 4006);
}

TEST_CASE("host args: no command transport is refused, and so are two", "[host][args]") {
    std::string err;
    bool ok = true;
    parse({ "-u", "0" }, &err, &ok);
    CHECK_FALSE(ok);
    CHECK(err.find("no command transport") != std::string::npos);
    parse({ "-u", "4008" }, &err, &ok);
    CHECK_FALSE(ok);
    parse({ "--tcp", "4007", "--uds", "/tmp/x.sock" }, &err, &ok);
    CHECK_FALSE(ok);
    CHECK(err.find("exactly one") != std::string::npos);
    parse({ "-u", "0", "--tcp", "4007" }, &err, &ok);
    CHECK(ok);
}

// The secret on stdin: one line of 64 hex digits, and nothing else is one.
TEST_CASE("host secret: 64 hex digits and a newline on stdin, nothing else", "[host][secret]") {
    auto read = [](const std::string& text, std::string* err) {
        Options o;
        FILE* f = tmpfile();   // fmemopen refuses an empty buffer; a file takes any text
        REQUIRE(f);
        REQUIRE(fwrite(text.data(), 1, text.size(), f) == text.size());
        rewind(f);
        const bool ok = supersonic_host::readSecret(o, f, err);
        fclose(f);
        CHECK(ok == (o.secret != nullptr));
        return ok;
    };
    const std::string hex = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f";
    std::string err;
    CHECK(read(hex + "\n", &err));
    CHECK(read(hex + "\r\n", &err));
    CHECK_FALSE(read("", &err));              CHECK(err.find("no secret") != std::string::npos);
    CHECK_FALSE(read(hex, &err));             // no newline: stdin closed mid-line
    CHECK_FALSE(read(hex.substr(2) + "\n", &err));
    CHECK_FALSE(read(hex + "00\n", &err));
    CHECK_FALSE(read(hex.substr(2) + "zz\n", &err));
    CHECK_FALSE(read(std::string(64, '0') + "\n", &err)); CHECK(err.find("zeros") != std::string::npos);
    Options none;
    CHECK_FALSE(supersonic_host::readSecret(none, nullptr, &err));
}

// scsynth's -V is verbosity, and goes to the guest like its other flags; -v is
// the version (SuperSonicMain handles it before parsing).
TEST_CASE("host args: -V sets scsynth's verbosity", "[host][args]") {
    const Options o = parse({ "-V", "2" });
    CHECK(o.cfg.guestConfig.find("verbosity=2") != std::string::npos);
}

#ifdef __APPLE__
// Booted with inputs off because the microphone permission was pending, the
// server turns them on once it is granted — unless inputs were asked to be off.
TEST_CASE("host: inputs wait for the microphone permission only when they were asked for", "[host]") {
    using supersonic_host::inputsWaitForPermission;
    CHECK(inputsWaitForPermission(ClockworkEngine::kAutoChannelCount, "not determined"));
    CHECK(inputsWaitForPermission(2, "denied"));
    CHECK_FALSE(inputsWaitForPermission(0, "not determined"));
    CHECK_FALSE(inputsWaitForPermission(ClockworkEngine::kAutoChannelCount, "authorized"));
}
#endif

TEST_CASE("host args: at most one command transport, and the segment ones need a segment", "[host][args]") {
    bool ok = true;
    std::string err;
    parse({ "--tcp", "4003", "--uds", "/tmp/x.sock" }, &err, &ok);
    CHECK_FALSE(ok);
    CHECK(err.find("exactly one") != std::string::npos);
    parse({ "-u", "0", "--shm-commands" }, &err, &ok);
    CHECK_FALSE(ok);
    CHECK(err.find("-u > 0") != std::string::npos);
    parse({ "-u", "0", "--shm-endpoint", "/tmp/y.sock" }, &err, &ok);
    CHECK_FALSE(ok);
    const Options fine = parse({ "-u", "4004", "--tcp", "4005", "--shm-endpoint", "/tmp/z.sock" }, &err, &ok);
    CHECK(ok);
    CHECK(fine.tcpPort == 4005);
    CHECK(fine.shmEndpoint == "/tmp/z.sock");
}

// The host chooses some of scsynth's options for itself (-D 1: a native process
// has a filesystem). What the help says is what the parser does, for each.
TEST_CASE("host usage: a default the host chooses is the one the help shows", "[host][args]") {
    const std::string u = supersonic_host::usage("Probe");
    const size_t d = u.find("  -D <num>");
    REQUIRE(d != std::string::npos);
    const std::string line = u.substr(d, u.find('\n', d) - d);
    INFO(line);
    CHECK(line.find("(default: 1)") != std::string::npos);
    CHECK(parse({ "--tcp", "4021" }).loadDefinitionsAtBoot);
    CHECK_FALSE(parse({ "-D", "0", "--tcp", "4022" }).loadDefinitionsAtBoot);
}

TEST_CASE("host usage: every flag the parser knows is in the help text", "[host][args]") {
    const std::string u = supersonic_host::usage("Probe");
    CHECK(u.find("Probe") != std::string::npos);
    for (const char* flag : { "-u", "-S", "-Z", "-z", "-i", "-o", "-n", "-b", "-a", "-c", "-m", "-w", "-B", "-H",
                              "--default-bpm", "--app-name", "--audio-driver", "--tcp", "--uds",
                              "--pipe", "--shm-commands", "--assets-mb", "--shm-endpoint",
                              "--headless", "--list-devices" })
        CHECK(u.find(flag) != std::string::npos);
}

#ifndef _WIN32
namespace {

struct IngestLog {
    std::mutex mu;
    std::vector<std::string> items;   // each message's address
    void record(const uint8_t* d, uint32_t n) {
        std::lock_guard<std::mutex> lk(mu);
        items.push_back(osc_test::parseAddress(d, n));
    }
    size_t count() { std::lock_guard<std::mutex> lk(mu); return items.size(); }
    std::string at(size_t i) { std::lock_guard<std::mutex> lk(mu); return items.at(i); }
};

bool waitUntil(const std::function<bool()>& f, int ms = 3000) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(ms);
    while (std::chrono::steady_clock::now() < deadline) {
        if (f()) return true;
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    return f();
}

int freePort(int type) {
    int fd = socket(AF_INET, type, 0);
    REQUIRE(fd >= 0);
    sockaddr_in sa {};
    sa.sin_family = AF_INET;
    sa.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    REQUIRE(bind(fd, reinterpret_cast<sockaddr*>(&sa), sizeof sa) == 0);
    socklen_t len = sizeof sa;
    REQUIRE(getsockname(fd, reinterpret_cast<sockaddr*>(&sa), &len) == 0);
    close(fd);
    return ntohs(sa.sin_port);
}

int connectTcp(int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    REQUIRE(fd >= 0);
    sockaddr_in sa {};
    sa.sin_family = AF_INET;
    sa.sin_port = htons(static_cast<uint16_t>(port));
    inet_pton(AF_INET, "127.0.0.1", &sa.sin_addr);
    REQUIRE(connect(fd, reinterpret_cast<sockaddr*>(&sa), sizeof sa) == 0);
    timeval tv { 2, 0 };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    // The secret first, as every client of a command port.
    std::vector<uint8_t> auth(256);
    auth.resize(clockwork_comms_secret_auth_packet(testSecret(), auth.data(), static_cast<uint32_t>(auth.size())));
    const uint32_t be = htonl(static_cast<uint32_t>(auth.size()));
    REQUIRE(write(fd, &be, 4) == 4);
    REQUIRE(write(fd, auth.data(), auth.size()) == static_cast<ssize_t>(auth.size()));
    return fd;
}
// The options a transport test starts from: the flags, and the test's secret.
Options withSecret(Options o) {
    o.secret.reset(clockwork_comms_secret_clone(testSecret()));
    return o;
}
void writeFramed(int fd, const osc_test::Packet& p) {
    const uint32_t be = htonl(static_cast<uint32_t>(p.size()));
    REQUIRE(write(fd, &be, 4) == 4);
    REQUIRE(write(fd, p.ptr(), p.size()) == static_cast<ssize_t>(p.size()));
}
std::vector<uint8_t> readFramed(int fd) {
    auto readAll = [&](uint8_t* dst, size_t n) {
        size_t got = 0;
        while (got < n) {
            const ssize_t r = read(fd, dst + got, n - got);
            if (r <= 0) return false;
            got += static_cast<size_t>(r);
        }
        return true;
    };
    uint8_t hdr[4];
    if (!readAll(hdr, 4)) return {};
    const uint32_t len = (uint32_t(hdr[0]) << 24) | (uint32_t(hdr[1]) << 16) | (uint32_t(hdr[2]) << 8) | uint32_t(hdr[3]);
    std::vector<uint8_t> body(len);
    if (!readAll(body.data(), len)) return {};
    return body;
}

} // namespace

TEST_CASE("host transports: no secret, no transport", "[host][transports]") {
    Options o = parse({ "-u", "0", "--tcp", "4020", "-B", "127.0.0.1" });
    CommandTransports t;
    std::string err;
    CHECK(t.select(o, nullptr, [](const uint8_t*, uint32_t) {}, &err) == nullptr);
    CHECK(err.find("secret") != std::string::npos);
}

TEST_CASE("host transports: TCP is the command port when asked, and a reply reaches its client",
          "[host][transports][rt]") {
    const int shmPort = freePort(SOCK_DGRAM), tcpPort = freePort(SOCK_STREAM);
    Options o = withSecret(parse({ "-u", std::to_string(shmPort), "--tcp", std::to_string(tcpPort), "-B", "127.0.0.1" }));
    IngestLog log;
    CommandTransports t;
    std::string err;
    IOscTransport* transport = t.select(o, nullptr, [&](const uint8_t* d, uint32_t n) { log.record(d, n); }, &err);
    REQUIRE(transport != nullptr);
    CHECK(t.description().find("TCP") != std::string::npos);
    REQUIRE(t.start());

    const int fd = connectTcp(tcpPort);
    writeFramed(fd, osc_test::message("/status"));
    REQUIRE(waitUntil([&] { return log.count() == 1; }));
    CHECK(log.at(0) == "/status");

    const auto reply = osc_test::message("/status.reply", int32_t{1});
    REQUIRE(transport->deliver(reply.ptr(), reply.size(), /*token*/ 0));
    const auto got = readFramed(fd);
    REQUIRE_FALSE(got.empty());
    CHECK(osc_test::parseAddress(got.data(), static_cast<uint32_t>(got.size())) == "/status.reply");
    close(fd);
    t.stop();
}
#endif

#ifndef _WIN32
TEST_CASE("host egress pump: the engine's replies reach the socket through the client API, not the engine's gateway",
          "[host][egress][rt]") {
    // The whole path a running host has, in one process: a TCP command port,
    // an engine that leaves its egress rings to the host, and the pump that
    // takes from them and routes to the transport.
    const int port = freePort(SOCK_STREAM);
    Options o = withSecret(parse({ "-u", "0", "--tcp", std::to_string(port), "-B", "127.0.0.1", "--headless" }));
    o.cfg.hostDrainsEgress = true;
    o.cfg.manualAudioPump = false;
    o.cfg.headless = true;

    // Before the engine, so it outlives it: the engine tells its transport
    // when its core is closing.
    CommandTransports t;
    EngineFixture fx(o.cfg);
    std::string err;
    IOscTransport* transport = t.select(o, nullptr,
        [&](const uint8_t* d, uint32_t n) { fx.engine().ingest(d, n, /*token*/ 0); }, &err);
    REQUIRE(transport != nullptr);
    fx.engine().setTransport(transport);
    REQUIRE(t.start());

    std::vector<std::string> debug;
    supersonic_host::EgressPump pump(fx.engine(), *transport, [&](const std::string& s) { debug.push_back(s); });
    pump.start();

    const int fd = connectTcp(port);
    auto replyAddress = [&] {
        const auto got = readFramed(fd);
        return got.empty() ? std::string() : osc_test::parseAddress(got.data(), static_cast<uint32_t>(got.size()));
    };
    writeFramed(fd, osc_test::message("/status"));
    CHECK(replyAddress() == "/status.reply");
    writeFramed(fd, osc_test::message("/b_query", int32_t{0}));
    CHECK(replyAddress() == "/b_info");
    close(fd);

    // Stopped, the pump takes nothing more; the engine's own transport
    // never saw these (the fixture listens there).
    pump.stop();
    OscReply r;
    CHECK_FALSE(fx.waitForReply("/b_info", r, 200));
    t.stop();
}
#endif
