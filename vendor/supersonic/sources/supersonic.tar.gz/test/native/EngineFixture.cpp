/*
 * EngineFixture.cpp
 *
 * The HeadlessDriver ticks process_audio() at real audio rate (2.67ms per
 * 128-sample block at 48kHz).  Worker threads (ReplyReader, DebugReader)
 * drain ring buffers naturally — just like the AudioWorklet + JS workers
 * in the WASM build.  Tests simply send OSC and waitForReply().
 */
#include "EngineFixture.h"
#include "RealtimeThread.h"
#include "DebugTail.h"
#include "ClockworkProcessor.h"
#include "HeadlessDriver.h"
#include <catch2/catch_test_macros.hpp>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <chrono>
#include <thread>
#include <filesystem>

// Render collected replies one per line. Caller holds mReplyMutex.
static std::string dumpReplies(const std::vector<OscReply>& replies) {
    if (replies.empty()) return "(none)";
    std::string out;
    for (auto& r : replies)
        out += "\n  | " + r.address + " (" + std::to_string(r.raw.size()) + " bytes)";
    return out;
}

ClockworkEngine::Config EngineFixture::defaultConfig() {
    ClockworkEngine::Config cfg;
    cfg.sampleRate        = 48000;
    cfg.bufferSize        = 128;
    cfg.udpPort           = 0;
    setGuestOption(cfg, "numBuffers", 1024);
    setGuestOption(cfg, "maxNodes", 1024);
    setGuestOption(cfg, "maxGraphDefs", 512);
    setGuestOption(cfg, "maxWireBufs", 64);
    cfg.headless          = true;
    // Pin channel counts for the headless test fixture. The live engine
    // uses kAutoChannelCount (-1) so JUCE picks up each device's real
    // channel count, but that's not meaningful without a device — tests
    // want a predictable 2-in / 2-out world to reason against.
    cfg.numOutputChannels = 2;
    cfg.numInputChannels  = 2;
    // Pumped: the test thread renders every block (manualAudioPump) on a
    // clock that is the sample count (freewheelClock), and runs the control
    // pass after it (hostDrivesControl), so a reply is delivered when the test
    // says rather than when the engine's gateway thread wakes: nothing a case
    // asserts can depend on how a thread was scheduled, or on a runner being
    // busy. A case whose claim is about real time asks for the headless
    // driver itself, and is tagged [rt]. SUPERSONIC_TEST_REALTIME=1 runs the
    // whole suite on the driver instead, the shape it once had.
    const char* realtime = std::getenv("SUPERSONIC_TEST_REALTIME");
    const bool pumped = !(realtime && *realtime == '1');
    cfg.manualAudioPump   = pumped;
    cfg.freewheelClock    = pumped;
    cfg.hostDrivesControl = pumped;
    return cfg;
}

ClockworkEngine::Config EngineFixture::driverConfig() {
    ClockworkEngine::Config cfg = defaultConfig();
    cfg.manualAudioPump   = false;
    cfg.freewheelClock    = false;
    cfg.hostDrivesControl = false;
    return cfg;
}

EngineFixture::EngineFixture() {
    init(defaultConfig());
}

EngineFixture::EngineFixture(const ClockworkEngine::Config& cfg) {
    init(cfg);
}

EngineFixture::EngineFixture(const ClockworkEngine::Config& cfg,
                             const std::function<void(ClockworkEngine&)>& beforeBoot) {
    init(cfg, beforeBoot);
}

void EngineFixture::init(const ClockworkEngine::Config& cfg,
                         const std::function<void(ClockworkEngine&)>& beforeBoot) {
    static uint64_t sGeneration = 0;
    mGeneration = ++sGeneration;
    // In manual-pump mode there is no audio-driver thread; the wait primitives
    // drive process_audio on the test thread instead (see pollUntil/waitForReply).
    mManualPump = cfg.manualAudioPump;
    mHostControl = cfg.hostDrivesControl;
    // The fixture runs the control pass after the blocks the test renders, and
    // only then: a driver's engine with it would never deliver a reply.
    INFO("cfg.hostDrivesControl without cfg.manualAudioPump: nothing runs the control pass "
         "(EngineFixture::driverConfig() is the driver's config)");
    REQUIRE((!cfg.hostDrivesControl || cfg.manualAudioPump));
    mSampleRate = cfg.sampleRate;

    // Wire reply/debug callbacks before initialising
    mEngine.onReply = [this](const uint8_t* data, uint32_t size) {
        OscReply r;
        r.address = osc_test::parseAddress(data, size);
        r.raw.assign(data, data + size);
        {
            std::lock_guard<std::mutex> lk(mReplyMutex);
            mReplies.push_back(std::move(r));
        }
        mReplyCv.notify_all();
    };

    // Routed, as the transport decided (before onReply, CallbackTransport::send): recorded here, then handed to
    // the test's observer, if it has set one
    mEngine.onReplyRouted = [this](uint32_t origin, uint32_t route, const uint8_t* data, uint32_t size) {
        {
            std::lock_guard<std::mutex> lk(mReplyMutex);
            mRouted.push_back({origin, route, osc_test::parseAddress(data, size)});
        }
        std::lock_guard<std::mutex> lk(mObserverMutex);
        if (mRoutedObserver) mRoutedObserver(origin, route, data, size);
    };

    mEngine.onDebug = [this](const std::string& msg) {
        debug_tail::push(msg);
        std::lock_guard<std::mutex> lk(mDebugMutex);
        mDebugMessages.push_back(msg);
    };

    if (beforeBoot) beforeBoot(mEngine);
    mEngine.init(cfg);

    // Wait for the engine to be ready (a pumped one is pumped by the wait)
    OscReply r;
    mEngine.sendOSC(osc_test::message("/sync", 0).ptr(),
                    osc_test::message("/sync", 0).size());
    waitForReply("/synced", r);

    // Create default group (1) — scsynth only creates root group (0).
    // All SuperCollider clients create group 1 at startup.
    send(osc_test::message("/g_new", 1, 0, 0));
    // Barrier: wait until /g_new has been processed (node tree mirror updated)
    auto syncPkt = osc_test::message("/sync", 1);
    mEngine.sendOSC(syncPkt.ptr(), syncPkt.size());
    waitForReply("/synced", r);

    // Clear any boot-time debug/reply output so tests start with a clean slate
    clearReplies();
    clearDebugMessages();
}

EngineFixture::~EngineFixture() {
    mEngine.shutdown();
    // shutdown() has stopped the threads that call these; dropping them says so, and leaves nothing holding this
    // fixture while the rest of it goes away.
    mEngine.onReply = nullptr;
    mEngine.onReplyRouted = nullptr;
    mEngine.onDebug = nullptr;
}

// ── OSC send ──────────────────────────────────────────────────────────────────

void EngineFixture::send(const osc_test::Packet& pkt) {
    send(pkt.ptr(), pkt.size());
}

void EngineFixture::send(const uint8_t* data, uint32_t size) {
    mEngine.sendOSC(data, size);
}

// ── Reply collection ─────────────────────────────────────────────────────────

bool EngineFixture::waitForReply(const std::string& addr, OscReply& out,
                                  int timeoutMs) {
    auto deadline = std::chrono::steady_clock::now()
                  + std::chrono::milliseconds(timeoutMs);

    auto take = [&]() -> bool {
        std::lock_guard<std::mutex> lk(mReplyMutex);
        for (auto it = mReplies.begin(); it != mReplies.end(); ++it) {
            if (it->address == addr) {
                out = *it;
                mReplies.erase(it);
                return true;
            }
        }
        return false;
    };

    // The test is the host: what it waits for comes from the blocks and passes
    // it runs, so the wait is a count of them.
    if (testIsTheHost()) {
        for (uint32_t owed = blocksOfAudio(timeoutMs);; --owed) {
            if (take()) return true;
            if (!owed) {
                // The caller's assertion expands to a bare "false"; say what we
                // waited for and what did arrive, so a timeout separates "wrong
                // reply" from "no reply at all" without a rerun.
                UNSCOPED_INFO("waitForReply(\"" << addr << "\") gave up after "
                              << timeoutMs << "ms of audio; replies held:" << repliesDump());
                return false;
            }
            pumpBlock();
        }
    }

    // Manual-pump mode with the engine's own gateway: it delivers replies after
    // the audio thread ticks, and nothing ticks unless we pump here on the test
    // thread. Two budgets, audio and wall clock, both spent before giving up
    // (pollUntil says why).
    if (testPumps()) {
        uint32_t owed = blocksOfAudio(timeoutMs);
        while (true) {
            if (owed) { pumpBlock(); --owed; }
            if (take()) return true;
            if (!owed && std::chrono::steady_clock::now() >= deadline) {
                // The caller's assertion expands to a bare "false"; say what we
                // waited for and what did arrive, so a timeout separates "wrong
                // reply" from "no reply at all" without a rerun.
                UNSCOPED_INFO("waitForReply(\"" << addr << "\") timed out after "
                              << timeoutMs << "ms; replies held:" << repliesDump());
                return false;
            }
            // Let the gateway thread (woken by the pump's processCount tick)
            // deliver before the next scan.
            std::this_thread::sleep_for(std::chrono::milliseconds(3));
        }
    }

    std::unique_lock<std::mutex> lk(mReplyMutex);
    while (true) {
        for (auto it = mReplies.begin(); it != mReplies.end(); ++it) {
            if (it->address == addr) {
                out = *it;
                mReplies.erase(it);
                return true;
            }
        }

        if (std::chrono::steady_clock::now() >= deadline) {
            // mReplyMutex is held here, so dump directly rather than via
            // repliesDump() (which takes the same non-recursive lock).
            UNSCOPED_INFO("waitForReply(\"" << addr << "\") timed out after "
                          << timeoutMs << "ms; replies held:" << dumpReplies(mReplies));
            return false;
        }

        mReplyCv.wait_until(lk, deadline);
    }
}

bool EngineFixture::sendAndExpectDone(const osc_test::Packet& pkt,
                                       int timeoutMs) {
    // The OSC address is the packet's first NUL-terminated string; the /done
    // that completes it names that address as its first argument.
    const std::string cmd(reinterpret_cast<const char*>(pkt.ptr()));
    send(pkt);
    return waitForDone(cmd, timeoutMs);
}

// scsynth completes an asynchronous command with `/done <cmd>`; matching the
// address alone took ANY /done for the one awaited, which held only while
// every command completed inline, before the guest's off-thread stages. A
// /done for an earlier command can now arrive later, so the name is checked.
bool EngineFixture::waitForDone(const std::string& cmd, int timeoutMs) {
    return pollUntil([&] {
        std::lock_guard<std::mutex> lk(mReplyMutex);
        for (auto it = mReplies.begin(); it != mReplies.end(); ++it) {
            if (it->address != "/done") continue;
            if (it->parsed().argCount() < 1 || it->parsed().argString(0) != cmd) continue;
            mReplies.erase(it);
            return true;
        }
        return false;
    }, timeoutMs);
}

uint32_t EngineFixture::blocksOfAudio(int ms) const {
    const double frames = double(ms) * double(mSampleRate) / 1000.0;
    return static_cast<uint32_t>(std::ceil(frames / double(get_audio_buffer_samples())));
}

bool EngineFixture::waitForBlocks(uint32_t n, int timeoutMs) {
    const uint32_t start =
        mEngine.processor().processCount.load(std::memory_order_acquire);
    // Unsigned wrap is fine: (now - start) is the number of blocks rendered
    // since the snapshot regardless of counter wraparound.
    // Pumped: the blocks are rendered here, now, however busy the machine is.
    if (testPumps()) {
        pumpBlock(n);
        return mEngine.processor().processCount.load(std::memory_order_acquire) - start >= n;
    }
    return pollUntil([&] {
        return mEngine.processor().processCount.load(
                   std::memory_order_acquire) - start >= n;
    }, timeoutMs);
}

std::vector<OscReply> EngineFixture::allReplies() const {
    std::lock_guard<std::mutex> lk(mReplyMutex);
    return mReplies;
}

void EngineFixture::clearReplies() {
    std::lock_guard<std::mutex> lk(mReplyMutex);
    mReplies.clear();
    mRouted.clear();
}

std::vector<RoutedReply> EngineFixture::routedReplies() const {
    std::lock_guard<std::mutex> lk(mReplyMutex);
    return mRouted;
}

void EngineFixture::setRoutedObserver(RoutedObserver fn) {
    std::lock_guard<std::mutex> lk(mObserverMutex);
    mRoutedObserver = std::move(fn);
}

// ── Debug ────────────────────────────────────────────────────────────────────

std::vector<std::string> EngineFixture::debugMessages() const {
    std::lock_guard<std::mutex> lk(mDebugMutex);
    return mDebugMessages;
}

void EngineFixture::clearDebugMessages() {
    std::lock_guard<std::mutex> lk(mDebugMutex);
    mDebugMessages.clear();
}

std::string EngineFixture::debugMessagesDump() const {
    std::lock_guard<std::mutex> lk(mDebugMutex);
    if (mDebugMessages.empty()) return "(none)";
    std::string out;
    for (auto& m : mDebugMessages) out += "\n  | " + m;
    return out;
}

std::string EngineFixture::repliesDump() const {
    std::lock_guard<std::mutex> lk(mReplyMutex);
    return dumpReplies(mReplies);
}

// ── HeadlessDriver control ───────────────────────────────────────────────────

void EngineFixture::stopHeadlessDriver() {
    if (mManualPump) return;   // pumped: there is no driver to stop
    mEngine.mHeadlessDriver->stop();
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
}

void EngineFixture::pumpBlock(uint32_t n) {
    if (testPumps()) {
        for (uint32_t i = 0; i < n; ++i) {
            mEngine.pumpAudioBlock();
            hostTurn();
        }
        return;
    }
    // A driver thread or a Device is rendering: a block pumped here would be a
    // second renderer. What a test means by "pump n" with one running is "let
    // n blocks pass" — so wait for its.
    if (!waitForBlocks(n))
        WARN("pumpBlock(" << n << "): the driver rendered no block within the wait");
}

void EngineFixture::pumpCallback(uint32_t frames, const std::function<void()>& afterEachBlock) {
    REQUIRE(testPumps());
    mEngine.pumpAudioCallback(frames, afterEachBlock);
    hostTurn();
}

void EngineFixture::restartPump() {
    REQUIRE(testPumps());
    mEngine.restartManualPump();
}

void EngineFixture::setHostWork(std::function<void()> work) {
    mHostWork = std::move(work);
}

void EngineFixture::hostTurn() {
    if (mHostControl) mEngine.controlPass();
    if (mHostWork) mHostWork();
}

void EngineFixture::waitForDeviceLane() {
    // Sent so far reaches the lane: the block that forwards a control verb, and
    // the pass that hands it over.
    if (testIsTheHost()) pumpBlock();
    // Shared, not on this stack: a lane that never gets to it runs it after
    // the REQUIRE below has thrown.
    auto done = std::make_shared<std::promise<void>>();
    auto ran = done->get_future();
    REQUIRE(mEngine.postDeviceTask([done] { done->set_value(); }));
    REQUIRE(ran.wait_for(std::chrono::seconds(30)) == std::future_status::ready);
}

// Assertions stay on the test thread: Catch2's aren't safe from another.
EngineFixture::Device::Device(EngineFixture& fx, int sampleRate, uint32_t frames,
                              std::function<void()> afterEachBlock) : mFx(fx) {
    REQUIRE(mFx.mManualPump);
    REQUIRE_FALSE(mFx.mDeviceRendering.load(std::memory_order_relaxed));
    mFx.mEngine.restartManualPump();
    mFx.mDeviceRendering.store(true, std::memory_order_relaxed);
    mThread = std::thread([this, sampleRate, frames, afterEachBlock = std::move(afterEachBlock)] {
        // A device's callback thread is real-time, and so is this one: an
        // ordinary thread stalled by a build on the same machine would be a
        // device that stopped calling, a dropout of the test's own making.
        clockwork::elevateCurrentThreadToRealtime(double(frames) / double(sampleRate));
        const auto began = std::chrono::steady_clock::now();
        for (uint64_t callback = 0; !mStop.load(std::memory_order_relaxed); ++callback) {
            const auto due = began + std::chrono::nanoseconds(static_cast<int64_t>(
                1e9 * double(callback * frames) / double(sampleRate)));
            std::this_thread::sleep_until(due);
            if (const int64_t stall = mStallNanos.exchange(0, std::memory_order_relaxed); stall > 0)
                std::this_thread::sleep_for(std::chrono::nanoseconds(stall));
            const auto late = std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now() - due).count();
            if (late > mWorstLateNanos.load(std::memory_order_relaxed))
                mWorstLateNanos.store(late, std::memory_order_relaxed);
            if (late > 1'000'000) {   // a millisecond: the jitter of a timer wake is less
                std::lock_guard<std::mutex> lock(mLateMutex);
                mLateWakes.push_back({due, late / 1e9});
            }
            mFx.mEngine.pumpAudioCallback(frames, afterEachBlock);
            mFx.hostTurn();
        }
    });
}

EngineFixture::Device::~Device() {
    mStop.store(true, std::memory_order_relaxed);
    mThread.join();
    mFx.mDeviceRendering.store(false, std::memory_order_relaxed);
}

EngineFixture::HeldSwap::HeldSwap(EngineFixture& fx, const std::string& deviceName, double sampleRate) : mFx(fx) {
    // The hook can run twice in a swap (a retry without the input), so it
    // waits on a signal that, once given, stays given.
    mFx.mEngine.testSwapFailure = [this](bool) -> std::string {
        mEntered.store(true, std::memory_order_release);
        mReleased.wait();
        return "held open";
    };
    mThread = std::thread([this, deviceName, sampleRate] {
        mResult = mFx.mEngine.switchDevice(deviceName, sampleRate);
    });
}

EngineFixture::HeldSwap::~HeldSwap() {
    release();
}

bool EngineFixture::HeldSwap::entered(int timeoutMs) {
    return mFx.waitForThread([this] { return mEntered.load(std::memory_order_acquire); }, timeoutMs);
}

SwapResult EngineFixture::HeldSwap::release() {
    if (!mJoined) {
        mRelease.set_value();
        mThread.join();
        mJoined = true;
        mFx.mEngine.testSwapFailure = nullptr;
    }
    return mResult;
}

// ── Synthdef helpers ─────────────────────────────────────────────────────────

bool EngineFixture::loadSynthDef(const std::string& name) {
    // Look in the shipped synthdef dir first, then the test-only dir
    // (where test fixtures can drop synthdefs that don't belong in the
    // npm package — e.g. stereo_passthrough used by Link Audio tests).
    std::filesystem::path fsPath =
        std::filesystem::path(CLOCKWORK_SYNTHDEFS_DIR) / (name + ".scsyndef");
    if (!std::filesystem::exists(fsPath)) {
        fsPath = std::filesystem::path(CLOCKWORK_TEST_SYNTHDEFS_DIR)
                 / (name + ".scsyndef");
    }
    if (!std::filesystem::exists(fsPath)) return false;

    std::ifstream f(fsPath, std::ios::binary);
    if (!f) return false;

    std::vector<uint8_t> data((std::istreambuf_iterator<char>(f)),
                               std::istreambuf_iterator<char>());
    if (data.empty()) return false;

    auto pkt = osc_test::messageWithBlob("/d_recv", data.data(), data.size());
    return sendAndExpectDone(pkt);
}
