/*
 * test_callbacks.cpp — Tests for onReply/onDebug callback behavior.
 *
 * Verifies that reply and debug callbacks fire correctly, deliver
 * well-formed OSC data, and that clearReplies() / ordering semantics
 * work as expected.
 */
#include "EngineFixture.h"
#include <thread>
#include <chrono>
#include <atomic>

// =============================================================================
// SECTION: Basic reply callback behavior
// =============================================================================

TEST_CASE("/status generates exactly one /status.reply callback", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    fx.send(osc_test::message("/status"));
    OscReply r;
    REQUIRE(fx.waitForReply("/status.reply", r));

    // Pump a few more blocks to let any straggler replies arrive

    // waitForReply consumed the first reply; verify no duplicates remain
    auto all = fx.allReplies();
    int statusCount = 0;
    for (auto& reply : all) {
        if (reply.address == "/status.reply")
            ++statusCount;
    }
    CHECK(statusCount == 0);  // no duplicate replies
}

// scsynth replies ride the OUT ring; /clock control replies ride NRT-out. Both
// drain through the one dispatchEgress, so a reply from each proves it.
TEST_CASE("OUT-ring and NRT-out replies both arrive via the unified egress drain", "[callback][egress]") {
    EngineFixture fx;
    fx.clearReplies();

    OscReply r;
    // OUT ring.
    fx.send(osc_test::message("/status"));
    REQUIRE(fx.waitForReply("/status.reply", r));

    // NRT-out ring.
    fx.send(osc_test::message("/clockwork/clock/tempo/get"));
    REQUIRE(fx.waitForReply("/clockwork/clock/tempo.reply", r));
}

TEST_CASE("/sync generates exactly one /synced callback with matching ID", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    fx.send(osc_test::message("/sync", 77));
    OscReply r;
    REQUIRE(fx.waitForReply("/synced", r));

    auto p = r.parsed();
    CHECK(p.argInt(0) == 77);

    // Pump extra to ensure no duplicates

    // waitForReply consumed the first reply; verify no duplicates remain
    auto all = fx.allReplies();
    int syncedCount = 0;
    for (auto& reply : all) {
        if (reply.address == "/synced")
            ++syncedCount;
    }
    CHECK(syncedCount == 0);  // no duplicate replies
}

TEST_CASE("Multiple /sync commands generate matching /synced replies", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    // Send 5 syncs with distinct IDs
    for (int i = 0; i < 5; ++i) {
        fx.send(osc_test::message("/sync", 100 + i));
    }

    // Wait for all 5 /synced replies
    for (int i = 0; i < 5; ++i) {
        OscReply r;
        REQUIRE(fx.waitForReply("/synced", r));
        CHECK(r.parsed().argInt(0) == 100 + i);
    }
}

TEST_CASE("/version generates /version.reply with string arguments", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    fx.send(osc_test::message("/version"));
    OscReply r;
    REQUIRE(fx.waitForReply("/version.reply", r));

    auto p = r.parsed();
    // /version.reply should contain at least: program name (string), major, minor
    REQUIRE(p.argCount() >= 3);
    CHECK(!p.argString(0).empty());  // program name is a non-empty string
}

// =============================================================================
// SECTION: Reply data integrity
// =============================================================================

TEST_CASE("Reply data contains valid OSC with parseable argCount > 0", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    // /status.reply always has multiple arguments
    fx.send(osc_test::message("/status"));
    OscReply r;
    REQUIRE(fx.waitForReply("/status.reply", r));

    auto p = r.parsed();
    CHECK(p.argCount() > 0);
    CHECK(p.address == "/status.reply");

    // Verify raw data is non-empty and parseable
    CHECK(!r.raw.empty());
}

TEST_CASE("/g_queryTree generates /g_queryTree.reply", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    // Query the root group (node 0) with flag=0 (no control values)
    fx.send(osc_test::message("/g_queryTree", 0, 0));
    OscReply r;
    REQUIRE(fx.waitForReply("/g_queryTree.reply", r));

    auto p = r.parsed();
    // /g_queryTree.reply: flag(0), groupID(1), numChildren(2), ...
    CHECK(p.argCount() >= 3);
    CHECK(p.argInt(1) == 0);    // root group ID
    CHECK(p.argInt(2) >= 1);    // at least the default group (1) as child
}

// =============================================================================
// SECTION: Debug callback behavior
// =============================================================================

TEST_CASE("debugMessages() is initially empty on fresh engine", "[callback]") {
    EngineFixture fx;

    auto msgs = fx.debugMessages();
    // The out rings live in the process-global engine arena, so a line from an
    // earlier test's engine can still be in flight when this fixture drains.
    // Name what arrived — "false" on its own says nothing about who wrote it.
    INFO("debug lines on a fresh engine:" << fx.debugMessagesDump());
    CHECK(msgs.empty());
}

TEST_CASE("Sending invalid OSC command generates debug output", "[callback]") {
    EngineFixture fx;

    // Enable dumpOSC so the engine prints debug info about incoming commands
    fx.send(osc_test::message("/dumpOSC", 1));

    // Send a command that does not exist — scsynth logs an error for unknown commands
    fx.send(osc_test::message("/nonexistent_command"));
    // Use /sync as a barrier — ensures the command was processed on the
    // audio thread and workers have drained the ring buffers.
    fx.send(osc_test::message("/sync", 999));
    OscReply syncReply;
    fx.waitForReply("/synced", syncReply);

    // Debug output is drained by a separate worker thread, so the /synced
    // reply (which travels the reply ring) doesn't guarantee the dumpOSC echo
    // has landed in debugMessages() yet — and the shared debug ring can still
    // carry non-matching lines from a prior test. Poll for the echo rather
    // than reading once, so a single early read can't catch a partial state.
    bool found = fx.pollUntil([&] {
        for (auto& m : fx.debugMessages()) {
            if (m.find("nonexistent") != std::string::npos ||
                m.find("Command")     != std::string::npos ||
                m.find("OSC")         != std::string::npos) {
                return true;
            }
        }
        return false;
    });
    CHECK(found);
}

// =============================================================================
// SECTION: clearReplies() semantics
// =============================================================================

TEST_CASE("clearReplies() actually clears collected replies", "[callback]") {
    EngineFixture fx;

    // Send /status which generates a /status.reply — we DON'T consume it.
    // Use /sync as a barrier to ensure the /status.reply has been collected.
    fx.send(osc_test::message("/status"));
    fx.send(osc_test::message("/sync", 500));
    OscReply barrier;
    fx.waitForReply("/synced", barrier);

    // /status.reply should still be in the reply buffer (not consumed)
    INFO("replies held after the barrier:" << fx.repliesDump());
    CHECK(!fx.allReplies().empty());

    // Clear and verify
    fx.clearReplies();
    INFO("replies surviving clearReplies():" << fx.repliesDump());
    CHECK(fx.allReplies().empty());

    // Engine should still work after clearing
    fx.send(osc_test::message("/status"));
    OscReply r;
    REQUIRE(fx.waitForReply("/status.reply", r));
}

// =============================================================================
// SECTION: Reply ordering
// =============================================================================

TEST_CASE("Reply ordering: /status then /sync replies arrive for both", "[callback]") {
    EngineFixture fx;
    fx.clearReplies();

    // Send /status followed by /sync in quick succession
    fx.send(osc_test::message("/status"));
    fx.send(osc_test::message("/sync", 999));

    // Wait for both replies
    OscReply statusReply;
    REQUIRE(fx.waitForReply("/status.reply", statusReply));
    CHECK(statusReply.parsed().argCount() >= 5);

    OscReply syncReply;
    REQUIRE(fx.waitForReply("/synced", syncReply));
    CHECK(syncReply.parsed().argInt(0) == 999);
}
