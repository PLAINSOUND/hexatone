// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025 Sam Aaron

#include "AudioRecovery.h"

namespace clockwork::audio {

LivenessMonitor::LivenessMonitor(int64_t stallWindow, int64_t confirmWindow)
    : mStallWindow(stallWindow), mConfirmWindow(confirmWindow) {}

void LivenessMonitor::observe(uint64_t tickCount, int64_t now) {
    if (!mSeen) {
        // Seed as already-Live: a fresh boot that is ticking needs no confirm
        // window. Backdating mRunStart by the confirm window makes phase() read
        // Live immediately.
        mSeen        = true;
        mLastCount   = tickCount;
        mLastAdvance = now;
        mRunStart    = now - mConfirmWindow;
        return;
    }

    // Whether we had already crossed the stall threshold as of this sample,
    // judged against the LAST advance (before we fold in this observation).
    // mLastAdvance is frozen until a tick advances and `now` only grows, so once
    // this is true it stays true until the next advance — no separate "was
    // stalled" flag is needed.
    const bool stalledNow = (now - mLastAdvance) >= mStallWindow;

    if (tickCount != mLastCount) {
        // Ticks advanced. If they are resuming out of a stall, this begins a
        // fresh run that must survive the confirm window before it counts as
        // Live — so a single twitch tick (one callback per reopen) can never
        // masquerade as recovered.
        if (stalledNow) mRunStart = now;
        mLastAdvance = now;
        mLastCount   = tickCount;
    }
}

LivenessPhase LivenessMonitor::phase(int64_t now) const {
    if (!mSeen) return LivenessPhase::Stalled;
    if (now - mLastAdvance >= mStallWindow)   return LivenessPhase::Stalled;
    if (now - mRunStart    >= mConfirmWindow) return LivenessPhase::Live;
    return LivenessPhase::Confirming;
}

RateSkewMonitor::RateSkewMonitor(int64_t window, int64_t maxGap,
                                 double tolerance, int badWindowsRequired)
    : mWindow(window), mMaxGap(maxGap), mTolerance(tolerance),
      mBadWindowsRequired(badWindowsRequired) {}

void RateSkewMonitor::reset() {
    mSeen      = false;
    mBadStreak = 0;
}

void RateSkewMonitor::observe(uint64_t frames, double nominalFramesPerUnit,
                              int64_t now) {
    // No usable nominal rate (device mid-transition) — nothing measured now
    // can be trusted later.
    if (nominalFramesPerUnit <= 0.0) {
        reset();
        return;
    }

    const bool discontinuity = !mSeen
        || (now - mLastTime) > mMaxGap
        || frames < mLastFrames
        || nominalFramesPerUnit != mRate;
    if (discontinuity) {
        mSeen        = true;
        mStartFrames = frames;
        mStartTime   = now;
        mRate        = nominalFramesPerUnit;
        mBadStreak   = 0;
        mLastFrames  = frames;
        mLastTime    = now;
        return;
    }

    mLastFrames = frames;
    mLastTime   = now;

    const int64_t span = now - mStartTime;
    if (span < mWindow) return;

    const double delivered = static_cast<double>(frames - mStartFrames);
    const double ratio =
        delivered / (mRate * static_cast<double>(span));
    mLastRatio = ratio;

    const double deviation = ratio < 1.0 ? 1.0 - ratio : ratio - 1.0;
    if (deviation > mTolerance) ++mBadStreak;
    else                        mBadStreak = 0;
    ++mWindowsCompleted;
    mLastWindowGood = deviation <= mTolerance;

    // Next window starts where this one ended — contiguous coverage, no
    // overlap, so badWindowsRequired windows means that much sustained skew.
    mStartFrames = frames;
    mStartTime   = now;
}

RateSkewPolicy::RateSkewPolicy(int maxRecoveries, double sameRatioTolerance)
    : mMaxRecoveries(maxRecoveries < 1 ? 1 : maxRecoveries),
      mTolerance(sameRatioTolerance) {}

bool RateSkewPolicy::sameFault(const RateSkewVerdict& v) const {
    if (mStreak == 0) return false;
    // Held at another rate: the report is the fault, and the reopen before
    // it — held or merely skewed, read at whatever ratio — was the one
    // chance to win the device back.
    if (v.heldElsewhere()) return true;
    if (mLast.heldElsewhere()) return false;
    const double d = v.ratio < mLast.ratio ? mLast.ratio - v.ratio : v.ratio - mLast.ratio;
    return d <= mTolerance;
}

// A different fault starts its streak at one.
int RateSkewPolicy::streakWith(const RateSkewVerdict& v) const {
    return sameFault(v) ? mStreak + 1 : 1;
}

RateSkewAction RateSkewPolicy::next(const RateSkewVerdict& v) const {
    switch (mPhase) {
    case Phase::GaveUp:
        return RateSkewAction::None;
    case Phase::Adopted:
        // Skewing at the rate it was measured delivering: no rate request
        // corrects this device.
        return RateSkewAction::GiveUp;
    case Phase::Recovering:
        break;
    }
    const int enough = v.heldElsewhere() ? 2 : mMaxRecoveries;
    return streakWith(v) >= enough ? RateSkewAction::AdoptRate
                                   : RateSkewAction::Recover;
}

void RateSkewPolicy::acted(const RateSkewVerdict& v) {
    switch (next(v)) {
    case RateSkewAction::None:
        return;
    case RateSkewAction::GiveUp:
        mPhase = Phase::GaveUp;
        return;
    case RateSkewAction::AdoptRate:
        mPhase = Phase::Adopted;
        break;
    case RateSkewAction::Recover:
        break;
    }
    mStreak = streakWith(v);
    mLast   = v;
}

void RateSkewPolicy::healthy() {
    if (mPhase == Phase::GaveUp) return;
    mPhase  = Phase::Recovering;
    mStreak = 0;
}

} // namespace clockwork::audio
