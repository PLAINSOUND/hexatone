// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025 Sam Aaron

/*
 * lanes.cpp — the engine boundary, implemented over the engine's existing
 * transport state. See lanes.h for the contract.
 *
 * Ingress and the NRT producer delegate to RingBufferWriter; the egress
 * drains delegate to clockwork_drain_ring (ring_drain.h, also used by the native
 * RingReader thread); the tick is process_audio.
 */
#include "lanes.h"
#include "lanes_internal.h"
#include "ring_drain.h"

#include <atomic>
#include <cstring>

#include "../audio_processor.h"          // arena globals + process_audio + accessors
#include "../audio_config.h"             // block-size and channel caps
#include "../clockwork_prefix.h"         // clockwork_sys_claims: whose message this is
#include "../clockwork_sys.h"            // clockwork_sys_refuse, the refusal reasons
#include "../shared_memory.h"            // layout, RingCursors, EgressRoute
#include "../in_ring_door.h"              // the in ring's boundary
#include "../workers/RingBufferWriter.h" // the multi-producer ring writer

// ── internal state ──────────────────────────────────────────────────────────

// NRT egress producer lock. Producers on control threads serialise their
// [route][osc] framing through here; this is the process-wide lock for the
// NRT-out lane (the engine's OscEgress delegates to clockwork_egress_nrt_write).
static std::atomic<int32_t> g_nrt_egress_lock{0};

// Largest NRT egress frame the producer accepts. Sized for the biggest
// producer — the device reports, which reach several KB on device-heavy
// Windows machines — but never more than half the ring so a frame can
// always drain (small-profile builds have a 4 KB NRT-out ring).
static constexpr uint32_t kNrtEgressMax =
    NRT_OUT_RING_SIZE / 2 < 8192 ? NRT_OUT_RING_SIZE / 2 : 8192;

// Per-lane consumer state (single consumer per lane, by contract). Process
// lifetime; reset with its ring's sequence counter when the ring begins a
// fresh epoch (clockwork_lanes_reset_rt_out_ring / _nrt_out_ring).
static ClockworkDrainState g_rt_drain_state;
static ClockworkDrainState g_nrt_drain_state;

extern "C" {

// Fresh ring epochs. The IN and NRT-out producers run through a cold-swap
// rebuild: transport ingress threads, and clockwork_log / clockwork_egress_nrt_write
// from any engine worker. Each serialises its whole read-head→publish
// sequence on its ring's writer spinlock (RingBufferWriter::write), so owning
// that lock across the reset linearises it — an in-flight write lands wholly
// in the old epoch (discarded here) or wholly in the fresh one, never
// interleaved with the zeroing. The lock words are never zeroed: releasing
// the spinlock is what returns them to 0, and a blind store would unlock
// under a holder.
static void spin_acquire(std::atomic<int32_t>& lock) { RingBufferWriter::lock(&lock); }

void clockwork_lanes_reset_in_ring(void) {
    if (!shared_memory || !cursors) return;
    spin_acquire(cursors->in_write_lock);
    cursors->in_head.store(0, std::memory_order_relaxed);
    cursors->in_tail.store(0, std::memory_order_relaxed);
    cursors->in_sequence.store(0, std::memory_order_relaxed);
    cursors->in_write_lock.store(0, std::memory_order_release);
}

// The RT-out ring's one writer is stopped by the caller: a new arena has no
// audio thread yet.
void clockwork_lanes_reset_rt_out_ring(void) {
    if (!shared_memory || !cursors) return;
    cursors->out_head.store(0, std::memory_order_relaxed);
    cursors->out_tail.store(0, std::memory_order_relaxed);
    cursors->out_read.store(0, std::memory_order_relaxed);
    cursors->out_sequence.store(0, std::memory_order_relaxed);
    g_rt_drain_state.lastSeq = -1;
}

void clockwork_lanes_reset_nrt_out_ring(void) {
    if (!shared_memory || !cursors) return;
    spin_acquire(g_nrt_egress_lock);
    cursors->nrt_out_head.store(0, std::memory_order_relaxed);
    cursors->nrt_out_tail.store(0, std::memory_order_relaxed);
    cursors->nrt_out_read.store(0, std::memory_order_relaxed);
    cursors->nrt_out_sequence.store(0, std::memory_order_relaxed);
    g_nrt_egress_lock.store(0, std::memory_order_release);
    g_nrt_drain_state.lastSeq = -1;
}

// ── Ingress ─────────────────────────────────────────────────────────────────

bool clockwork_ingress_write(const uint8_t* osc, uint32_t len, uint32_t source_id) {
    return clockwork_ingress_write_status(osc, len, source_id) == InRingWrite::Written;
}

} // extern "C"

InRingWrite clockwork_ingress_write_status(const uint8_t* osc, uint32_t len, uint32_t source_id) {
    if (!memory_initialized || !shared_memory || !cursors || !osc || len == 0)
        return InRingWrite::Full;
    // A control verb of clockwork's, while the engine serves the control ring
    // (lanes.h, clockwork_control_serve): written there, where no audio
    // block is between it and its answer. The same rule clockwork_client_send
    // reads from the same bytes, so a client in any process does the same.
    const uint32_t flags = cursors->status_flags.load(std::memory_order_acquire);
    if ((flags & STATUS_CONTROL_SERVED) && clockwork_sys_control_takes(osc, len)) {
        auto* ctl = reinterpret_cast<ControlRingCursors*>(shared_memory + CONTROL_RING_START);
        if (!RingBufferWriter::write(
                shared_memory + CONTROL_RING_START + CONTROL_RING_HEADER_SIZE,
                CONTROL_RING_SIZE - CONTROL_RING_HEADER_SIZE,
                &ctl->head, &ctl->tail, &ctl->sequence, &ctl->write_lock,
                osc, len, source_id))
            return InRingWrite::Full;
        clockwork_control_wake();
        return InRingWrite::Written;
    }
    // No guest instance to take it: refused at the boundary (in_ring_door.h),
    // with the word on the NRT egress for the source that sent it, as the
    // client ABI's status says the same to its caller (docs/RESTARTS.md).
    // Clockwork's own verbs go through and wait in the ring for the engine,
    // instance or none.
    const InRingWrite wrote = in_ring_write(shared_memory, shared_memory + IN_RING_START, IN_RING_SIZE,
                                            cursors, osc, len, source_id);
    if (wrote == InRingWrite::NoInstance)
        clockwork_sys_refuse(osc, len, CLOCKWORK_REFUSED_NO_INSTANCE,
            arenaInstanceGeneration(shared_memory),
            [source_id](const uint8_t* d, uint32_t n) {
                clockwork_egress_nrt_write(EGRESS_REPLY, source_id, d, n);
            });
    return wrote;
}

extern "C" {

// ── Egress ──────────────────────────────────────────────────────────────────

// Both egress rings carry Message frames whose payload is [route:u32][osc];
// the drains peel the route word before the callback sees the OSC bytes.
// They walk from the ring's read cursor, as clockwork_client_poll does, and
// give the space back as soon as the walk ends (clockwork_ring_give_back).
static uint32_t drain_egress_ring(uint8_t* buffer, uint32_t size,
                                  std::atomic<int32_t>* head,
                                  std::atomic<int32_t>* tail,
                                  std::atomic<int32_t>* read,
                                  ClockworkDrainState& st,
                                  const ClockworkDrainMetrics& m,
                                  ClockworkEgressFn fn, void* ctx,
                                  uint32_t max_frames) {
    clockwork_ring_give_back(tail, read);   // a client's last batch, if it had one
    const uint32_t delivered = clockwork_drain_ring(buffer, size, head, read, st, m, max_frames,
        [fn, ctx](uint32_t sourceId, const uint8_t* payload, uint32_t n, uint32_t seq) {
            if (n >= EGRESS_ROUTE_SIZE) {
                uint32_t route;
                std::memcpy(&route, payload, sizeof(route));
                fn(ctx, sourceId, route,
                   payload + EGRESS_ROUTE_SIZE, n - EGRESS_ROUTE_SIZE, seq);
            }
            return ClockworkDrainVerdict::Consume;
        });
    clockwork_ring_give_back(tail, read);
    return delivered;
}

uint32_t clockwork_egress_rt_drain(ClockworkEgressFn fn, void* ctx, uint32_t max_frames) {
    if (!memory_initialized || !shared_memory || !cursors || !fn) return 0;
    // RT egress traffic counts into the segment-resident metrics so external
    // observers see reply/notification volume and ring health.
    ClockworkDrainMetrics m;
    if (metrics) {
        m.received  = &metrics->osc_in_messages_received;
        m.bytes     = &metrics->osc_in_bytes_received;
        m.corrupted = &metrics->osc_in_corrupted;
        m.seqGaps   = &metrics->messages_sequence_gaps;
    }
    return drain_egress_ring(shared_memory + RT_OUT_RING_START, RT_OUT_RING_SIZE,
                             &cursors->out_head, &cursors->out_tail, &cursors->out_read,
                             g_rt_drain_state, m, fn, ctx, max_frames);
}

uint32_t clockwork_egress_nrt_drain(ClockworkEgressFn fn, void* ctx, uint32_t max_frames) {
    if (!memory_initialized || !shared_memory || !cursors || !fn) return 0;
    // The same reply counters as the RT ring: which ring a reply rode is an
    // implementation detail (a guest's off-thread stage answers here, its
    // audio-thread stage there), and a client's "replies received" is the
    // sum. Sequence gaps stay per ring — this ring numbers its own frames.
    ClockworkDrainMetrics m;
    if (metrics) {
        m.received  = &metrics->osc_in_messages_received;
        m.bytes     = &metrics->osc_in_bytes_received;
        m.corrupted = &metrics->osc_in_corrupted;
    }
    const uint32_t delivered =
        drain_egress_ring(shared_memory + NRT_OUT_RING_START, NRT_OUT_RING_SIZE,
                          &cursors->nrt_out_head, &cursors->nrt_out_tail, &cursors->nrt_out_read,
                          g_nrt_drain_state, m, fn, ctx, max_frames);
    clockwork_egress_nrt_room_made();
    return delivered;
}

uint32_t clockwork_egress_nrt_max_frame(void) {
    return kNrtEgressMax - EGRESS_ROUTE_SIZE;
}

// Raised by the control pass while it holds work for room in the NRT egress
// ring; lowered by the reader that makes room, which wakes the pass. Process
// wide: every reader of this ring is in the engine's process.
static std::atomic<uint32_t> g_nrt_room_wanted{0};

static uint32_t nrt_free(void) {
    return ring_free_bytes(
        static_cast<uint32_t>(cursors->nrt_out_head.load(std::memory_order_acquire)),
        static_cast<uint32_t>(cursors->nrt_out_tail.load(std::memory_order_acquire)),
        NRT_OUT_RING_SIZE);
}

// The flag goes up before the second look, and a reader looks at it after it
// gives room back, so either the second look sees the room or the reader sees
// the flag.
void clockwork_egress_nrt_want_room(void) {
    g_nrt_room_wanted.store(1, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_seq_cst);
}

int clockwork_egress_nrt_room(uint32_t bytes) {
    if (!memory_initialized || !shared_memory || !cursors) return 0;
    if (nrt_free() >= bytes) return 1;
    clockwork_egress_nrt_want_room();
    return nrt_free() >= bytes;
}

uint32_t clockwork_egress_nrt_pending(void) {
    if (!memory_initialized || !shared_memory || !cursors) return 0;
    const auto head = static_cast<uint32_t>(cursors->nrt_out_head.load(std::memory_order_acquire));
    const auto read = static_cast<uint32_t>(cursors->nrt_out_read.load(std::memory_order_acquire));
    return (head - read + NRT_OUT_RING_SIZE) % NRT_OUT_RING_SIZE;
}

void clockwork_egress_nrt_room_made(void) {
    std::atomic_thread_fence(std::memory_order_seq_cst);
    if (g_nrt_room_wanted.load(std::memory_order_relaxed) != 0
        && g_nrt_room_wanted.exchange(0, std::memory_order_relaxed) != 0)
        clockwork_control_wake();
}

bool clockwork_egress_nrt_write(uint32_t route, uint32_t token,
                         const uint8_t* osc, uint32_t len) {
    if (!memory_initialized || !shared_memory || !cursors || !osc || len == 0)
        return false;
    // Subtraction form: len + EGRESS_ROUTE_SIZE would wrap for len near
    // UINT32_MAX and slip past the bound into the stack memcpy below. Too big
    // ever to carry is refused and counted, as a full ring's refusal is: the
    // frame reaches no one either way.
    if (len > kNrtEgressMax - EGRESS_ROUTE_SIZE) {
        if (metrics) metrics->egress_frames_refused.fetch_add(1, std::memory_order_relaxed);
        return false;
    }

    uint8_t buf[kNrtEgressMax];
    std::memcpy(buf, &route, sizeof(route));
    std::memcpy(buf + sizeof(route), osc, len);
    const bool written = RingBufferWriter::write(
        shared_memory + NRT_OUT_RING_START, NRT_OUT_RING_SIZE,
        &cursors->nrt_out_head, &cursors->nrt_out_tail,
        &cursors->nrt_out_sequence, &g_nrt_egress_lock,
        buf, len + EGRESS_ROUTE_SIZE, token);
    // Refused for want of room: counted, since the line logging it would
    // ride this same full ring (PerformanceMetrics::egress_frames_refused).
    if (!written && metrics) metrics->egress_frames_refused.fetch_add(1, std::memory_order_relaxed);
    if (written) clockwork_control_wake();
    return written;
}

void clockwork_egress_count_undelivered(uint32_t n) {
    if (n && metrics) metrics->egress_frames_undelivered.fetch_add(n, std::memory_order_relaxed);
}

// ── Tick ────────────────────────────────────────────────────────────────────

#ifdef __EMSCRIPTEN__
EMSCRIPTEN_KEEPALIVE
#endif
bool clockwork_tick(ClockworkBlockTime* time, uint32_t out_channels, uint32_t in_channels) {
    if (!time || time->struct_bytes < sizeof(ClockworkBlockTime)) return false;
    return process_audio(*time, out_channels, in_channels);
}

const float* clockwork_audio_out(void) {
    return reinterpret_cast<const float*>(get_audio_output_bus());
}

float* clockwork_audio_in(void) {
    return reinterpret_cast<float*>(get_audio_input_bus());
}

uint32_t clockwork_block_size(void) {
    return static_cast<uint32_t>(get_audio_buffer_samples());
}

double clockwork_sample_rate(void) {
    return get_audio_sample_rate();
}

ClockworkTimetag clockwork_block_time(void) {
    return get_audio_block_time();
}

// ── Init ──────────────────────────────────────────────────────────────────────

// The arena override init_memory() consults (set by the native backend when a
// public POSIX segment exists; null otherwise). Declared here so clockwork_init
// copies the guest's config block into the SAME arena init_memory will read:
// reading from arena_storage while the host wrote to a segment would see
// zeros.
extern uint8_t* g_external_segment;

// How many hosts hold the engine. Not atomic: attach and detach are control
// calls, made from a host's setup path, never from the audio thread, like
// clockwork_init.
static uint32_t g_attached = 0;

// Can the running engine serve a host that asked for this?
//
// Rate and block are exact: every host in the process renders the same blocks
// at the same rate, so they are not negotiable per-caller. A block of 0 means
// "whatever is running". Channels only have to be ENOUGH — a joiner that needs
// two of an engine that opened eight is served.
static bool geometry_serves(double sample_rate, uint32_t block_size,
                            uint32_t input_channels, uint32_t output_channels) {
    if (sample_rate != g_clockwork_config.sample_rate)              return false;
    if (block_size != 0 && block_size != g_clockwork_config.block_size) return false;
    if (input_channels  > g_clockwork_config.input_channels)        return false;
    if (output_channels > g_clockwork_config.output_channels)       return false;
    return true;
}

int clockwork_attach(double   sample_rate,
                uint32_t block_size,
                uint32_t input_channels,
                uint32_t output_channels,
                uint32_t verbosity,
                void*    guest_memory,
                uint32_t guest_memory_bytes,
                const void* guest_config,
                uint32_t    guest_config_bytes,
                uint32_t    arena_bytes,
                const void* assets,
                uint32_t    assets_bytes,
                void*       returns,
                uint32_t    returns_bytes) {
    if (g_attached == 0) {
        clockwork_init(sample_rate, block_size, input_channels, output_channels,
                  verbosity, guest_memory, guest_memory_bytes,
                  guest_config, guest_config_bytes, arena_bytes,
                  assets, assets_bytes, returns, returns_bytes);
        g_attached = 1;
        return CLOCKWORK_ATTACH_BOOTED;
    }

    if (!geometry_serves(sample_rate, block_size, input_channels, output_channels)) {
        clockwork_log("[attach] refused: running at %.0f Hz, %u frames, %u in / %u out; "
                "asked for %.0f Hz, %u frames, %u in / %u out",
                g_clockwork_config.sample_rate, g_clockwork_config.block_size,
                g_clockwork_config.input_channels, g_clockwork_config.output_channels,
                sample_rate, block_size, input_channels, output_channels);
        return CLOCKWORK_ATTACH_REFUSED;
    }

    // Joined. Deliberately nothing else: the arguments are not applied, the
    // guest config is not copied over the running one, and the arena is not
    // re-pointed. A joiner takes what is there.
    ++g_attached;
    return CLOCKWORK_ATTACH_JOINED;
}

void     clockwork_detach(void)   { if (g_attached) --g_attached; }
uint32_t clockwork_attached(void) { return g_attached; }

void clockwork_init(double   sample_rate,
              uint32_t block_size,
              uint32_t input_channels,
              uint32_t output_channels,
              uint32_t verbosity,
              void*    guest_memory,
              uint32_t guest_memory_bytes,
              const void* guest_config,
              uint32_t    guest_config_bytes,
              uint32_t    arena_bytes,
              const void* assets,
              uint32_t    assets_bytes,
              void*       returns,
              uint32_t    returns_bytes) {
    // THE SOLE-HOST CALL. Reconfiguring is routine — a device switch arrives
    // here — but once a second host has attached there is no longer any such
    // thing as "the" host's geometry, and applying one host's would silently
    // reconfigure the other's engine. Refused rather than obeyed. See
    // clockwork_attach in lanes.h.
    if (g_attached > 1) {
        clockwork_log("[init] refused: %u hosts are attached, so there is no "
                "single host whose geometry to apply. Use clockwork_attach.",
                g_attached);
        return;
    }
    // However this host arrived, it is now the one attached.
    if (g_attached == 0) g_attached = 1;

    uint8_t* const arena = g_external_segment ? g_external_segment : clockwork_local_arena();
#if CLOCKWORK_SYNTH
    // AN ARENA ALREADY UP IS AUDIO COMING BACK to the instance in it, as a
    // device returning is (docs/RESTARTS.md, "One event, every route"): a
    // page whose worklet the browser took away, reloaded over the same
    // memory; a host attaching again; a host's own device change. It does the
    // least that gets the engine back where it was (come_back, below, once
    // the host's bytes are in place). With no block rendering, which is this
    // call's contract anyway.
    const bool coming_back = memory_initialized && get_shared_memory_base() == arena;
#endif

    // Copy the guest's bytes into the region reserved for them, without
    // looking at any of them. NULL means the host has already put them there
    // (the web one has no C pointer to pass) or that there are none.
    if (guest_config && guest_config_bytes) {
        // Refused, not cut short: a config that does not fit is one the host
        // and the region disagree about, and a truncated block boots a guest
        // that cannot tell it was cut mid-line. ClockworkEngine refuses the
        // same config before it gets here, and the web side throws on it
        // (writeGuestConfigToMemory); this is the backstop for a host that
        // calls clockwork_init itself.
        if (guest_config_bytes > GUEST_CONFIG_SIZE) {
            clockwork_log("[init] refused: guest config is %u bytes but the region "
                    "holds %u — raise GUEST_CONFIG_SIZE (shared_memory.h) or send less",
                    guest_config_bytes, (uint32_t)GUEST_CONFIG_SIZE);
            return;
        }
        std::memcpy(arena + GUEST_CONFIG_START, guest_config, guest_config_bytes);
    }

    clockwork_set_engine_config(sample_rate, block_size, input_channels,
                           output_channels, verbosity,
                           guest_memory, guest_memory_bytes, arena_bytes,
                           assets, assets_bytes, returns, returns_bytes);
#if CLOCKWORK_SYNTH
    if (coming_back) {
        come_back();
        return;
    }
#endif
    init_memory();
}

void clockwork_set_channel_ceilings(uint32_t input_channels, uint32_t output_channels) {
    g_clockwork_config.input_channels  = input_channels;
    g_clockwork_config.output_channels = output_channels;
}

void clockwork_declare_fp_env(uint32_t env) {
    g_clockwork_config.fp_env = env;
}

void clockwork_set_guest_bulk_bytes(size_t bytes) {
    g_clockwork_config.guest_bulk_bytes = bytes;
}

const char* clockwork_boot_error(void) {
    return clockwork_last_boot_error();
}

// ── Layout ──────────────────────────────────────────────────────────────────

const ClockworkArenaHeader* clockwork_arena_header(void) {
    return arenaHeader(get_shared_memory_base());
}

void* clockwork_lanes_base(void) {
    return get_shared_memory_base();
}

// ── The control ring (lanes.h) ──────────────────────────────────────────────

void clockwork_control_serve(int on) {
    if (!cursors) return;
    if (on) cursors->status_flags.fetch_or(STATUS_CONTROL_SERVED, std::memory_order_release);
    else    cursors->status_flags.fetch_and(~static_cast<uint32_t>(STATUS_CONTROL_SERVED),
                                           std::memory_order_release);
}

int clockwork_control_served(void) {
    return cursors && (cursors->status_flags.load(std::memory_order_acquire) & STATUS_CONTROL_SERVED) ? 1 : 0;
}

// One pointer, so a writer always calls a function with its own context.
static std::atomic<const ClockworkControlWaker*> g_control_waker{nullptr};

void clockwork_control_waker(const ClockworkControlWaker* waker) {
    g_control_waker.store(waker, std::memory_order_release);
}

void clockwork_control_wake(void) {
    if (const ClockworkControlWaker* w = g_control_waker.load(std::memory_order_acquire))
        w->wake(w->ctx);
}

}  // extern "C"
