// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025 Sam Aaron
/*
 * ShmTransport.cpp — see ShmTransport.h. Reply-ring frames are standard
 * Message-framed OSC (ring/ring.h wire format, sourceId = origin token, no
 * route word): the peer drains them with the stock reader protocol.
 */
#include "ShmTransport.h"

#include "RingBufferWriter.h"

bool ShmTransport::writeReply(const uint8_t* data, uint32_t size) {
    auto* slot = mPlaneSlot.load(std::memory_order_acquire);
    if (!slot) return false;
    ShmPeerPlaneHeader* plane = slot->load(std::memory_order_acquire);
    if (!plane) return false;
    bool ok = RingBufferWriter::write(
        shm_peer_rep_ring(plane), SHM_PEER_REP_RING_SIZE,
        &plane->rep_head, &plane->rep_tail, &plane->rep_sequence,
        &mRepWriteLock,
        data, size, SHM_PEER_ORIGIN_TOKEN);
    if (!ok)
        plane->rep_dropped.fetch_add(1, std::memory_order_relaxed);
    return ok;
}

// networkOnly is moot — the peer is a real external process, not an
// in-process observer.
bool ShmTransport::send(uint32_t token, const uint8_t* data, uint32_t size,
                        bool /*networkOnly*/) {
    // Resolve semantics: only the plane's peer is addressable here (token 0 is
    // the in-process caller; any other value is no peer of ours).
    if (token != SHM_PEER_ORIGIN_TOKEN) return false;
    return writeReply(data, size);
}

// The audience is the one peer, if it subscribed.
uint32_t ShmTransport::broadcastTo(const std::atomic<bool>& subscribed,
                                   const uint8_t* data, uint32_t size) {
    return subscribed.load(std::memory_order_relaxed) && !writeReply(data, size) ? 1u : 0u;
}
uint32_t ShmTransport::broadcastNotify(const uint8_t* data, uint32_t size) { return broadcastTo(mNotify, data, size); }
uint32_t ShmTransport::broadcastLink(const uint8_t* data, uint32_t size) { return broadcastTo(mLink, data, size); }
uint32_t ShmTransport::broadcastMidi(const uint8_t* data, uint32_t size) { return broadcastTo(mMidi, data, size); }
uint32_t ShmTransport::broadcastGamepad(const uint8_t* data, uint32_t size) { return broadcastTo(mGamepad, data, size); }
uint32_t ShmTransport::broadcastOsc(const uint8_t* data, uint32_t size) { return broadcastTo(mOsc, data, size); }

// Caller-relative subscription with one possible caller: accept only the
// peer's token (an in-process caller — token 0 — is unaddressable here, the
// same rejection the socket transports apply to portless callers).
bool ShmTransport::subscribeFlag(std::atomic<bool>& flag, uint32_t token) {
    if (token != SHM_PEER_ORIGIN_TOKEN) return false;
    return !flag.exchange(true, std::memory_order_relaxed);
}

bool ShmTransport::subscribeNotify(uint32_t token) { return subscribeFlag(mNotify, token); }
// Registering an explicit localhost reply *port* is a UDP concept (the GUI's
// /clockwork/devices/report path); the SHM peer subscribes caller-relative.
void ShmTransport::unsubscribeNotify(uint32_t token) {
    if (token == SHM_PEER_ORIGIN_TOKEN) mNotify.store(false, std::memory_order_relaxed);
}
void ShmTransport::clearNotify() { mNotify.store(false, std::memory_order_relaxed); }

bool ShmTransport::subscribeLink(uint32_t token) { return subscribeFlag(mLink, token); }
void ShmTransport::unsubscribeLink(uint32_t token) {
    if (token == SHM_PEER_ORIGIN_TOKEN) mLink.store(false, std::memory_order_relaxed);
}
bool ShmTransport::subscribeMidi(uint32_t token) { return subscribeFlag(mMidi, token); }
void ShmTransport::unsubscribeMidi(uint32_t token) {
    if (token == SHM_PEER_ORIGIN_TOKEN) mMidi.store(false, std::memory_order_relaxed);
}
bool ShmTransport::subscribeGamepad(uint32_t token) { return subscribeFlag(mGamepad, token); }
void ShmTransport::unsubscribeGamepad(uint32_t token) {
    if (token == SHM_PEER_ORIGIN_TOKEN) mGamepad.store(false, std::memory_order_relaxed);
}
bool ShmTransport::subscribeOsc(uint32_t token) { return subscribeFlag(mOsc, token); }
void ShmTransport::unsubscribeOsc(uint32_t token) {
    if (token == SHM_PEER_ORIGIN_TOKEN) mOsc.store(false, std::memory_order_relaxed);
}
