// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025-2026 Sam Aaron
/*
 * dsp_api.h — the contract between clockwork and a DSP.
 *
 * The DSP fills buffers and is handed messages with the time they are meant
 * for. What it does in between is its own affair, including whether it has a
 * graph, a node tree, buses, or a schedule at all.
 *
 * See docs/BOUNDARY.md.
 */
#ifndef CLOCKWORK_DSP_API_H
#define CLOCKWORK_DSP_API_H

#include <stddef.h>
#include <stdint.h>

#include "clockwork_event_sink.h"   /* ClockworkSink: where a DSP's own output goes */
#include "clockwork_timetag.h"      /* ClockworkTimetag: every time across this boundary */

struct ClockworkClockState;

#ifdef __cplusplus
extern "C" {
#endif

/* An instance. Opaque, with no C transcription of its fields anywhere, so
   nothing can drift. */
struct Dsp;

/* ── What clockwork gives the DSP ─────────────────────────────────────── */

typedef struct DspConfig {
    double   sample_rate;
    uint32_t block_size;        /* frames per dsp_process call */

    /* CEILINGS, not counts. The live counts arrive per block and change while
       running: Link peers join and leave, aux sinks are added, a device switch
       brings a different interface. Size buffers against these in dsp_new —
       the only place a DSP may allocate — and read the live counts per block.
       Clockwork guarantees the per-block counts never exceed them. */
    uint32_t max_input_channels;
    uint32_t max_output_channels;

    /* The session clock. Read it with readClockworkClock()
       (clockwork_clock_state.h — the one other header a DSP includes), NEVER
       field by field: that is how the coherence rules get broken. May be
       NULL; readClockworkClock() then answers with a sane default. */
    const struct ClockworkClockState* clock;

    /* WHICH CHANNEL IS WHICH. Without this dsp_process is handed an anonymous
       range: a stereo file's left and right are indistinguishable from each
       other and from the microphone.

       Read it at the point of use — `channel_map->in[c]` is one relaxed load
       and tells you the kind (device, port, nothing) and which stream owns the
       channel. There is nothing to remember between blocks and nothing to
       consume: the read IS the lookup, and it is current by construction.

       The stream table beside it (names, ranges) is the COLD half, guarded by
       `generation`, and is not audio-thread work. See ClockworkChannelMapState
       in shared_memory.h.

       A channel is described no later than the audio it carries: the map entry
       is written before the binding is published. May be NULL when the host
       reserved no arena. */
    const struct ClockworkChannelMapState* channel_map;

    /* A window of shared memory the DSP may use however it likes. Clockwork
       publishes these bytes and never interprets them — with ONE exception,
       so that a client can poll it cheaply: the FIRST uint32 is a version
       stamp the guest bumps whenever it changes anything else in the window.
       Clockwork watches that word and nothing else; a guest that never bumps
       it is simply snapshotted on the usual interval, and one that publishes
       nothing may ignore the region entirely. NULL/0 if none. */
    void*    shm_window;
    uint32_t shm_window_bytes;

    /* Storage that OUTLIVES THIS INSTANCE, private to the DSP. Clockwork will
     * not touch it and will not zero it across a rebuild. A COLD BOOT DOES
     * clear it — only clockwork knows whether this is a device switch or a
     * fresh engine in a process that had one before.
     *
     * It exists because a DSP does not always get to say goodbye: a browser
     * kills the worklet outright when a tab is backgrounded, and there is no
     * thread left to run a save callback on.
     *
     * The bytes are hostile and must be treated so:
     *
     *   - TORN. A death mid-write leaves half an update. Stamp a generation
     *     and validate before believing anything here.
     *   - STALE. It may be from a run that crashed, and restoring blindly can
     *     resurrect the cause.
     *   - NOT DURABLE. Shared memory, not a file. It does not cross a process
     *     boundary, and a transport without shared memory has none of it.
     *
     * NULL/0 if none, which is a working state: a DSP given nothing restores
     * nothing and must still start. */
    void*    persistent;
    uint32_t persistent_bytes;

    /* ── The guest's memory, and the two bulk lanes ──────────────────────
     *
     * A GUEST'S MEMORY, IN FOUR SENTENCES. You get two spans, one per speed:
     * `memory` is fast and `memory_bulk` is bulk. Say how much of each you
     * need (DspInfo::memory_bytes_wanted and memory_bulk_bytes_wanted, plus
     * dsp_memory_bytes and dsp_memory_bulk_bytes for what your configuration
     * adds) and clockwork gives exactly that, or refuses the boot and says
     * why. Lay out your hot per-block state in `memory` by hand; everything
     * you allocate as you run comes from `memory_bulk`, through clockwork's
     * allocator (DspHost::alloc_bytes, or in Rust simply Box and Vec). There
     * is nothing else: a sample arrives read-only in `assets`, what you hand
     * back goes in `returns`, and your window, config and persistent store
     * are in the arena above.
     *
     * On a desktop or the web the two speeds are one RAM and the two spans
     * are slices of one block; a guest is written once and only the sizes
     * change per target. On a device with two kinds of RAM (the ESP32-S3:
     * ~512 KiB of internal SRAM behind 8 MiB of slower PSRAM) `memory` is
     * internal SRAM and `memory_bulk` PSRAM, and the placement is the host's
     * memory profile's, never a guest crate's. The rule for a device: touched
     * every block goes fast; touched less than that goes bulk.
     *
     * EACH REGION HAS EXACTLY ONE WRITER: the guest writes `memory` and
     * `returns`, the client writes `assets`. `assets` is const here, so a GUEST
     * that writes it does not compile; the client holds the same bytes
     * writable, and its own view of `returns` is const for the same reason.
     *
     * Bulk moves by not being copied. A client writes into `assets` from its own
     * thread and sends a short message saying where; the guest receives an
     * offset rather than a payload. Nothing large crosses the audio thread in
     * either direction, which matters because every entry point in this header
     * is called on the audio thread — and on web that is forced, since the
     * guest exists only inside the AudioWorklet and no off-thread door can
     * exist.
     *
     * OFFSETS, NOT POINTERS, in any message naming a position in these. A
     * reader maps the segment wherever the kernel puts it, which is not the
     * address the engine sees, so a raw pointer names the wrong bytes on the
     * other side — and does so without faulting.
     *
     * A SEGMENT PUBLISHES THESE, IT DOES NOT CREATE THEM. A host with no
     * shared segment still hands over all three; a client in its own process
     * reads them in place. */

    /* THE FAST SPAN: what the guest lays out by hand at dsp_new and holds
     * for the instance's life, reached with no allocator — its tables, its
     * pools, its buses, anything sized by its configuration and touched
     * every block. Clockwork reserves it from fast RAM, sized to what the
     * guest asks, zeroes it at every dsp_new and never touches a byte after
     * that. NOTHING ELSE WRITES HERE, and no client can reach it: it is not
     * in the arena.
     *
     * NULL/0 for a guest that asked for none (a guest whose state is all
     * allocated, a Rust guest that keeps it in a Box, say), where the host
     * profile gives no floor either.
     *
     * Nothing in clockwork can stop a guest keeping its state in globals or
     * taking it with malloc, and such a guest runs; but memory taken those
     * ways lives wherever the linker or the allocator put it, which
     * clockwork can neither tier on a device nor name as the guest's on a
     * map, and a malloc on the audio thread is the one thing the whole
     * engine is built to avoid. So clockwork counts them (guest_malloc.h):
     * where the link lets it stand between the program and its allocator,
     * every malloc and new made inside a guest entry point is counted as the
     * guest's, and the metrics say what it holds and how often it allocated
     * while processing. */
    void*    memory;
    uint32_t memory_bytes;

    /* THE BULK SPAN: where everything the guest allocates as it runs comes
     * from. Clockwork runs its allocator over the whole of it (DspHost::
     * alloc_bytes and free_bytes; a Rust guest's Box and Vec go there by
     * themselves, through clockwork's global allocator, while a guest entry
     * point is open), so A GUEST NEVER WRITES IT BY HAND: the base and the
     * size are here so a guest can tell its own range from a client's
     * (an asset in the assets area is never freed), and for nothing else. Zeroed
     * and started over at every dsp_new. On a device with two kinds of RAM
     * this is the slow, large one.
     *
     * The allocator is lock-free on the audio thread and answers NULL when
     * the span is full; it never blocks, never grows and never reaches
     * malloc. What you declared is what you have. Sized by the
     * guest's bulk want, or the host profile's default when the guest
     * declares none (a desktop's 64 MB; what the client sized on the web).
     *
     * NULL/0 only on a host with no pool at all (a no-DSP core). */
    void*    memory_bulk;
    uint32_t memory_bulk_bytes;

    /* Bulk in. THE CLIENT WRITES, THE GUEST ONLY READS — hence const. A guest
     * that needs to mutate what arrived copies it into its own memory first.
     *
     * A published range belongs to the guest until it says otherwise, so a
     * guest that reads in place rather than copying must say when it is done.
     * NULL/0 when the host offers no inbound bulk. */
    const void* assets;
    uint32_t    assets_bytes;

    /* Bulk out. THE GUEST WRITES, THE CLIENT ONLY READS. Write the payload
     * here and send a short message saying where it landed, rather than
     * pushing it through emit_osc, which would copy it in the audio callback.
     * NULL/0 when the host offers no outbound bulk. */
    void*    returns;
    uint32_t returns_bytes;

    /* The guest's own configuration, written by the host, opaque here — how
       many buses, how many nodes, how big a wire pool. Clockwork reserves the
       region, copies the block in, and hands over base and length without
       looking inside, so a change to the layout cannot break it. NULL/0 if the
       host supplies none. */
    const void* guest_config;
    uint32_t    guest_config_bytes;

    /* Pins the RNG seed for an offline render, so two runs of the same score
       agree. 0 for "seed however you like". */
    int32_t  deterministic_seed;

    /* THE FLOATING-POINT ENVIRONMENT OF THE THREAD dsp_process RUNS ON, as the
     * host declared it (DspFpEnv). Denormal flush-to-zero is a per-thread CPU
     * flag; the native device layer arms it on its audio thread, a web worklet
     * cannot arm it at all, and an embedded host may or may not. Two targets
     * that differ here render different tails from the same filter, so a guest
     * that promises the same samples on every target must not depend on the
     * flag — it reads this, and either flushes in software itself or keeps its
     * state out of the denormal range by construction.
     *
     * DSP_FP_ENV_UNKNOWN means the host declared nothing. Treat it as
     * DENORMALS_HONOURED: assuming a flush that is not there is the failure
     * that costs CPU; assuming none when there is one costs nothing. */
    int32_t  fp_env;
} DspConfig;

/* What DspConfig::fp_env can say. */
typedef enum DspFpEnv {
    DSP_FP_ENV_UNKNOWN            = 0,  /* the host declared nothing */
    DSP_FP_ENV_DENORMALS_HONOURED = 1,  /* IEEE denormals are computed (web, always) */
    DSP_FP_ENV_FLUSH_TO_ZERO      = 2   /* FTZ/DAZ armed on the audio thread by the host */
} DspFpEnv;

/* A DSP's hold on a tap slot (DspHost::tap_open). Four words, the shape
   the tap substrate spells out (rust/clockwork-taps), and a DSP treats it
   as opaque apart from two reads: `slot` is non-NULL while the handle owns a
   slot, and `channels` is how many channels that slot carries, as clamped by
   the host. The other two are unused and 0. */
typedef struct DspTapHandle {
    void*    slot;
    float*   data;
    uint32_t channels;
    uint32_t max_frames;
} DspTapHandle;

/* What the DSP may call back into. Every entry may be NULL; a DSP must check.
   `ctx` is clockwork's own and is passed back untouched. */
typedef struct DspHost {
    void* ctx;

    /* Send OSC out — a reply, a notification, anything. `origin` echoes the
     * value the message being answered arrived with, so clockwork can route it
     * back. Callable from the audio thread.
     *
     * 0 addresses the notification audience — the clients that asked to be
     * notified — one unicast per subscriber. That list is empty until someone
     * subscribes, and a client that sent a request is not on it by virtue of
     * having sent one, so a REPLY MUST CARRY THE ORIGIN IT WAS GIVEN. A
     * non-zero return means the frame was queued, never that anything
     * received it.
     *
     * BULK DOES NOT GO HERE: sending copies the payload into the egress ring,
     * so a large reply is a large memcpy in the audio callback. Write it into
     * DspConfig::returns and send a short message saying where.
     *
     * Returns non-zero if accepted. A full ring DROPS and counts rather than
     * blocking, so a guest that sends bulk here gets a refusal it can see. */
    int (*emit_osc)(void* ctx, uint32_t origin, const uint8_t* bytes, uint32_t len);

    /* Diagnostics. `level` follows syslog severities (3 = error, 6 = info,
     * 7 = debug). Hand it FINISHED TEXT: it formats nothing.
     *
     * Callable from any thread, INCLUDING the audio thread, which is where a
     * DSP's own errors mostly happen: on the audio thread the text is copied
     * into the lock-free debug ring and dropped, counted, when that is full;
     * on any other thread it may take a lock. So it is not free — a line per
     * block is fine, a line per sample is not — but it never blocks the
     * tick. */
    void (*log)(void* ctx, int level, const char* text);

    /* Open a sink onto an external destination and get a handle. `target` names
     * it in the endpoint's own terms: a MIDI port name, or "host:port" for OSC.
     * `capacity` is clamped into the allowed range and rounded up to a power of
     * two, so you get at least what you asked for.
     *
     * Returns CLOCKWORK_SINK_NONE if the destination does not exist or this
     * build cannot reach it. CHECK IT: a sink that opened onto nothing would
     * accept every message and deliver none.
     *
     * CONTROL THREAD ONLY. It allocates and may touch the device, so it belongs
     * in dsp_new, never in dsp_process.
     *
     * GAP: a DSP usually learns which destination to open from a control
     * message, and dsp_osc is its only door for one — but dsp_osc runs on the
     * audio thread. So a DSP either opens in dsp_new from something it was
     * configured with, or opens on the audio thread and accepts an allocation
     * there. Closing this needs a per-instance control tick the boundary lacks.
     *
     * NOT IDEMPOTENT. Opening the same target twice gives two handles, two
     * sinks and two of the 16 slots clockwork remembers a DSP's sinks in;
     * after that this answers CLOCKWORK_SINK_NONE. The substrate cannot
     * usefully de-duplicate, because a sink belongs to whoever opened it and
     * clockwork closes a DSP's sinks when the DSP is freed — handing back a
     * sink another owner opened would let dsp_free close the engine's own MIDI
     * clock output. A DSP that opens on demand should therefore de-duplicate
     * the way clockwork does internally: list the open sinks and compare
     * clockwork_sink_target (clockwork_event_sink.h) before opening.
     *
     * Clockwork closes every sink a DSP opened when that DSP is freed. There is
     * deliberately no close here: a DSP's sinks last as long as the DSP. */
    ClockworkSink (*open_sink)(void* ctx, ClockworkSinkKind kind, const char* target,
                         uint32_t capacity);

    /* Send one message to a sink, delivered at `when` — an OSC timetag in the
     * same domain as dsp_process's block_time, or
     * clockwork_timetag_immediately(). A DSP that knows a note is due 20 ms
     * into the block says clockwork_timetag_add(block_time, 20 ms) and stops
     * thinking about it.
     *
     * Returns non-zero if accepted; a full sink DROPS and counts.
     *
     * CALLABLE FROM dsp_process. Never allocates, locks or blocks. */
    int (*send_sink)(void* ctx, ClockworkSink sink, const uint8_t* bytes,
                     uint32_t len, ClockworkTimetag when);

    /* Give back bytes taken through alloc_bytes. Callable from any thread,
       the audio thread included: freeing is lock-free and a foreign thread's
       free is parked for the engine thread to drain. NULL is ignored; a
       pointer the guest's pool does not hold (a foreign thread's allocation,
       which came from the system) goes back to where it came from. */
    void (*free_bytes)(void* ctx, void* ptr);

    /* The guest is done with an asset it was handed through dsp_asset: the
     * slot in the assets area may be reclaimed. Clockwork tells the client that
     * committed it (/clockwork/asset/released <id>), and the client's pool
     * takes the slot back. Callable from dsp_process and dsp_osc — it emits
     * one short message and nothing else. Returns non-zero if the id was a
     * live asset; a release of something not committed is ignored. NULL on a
     * host with no asset facility. */
    int (*asset_release)(void* ctx, uint32_t id);

    /* Take bytes from the guest's bulk memory (DspConfig::memory_bulk), the
     * span clockwork runs its allocator over; free_bytes gives them back.
     *
     * This is where everything a C guest allocates as it runs comes from —
     * a definition, a buffer a client asked for empty, a table — so that no
     * guest ships an allocator of its own or reaches past this header for
     * one. A Rust guest does not call this: its Box and Vec land in the same
     * span by themselves while one of its entry points is open.
     *
     * Lock-free and callable from ANY THREAD, the audio thread included: on
     * the engine thread from the pool, and a request it cannot meet answers
     * NULL rather than blocking or growing on that thread; on any other
     * thread from the system allocator, on that thread. 64-byte aligned,
     * so a block can hold the vectors of any SIMD width up to AVX-512.
     * A host with no pool leaves this NULL and a guest falls back to
     * whatever it has. NULL for 0 bytes. */
    void* (*alloc_bytes)(void* ctx, size_t bytes);

    /* ── Taps ────────────────────────────────────────────────────────────
     *
     * A tap is a stream of audio a client reads out of shared memory to
     * draw. Clockwork owns the slots and the ring format; a DSP that wants to
     * publish one claims a slot here and appends blocks to it, and never
     * learns the layout.
     *
     * tap_open claims slot `index` for `channels` channels — clamped to
     * what a slot carries, and the clamped count is written back into the
     * handle — and returns non-zero if it did. The handle is the DSP's, and
     * it is the handle's ADDRESS that owns the slot: a slot may be re-claimed
     * through another handle while a superseded one still lives (a graph
     * rebuilt under a running client), and a late close from the old handle
     * then does nothing. Callable from the audio thread; never allocates.
     *
     * tap_write appends `frames` frames from `n_channels` channel buffers.
     * Fewer channels than the slot carries fill the rest with the last one
     * given. Clockwork anchors the block on its own sample clock, so the DSP
     * has no position to pass. Audio thread; never allocates or blocks.
     *
     * tap_close gives the slot back, if `hnd` still owns it. */
    int  (*tap_open)(void* ctx, uint32_t index, uint32_t channels, DspTapHandle* hnd);
    void (*tap_write)(void* ctx, DspTapHandle* hnd, const float* const* channels,
                        uint32_t n_channels, uint32_t frames);
    void (*tap_close)(void* ctx, DspTapHandle* hnd);
    /* Drop every message clockwork holds for this DSP ahead of its time: the
     * timestamped bundles a client sent early, which clockwork keeps and
     * delivers to dsp_osc when each falls due. For a DSP's own "clear the
     * schedule" verb (scsynth's /clearSched), which would otherwise clear
     * nothing, since the DSP holds none of them. Nothing already delivered
     * is affected, and clockwork's own scheduled events (its /clockwork/
     * schedule verb, the clock) are not a DSP's to drop.
     *
     * CALLABLE FROM dsp_process: it runs where the schedule is driven. */
    void (*flush_schedule)(void* ctx);
} DspHost;

/* ── What the DSP says about itself ─────────────────────────────────────── */

/* Vocabulary as data — the native counterpart of js/lib/dsp_profile.js. The C
   ABI stays fixed while each DSP declares its own words. */
typedef struct DspInfo {
    const char* name;
    const char* version;

    /* Non-zero if the DSP holds its own schedule and wants every message the
       moment it arrives, carrying its timetag. Zero to have clockwork hold
       timed messages and deliver them when due. */
    int32_t holds_schedule;

    /* WHAT THE DSP NEEDS OF ITS MEMORY, in bytes, per speed: the fast span
     * it lays out by hand (DspConfig::memory) and the bulk span it allocates
     * from (DspConfig::memory_bulk). Static, like the rest of this struct,
     * because a guest that carves everything it will ever hold at dsp_new
     * knows the figure before any instance exists — a loop cell of so many
     * seconds, a voice pool of so many slots — and the host should learn it
     * before booting audio, not from a failed carve halfway through dsp_new.
     * What the guest's configuration adds is asked separately
     * (dsp_memory_bytes, dsp_memory_bulk_bytes), and the host profile's
     * default is a floor under each.
     *
     * Clockwork compares these with what it can offer and REFUSES dsp_new,
     * with a logged reason, when a non-zero want cannot be met in the speed
     * it names. It NEVER spills: a hot pool that silently landed in PSRAM is
     * a performance cliff with no error, which is worse than a boot that
     * says why it stopped.
     *
     * 0 means "no claim": take what the profile offers. A guest whose state
     * is all allocated declares 0 for the fast span and gets none. */
    uint32_t memory_bytes_wanted;
    uint32_t memory_bulk_bytes_wanted;

    /* Non-zero if the DSP wants the host's INBOUND EVENTS — what a MIDI port
     * or a game controller sent, as "/clockwork/midi/in/…",
     * "/clockwork/gamepad/in/…", and the "/clockwork/midi/ports" /
     * "/clockwork/gamepad/devices" pushes — handed to dsp_osc as they arrive,
     * on the audio thread, beside the clients that subscribed to them. The
     * one exception to the rule that nothing under "/clockwork/" reaches a
     * DSP, and made only because the DSP asked. Each carries the moment it
     * arrived as a trailing `t` argument when the host knows it (the web does;
     * a native port's arrival is the block it was drained in), so a DSP that
     * holds its own schedule can place it on its own timeline. Zero: a client
     * that wants the DSP to hear a keyboard relays it. Same host on both
     * sides: a DSP that sets this never learns which host it is on. */
    int32_t wants_events;

    /* WHAT THE WINDOW IS. shm_window is the guest's to lay out and clockwork
       never interprets it, so a client that reads the window by hand has no
       way to know which guest wrote it, or which layout, before it casts a
       pointer. These two words say: a magic naming the guest's window format
       and the version of that format. Clockwork copies them into the arena
       table's window entry when the guest binds (CLOCKWORK_GEOM_WINDOW_MAGIC,
       CLOCKWORK_GEOM_WINDOW_VERSION), where every reader of the table finds
       them. 0 and 0: undeclared — a client reading the window is on its
       own. */
    uint32_t window_magic;
    uint32_t window_version;
    /* WHAT DEVICE CHANGE THE INSTANCE CAN TAKE LIVE (DSP_SURVIVES_*). A
       device change clockwork would otherwise answer with a cold restart —
       the instance destroyed and built again, everything it held gone,
       every client told to rebuild (docs/RESTARTS.md) — is a HOT one when
       the instance declares it survives that kind of change: the device is
       reopened, the instance is told the new facts (dsp_reconfigure), and
       it keeps everything it holds. 0: survives nothing; every such change
       is cold, and dsp_reconfigure is never called. A guest built for one
       rate and one channel count — a server whose world is laid out at
       boot — declares 0 and is not wrong to. */
    uint32_t survives;
} DspInfo;

/* DspInfo::survives: the kinds of device change an instance takes live. */
#define DSP_SURVIVES_RATE_CHANGE     (1u << 0)   /* a different sample rate */
#define DSP_SURVIVES_CHANNEL_CHANGE  (1u << 1)   /* different channel ceilings */

/* Static: describable before any instance exists, so a host can report what it
   is linked against without booting audio. */
const DspInfo* dsp_describe(void);

/* The fast span an instance built from this guest config lays out at
   dsp_new (DspConfig::memory), in bytes: what its configuration asks for
   beyond DspInfo::memory_bytes_wanted — a server guest's real-time pool is
   one of its options, and only the guest can read that. Clockwork reserves
   the larger of the two from fast RAM before dsp_new, every build. 0: the
   static want is the whole of it. Static, like dsp_describe: no instance
   exists yet. `guest_config` is DspConfig's. */
uint64_t dsp_memory_bytes(const void* guest_config, uint32_t guest_config_bytes);

/* The same for the bulk span (DspConfig::memory_bulk): what this
   configuration will make the instance allocate as it runs, beyond
   DspInfo::memory_bulk_bytes_wanted — buffers a client may ask for empty,
   definitions. Clockwork reserves the largest of the two and the host
   profile's default before dsp_new, every build. 0: no claim beyond those.
   Static, like dsp_describe. */
uint64_t dsp_memory_bulk_bytes(const void* guest_config, uint32_t guest_config_bytes);

/* ── Lifecycle ──────────────────────────────────────────────────────────── */

/* Build an instance, or NULL with `err` set to a message the DSP owns. */
struct Dsp* dsp_new(const DspConfig* config, const DspHost* host, const char** err);

/* Destroy an instance. WHAT THE GUEST OWES HERE (docs/RESTARTS.md, "What the
   guest owes"): before this returns, every ask the instance accepted and has
   not yet answered is answered, in the guest's own words — a load it was
   still doing, a read it was still waiting on — so no client is left holding
   a question an instance that no longer exists would have answered. What the
   guest holds is its business; clockwork's part is that those answers leave
   on the rings before the rings reset. What it keeps across a rebuild is what
   it wrote into DspConfig::persistent; everything else goes with it. */
void        dsp_free(struct Dsp* dsp);

/* A device change the instance declared it survives (DspInfo::survives):
   the new rate and channel ceilings, in place, with audio stopped — no
   block renders between the device going down and this returning — and
   nothing else changed: the memory, the window, the clock, the channel map
   are where they were. Return 0 to take it; non-zero to refuse, on which
   clockwork does what it would have done had the instance declared no
   survival: destroys it and builds it again, a cold restart. Never called
   for a change the instance did not declare. */
int         dsp_reconfigure(struct Dsp* dsp, double sample_rate,
                            uint32_t max_input_channels, uint32_t max_output_channels);

/* ── The tick ───────────────────────────────────────────────────────────── */

/*
 * Render one block: read `frames` from each of `n_in` input channels, write
 * `frames` to each of `n_out` output channels. `in` may be NULL when the host
 * captures no input. Output is WRITTEN, NOT ACCUMULATED — a DSP with nothing to
 * say writes silence.
 *
 * THE COUNTS ARRIVE PER BLOCK and change while running. Neither exceeds the
 * ceiling in DspConfig.
 *
 * A channel index is a STABLE SLOT for the lifetime of the stream occupying it.
 * A peer leaving does not renumber the peers after it — its slot goes silent
 * and stays reserved until reused — because renumbering would silently hand a
 * DSP somebody else's audio on a channel it was already processing. Slots above
 * the live count are not written and must not be read.
 *
 * `block_time` is the OSC timetag of the block's FIRST frame. A message due at
 * T lands at frame clockwork_timetag_offset(block_time, T) * sample_rate / 2^32,
 * and the DSP does that arithmetic because only the DSP knows what it means to
 * act at a frame.
 *
 * Called on the audio thread. No allocation, no locks, no IO.
 */
void dsp_process(struct Dsp* dsp,
                 const float* const* in, uint32_t n_in,
                 float* const* out, uint32_t n_out,
                 uint32_t frames,
                 ClockworkTimetag block_time);

/* ── Messages ───────────────────────────────────────────────────────────── */

/*
 * Hand the DSP one OSC message or bundle.
 *
 * `when` is ALWAYS the message's own timetag; clockwork never flattens it to
 * "now". A DSP that declared holds_schedule receives messages as they arrive
 * and decides when to act; one that did not receives each during the block in
 * which it comes due. Either way the exact time survives, which is what makes
 * sub-block placement possible. OSC's "immediately" is kept, and
 * clockwork_timetag_is_immediate says so.
 *
 * `origin` identifies the sender; pass it to DspHost::emit_osc unchanged.
 *
 * `block_time` is the timetag of the first frame of THE BLOCK THIS MESSAGE IS
 * FOR — the other half of dsp_process's placement arithmetic. Messages are
 * delivered before dsp_process renders the block they belong to, so a DSP that
 * used dsp_process's block_time instead would be a whole block out. A DSP that
 * does not place events within a block may ignore it.
 *
 * ON THE AUDIO THREAD. Both call sites are inside process_audio and there is no
 * other delivery path, so this must not allocate or block.
 *
 * `bytes` POINTS INTO THE INGRESS RING and is valid only for this call. A guest
 * that wants to keep a payload must copy it out before returning — so the
 * memcpy lands on the audio thread whatever its size. Clockwork having avoided
 * a copy moves who pays for it, not whether it is paid.
 *
 * A TIMED MESSAGE IS COPIED TWICE when the DSP does not hold its own schedule:
 * clockwork copies the payload into its data pool (SCHEDULER_DATA_POOL_SIZE) on
 * the audio thread during the drain, and the guest copies it again when it
 * fires.
 *
 * SO DO NOT SEND BULK THROUGH HERE. Write it into DspConfig::returns and
 * send a short message saying where. What belongs here is commands, parameters,
 * notes, and references to bulk that lives elsewhere.
 */
void dsp_osc(struct Dsp* dsp,
             const uint8_t* bytes,
             uint32_t len,
             ClockworkTimetag when,
             uint32_t origin,
             ClockworkTimetag block_time);


/* ── Assets: bulk that enters through the assets area lane ─────────────────────── */

/*
 * A sample, a wavetable, a synthdef bundle, a model: a large blob the guest
 * needs in memory and must never receive through the message ring. It enters
 * through the assets area lane (DspConfig::assets), and only the CLIENT puts it there:
 * the client owns the lane and a pool over it (clockwork_asset_pool.h), writes
 * the bytes into a slot — decoding a file first if that is what the bytes
 * need, with clockwork_audio_file.h, which is a client API — and sends one
 * message naming the slot:
 *
 *   /clockwork/asset/commit  ,iiiiiif  id kind offset bytes channels frames rate
 *                            (rate may come as an int: a whole number of Hz)
 *
 * The audio thread checks the range against the lane and hands the guest a
 * pointer through dsp_asset. No copy: the guest reads the client's bytes where
 * they lie, for as long as it holds the asset. When it lets go it calls
 * DspHost::asset_release, and the client hears
 *
 *   /clockwork/asset/released  ,i  id
 *
 * and reclaims the slot. A commit that cannot be honoured is answered with
 *   /clockwork/asset/refused   ,is id reason
 * and the guest never sees it. A commit that could is answered with
 *   /clockwork/asset/committed ,i  id
 *
 * The id is the client's, and the guest's key to whatever it binds the bytes
 * to; committing an id that is still held is refused until it is released.
 * Nothing here knows what a sample is. The KIND says how to read the bytes,
 * and RAW says "however the guest likes".
 */
enum {
    CLOCKWORK_ASSET_RAW       = 0,   /* bytes; channels/frames/rate carry nothing */
    CLOCKWORK_ASSET_AUDIO_F32 = 1    /* interleaved 32-bit float frames; byte_count
                                      * == frames * channels * 4, and rate is Hz */
};

typedef struct ClockworkAsset {
    uint32_t    struct_bytes;   /* sizeof(ClockworkAsset), for the guest to check */
    uint32_t    id;
    uint32_t    kind;           /* CLOCKWORK_ASSET_* */
    uint32_t    origin;         /* who committed it; opaque to the guest */
    const void* bytes;          /* into the assets area; valid until the guest releases */
    uint32_t    byte_count;
    uint32_t    channels;       /* AUDIO_F32 only, else 0 */
    uint32_t    frames;
    float       sample_rate;
} ClockworkAsset;

/*
 * Take an asset. Called on the audio thread, between messages of the block the
 * commit arrived in; the range has been checked against the lane and, for
 * AUDIO_F32, the geometry against the byte count. Return 0 to take it — the
 * bytes stay valid until the guest calls DspHost::asset_release(id) — or
 * non-zero to refuse, which the client hears as /clockwork/asset/refused.
 * No allocation, no locks, no IO: binding a pointer is all this is for.
 */
int dsp_asset(struct Dsp* dsp, const ClockworkAsset* asset);

#ifdef __cplusplus
}
#endif

#endif /* CLOCKWORK_DSP_API_H */
