/*
  ==============================================================================

   This file is part of the JUCE library.
   Copyright (c) 2022 - Raw Material Software Limited

   JUCE is an open source library subject to commercial or open-source
   licensing.

   The code included in this file is provided under the terms of the ISC license
   http://www.isc.org/downloads/software-support-policy/isc-license. Permission
   To use, copy, modify, and/or distribute this software for any purpose with or
   without fee is hereby granted provided that the above copyright notice and
   this permission notice appear in all copies.

   JUCE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY, AND ALL WARRANTIES, WHETHER
   EXPRESSED OR IMPLIED, INCLUDING MERCHANTABILITY AND FITNESS FOR PURPOSE, ARE
   DISCLAIMED.

  ==============================================================================
*/

namespace juce
{

//==============================================================================
/**
    Represents a type of audio driver, such as DirectSound, ASIO, CoreAudio, etc.

    To get a list of available audio driver types, use the AudioDeviceManager::createAudioDeviceTypes()
    method. Each of the objects returned can then be used to list the available
    devices of that type. E.g.
    @code
    OwnedArray<AudioIODeviceType> types;
    myAudioDeviceManager.createAudioDeviceTypes (types);

    for (int i = 0; i < types.size(); ++i)
    {
        String typeName (types[i]->getTypeName());  // This will be things like "DirectSound", "CoreAudio", etc.

        types[i]->scanForDevices();                 // This must be called before getting the list of devices

        StringArray deviceNames (types[i]->getDeviceNames());  // This will now return a list of available devices of this type

        for (int j = 0; j < deviceNames.size(); ++j)
        {
            AudioIODevice* device = types[i]->createDevice (deviceNames [j]);

            ...
        }
    }
    @endcode

    For an easier way of managing audio devices and their settings, have a look at the
    AudioDeviceManager class.

    @see AudioIODevice, AudioDeviceManager

    @tags{Audio}
*/
class JUCE_API  AudioIODeviceType
{
public:
    //==============================================================================
    /** Returns the name of this type of driver that this object manages.

        This will be something like "DirectSound", "ASIO", "CoreAudio", "ALSA", etc.
    */
    const String& getTypeName() const noexcept                      { return typeName; }

    //==============================================================================
    /** Refreshes the object's cached list of known devices.

        This must be called at least once before calling getDeviceNames() or any of
        the other device creation methods.
    */
    virtual void scanForDevices() = 0;

    /** Returns the list of available devices of this type.

        The scanForDevices() method must have been called to create this list.

        @param wantInputNames    for devices which have separate inputs and outputs
                                 this determines which list of names is returned
    */
    virtual StringArray getDeviceNames (bool wantInputNames = false) const = 0;

    /** Returns the name of the default device.

        This will be one of the names from the getDeviceNames() list.

        @param forInput     if true, this means that a default input device should be
                            returned; if false, it should return the default output
    */
    virtual int getDefaultDeviceIndex (bool forInput) const = 0;

    /** Returns the index of a given device in the list of device names.
        If asInput is true, it shows the index in the inputs list, otherwise it
        looks for it in the outputs list.
    */
    virtual int getIndexOfDevice (AudioIODevice* device, bool asInput) const = 0;

    /** Returns true if two different devices can be used for the input and output.
    */
    virtual bool hasSeparateInputsAndOutputs() const = 0;

    /** Creates one of the devices of this type.

        The deviceName must be one of the strings returned by getDeviceNames(), and
        scanForDevices() must have been called before this method is used.
    */
    virtual AudioIODevice* createDevice (const String& outputDeviceName,
                                         const String& inputDeviceName) = 0;

    //==============================================================================
    /** smoothie addition: what a device is, as its driver says without
        opening it. What the driver can't say is left as it is here. */
    struct DeviceTraits
    {
        bool wireless = false;        /**< its link negotiates its own rate and
                                           buffer (AirPlay, Bluetooth) */
        bool isVirtual = false;       /**< made in software (Loopback, BlackHole) */
        bool aggregateClass = false;  /**< made of other devices (an aggregate, a
                                           multi-output device) */
        bool pairs = true;            /**< can play as one with a different device,
                                           output on one and input on the other
                                           (createDevice with two names) */
        int numOutputChannels = -1;   /**< -1: can't say without opening it */
        int numInputChannels = -1;
        Array<double> sampleRates;    /**< empty: can't say without opening it */
        Array<int> bufferSizes;       /**< empty: can't say without opening it */
        String kind;                  /**< the driver's own word for how it is
                                           connected, for logs ("usb ", "blue") */
    };

    /** smoothie addition: the traits of the device getDeviceNames lists as
        `deviceName`. The default knows nothing about it.
    */
    virtual DeviceTraits getDeviceTraits (const String& deviceName) const;

    /** smoothie addition: the operating system's default output (or input)
        among this type's devices, by the name getDeviceNames gives it; empty
        when the type has no such thing (ASIO) or can't say. The default
        answers by getDefaultDeviceIndex.
    */
    virtual String getSystemDefaultDeviceName (bool forInput) const;

    /** smoothie addition: the name of the application the devices are
        opened for, for what a type makes in the operating system's name (a
        CoreAudio aggregate device, a PipeWire node). The default keeps none.
    */
    virtual void setClientName (const String& name);

    //==============================================================================
    /** smoothie addition: what a device-change sink is told changed. */
    enum class DeviceChange
    {
        list,          /**< Devices came or went: the lists need rescanning. */
        openDevice,    /**< An open device of this type changed where it stands
                            (its channels, its rate) or stopped being alive. The
                            device does nothing about it by itself: the sink's
                            owner looks (AudioIODevice::readLiveState) and
                            decides. */
        systemDefault  /**< The operating system's default device moved
                            (getSystemDefaultDeviceName). */
    };

    /** smoothie addition: the one way this type's device changes leave it.
        Nothing in Smoothie reacts to a change by itself — no rescan on the
        message thread, no device reopening or restarting itself — so a type
        with no sink keeps its changes to itself. A type that hears from its
        OS callback (CoreAudio) delivers on the OS's thread, the moment it
        reports, and leaves the rescan to the sink's owner, so its lists are
        only touched by the thread that owns the device. Setting nullptr waits
        for a delivery in progress, so once it returns the old sink is never
        called again.
    */
    void setDeviceChangeSink (std::function<void (DeviceChange)> sink);

    //==============================================================================
    /** Destructor. */
    virtual ~AudioIODeviceType();

    //==============================================================================
    /** Creates a CoreAudio device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_CoreAudio();
    /** Creates an iOS device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_iOSAudio();
    /** Creates a WASAPI device type in the specified mode if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_WASAPI (WASAPIDeviceMode deviceMode);
    /** Creates a DirectSound device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_DirectSound();
    /** Creates an ASIO device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_ASIO();
    /** Creates an ALSA device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_ALSA();
    /** Creates a JACK device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_JACK();
    /** Creates an Android device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_Android();
    /** Creates an Android OpenSLES device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_OpenSLES();
    /** Creates an Oboe device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_Oboe();
    /** Creates a Bela device type if it's available on this platform, or returns null. */
    static AudioIODeviceType* createAudioIODeviceType_Bela();

   #ifndef DOXYGEN
    [[deprecated ("You should call the method which takes a WASAPIDeviceMode instead.")]]
    static AudioIODeviceType* createAudioIODeviceType_WASAPI (bool exclusiveMode);
   #endif

protected:
    explicit AudioIODeviceType (const String& typeName);

    /** smoothie addition: tells the sink, if one is set, on the calling
        thread (see setDeviceChangeSink). Replaces JUCE's
        callDeviceChangeListeners.
    */
    void reportDeviceChange (DeviceChange change);

private:
    String typeName;
    CriticalSection sinkLock;
    std::function<void (DeviceChange)> deviceChangeSink;

    JUCE_DECLARE_NON_COPYABLE (AudioIODeviceType)
};

} // namespace juce
