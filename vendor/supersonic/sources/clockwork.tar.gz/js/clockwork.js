// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025 Sam Aaron

/**
 * Clockwork - hosts a guest DSP compiled to WebAssembly
 * Coordinates SharedArrayBuffer, WASM, AudioWorklet, and IO Workers
 */

import { createTransport, OscChannel } from "./lib/transport/index.js";
import { readTimetag, getCurrentNTPFromPerformance } from "./lib/osc_classifier.js";
import { clockworkSys, oscAddress, REASON_NO_INSTANCE } from "./lib/clockwork_sys.js";
import { HostFront } from "./lib/host_front.js";

export { OscChannel };
import { AssetLoader } from "./lib/asset_loader.js";
import { guestMetrics } from "./lib/guest_metrics.js";
import { ENGINE_PROCESS_COUNT, GUEST_METRICS_BASE } from "./lib/metrics_offsets.js";
import { EventEmitter } from "./lib/event_emitter.js";
import { MetricsReader } from "./lib/metrics_reader.js";
import { readHistoryWindows } from "./lib/metrics_history.js";
import { METRICS_SCHEMA } from "./lib/metrics_schema.js";
import { ClockworkClock } from "./lib/clockwork_clock.js";
import { AudioHealthMonitor } from "./lib/audio_health_monitor.js";
import { AudioCapture } from "./lib/audio_capture.js";
import { tapSlotViews, tapSlotLive, tapSlotActivations, readTapSlot } from "./lib/tap_slot.js";
import { readArena, regionBytes, readGeneration, instanceGeneration, REGION, REGION_NAMES } from "./lib/arena.js";
import { ringCursorsReader } from "./lib/ring_cursors_reader.js";
import { IN_WRITE_LOCK } from "./lib/ring_cursor_offsets.js";
import { IN_BUFFER_USED_BYTES, OUT_BUFFER_USED_BYTES, NRT_OUT_BUFFER_USED_BYTES, IN_BUFFER_PEAK_BYTES, OUT_BUFFER_PEAK_BYTES, NRT_OUT_BUFFER_PEAK_BYTES, CTX_IN_BUFFER_CAPACITY, CTX_OUT_BUFFER_CAPACITY, CTX_NRT_OUT_BUFFER_CAPACITY } from "./lib/metrics_offsets.js";
import * as oscFast from "./lib/osc_fast.js";
// Timeout waiting for the DSP profile's synced reply from the engine
const SYNC_TIMEOUT_MS = 10000;
// Timeout waiting for AudioWorklet initialization
const WORKLET_INIT_TIMEOUT_MS = 5000;
// Timeout waiting for the worklet's clearSched ack in purge(). A live worklet
// acks synchronously from its message handler, so this only elapses when the
// worklet is gone — at which point purge() resolves best-effort so recover()
// can fall back to reload() instead of hanging.
const PURGE_ACK_TIMEOUT_MS = 1000;
// How long a worklet being let go has to say it rendered its last block (#retireWorklet). A live one answers within a
// render quantum; one that does not is gone, or stalled, and in SAB mode the stop word keeps it from rendering again.
const RETIRE_ACK_TIMEOUT_MS = 250;
// Interval for metrics/tree snapshots in postMessage mode (ms)
const SNAPSHOT_INTERVAL_MS = 150;
import { MemoryLayout } from "./memory_layout.js";
import { addWorkletModule } from "./lib/worker_loader.js";

const HEX = [];
for (let i = 0; i < 256; i++) HEX[i] = i.toString(16).padStart(2, '0');

function formatUUID(bytes) {
  return HEX[bytes[0]] + HEX[bytes[1]] + HEX[bytes[2]] + HEX[bytes[3]] + '-' +
    HEX[bytes[4]] + HEX[bytes[5]] + '-' + HEX[bytes[6]] + HEX[bytes[7]] + '-' +
    HEX[bytes[8]] + HEX[bytes[9]] + '-' + HEX[bytes[10]] + HEX[bytes[11]] +
    HEX[bytes[12]] + HEX[bytes[13]] + HEX[bytes[14]] + HEX[bytes[15]];
}

function formatUUIDShort(bytes) {
  return '\u2026' + HEX[bytes[13]] + HEX[bytes[14]] + HEX[bytes[15]];
}

function formatOscArg(a, maxLen) {
  if (a && a.type === 'uuid' && a.value) return formatUUIDShort(a.value);
  if (a instanceof Uint8Array || a instanceof ArrayBuffer) return `<${a.byteLength || a.length} bytes>`;
  const str = JSON.stringify(a);
  return maxLen && str.length > maxLen ? str.slice(0, maxLen) + '...' : str;
}

// A packet as text: a message as `/address arg, arg`; a bundle as its messages, a line each (the time it is for is
// the event's scheduledTime). A bundle used to throw here, which the caller swallowed, so nothing sent as a
// bundle ever reached out:text.
function formatOscText(decoded, maxLen) {
  if (decoded?.packets) return decoded.packets.map((p) => formatOscText(p, maxLen)).join('\n');
  const args = decoded.slice(1).map((a) => formatOscArg(a, maxLen)).join(', ');
  return `${decoded[0]}${args ? ' ' + args : ''}`;
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formatOscArgHtml(arg, address, argIndex) {
  if (arg && arg.type === 'uuid' && arg.value) {
    return `<span class="clockwork-osc-string" title="${formatUUID(arg.value)}">${formatUUIDShort(arg.value)}</span>`;
  }
  let value = arg, type = null;
  if (typeof arg === 'object' && arg !== null && arg.value !== undefined) {
    value = arg.value;
    type = arg.type;
  }
  if (type === 'b' || value instanceof Uint8Array || value instanceof ArrayBuffer) {
    const len = value.byteLength ?? value.length ?? '?';
    return `<span class="clockwork-osc-binary">&lt;${len} bytes&gt;</span>`;
  }
  const isFloat = type === 'f' || (type === null && typeof value === 'number' && !Number.isInteger(value));
  const isInt = type === 'i' || (type === null && Number.isInteger(value));
  if (isFloat) return `<span class="clockwork-osc-float">${parseFloat(value.toFixed(3))}</span>`;
  if (isInt) return `<span class="clockwork-osc-int">${value}</span>`;
  if (typeof value === 'string') return `<span class="clockwork-osc-string">${escapeHtml(JSON.stringify(value))}</span>`;
  return `<span class="clockwork-osc-string">${escapeHtml(value)}</span>`;
}

function formatOscLineHtml(msg, sequence, timestamp, startTime, sourceId) {
  const address = msg[0];
  const args = msg.slice(1);
  const relTime = startTime && timestamp ? (timestamp - startTime).toFixed(2) : '';
  let html = `<span class="clockwork-osc-seq">[${sequence}]</span>`;
  if (relTime) html += ` <span class="clockwork-osc-time">${relTime}</span>`;
  if (sourceId !== undefined) html += ` <span class="clockwork-osc-source">ch${sourceId}</span>`;
  html += ` <span class="clockwork-osc-address">${escapeHtml(address)}</span>`;
  if (args.length > 0) {
    const argsHtml = args.map((a, i) => formatOscArgHtml(a, address, i)).join(', ');
    html += ' ' + argsHtml;
  }
  return html;
}

function formatBundleHtml(decoded, sequence, timestamp, startTime, sourceId) {
  if (!decoded.packets) return formatOscLineHtml(decoded, sequence, timestamp, startTime, sourceId);
  if (decoded.packets.length === 1) return formatOscLineHtml(decoded.packets[0], sequence, timestamp, startTime, sourceId);
  const relTime = startTime && timestamp ? (timestamp - startTime).toFixed(2) : '';
  let html = `<span class="clockwork-osc-seq">[${sequence}]</span>`;
  if (relTime) html += ` <span class="clockwork-osc-time">${relTime}</span>`;
  if (sourceId !== undefined) html += ` <span class="clockwork-osc-source">ch${sourceId}</span>`;
  html += ` <span class="clockwork-osc-bundle">Bundle (${decoded.packets.length})</span>`;
  for (const pkt of decoded.packets) {
    const addr = pkt[0];
    const pktArgs = pkt.slice(1);
    html += `<br><span class="clockwork-osc-address">${escapeHtml(addr)}</span>`;
    if (pktArgs.length > 0) {
      html += ' ' + pktArgs.map((a, i) => formatOscArgHtml(a, addr, i)).join(', ');
    }
  }
  return html;
}

export class Clockwork {
  // Expose OSC utilities as static methods (uses plain args, not typed {type, value} format)
  static osc = {
    encodeMessage: (address, args) => oscFast.copyEncoded(oscFast.encodeMessage(address, args)),
    encodeBundle: (timeTag, packets) => oscFast.copyEncoded(oscFast.encodeBundle(timeTag, packets)),
    decode: (data) => oscFast.decodePacket(data),
    encodeSingleBundle: (timeTag, address, args) =>
      oscFast.copyEncoded(oscFast.encodeSingleBundle(timeTag, address, args)),
    readTimetag: (bundleData) => readTimetag(bundleData),
    ntpNow: () => getCurrentNTPFromPerformance(),
    NTP_EPOCH_OFFSET: oscFast.NTP_EPOCH_OFFSET,
  };

  /**
   * Schema describing every available metric — each key maps to
   * { offset, type, unit, description } for the merged Uint32Array — plus a
   * `layout` panel structure for rendering a metrics UI.
   */
  static getMetricsSchema() {
    return METRICS_SCHEMA;
  }

  #audioContext;
  #workletNode;
  #workletStop = null;   // SAB mode: the word the worklet reads before every block, set when it is let go
  #node = null;
  #osc;
  #wasmMemory;
  #syncListeners;
  #fetchRetryConfig;
  #assetLoader;
  #guestWriteSeq = 0;
  #guestReadSeq = 0;
  #guestGrowSeq = 0;
  #exportCallSeq = 0;
  #initialized;
  #initializing;
  #initPromise;
  #capabilities;
  #version;
  #generation = 0;   // the guest instance's, as the worklet reported it (postMessage); SAB reads it live
  #closedGeneration = 0;   // the generation a reload closed, carried into the next memory
  #guestMetrics = Object.freeze({});
  #guestMetricsPanels = Object.freeze([]);
  #config;

  #eventEmitter;
  #metricsReader;
  #clock;
  #audioCapture;
  #audioHealthMonitor;

  #oscChannel;

  // The host's front (js/lib/host_front.js): the far end of clockwork's
  // chain on the web. Every /clockwork/ verb the worklet's audio thread does
  // not answer itself comes back here to be answered — MIDI and gamepad,
  // when enabled — or refused by name.
  #front = null;

  // Node ID counter for PM mode (SAB mode uses shared memory).
  // Starts at 1000: 0 is the root group and
  // 1–999 are left free for the client to assign by hand.
  #nodeIdCounter = 1000;

  #previousAudioContextState = null;
  // Whether the engine made its context (and so closes it), or the host handed it one (the host's to close)
  #ownsAudioContext = false;
  #nextAudioContext = null;   // a context the next reload moves onto (reload()'s option: recover()'s spare)
  #onContextState = null;
  // A reload in progress: every caller asking for one while it runs gets the same one
  #reloading = null;
  // Counted up by every shutdown(): a boot that started before one sees the count move, and stops, rather than going
  // on to build on what shutdown() took away (and to say 'ready' for an engine that is gone)
  #lifeEpoch = 0;
  // What the engine is doing, in native's words (getEngineState), and 'statechange' says every change of it
  #engineState = 'stopped';
  // The page's events the engine is listening to, while it is up
  #pageHandlers = null;

  #cachedWasmBytes = null;

  #snapshotsSent = 0;

  #earlyDebugMessages = [];
  #debugRawHandler = null;

  // Cached TypedArray views for tap slots (lazily initialized, avoids per-frame allocations)
  #tapViews = null;

  /* Guest options are the product's to validate — clockwork enforces its own
   * rules (128-frame blocks and the rest) through its own `audio` options.
   */

  /*
   * Build the memory config.
   *
   * CLOCKWORK NEVER LOOKS INSIDE GUEST CONFIG to size anything. A guest that
   * wants more memory says so the way any caller does, through
   * `memory: { guestMemorySize }`.
   */
  #buildMemoryConfig(overrides) {
    const mem = overrides ? { ...MemoryLayout, ...overrides } : { ...MemoryLayout };
    // Re-derive computed values, since spreading an object loses its getters.
    //
    // This has to stay the same sum as MemoryLayout.guestMemoryOffset. It did
    // not when memArenaSize was added: the region moved up by 32MB and this
    // copy of the formula did not, so every guest write was checked against a
    // base 32MB below the real one and refused. ?? rather than ||, so a
    // deliberate 0 for any part is not silently replaced by the default.
    // The ASSETS IS LAST and everything else is fixed, because only the top
    // region can grow in place — see MemoryLayout.assetsOffset, which says why
    // bulk in is the thing that grows and the arena is not.
    mem.returnsOffset      = (mem.wasmHeapSize ?? MemoryLayout.wasmHeapSize)
                          + (mem.ringBufferReserved ?? MemoryLayout.ringBufferReserved)
                          + (mem.memArenaSize ?? MemoryLayout.memArenaSize);
    mem.guestMemoryOffset = mem.returnsOffset
                          + (mem.returnsSize ?? MemoryLayout.returnsSize);
    mem.assetsOffset       = mem.guestMemoryOffset
                          + (mem.guestMemorySize ?? MemoryLayout.guestMemorySize);
    mem.totalMemory    = mem.assetsOffset + mem.assetsSize;
    mem.maxTotalMemory = mem.assetsOffset + Math.max(mem.maxAssetsSize,
                                                    mem.assetsSize);
    return mem;
  }

  constructor(options = {}) {
    this.#initialized = false;
    this.#initializing = false;
    this.#initPromise = null;
    this.#capabilities = {};
    this.#version = null;

    this.#eventEmitter = new EventEmitter();
    this.#audioCapture = new AudioCapture({});

    this.#audioContext = null;
    this.#workletNode = null;
    this.#osc = null;

    // Configuration
    // baseURL is a convenience shorthand when all assets are co-located
    // coreBaseURL is for the WASM + AudioWorklet assets
    // workerBaseURL is for the workers
    const baseURL = options.baseURL || null;
    const coreBaseURL = options.coreBaseURL || baseURL;
    const workerBaseURL = options.workerBaseURL || (baseURL ? `${baseURL}workers/` : null);
    const wasmBaseURL = options.wasmBaseURL || (coreBaseURL ? `${coreBaseURL}wasm/` : null);

    if (!workerBaseURL || !wasmBaseURL) {
      throw new Error(
        `Clockwork needs to be told where its files are.\n\n` +
        `Clockwork is not a package of its own: it ships inside the product\n` +
        `that carries it (its dist/ — clockwork.js, workers/, wasm/). Name it:\n` +
        `  new Clockwork({ baseURL: '/path/to/that/dist/' })\n\n` +
        `or each part, when the engine wasm lives elsewhere (a CDN package):\n` +
        `  new Clockwork({\n` +
        `    workerBaseURL: '.../dist/workers/',\n` +
        `    coreBaseURL:   '.../<core package>/',   // wasm/ and the worklet under it\n` +
        `  })\n\n` +
        `See docs/BUILDING.md in the clockwork repository.`
      );
    }

    /* Guest config is OPAQUE. Clockwork asks for what it needs in its own
     * words, under `audio`: how many channels to open and how many to read.
     */
    const guestOptions = { ...options.guestOptions };
    // The transport, unless the caller says: SAB where the page is
    // cross-origin isolated (the headers are there, so the lower-latency
    // path is open), postMessage everywhere else. Until 2026-09-13 the
    // default was postMessage even on an isolated page, and every product
    // wrote this line itself.
    const mode = options.mode || (globalThis.crossOriginIsolated ? 'sab' : 'postMessage');

    // What the guest declares about itself: its metrics (js/lib/guest_metrics.js).
    // Nothing else — clockwork holds no opinion about which engine is
    // underneath, and needs none: the sync barrier is its own verb.
    this.#guestMetrics = guestMetrics(options.guestMetrics);
    this.#guestMetricsPanels = Object.freeze([...(options.guestMetricsPanels ?? [])]);
    // After the declaration is resolved, because the reader needs what this
    // guest says it exposes. None is a normal answer.
    this.#metricsReader = new MetricsReader({
      mode,
      guestMetrics: this.#guestMetrics,
    });

    this.#config = {
      mode: mode,
      snapshotIntervalMs: options.snapshotIntervalMs ?? SNAPSHOT_INTERVAL_MS,
      // The latest a timed event may play, ms: one later is dropped and counted (engineSchedulerLateDropped).
      // 0, the default, plays everything, however late. A page that can be flooded sets a limit.
      schedulerLateLimitMs: options.schedulerLateLimitMs ?? 0,
      // What the page going away, or out of sight, does to the engine. pagehide: 'shutdown' (the default: an engine
      // left running after its page is what a phone keeps playing with no page at all) or 'none'. hidden: 'keep'
      // (the default: a performer's tab behind another plays on) or 'suspend' (and resume when shown again).
      pageLifecycle: { pagehide: 'shutdown', hidden: 'keep', ...options.pageLifecycle },
      wasmBytes: options.wasmBytes ?? null,
      wasmUrl: options.wasmUrl || wasmBaseURL + "clockwork-engine.wasm",
      wasmBaseURL: wasmBaseURL,
      workletUrl: options.workletUrl || (coreBaseURL ? `${coreBaseURL}workers/clockwork_audio_worklet.js` : workerBaseURL + "clockwork_audio_worklet.js"),
      workerBaseURL: workerBaseURL,
      audioContext: options.audioContext || null,
      // Where the egress is drained, when the host wants it somewhere other than a worker of clockwork's own:
      // a MessagePort (or Worker) speaking the reader protocol. See lib/osc_in_pump.js.
      oscInEndpoint: options.oscInEndpoint ?? null,
      autoConnect: options.autoConnect !== false,
      audioContextOptions: {
        latencyHint: "interactive",
        sampleRate: 48000,
        ...options.audioContextOptions,
      },
      memory: this.#buildMemoryConfig(options.memory),
      guestOptions,
      audio: {
        outputChannels: options.audio?.outputChannels ?? 2,
        inputChannels: options.audio?.inputChannels ?? 0,
      },
      activityEvent: {
        maxLineLength: options.activityEvent?.maxLineLength ?? 200,
        engineMaxLineLength: options.activityEvent?.engineMaxLineLength ?? null,
        oscInMaxLineLength: options.activityEvent?.oscInMaxLineLength ?? null,
        oscOutMaxLineLength: options.activityEvent?.oscOutMaxLineLength ?? null,
      },
      debug: options.debug ?? false,
      // The main-thread subsystems (js/lib/host_front.js). Off by default:
      // Web MIDI asks the user's permission, and a page that never sends a
      // /clockwork/midi/ verb should not. `true`, or an object of manager
      // options (a test injects its fake device access there).
      midi: options.midi ?? false,
      gamepad: options.gamepad ?? false,
      debugEngine: options.debugEngine ?? false,
      debugOscIn: options.debugOscIn ?? false,
      debugOscOut: options.debugOscOut ?? false,
    };

    // The growth ceiling, resolved once: caller's option → layout default →
    // the committed size, which means "do not grow". It belongs to the ASSETS,
    // which is the region that grows.
    this.#config.effectiveMaxAssets = options.maxAssets
        || this.#config.memory.maxAssetsSize
        || this.#config.memory.assetsSize;


    this.#fetchRetryConfig = {
      maxRetries: options.fetchMaxRetries ?? 3,
      baseDelay: options.fetchRetryDelay ?? 1000,
    };

    this.#assetLoader = new AssetLoader({
      onLoadingEvent: (event, data) => this.#eventEmitter.emit(event, data),
      maxRetries: this.#fetchRetryConfig.maxRetries,
      baseDelay: this.#fetchRetryConfig.baseDelay,
      skipHeadRequests: options.skipHeadRequests ?? false,
    });

    this.bootStats = {
      initStartTime: null,
      initDuration: null,
    };
  }

  // ============================================================================
  // PUBLIC GETTERS
  // ============================================================================

  get initialized() { return this.#initialized; }
  get initializing() { return this.#initializing; }

  // Mirrors C++ ClockworkEngine::isRunning(). Same value as the
  // `initialized` getter, exposed as a method to match the C++ API shape.
  isRunning() { return this.#initialized; }

  // Mirrors C++ ClockworkEngine::engineState() (src/engine_state.h), word for word:
  //   'booting'     init() under way
  //   'running'     up
  //   'restarting'  reload() under way — native's cold swap
  //   'stopped'     not started, or shut down
  //   'error'       the last init() or reload() failed; init() or reset() tries again
  // Every change is emitted as 'statechange' { state, previous, reason } (and { error } on 'error'), as native sends
  // /clockwork/statechange <state> <reason>. Whether the audio itself is running is the context's, not the engine's
  // — native has no such state — and is said by the audiocontext:* events.
  getEngineState() { return this.#engineState; }

  #setEngineState(state, reason, detail = {}) {
    const previous = this.#engineState;
    if (state === previous) return;
    this.#engineState = state;
    this.#eventEmitter.emit('statechange', { state, previous, reason, ...detail });
  }
  get audioContext() { return this.#audioContext; }
  // ClockworkClock — engine-wide session-state + time authority.
  // Available after init() resolves. Read-only reference.
  get clock() { return this.#clock; }
  get mode() { return this.#config.mode; }
  get bufferConstants() { return this.#metricsReader.bufferConstants; }
  get arenaBase() { return this.#metricsReader.arenaBase; }
  get sharedBuffer() { return this.#metricsReader.sharedBuffer; }
  /*
   * The guest's memory object, for a client that maps its own region.
   *
   * `sharedBuffer` is not a substitute: growth leaves earlier ArrayBuffer
   * references valid but still sized to the OLD length, so a client holding
   * one cannot see memory it has just grown into. The Memory object always
   * yields the current buffer. Null in postMessage mode, where the client
   * has no heap of its own and must go through writeAssets.
   */
  get wasmMemory() { return this.#wasmMemory; }
  /*
   * Fetching, with the retry and progress policy clockwork already applies
   * to its own artifacts. A client fetching a definition or sample material
   * wants exactly that behaviour and should not build a second one beside it.
   */
  get assetLoader() { return this.#assetLoader; }
  get node() { return this.#node; }
  get osc() { return this.#osc; }
  /*
   * The main-thread subsystems, when enabled (`midi: true`, `gamepad: true`):
   * the MidiManager and GamepadManager the front answers /clockwork/midi/ and
   * /clockwork/gamepad/ with. Null when not enabled, and before init. A client
   * reaches them here to open a port, list what is connected, or ask for a
   * tempo — not to take its events, which come off the egress like every other
   * event, and which midiInDecode turns into fields on either host.
   */
  get midi() { return this.#front?.midi ?? null; }
  get gamepad() { return this.#front?.gamepad ?? null; }
  // Why `midi` / `gamepad` is null although it was asked for: the error its
  // init threw (a platform with no Web MIDI backend, a missing wasm). Null
  // when the subsystem is up or was never requested.
  get midiError() { return this.#front?.midiError ?? null; }
  get gamepadError() { return this.#front?.gamepadError ?? null; }

  /*
   * Bring a main-thread subsystem up after init, for a host that asks for it
   * when the player does rather than at boot. Web MIDI is asked for with a
   * prompt on some browsers, and a page that never touches MIDI should never
   * ask; a page that does should ask from the gesture that wanted it, not
   * while the audio is starting. `opts` is what the constructor's `midi:`
   * takes — true, or the MidiManager options (requestAccess, wasm).
   *
   * The front is rebuilt, so an enabled gamepad comes back up with it, and
   * calling this again re-acquires MIDI. Resolves to the manager, or null
   * when it could not come up, where `midiError` says why.
   */
  async enableMidi(opts = true) {
    this.#config.midi = opts;
    await this.#initializeFront();
    return this.midi;
  }

  // ============================================================================
  // EVENT EMITTER DELEGATION
  // ============================================================================

  /*
   * Raise an event on clockwork's own emitter.
   *
   * For a product built on clockwork: its events should reach listeners
   * through the same `on()` its clients already use, rather than a second
   * emitter beside it that callers have to know about separately.
   */
  emit(event, payload) { return this.#eventEmitter.emit(event, payload); }
  on(event, callback) { return this.#eventEmitter.on(event, callback); }
  off(event, callback) { this.#eventEmitter.off(event, callback); return this; }
  once(event, callback) { return this.#eventEmitter.once(event, callback); }
  removeAllListeners(event) { this.#eventEmitter.removeAllListeners(event); return this; }

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  async init() {
    if (this.#initialized) return;
    if (this.#initPromise) return this.#initPromise;

    this.#initPromise = this.#doInit();
    return this.#initPromise;
  }

  async #doInit() {
    this.#initializing = true;
    this.bootStats.initStartTime = performance.now();
    const epoch = this.#lifeEpoch;
    const stillWanted = () => { if (epoch !== this.#lifeEpoch) throw new Error("shut down while starting"); };
    this.#setEngineState('booting', 'init');
    this.#listenToPage();

    try {
      this.#setAndValidateCapabilities();
      this.#initializeMemory();
      this.#initializeAudioContext();
      const wasmBytes = await this.#loadWasm();
      stillWanted();
      await this.#initializeAudioWorklet(wasmBytes);
      stillWanted();
      await this.#initializeOSC();
      stillWanted();
      await this.#initializeFront();
      stillWanted();
      await this.#finishInitialization();
    } catch (error) {
      // What was built, taken down again: a context left running holds a phone's audio session, and a half-open
      // transport its workers. The client is then as it was before init() — ready to be asked again.
      try { await this.#partialShutdown(); } catch (e) { /* partly down already */ }
      this.#initializing = false;
      this.#initPromise = null;
      if (epoch === this.#lifeEpoch) this.#setEngineState('error', 'boot-failed', { error });
      this.#stopListeningToPage();
      console.error("[Clockwork] Initialization failed:", error);
      this.#eventEmitter.emit('error', error);
      throw error;
    }
  }

  // ============================================================================
  // METRICS API
  // ============================================================================

  getMetrics() {
    return this.#gatherMetrics();
  }

  /**
   * What every counter and gauge did over the last hour (metrics_history.js): for each metric with a history, the
   * windows `s1`, `s10`, `m1` (the last second, ten seconds and minute), `m10` and `h1` — each the lowest and highest
   * value seen, the last, the change across the window (a counter's count in that time) and how many buckets it
   * covered. Kept by the engine, so it survives a reload of the page's engine; {} before the engine is up.
   * @returns {Object}
   */
  getMetricsHistory() {
    const bc = this.#metricsReader?.bufferConstants;
    return readHistoryWindows(this.#metricsReader?.historyWords(), bc);
  }

  /**
   * Get metrics as a flat Uint32Array for zero-allocation reading.
   * Returns the same array reference every call — values are updated in-place.
   * Slots 0-49: SAB/snapshot metrics (slot 50 is the C++ struct's alignment
   * padding, reused by the first context metric), 50-68: main-thread context
   * metrics, 69+: metrics the guest declared in its DSP profile.
   * Use getMetricsSchema().metrics for offset mappings.
   * @returns {Uint32Array}
   */
  getMetricsArray() {
    this.#updateMergedArray();
    return this.#metricsReader.getMergedArray();
  }

  /**
   * Get a diagnostic snapshot containing metrics and memory info.
   * Useful for debugging timing issues, capturing state for bug reports, etc.
   * @returns {Object} Snapshot with timestamp, metrics (with descriptions) and memory info
   */
  getSnapshot() {
    const rawMetrics = this.#gatherMetrics();
    const schemaMetrics = Clockwork.getMetricsSchema()?.metrics || {};

    const metricsWithDescriptions = {};
    for (const [key, value] of Object.entries(rawMetrics)) {
      const def = schemaMetrics[key];
      if (def?.description) {
        metricsWithDescriptions[key] = {
          value,
          description: def.description,
        };
      } else {
        metricsWithDescriptions[key] = { value };
      }
    }

    // Get JS heap memory info (Chrome only, non-standard API)
    let memory = null;
    if (typeof performance !== 'undefined' && performance.memory) {
      memory = {
        usedJSHeapSize: performance.memory.usedJSHeapSize,
        totalJSHeapSize: performance.memory.totalJSHeapSize,
        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit,
      };
    }

    return {
      timestamp: new Date().toISOString(),
      metrics: metricsWithDescriptions,
      memory,
    };
  }

  /**
   * Get a comprehensive system performance report.
   *
   * Includes hardware info, audio configuration, Chrome playbackStats (if available),
   * a cross-browser audio health percentage, and a human-readable health assessment.
   * Useful for diagnosing audio crackling on constrained hardware.
   * @returns {Object} SystemReport
   */
  getSystemReport() {
    this.#ensureInitialized('get system report');

    const metrics = this.#gatherMetrics();
    const issues = [];

    const system = {
      userAgent: navigator.userAgent,
      hardwareConcurrency: navigator.hardwareConcurrency ?? null,
      deviceMemory: navigator.deviceMemory ?? null,
      platform: navigator.platform,
    };

    const audio = {
      sampleRate: this.#audioContext.sampleRate,
      baseLatency: this.#audioContext.baseLatency ?? null,
      outputLatency: this.#audioContext.outputLatency ?? null,
      state: this.#audioContext.state,
      channelCount: this.#config.audio.outputChannels,
    };

    // Playback stats (Chrome 146+)
    const pbStats = this.#capabilities.playbackStats ? this.#audioContext.playbackStats : null;
    const playbackStats = pbStats ? {
      glitchCount: pbStats.fallbackFramesEvents,
      glitchDurationS: pbStats.fallbackFramesDuration,
      totalDurationS: pbStats.totalFramesDuration,
      averageLatencyS: pbStats.averageLatency,
      maximumLatencyS: pbStats.maximumLatency,
    } : null;

    const healthPct = this.#audioHealthMonitor?.getHealth()?.healthPct ?? 100;

    if (healthPct < 95) {
      issues.push({
        severity: healthPct < 80 ? 'critical' : 'warning',
        message: `Audio health at ${healthPct}% — audio thread may be falling behind`,
      });
    }
    if (metrics.engineSchedulerLates > 0) {
      issues.push({
        severity: 'warning',
        message: `${metrics.engineSchedulerLates} late bundles in engine scheduler`,
      });
    }
    if (metrics.engineWasmErrors > 0) {
      issues.push({
        severity: 'error',
        message: `${metrics.engineWasmErrors} WASM errors detected`,
      });
    }
    if (pbStats?.fallbackFramesEvents > 0) {
      issues.push({
        severity: 'warning',
        message: `${pbStats.fallbackFramesEvents} audio glitch events (${(pbStats.fallbackFramesDuration * 1000).toFixed(1)}ms total silence)`,
      });
    }

    const summary = issues.length === 0
      ? `Audio health: ${healthPct}% — no issues detected`
      : `Audio health: ${healthPct}% — ${issues.length} issue(s): ${issues.map(i => i.message).join('; ')}`;

    return {
      timestamp: new Date().toISOString(),
      system,
      audio,
      playbackStats,
      engine: {
        mode: this.mode,
        version: this.#version,
        bootTimeMs: this.bootStats.initDuration,
      },
      health: {
        audioHealthPct: healthPct,
        issues,
        summary,
      },
      metrics,
    };
  }

  // ============================================================================
  // TIMING API
  // ============================================================================

  /**
   * Set clock offset for multi-system sync (e.g., Ableton Link, NTP server).
   * This shifts all scheduled bundle execution times by the specified offset.
   * Positive values mean the shared/server clock is ahead of local time —
   * bundles with shared-clock timetags are shifted earlier to compensate.
   * @param {number} offsetS - Offset in seconds
   */
  setClockOffset(offsetS) {
    this.#ensureInitialized('set clock offset');
    this.#clock?.setClockOffset(offsetS);
  }

  // ============================================================================
  // RECOVERY API
  // ============================================================================

  /**
   * Smart recovery - tries quick resume first, falls back to full reload.
   * Use this when you don't know if a quick resume will work.
   *
   * The reload is onto a new audio context, made here before anything is awaited. recover() is called from a press,
   * and a browser lets audio start only within one; and the context there is may be past saving: iOS, after an
   * interruption (a call, another app, the page switched away from), gives back a context that says it is running
   * and renders nothing, and no worklet on it — the old one or a reload's — ever processes again. A context made
   * any later (a reload's own, seconds in) starts suspended. So the spare is made now, the quick resume tries the
   * context there is, and the spare is used only if that fails; otherwise it is closed.
   * @returns {Promise<boolean>} true if audio is running after recovery
   */
  async recover() {
    if (!this.#initialized) return false;

    if (__DEV__) console.log('[Dbg-Clockwork] Attempting recovery...');

    const spare = this.#spareAudioContext();
    if (await this.resume()) {
      if (__DEV__) console.log('[Dbg-Clockwork] Quick resume succeeded');
      spare?.close().catch(() => {});
      return true;
    }

    if (__DEV__) console.log('[Dbg-Clockwork] Resume failed, doing full reload onto a new context');
    return await this.reload({ audioContext: spare });
  }

  // A context to recover onto, made and started within the press that asked for recovery (recover()); null where
  // there is no Web Audio to make one with.
  #spareAudioContext() {
    if (typeof AudioContext === 'undefined') return null;
    try {
      const ctx = new AudioContext(this.#config.audioContextOptions);
      ctx.resume().catch(() => {});
      return ctx;
    } catch (e) {
      return null;
    }
  }

  /**
   * Quick resume - just resumes AudioContext and resyncs timing.
   * Memory and node tree are preserved. Does NOT emit 'setup' event.
   * Use when you know the worklet is still running (e.g., tab was just backgrounded briefly).
   * @returns {Promise<boolean>} true if worklet is running after resume
   */
  async resume() {
    if (!this.#initialized || !this.#audioContext) return false;
    const ctx = this.#audioContext;

    // Already running: there is nothing to start, and nothing to throw away — a purge here would drop every bundle
    // scheduled ahead, and the music with it. All a caller can want to know is whether the audio thread is alive.
    if (ctx.state === 'running') return await this.#audioThreadAlive();

    // Started first, and synchronously: resume() is called from a press, and a browser lets audio start only inside
    // one. Everything awaited before this point is time the press has already run out of.
    const starting = ctx.resume().catch(() => {});

    // What queued while the engine slept plays when it is back, late by the gap, on every target: the engine drops
    // nothing for a gap (docs/RESTARTS.md). purge() is there for a host that wants it gone.
    await starting;

    const alive = await this.#audioThreadAlive();
    if (alive) this.#eventEmitter.emit('resumed');
    return alive;
  }

  // Whether the audio thread is running: its process count seen to move on. Watched for long enough to see it move on
  // either transport — postMessage's count arrives in snapshots every snapshotIntervalMs, and a fixed 200 ms could see
  // none of them and call a live engine dead (and send recover() into a reload it did not need).
  async #audioThreadAlive() {
    // postMessage mode: the count comes in snapshots the worklet posts as it renders, and one posted just before the
    // context suspended can land after this starts and read as a rise. The baseline is taken once any in flight
    // has landed.
    if (this.#config.mode === 'postMessage')
      await new Promise((r) => setTimeout(r, this.#config.snapshotIntervalMs ?? SNAPSHOT_INTERVAL_MS));
    const first = this.#readProcessCount();
    if (first === null) return this.#audioContext?.state === 'running';   // no metrics yet: the context is all there is to go on
    const limit = Math.max(250, 3 * (this.#config.snapshotIntervalMs ?? 150));
    const t0 = performance.now();
    let moved = false;
    while (performance.now() - t0 < limit) {
      await new Promise((r) => setTimeout(r, 25));
      const n = this.#readProcessCount();
      if (n !== null && n > first) { moved = true; break; }
    }
    if (!moved) return false;
    await this.#clockReadable(limit - (performance.now() - t0));   // ...and its clock readable
    return true;
  }

  // The engine's clock readable by the page, or `limitMs` passed: the sample clock it publishes (SAB), or its word on
  // the time down the main channel's port (postMessage, every few blocks). A page that reads clock.now() the moment
  // init() or resume() returns gets the engine's time, not 0.
  async #clockReadable(limitMs) {
    const t0 = performance.now();
    while (performance.now() - t0 < limitMs && !(this.#oscChannel?.now() > 0)) await new Promise((r) => setTimeout(r, 10));
  }

  /**
   * Suspend the AudioContext and stop the drift timer.
   * The worklet remains loaded but processing stops.
   * The audiocontext statechange listener handles emitting events.
   */
  async suspend() {
    if (!this.#initialized) return;
    try {
      await this.#audioContext?.suspend();
    } catch (e) {
      // Suspend may fail
    }
  }

  /**
   * Full reload - recreates the worklet and its module, and brings the engine
   * back as it was. Over the memory it ran in (SAB) the instance carries on
   * when nothing it was built for changed: nothing is lost, no 'setup' is
   * said, and 'reload:complete' says `resumed`. Otherwise a new instance is
   * built, restoreClientState() puts back whatever the product was holding,
   * and 'setup' is said so you can rebuild groups, FX chains, bus routing.
   * Use when the worklet was killed (e.g., long background, browser reclaimed memory).
   * @param {{ audioContext?: AudioContext }} [options] audioContext: a context to reload onto in place of the one there
   *   is (recover()'s spare): the engine's own from then on, and closed with it
   * @returns {Promise<boolean>} true if reload succeeded
   */
  async reload({ audioContext = null } = {}) {
    // One at a time: recovery is asked for from several places at once (a press, a key, the tab coming back), and two
    // teardowns racing two builds leave nothing working. Every caller gets the reload already under way.
    if (this.#reloading) { audioContext?.close().catch(() => {}); return this.#reloading; }
    if (!this.#initialized) { audioContext?.close().catch(() => {}); return false; }
    this.#nextAudioContext = audioContext;
    this.#reloading = this.#doReload().finally(() => { this.#reloading = null; });
    return this.#reloading;
  }

  async #doReload() {
    this.#setEngineState('restarting', 'reload');
    this.#eventEmitter.emit('reload:start');
    try {
      return await this.#reloadSteps();
    } catch (error) {
      // Whatever the failed reload built, taken down (a context it made included), and the failure said. The answer
      // is false, as recover()'s is: an exception thrown past a recovery path leaves its caller with no way back.
      try { await this.#partialShutdown(); } catch (e) { /* partly down already */ }
      console.error("[Clockwork] reload failed:", error);
      this.#setEngineState('error', 'reload-failed', { error });
      this.#eventEmitter.emit('reload:failed', { error });
      this.#eventEmitter.emit('reload:complete', { success: false, error });
      return false;
    }
  }

  async #reloadSteps() {
    // A reload is audio coming back, and the engine does the least that gets it back where it was (docs/RESTARTS.md):
    // over the memory it ran in (SAB), with nothing changed that the instance was built for, the instance carries on
    // as it was, its generation with it, and nothing it held was lost. A new instance — another rate it cannot take,
    // or new memory (postMessage, whose worklet took its memory with it) — has a generation of its own.
    const before = this.#instanceGeneration();
    await this.#closeInstance();
    await this.#partialShutdown();
    await this.#partialInit();
    const resumed = this.#instanceGeneration() === before;

    // Everything a new instance was not given, put back by the only party
    // that knows what it was.
    //
    // Clockwork used to restore one category itself — definitions — by
    // watching for the verb that carried them, reading a name out of each blob
    // through the profile, and replaying the lot here. Two categories, two
    // mechanisms, and clockwork's one worked only for the guest that had
    // declared its vocabulary. Now there is one, and it covers definitions,
    // samples and whatever else a guest invents, because the product re-sends
    // rather than clockwork replaying.
    //
    // BEFORE the sync below, so one barrier covers all of it.
    if (!resumed) {
      try {
        await this.restoreClientState();
      } catch (e) {
        console.error("[Clockwork] client state did not survive the reload:", e);
      }
    }

    // Verified, not assumed: the first message or two after a reload can
    // still go missing (observed on the reused-SAB path even with the ring
    // epoch, engine-pumping wait and writer-lock fixes — the pipe is
    // reliable from roughly half a second in). Recovery code retries with
    // short timeouts instead of betting ten seconds on the first attempt.
    await this.#syncWithRetry();

    // Only now 'setup' and 'ready': a host rebuilds on a new instance (its groups, its FX), and what it builds
    // refers to the definitions and buffers just put back. Said any earlier, it refers to what is not there yet. An
    // instance that carried on still has everything a host built on it, and 'setup' would build it all twice.
    this.#setEngineState('running', 'reload');
    await this.#announceReady({ setup: !resumed });

    this.#eventEmitter.emit('reload:complete', { success: true, resumed });
    return true;
  }

  async #syncWithRetry(attempts = 6, timeoutMs = 1500) {
    let lastErr = null;
    for (let i = 0; i < attempts; i++) {
      try {
        await this.sync(undefined, timeoutMs);
        return;
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr ?? new Error("sync failed after reload");
  }

  /**
   * Let go of the in ring's writer lock in a reused SAB, in the one window
   * where it is safe: after partialShutdown (workers terminated, worklet gone)
   * and before anything new attaches.
   *
   * Nothing else of the rings is touched. A reload over the same memory is a
   * rebuild (docs/RESTARTS.md, "One event, every route"): the engine keeps
   * every ring and the cursors with them, what waited in the in ring is
   * refused by the new instance, and the page's readers read on from where
   * they were, past the old instance's words to the new one's setup. The
   * writer lock is the exception because its holder is gone: partialShutdown
   * has terminated every worker and the worklet, so a surviving 1 is stale by
   * construction — left in place, every write after reload spins the lock's
   * 10-second deadlock path and the restore-phase traffic dies in exactly the
   * /clockwork/synced-timeout shape.
   */
  #releaseStaleWriterLock() {
    if (this.#config.mode !== 'sab' || !this.#wasmMemory) return;
    const bc = this.#metricsReader?.bufferConstants;
    const arenaBase = this.#metricsReader?.arenaBase;
    if (!bc || arenaBase == null || bc.RING_CURSORS_START == null) return;
    const cursors = new Int32Array(this.#wasmMemory.buffer, arenaBase + bc.RING_CURSORS_START, IN_WRITE_LOCK / 4 + 1);
    Atomics.store(cursors, IN_WRITE_LOCK / 4, 0);
  }

  async #awaitEngineProcessing(timeoutMs = 5000) {
    const view = this.#metricsReader?.getMetricsView?.() ?? null;
    const readCount = () => {
      if (view) return Atomics.load(view, ENGINE_PROCESS_COUNT);
      // postMessage mode: snapshots carry the counter with some lag, which
      // is fine — the wait only needs "the engine is demonstrably running".
      const snap = this.#metricsReader?.getSnapshotBuffer?.();
      return snap ? new Uint32Array(snap, 0, ENGINE_PROCESS_COUNT + 1)[ENGINE_PROCESS_COUNT] : null;
    };
    const t0 = performance.now();
    let last = null;
    let rises = 0;
    while (performance.now() - t0 < timeoutMs) {
      const n = readCount();
      if (n != null && last != null && n > last) {
        rises += 1;
        if (rises >= 2) return true;
      }
      if (n != null) last = n;
      await new Promise((r) => setTimeout(r, 25));
    }
    console.warn("[Clockwork] Engine did not start processing within", timeoutMs, "ms");
    return false;
  }

  // The instance closes before the memory it ran in goes (docs/RESTARTS.md, "One event, every route"). In postMessage
  // mode the worklet's memory is its own: what waits there for the instance is refused there, and relayed while the
  // worklet can still say so. The generation it closed is carried into the next memory either way. SAB mode keeps
  // its memory, and the next engine's build there does the rest itself.
  async #closeInstance() {
    this.#closedGeneration = Math.max(this.#closedGeneration, this.#instanceGeneration());
    if (this.#config.mode === 'sab' || !this.#workletNode) return;
    const port = this.#workletNode.port;
    const closed = await new Promise((resolve) => {
      const onMessage = (event) => {
        if (event.data?.type !== 'closed') return;
        clearTimeout(timer);
        port.removeEventListener('message', onMessage);
        resolve(event.data);
      };
      // A worklet that is gone (the tab's scope reclaimed) answers nothing: what waited went with it.
      const timer = setTimeout(() => { port.removeEventListener('message', onMessage); resolve(null); },
                               PURGE_ACK_TIMEOUT_MS);
      port.addEventListener('message', onMessage);
      port.postMessage({ type: 'close' });
    });
    if (closed) this.#closedGeneration = Math.max(this.#closedGeneration, closed.generation ?? 0);
  }

  async #partialShutdown() {
    this.#abandonSyncs("the engine shut down");

    await this.#releaseEngine();

    this.#initialized = false;
    this.#tapViews = null;
    this.#initPromise = null;
    this.#oscChannel = null;
    this.#audioHealthMonitor?.reset();
  }

  async #partialInit() {
    this.#initializing = true;
    this.bootStats.initStartTime = performance.now();

    try {
      this.#releaseStaleWriterLock();
      this.#initializeAudioContext();
      const wasmBytes = await this.#loadWasm();
      await this.#initializeAudioWorklet(wasmBytes);
      await this.#initializeOSC();
      await this.#initializeFront();
      // The definition/buffer restores below go to the new instance once it
      // is processing: two increasing reads of process_count prove the
      // engine is pumping.
      await this.#awaitEngineProcessing();
      await this.#finishInitialization({ announce: false });
    } catch (error) {
      this.#initializing = false;
      this.#initPromise = null;
      console.error("[Clockwork] Partial init failed:", error);
      this.#eventEmitter.emit('error', error);
      throw error;
    }
  }

  // The page's own lifecycle, which the engine's context and workers live and die by (config.pageLifecycle). Listened
  // to from init() until shutdown(): a reload keeps listening, and a shut-down engine hears nothing.
  #listenToPage() {
    if (this.#pageHandlers || typeof window === 'undefined' || typeof document === 'undefined') return;
    const policy = this.#config.pageLifecycle;
    const onPageHide = () => {
      if (policy.pagehide === 'shutdown') this.shutdown();   // its first steps are synchronous: the context is closed within the event
    };
    const onVisibility = () => {
      if (policy.hidden !== 'suspend' || !this.#initialized) return;
      if (document.visibilityState === 'hidden') this.suspend();
      else this.resume();   // may be refused without a press (iOS): the context stays suspended, for the host to ask for one
    };
    window.addEventListener('pagehide', onPageHide);
    document.addEventListener('visibilitychange', onVisibility);
    this.#pageHandlers = { onPageHide, onVisibility };
  }

  #stopListeningToPage() {
    const handlers = this.#pageHandlers;
    if (!handlers) return;
    this.#pageHandlers = null;
    window.removeEventListener('pagehide', handlers.onPageHide);
    document.removeEventListener('visibilitychange', handlers.onVisibility);
  }

  // Everything waiting on a sync() told the engine has gone
  #abandonSyncs(why) {
    const pending = this.#syncListeners;
    this.#syncListeners = null;
    for (const handler of pending?.values() ?? []) handler.abandon?.(why);
  }

  // 'setup', where a host builds on a new instance, then 'ready'
  async #announceReady({ setup = true } = {}) {
    // a listener that failed to build on the engine: the engine is up, but the host's world on it is not, and it
    // says so on 'error' rather than the boot looking as if it went fine
    for (const error of setup ? await this.#eventEmitter.emitAsync('setup') : []) {
      this.#eventEmitter.emit('error', new Error(`a 'setup' listener failed: ${error?.message ?? error}`, { cause: error }));
    }
    this.#eventEmitter.emit('ready', { capabilities: this.#capabilities, bootStats: this.bootStats });
  }

  // ============================================================================
  // THE GUEST'S PUBLISH WINDOW
  // ============================================================================

  /**
   * Where the guest publishes, and how to reach it in either mode.
   *
   * Clockwork does not know what is in there — a node tree, a meter table, a
   * grid of anything. It reserves the region, copies it out beside the metrics
   * on change, and hands a consumer the bytes. Whoever knows the guest's
   * layout casts them.
   *
   * @returns {{buffer: ArrayBuffer|SharedArrayBuffer, offset: number, size: number}|null}
   */
  readWindow() {
    if (!this.#initialized) return null;
    const bc = this.#metricsReader.bufferConstants;
    if (!bc) return null;

    if (this.#config.mode === 'postMessage') {
      // The snapshot is METRICS followed by the window, copied as one unit,
      // so the window starts where the metrics end.
      const snapshot = this.#metricsReader.getSnapshotBuffer();
      if (!snapshot) return null;
      return { buffer: snapshot, offset: bc.METRICS_SIZE, size: bc.GUEST_WINDOW_SIZE };
    }

    const sab = this.#metricsReader.sharedBuffer;
    if (!sab) return null;
    return {
      buffer: sab,
      offset: this.#metricsReader.arenaBase + bc.GUEST_WINDOW_START,
      size:   bc.GUEST_WINDOW_SIZE,
    };
  }

  // ============================================================================
  // TAPS API
  // ============================================================================

  /** @returns {object} Cached TypedArray views for a tap stream slot (lazily created) */
  #getTapSlotViews(tapNum) {
    if (!this.#tapViews) {
      this.#tapViews = new Array(this.#metricsReader.bufferConstants.TAP_SLOT_COUNT);
    }
    let views = this.#tapViews[tapNum];
    if (views) return views;

    const bc = this.#metricsReader.bufferConstants;
    const sab = this.#metricsReader.sharedBuffer;
    const base = this.#metricsReader.arenaBase;
    // One index space in one region: the guest's slots, then the engine's
    // track taps, one stride apart (docs/ARENA.md).
    const slotOffset = base + bc.TAPS_START + bc.TAPS_HEADER_SIZE + tapNum * bc.TAP_SLOT_SIZE;
    views = tapSlotViews(sab, slotOffset, {
      headerBytes: bc.TAP_SLOT_HEADER_SIZE,
      ringFrames: bc.TAP_RING_FRAMES,
      channels: bc.TAP_CHANNELS,
    });
    this.#tapViews[tapNum] = views;
    return views;
  }

  // ============================================================================
  // THE ARENA, AS A CLIENT SEES IT
  //
  // What the C ABI gives a native client (clockwork_client_region and the
  // readers over it), here for the browser: a region by id with its bytes as a
  // view, every region with its name, the control plane's cursors, and the
  // rings' levels. SAB mode only: in postMessage mode a client has no view of
  // the engine's memory and these answer null.
  // ============================================================================

  /**
   * A region of the arena, by id (REGION in lib/arena.js): its entry from the
   * table — offset, bytes, owner, audience, geometry words — its name in the
   * arena doc's words, and `bytes`, a Uint8Array over the shared buffer. The
   * table is read each call, so a reload's new arena is seen as soon as it is
   * published. Null when the region is not carved in this build, or not SAB.
   * @param {number} id
   * @returns {null|{ id: number, name: string, offset: number, bytes: Uint8Array, byteLength: number, owner: number, audience: number, geom: Uint32Array }}
   */
  region(id) {
    const arena = this.#arena();
    const e = arena?.entries.get(id);
    if (!e) return null;
    return { id, name: REGION_NAMES[id] ?? `region ${id}`, offset: e.offset, byteLength: e.bytes, owner: e.owner, audience: e.audience, geom: e.geom,
             bytes: regionBytes(this.sharedBuffer, this.arenaBase, e) };
  }

  /** Every region the arena carves, as region() gives them, in table order. */
  regions() {
    const arena = this.#arena();
    return arena ? [...arena.entries.keys()].map((id) => this.region(id)) : [];
  }

  /** The arena's header and table (lib/arena.js readArena), or null when not SAB or not yet published. */
  arena() { return this.#arena(); }

  #arena() {
    const buf = this.sharedBuffer, base = this.arenaBase;
    if (!buf || base == null) return null;
    try { return readArena(buf, base); } catch { return null; }
  }

  // The guest instance's generation (docs/RESTARTS.md): read live off the arena
  // where the page shares it (SAB), else the worklet's word at 'initialized'.
  // Between builds the two agree; the live read is for a page holding the
  // arena across a reload, which carries the instance on or builds another.
  #instanceGeneration() {
    const buf = this.sharedBuffer, base = this.arenaBase;
    if (buf && base != null) {
      try { return instanceGeneration(readGeneration(buf, base)); } catch { /* not yet mapped */ }
    }
    return this.#generation;
  }

  /**
   * The control plane's cursors (lib/ring_cursors_reader.js): each ring's head and
   * tail, the last sequence number either way, the status flags. Null when not SAB.
   */
  ringCursors(into = {}) {
    const r = this.region(REGION.CLOCKWORK_RING_CURSORS);
    if (!r) return null;
    return ringCursorsReader(this.sharedBuffer, this.arenaBase + r.offset)(into);
  }

  /**
   * The three rings' levels, in bytes and sequence numbers: what is in flight
   * now, the most ever, the capacity, and the sequence of the last message.
   * From the metrics (used, peak, capacity) and the control plane (sequence).
   * @returns {null|{ in: RingLevel, out: RingLevel, nrtOut: RingLevel }} where RingLevel is { used, peak, capacity, sequence }
   */
  ringLevels() {
    const mx = this.getMetricsArray(), c = this.ringCursors();
    if (!mx || !c) return null;
    return {
      in: { used: mx[IN_BUFFER_USED_BYTES], peak: mx[IN_BUFFER_PEAK_BYTES], capacity: mx[CTX_IN_BUFFER_CAPACITY], sequence: c.inSequence },
      out: { used: mx[OUT_BUFFER_USED_BYTES], peak: mx[OUT_BUFFER_PEAK_BYTES], capacity: mx[CTX_OUT_BUFFER_CAPACITY], sequence: c.outSequence },
      nrtOut: { used: mx[NRT_OUT_BUFFER_USED_BYTES], peak: mx[NRT_OUT_BUFFER_PEAK_BYTES], capacity: mx[CTX_NRT_OUT_BUFFER_CAPACITY], sequence: c.nrtOutSequence },
    };
  }

  /**
   * Get the newest `frames` frames of a tap stream.
   *
   * The stream is a lossless interleaved ring with a monotonic write cursor
   * (see docs/PORTS.md); this copies out the window ending at
   * the current cursor. SAB mode only for now.
   *
   * @param {number} tapNum - Tap slot index (0 to maxTaps-1)
   * @param {number} [frames] - Window length; defaults to 1024
   * @returns {{ frames: number, channels: number, writePosition: bigint, interleaved: Float32Array }|null}
   */
  getTap(tapNum, frames = 1024) {
    if (!this.#initialized) return null;

    const bc = this.#metricsReader.bufferConstants;
    if (!bc || bc.TAPS_START == null || bc.TAP_SLOT_COUNT == null) return null;
    if (tapNum < 0 || tapNum >= bc.TAP_SLOT_COUNT) return null;

    // TODO: PM mode — read from latest heartbeat snapshot
    if (!this.#metricsReader.sharedBuffer) return null;

    return readTapSlot(this.#getTapSlotViews(tapNum), frames);
  }

  /**
   * How many times a tap slot has gone live. A reader polls, and a slot can
   * be claimed and released between two polls (a loop started and stopped in
   * a moment); a reader that noted this and sees another number knows the
   * slot went live in between. Wraps: compare for change only. SAB mode only.
   *
   * @param {number} tapNum - Tap slot index (0 to maxTaps-1)
   * @returns {number|null} null when uninitialised, out of range, or not SAB
   */
  getTapActivations(tapNum) {
    if (!this.#initialized) return null;
    const bc = this.#metricsReader.bufferConstants;
    if (!bc || bc.TAPS_START == null || bc.TAP_SLOT_COUNT == null) return null;
    if (tapNum < 0 || tapNum >= bc.TAP_SLOT_COUNT) return null;
    if (!this.#metricsReader.sharedBuffer) return null;
    return tapSlotActivations(this.#getTapSlotViews(tapNum));
  }

  /**
   * Get all active tap slots.
   * @returns {Array<{ index: number, channels: number }>}
   */
  getTaps() {
    if (!this.#initialized) return [];

    const bc = this.#metricsReader.bufferConstants;
    if (!bc || bc.TAPS_START == null || bc.TAP_SLOT_COUNT == null) return [];
    if (!this.#metricsReader.sharedBuffer) return [];

    const taps = [];
    for (let i = 0; i < bc.TAP_SLOT_COUNT; i++) {
      const views = this.#getTapSlotViews(i);
      if (tapSlotLive(views)) {
        taps.push({ index: i, channels: views.meta[1] });
      }
    }
    return taps;
  }

  /**
   * Get tap schema (capacity, ring frames per slot, channels).
   * @returns {{ maxTaps: number, ringFrames: number, channels: number }|null}
   */
  static getTapSchema() {
    // Compile-time defaults — matches shared_memory.h SCOPE_ constants.
    // A proper implementation would read from the WASM buffer layout.
    return {
      maxTaps: 32,
      ringFrames: 16384,
      channels: 2,
    };
  }

  // ============================================================================
  // AUDIO CAPTURE API
  //
  // The scope is clockwork's and flow from boot: the OUT slot is what
  // left for the device each block, written by the tick at the device edge
  // (audio_processor.cpp), the IN slot what arrived. A capture is a reader's
  // notion — startCapture notes the writer's cursor, stopCapture returns
  // what was written since — and toggles nothing in the engine. See
  // js/lib/audio_capture.js and docs/ARENA.md.
  // ============================================================================

  startCapture() {
    this.#ensureInitialized("start capture");
    if (!this.#audioCapture.isAvailable()) {
      throw new Error(
        "Audio capture is only available in SAB mode (set mode: 'sab').");
    }
    this.#audioCapture.start();
  }

  stopCapture() {
    this.#ensureInitialized("stop capture");
    return this.#audioCapture.stop();
  }

  isCaptureEnabled() {
    return this.#audioCapture.isEnabled();
  }

  getCaptureFrames() {
    return this.#audioCapture.getFrameCount();
  }

  getMaxCaptureDuration() {
    return this.#audioCapture.getMaxDuration();
  }

  // ============================================================================
  // OSC MESSAGING API
  // ============================================================================

  /**
   * Send a message and wait for its reply — the request/reply shape every
   * guest's verbs have (`/tau/spawn` → `/tau/spawned`, `/d_recv` → `/done`),
   * which each product wrote for itself until 2026-09-13.
   *
   * Resolves with the decoded reply (`[address, ...args]`): the first
   * inbound message at `reply`, or the first for which `match(msg)` is true
   * when given. Rejects with the error message's args when a message at
   * `error` arrives first (`/fail`, `/tau/error` — the engine's word, which
   * a product's own request() can default), and on the timeout.
   *
   * @param {string} address the verb to send
   * @param {any[]} [args=[]] its arguments
   * @param {object} o
   * @param {string} o.reply the address the answer comes on (required)
   * @param {string|null} [o.error] the address a refusal comes on
   * @param {(msg: any[]) => boolean} [o.match] narrows the reply, e.g. by an id
   * @param {number} [o.timeoutMs=10000]
   * @returns {Promise<any[]>}
   */
  request(address, args = [], { reply, error = null, match = null, timeoutMs = SYNC_TIMEOUT_MS } = {}) {
    this.#ensureInitialized("request");
    if (typeof reply !== "string" || !reply.startsWith("/")) {
      throw new TypeError("request() needs the reply address: request(verb, args, { reply: '/some/reply' })");
    }
    return new Promise((resolve, reject) => {
      const done = (fn) => (v) => { clearTimeout(timer); this.off('in', on); fn(v); };
      const ok = done(resolve), fail = done(reject);
      const timer = setTimeout(() => fail(new Error(`no ${reply} to ${address} within ${timeoutMs} ms`)), timeoutMs);
      const on = (msg) => {
        if (msg[0] === reply && (!match || match(msg))) ok(msg);
        else if (error && msg[0] === error && (!match || match(msg))) {
          const e = new Error(`${address} refused: ${msg.slice(1).map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ")}`);
          e.reply = msg;
          fail(e);
        }
      };
      this.on('in', on);
      try { this.send(address, ...args); } catch (e) { fail(e); }
    });
  }

  send(address, ...args) {
    this.#ensureInitialized("send OSC messages");

    // NOTHING IS INSPECTED HERE. What a product needs back after a reload is
    // the product's to remember, and it puts it back through
    // restoreClientState(). See reload().

    const normalizedArgs = args.map(arg => {
      if (arg instanceof ArrayBuffer) return new Uint8Array(arg);
      return arg;
    });

    const oscData = Clockwork.osc.encodeMessage(address, normalizedArgs);
    this.sendOSC(oscData);
  }

  sendOSC(oscData) {
    this.#ensureInitialized("send OSC data");

    const uint8Data = this.#toUint8Array(oscData);
    this.#sendPreparedOSC(uint8Data);
  }

  /**
   * Flush pending OSC from the WASM scheduler and the IN ring.
   *
   * Uses a postMessage flag (not the ring buffer) to avoid the race where stale
   * scheduled bundles would fire before a clearSched command could be read from
   * the ring buffer. Resolves when the worklet acks — or, if the worklet is
   * gone, when that ack times out.
   *
   * @returns {Promise<void>}
   */
  async purge() {
    this.#ensureInitialized("purge");

    await new Promise(resolve => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        this.#workletNode.port.removeEventListener('message', handler);
        resolve();
      };
      const handler = (event) => {
        if (event.data.type === 'clearSchedAck') finish();
      };
      // The worklet acks synchronously from its message handler, so a live
      // worklet — even one whose AudioContext is suspended — replies almost
      // immediately. A missing ack therefore means the worklet is gone (its
      // global scope was reclaimed, e.g. a long-backgrounded mobile tab — the
      // exact case recover() exists to handle). Resolve best-effort on a
      // timeout so purge()/resume()/recover() can't wedge and recover() falls
      // through to reload() instead of hanging forever.
      const timer = setTimeout(() => {
        this.#warn('purge() timed out waiting for clearSchedAck: the audio worklet may be gone');
        finish();
      }, PURGE_ACK_TIMEOUT_MS);
      this.#workletNode.port.addEventListener('message', handler);
      this.#workletNode.port.postMessage({ type: 'clearSched', ack: true });
    });
  }

  /**
   * A transferable channel letting a Web Worker send OSC straight to the
   * worklet, bypassing the main thread. SAB-backed or MessagePort-backed
   * depending on transport.
   *
   * @returns {OscChannel}
   */
  createOscChannel(options = {}) {
    this.#ensureInitialized("create OSC channel");
    return this.#osc.createOscChannel(options);
  }

  /**
   * Get the next unique node ID.
   *
   * Globally unique with no coordination. IDs start at 1000: 0 is the root group
   * and 1-999 are left free for the client to assign by hand.
   *
   * SAB mode is a single atomic increment; PM mode allocates by range.
   * Also available on OscChannel, for Web Workers.
   *
   * @returns {number} A unique node ID (>= 1000)
   */
  nextNodeId() {
    this.#ensureInitialized("allocate node IDs");
    return this.#oscChannel.nextNodeId();
  }

  // ============================================================================
  // ASSET LOADING API
  // ============================================================================

  /**
   * The fixed slice the layout gave the guest for its working memory, if any.
   *
   * By default none (size 0): clockwork reserves the guest's working memory
   * itself, inside the placement arena, sized to what the guest asks
   * (js/memory_layout.js guestMemorySize). What lives there is the guest's
   * alone; no client reads it.
   *
   * @returns {{offset: number, size: number, maxSize: number}} byte addresses
   *          in the guest's own address space
   */
  guestMemory() {
    const mem = this.#config.memory;
    return {
      offset:  mem.guestMemoryOffset,
      size:    mem.guestMemorySize,
      maxSize: mem.guestMemorySize,   // fixed at boot: the assets area is what grows
    };
  }

  /**
   * The inbound staging region. THE CLIENT WRITES IT, THE GUEST ONLY READS IT.
   *
   * Bulk into the engine goes here — a sample, a wavetable, an impulse
   * response — followed by a short message saying where it landed. It is not
   * the guest's arena, and there is deliberately no way to write to that from
   * here: a region with two writers would need both sides to agree at runtime
   * about which bytes belong to whom, and nothing could enforce that.
   *
   * @returns {{offset: number, size: number}}
   */
  assets() {
    const mem = this.#config.memory;
    // SIZE IS MEASURED, NOT REMEMBERED. growAssets moves the end of the
    // memory, so reading it back keeps a grown region from being reported at
    // its boot size — which would refuse every write past the initial commit,
    // since the range check is what a caller is held to. In postMessage mode
    // there is no heap here to measure, so growAssets maintains the number.
    const committed = this.#wasmMemory
      ? Math.max(0, this.#wasmMemory.buffer.byteLength - mem.assetsOffset)
      : mem.assetsSize;
    return {
      offset:  mem.assetsOffset,
      size:    committed,
      maxSize: this.#config.effectiveMaxAssets ?? mem.maxAssetsSize,
    };
  }

  /**
   * The outbound staging region. THE GUEST WRITES IT, THE CLIENT ONLY READS IT.
   *
   * @returns {{offset: number, size: number}}
   */
  returns() {
    const mem = this.#config.memory;
    return { offset: mem.returnsOffset, size: mem.returnsSize };
  }

  /**
   * Commit more assets, growing the WASM heap by whole pages.
   *
   * The CEILING CANNOT MOVE. `maximum` is fixed when the memory is
   * constructed and reserves address space that growth then commits into, so
   * this can only ever reach `assets().maxSize`. A client that needs more
   * than that must ask for it before boot, not here.
   *
   * @param {number} bytes  how much more is needed, rounded up to whole pages
   * @returns {Promise<boolean>} false if the ceiling refused it
   */
  async growAssets(bytes) {
    this.#ensureInitialized("grow assets");
    const pages = Math.ceil(bytes / 65536);
    if (pages <= 0) return true;

    if (this.#config.mode === "sab") {
      // Growing a SHARED memory does not detach its buffer, which is what
      // lets an allocator keep references to regions it took earlier.
      return this.#wasmMemory.grow(pages) !== -1;
    }
    // PM mode: the worklet owns the only heap there is, so it does the growing.
    // There is nothing here to measure afterwards, so the committed size is
    // carried forward by hand — see assets().
    const growId = ++this.#guestGrowSeq;
    return this.#workletReply(
      { type: "growMemory", growId, pages },
      "memoryGrown",
      (d) => d.growId === growId,
      "grow assets",
    ).then((d) => {
      const ok = !!d.success;
      if (ok) this.#config.memory.assetsSize += pages * 65536;
      return ok;
    }).catch(() => false);
  }

  /**
   * Call a named wasm export on the audio thread and return its result.
   *
   * A guest (or a demo like rerezzed) sometimes has to invoke one of its own
   * exports from inside the audio context — spawning a program, staging a
   * pipeline — where it can touch the live engine directly. The worklet runs
   * the export and posts the result back.
   */
  async callExport(name, args = []) {
    const callId = ++this.#exportCallSeq;
    const reply = await this.#workletReply(
      { type: "callExport", callId, name, args },
      "exportCalled",
      (d) => d.callId === callId,
      `call ${name}`,
    );
    if (reply.error) throw new Error(`callExport ${name}: ${reply.error}`);
    return reply.result;
  }

  /**
   * Put bytes into the ASSETS at `offset`, for the guest to read.
   *
   * SAB mode writes straight into the shared heap; postMessage mode ships the
   * bytes to the worklet to write. Bulk never rides OSC ingress either way.
   *
   * OFFSET, NOT POINTER — measured from the base of the assets area. Native maps the
   * same region at a different address than the engine's, so an absolute
   * pointer names the wrong bytes there without faulting.
   *
   * @param {number} offset  a byte offset into `assets()`
   * @param {ArrayBuffer|ArrayBufferView} bytes
   * @returns {Promise<{offset: number, bytes: number}>}
   */
  async writeAssets(offset, bytes) {
    this.#ensureInitialized("write assets");
    const src = ArrayBuffer.isView(bytes)
      ? new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength)
      : new Uint8Array(bytes);

    const region = this.assets();
    this.#checkGuestRange(offset, src.byteLength, region, "write assets");
    const ptr = region.offset + offset;

    if (this.#config.mode === "sab") {
      new Uint8Array(this.#wasmMemory.buffer, ptr, src.byteLength).set(src);
      return { offset, bytes: src.byteLength };
    }

    // A detached transferable cannot be recovered, so copy before handing over.
    const copyId = ++this.#guestWriteSeq;
    const buf = src.slice().buffer;
    await this.#workletReply(
      { type: "copyBufferData", copyId, ptr, data: buf },
      "bufferCopied",
      (d) => d.copyId === copyId,
      "write guest memory",
      [buf],
    );
    return { offset, bytes: src.byteLength };
  }

  /*
   * Refuse a range that leaves the guest's region, before anyone acts on it.
   *
   * Written as a subtraction rather than as `offset + len > size` because the
   * latter passes on overflow — a huge length wraps and the check waves it
   * through, which in SAB mode is a write past the region and in native terms
   * is the read the C++ side's region_at() exists to prevent. Same shape on
   * both sides on purpose.
   */
  #checkGuestRange(offset, len, region, what) {
    const size = region.size;
    if (!Number.isInteger(offset) || !Number.isInteger(len)
        || offset < 0 || len < 0 || offset > size || len > size - offset) {
      throw new RangeError(
        `${what}: [${offset}, ${offset + len}) is outside the region `
        + `(0..${size})`);
    }
  }

  /**
   * Something went wrong that a caller should hear of in every build, not only a
   * development one's console: said there, and emitted as 'warning' ({ message })
   * so a host can show it in its own log.
   */
  #warn(message) {
    console.warn(`[Clockwork] ${message}`);
    this.#eventEmitter.emit('warning', { message });
  }

  /**
   * Read bytes out of the RETURNS, which only the guest writes.
   *
   * The mirror of writeAssets: a guest writes a blob into the returns area and sends a
   * short message saying where. `offset` is region-relative, as there.
   *
   * ASYNC ON BOTH TRANSPORTS, though SAB could answer synchronously — a
   * signature that changed shape with the transport would break any caller that
   * awaited only in postMessage mode.
   *
   * @param {number} offset  a byte offset into `returns()`
   * @param {number} len
   * @returns {Promise<Uint8Array>} a COPY, so a later growth cannot invalidate it
   */
  async readReturns(offset, len) {
    this.#ensureInitialized("read returns");
    const region = this.returns();
    this.#checkGuestRange(offset, len, region, "read returns");
    const ptr = region.offset + offset;

    if (this.#config.mode === "sab") {
      return new Uint8Array(this.#wasmMemory.buffer, ptr, len).slice();
    }

    const readId = ++this.#guestReadSeq;
    const reply = await this.#workletReply(
      { type: "readBufferData", readId, ptr, len },
      "bufferRead",
      (d) => d.readId === readId,
      "read guest memory",
    );
    return new Uint8Array(reply.data);
  }

  /*
   * One request to the worklet, one matching reply, or a timeout.
   *
   * Both memory primitives need the same shape, and the message names live in one
   * place so they can be checked against the worklet — a name the worklet never
   * implemented can only ever time out.
   */
  #workletReply(message, replyType, matches, what, transfer = []) {
    const port = this.#workletNode.port;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        port.removeEventListener("message", handler);
        reject(new Error(`${what}: the worklet did not answer within 10s`));
      }, 10000);
      const handler = (e) => {
        if (!e.data || e.data.type !== replyType || !matches(e.data)) return;
        clearTimeout(timer);
        port.removeEventListener("message", handler);
        e.data.success === false
          ? reject(new Error(e.data.error || `${what}: the worklet refused`))
          : resolve(e.data);
      };
      port.addEventListener("message", handler);
      port.postMessage(message, transfer);
    });
  }

  /**
   * The barrier: resolves once everything sent before it has been handed to
   * the guest, in order. Clockwork's own verb (`/clockwork/sync` →
   * `/clockwork/synced`), answered on the audio thread at the point the
   * message is reached in the drain — so it works for every guest, with
   * nothing declared. Until 2026-09-13 it borrowed the guest's word
   * (`/sync` for scsynth) through a profile.
   */
  async sync(syncId = Math.floor(Math.random() * 2147483647), timeoutMs = SYNC_TIMEOUT_MS) {
    this.#ensureInitialized("sync");

    const syncPromise = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.#syncListeners?.delete(syncId);
        reject(new Error(`Timeout waiting for ${clockworkSys("synced")} response`));
      }, timeoutMs);

      const messageHandler = () => {
        clearTimeout(timeout);
        this.#syncListeners.delete(syncId);
        resolve();
      };
      // the engine going away before the answer: said now, rather than as a timeout ten seconds later
      messageHandler.abandon = (why) => {
        clearTimeout(timeout);
        reject(new Error(why));
      };

      if (!this.#syncListeners) this.#syncListeners = new Map();
      this.#syncListeners.set(syncId, messageHandler);
    });

    this.send(clockworkSys("sync"), syncId);
    await syncPromise;

    if (this.#config.mode === 'postMessage') {
      await new Promise(r => setTimeout(r, this.#config.snapshotIntervalMs * 2));
    }
  }

  // ============================================================================
  // INFO API
  // ============================================================================

  getInfo() {
    this.#ensureInitialized("get info");

    return {
      sampleRate: this.#audioContext.sampleRate,
      totalMemory: this.#config.memory.totalMemory,
      wasmHeapSize: this.#config.memory.wasmHeapSize,
      guestMemorySize: this.#config.memory.guestMemorySize,
      bootTimeMs: this.bootStats.initDuration,
      capabilities: { ...this.#capabilities },
      version: this.#version,
      generation: this.#instanceGeneration(),
    };
  }

  // ============================================================================
  // LIFECYCLE API
  // ============================================================================

  async shutdown() {
    if (!this.#initialized && !this.#initializing) return;

    // A boot under way sees this and stops (#doInit's stillWanted), and the client is no longer starting
    this.#lifeEpoch++;
    this.#initializing = false;
    this.#initPromise = null;
    this.#stopListeningToPage();
    this.#setEngineState('stopped', 'shutdown');

    this.#eventEmitter.emit("shutdown");
    this.#audioHealthMonitor?.reset();
    this.#audioHealthMonitor = null;
    this.#abandonSyncs("the engine shut down");

    await this.#releaseEngine();

    this.#oscChannel = null;
    this.#initialized = false;
    this.#tapViews = null;
    this.#initPromise = null;
    this.#wasmMemory = null;
    this.bootStats = { initStartTime: null, initDuration: null };
  }

  async destroy() {
    this.#eventEmitter.emit("destroy");
    await this.shutdown();
    this.#cachedWasmBytes = null;
    this.#eventEmitter.removeAllListeners();
  }

  async reset() {
    await this.shutdown();
    await this.init();
  }

  // ============================================================================
  // PRIVATE: INITIALIZATION HELPERS
  // ============================================================================

  #setAndValidateCapabilities() {
    this.#capabilities = {
      audioWorklet: typeof AudioWorklet !== "undefined",
      sharedArrayBuffer: typeof SharedArrayBuffer !== "undefined",
      crossOriginIsolated: window.crossOriginIsolated === true,
      atomics: typeof Atomics !== "undefined",
      webWorker: typeof Worker !== "undefined",
      playbackStats: typeof AudioContext !== "undefined" && 'playbackStats' in AudioContext.prototype,
    };

    const mode = this.#config.mode;
    const required = ["audioWorklet", "webWorker"];

    if (mode === 'sab') {
      required.push("sharedArrayBuffer", "crossOriginIsolated", "atomics");
    }

    const missing = required.filter((f) => !this.#capabilities[f]);

    if (missing.length > 0) {
      const error = new Error(`Missing required features for ${mode} mode: ${missing.join(", ")}`);
      if (mode === 'sab' && !this.#capabilities.crossOriginIsolated) {
        error.message += "\n\nConsider using mode: 'postMessage' which doesn't require COOP/COEP headers.";
      }
      throw error;
    }

    if (mode !== 'sab' && mode !== 'postMessage') {
      throw new Error(`Invalid mode: '${mode}'. Use 'sab' or 'postMessage'.`);
    }
  }

  #initializeMemory() {
    const memConfig = this.#config.memory;
    const mode = this.#config.mode;

    if (mode === 'sab') {
      // Initial pages must be at least the compile-time minimum (WASM binary constraint).
      // User overrides that increase guestMemorySize will increase initial; decreases are clamped.
      const minPages = MemoryLayout.totalPages;
      const totalPages = Math.max(Math.ceil(memConfig.totalMemory / 65536), minPages);
      // For shared WASM memory, maximum must match the compile-time cap.
      const maxPages = Math.ceil(memConfig.maxTotalMemory / 65536);
      this.#wasmMemory = new WebAssembly.Memory({
        initial: totalPages,
        maximum: maxPages,
        shared: true,
      });
    } else {
      this.#wasmMemory = null;
    }

    // No allocator here. Clockwork reserves the guest's region and moves
    // opaque bytes into it; whoever knows what those bytes mean runs its own
    // allocator over `guestMemory()`. A pool here would be a SECOND allocator
    // over the same region as the guest's, handing out overlapping pointers.
  }

  #initializeAudioContext() {
    // A context the host made is the host's: used, never closed, and kept across a reload. One that has been closed
    // is no use to anyone, so the engine makes its own in its place (and that one is the engine's to close). A reload
    // given one to move onto (recover()'s, the host's past saving) makes that the engine's own, and the host's is
    // not gone back to: a later reload makes its own.
    const next = this.#nextAudioContext;
    this.#nextAudioContext = null;
    if (next) this.#config.audioContext = null;
    const supplied = this.#config.audioContext;
    this.#ownsAudioContext = !supplied || supplied.state === 'closed';
    const ctx = this.#audioContext = next ?? (this.#ownsAudioContext ? new AudioContext(this.#config.audioContextOptions) : supplied);

    // Started here, synchronously, before anything is awaited. init() and recover() are called from inside a press,
    // and a browser lets audio start only within one: a context born suspended (iOS, a page's autoplay rules) would
    // otherwise stay suspended, and the clock that waits on it would wait for nothing.
    if (ctx.state !== 'running') ctx.resume().catch(() => {});

    this.#previousAudioContextState = ctx.state;
    this.#onContextState = () => {
      const state = ctx.state;
      const previousState = this.#previousAudioContextState;
      this.#previousAudioContextState = state;

      this.#eventEmitter.emit('audiocontext:statechange', { state });
      if (state === 'suspended') {
        this.#eventEmitter.emit('audiocontext:suspended');
        this.#audioHealthMonitor?.reset();
      } else if (state === 'running') {
        this.#eventEmitter.emit('audiocontext:resumed');
        this.#audioHealthMonitor?.reset();
      } else if (state === 'interrupted') {
        this.#eventEmitter.emit('audiocontext:interrupted');
        this.#audioHealthMonitor?.reset();
      }
    };
    ctx.addEventListener('statechange', this.#onContextState);

    this.#audioHealthMonitor = new AudioHealthMonitor({ audioContext: ctx });
  }

  // The context let go of: its listener taken off (a reload would otherwise leave one on every context the engine has
  // ever had), and closed only if the engine made it — a host's context stays open, for the host.
  // What shutdown() and a reload both let go, in this order: the transport and the front it fed, the worklet, then
  // the context. One path, so neither can miss a step the other takes.
  async #releaseEngine() {
    if (this.#osc) {
      await this.#osc.dispose();
      this.#osc = null;
    }
    // Stop forwarding worklet debug batches — the transport is gone. A live
    // handler here would deref the null #osc when a late batch arrives.
    this.#debugRawHandler = null;
    // The front's devices close with the transport that fed them.
    this.#front?.dispose();
    this.#front = null;
    await this.#retireWorklet();
    await this.#releaseAudioContext();
  }

  // THE OLD WORKLET STOPS BEFORE IT IS LET GO. A processor that says true is called for as long as its context runs,
  // connected or not, and a host's context outlives the engine it gave Clockwork: a worklet let go without a word
  // rendered on, over the memory the next one renders (a reload in SAB mode: the engine driven twice a block) or over
  // nothing, an audio thread spent for the life of the page. So it is told, in the word it reads before every block
  // (SAB) and in a message it answers once it is out ('retire', 'retired'). One that does not answer in time is gone,
  // or stalled, and the word keeps it from rendering again.
  async #retireWorklet() {
    const node = this.#workletNode;
    const stop = this.#workletStop;
    this.#workletNode = null;
    this.#workletStop = null;
    if (!node) return;
    if (stop) Atomics.store(stop, 0, 1);
    await new Promise((resolve) => {
      let timer = 0;
      const done = () => { clearTimeout(timer); node.port.removeEventListener('message', onMessage); resolve(); };
      const onMessage = (event) => { if (event.data?.type === 'retired') done(); };
      timer = setTimeout(done, RETIRE_ACK_TIMEOUT_MS);
      node.port.addEventListener('message', onMessage);
      node.port.postMessage({ type: 'retire' });
    });
    node.disconnect();
    node.port.close();
  }

  async #releaseAudioContext() {
    const ctx = this.#audioContext;
    if (!ctx) return;
    this.#audioContext = null;
    if (this.#onContextState) ctx.removeEventListener('statechange', this.#onContextState);
    this.#onContextState = null;
    if (this.#ownsAudioContext && ctx.state !== 'closed') {
      try { await ctx.close(); } catch (e) { /* already closing */ }
    }
  }

      async #loadWasm() {
    if (this.#cachedWasmBytes) return this.#cachedWasmBytes;

    const wasmName = this.#config.wasmUrl.split('/').pop();

    if (this.#config.wasmBytes) {
      const wasmBytes = this.#config.wasmBytes;
      this.#eventEmitter.emit('loading:start', { type: 'wasm', name: wasmName, size: wasmBytes.byteLength });
      this.#eventEmitter.emit('loading:complete', { type: 'wasm', name: wasmName, size: wasmBytes.byteLength });
      this.#cachedWasmBytes = wasmBytes;
      return wasmBytes;
    }
    const wasmBytes = await this.#assetLoader.fetch(this.#config.wasmUrl, { type: 'wasm', name: wasmName });
    this.#cachedWasmBytes = wasmBytes;

    return wasmBytes;
  }

  async #initializeAudioWorklet(wasmBytes) {
    await addWorkletModule(this.#audioContext.audioWorklet, this.#config.workletUrl);

    const numOutputChannels = this.#config.audio.outputChannels;
    this.#workletNode = new AudioWorkletNode(this.#audioContext, "clockwork-processor", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [numOutputChannels],
    });

    if (this.#config.autoConnect) {
      const dest = this.#audioContext.destination;
      if (numOutputChannels > 2) {
        dest.channelCount = Math.min(numOutputChannels, dest.maxChannelCount);
        dest.channelInterpretation = 'discrete';
      }
      this.#workletNode.connect(dest);
    }

    this.#node = this.#createNodeWrapper();
    this.#workletNode.port.start();
    this.#setupMessageHandlers();

    const mode = this.#config.mode;
    const sharedBuffer = mode === 'sab' ? this.#wasmMemory.buffer : null;
    this.#workletStop = mode === 'sab' ? new Int32Array(new SharedArrayBuffer(4)) : null;

    this.#workletNode.port.postMessage({
      type: "init",
      mode: mode,
      sharedBuffer: sharedBuffer,
      stopBuffer: this.#workletStop?.buffer ?? null,
      snapshotIntervalMs: this.#config.snapshotIntervalMs,
      schedulerLateLimitMs: this.#config.schedulerLateLimitMs,
    });

    const loadWasmMsg = {
      type: "loadWasm",
      wasmBytes: wasmBytes,
      // The generation a reload closed, which this memory carries on (#closeInstance).
      carriedGeneration: this.#closedGeneration,
      // The guest's config block, already encoded by whoever knows its shape.
      guestConfigBytes: this.encodeGuestConfig({
        mode,
        guestMemoryOffset: this.#config.memory.guestMemoryOffset,
      }),
      // Where the guest's opaque region is.
      guestMemoryOffset: this.#config.memory.guestMemoryOffset,
      guestMemorySize: this.#config.memory.guestMemorySize,
      // The two one-way bulk lanes. Each has exactly one writer: the client
      // writes the assets area and the guest only reads it; the guest writes the
      // returns and the client only reads it. Neither overlaps the arena.
      assetsOffset: this.#config.memory.assetsOffset,
      assetsSize: this.#config.memory.assetsSize,
      returnsOffset: this.#config.memory.returnsOffset,
      returnsSize: this.#config.memory.returnsSize,
      // And the span clockwork::mem allocates from, which sits below that region and
      // is where the guest's real-time pool comes from. A build-time constant
      // cannot size it: how big that pool is, is a runtime question.
      memArenaSize: this.#config.memory.memArenaSize ?? 0,
      inputChannels: this.#config.audio.inputChannels,
      outputChannels: this.#config.audio.outputChannels,
      sampleRate: this.#audioContext.sampleRate,
    };

    if (mode === 'sab') {
      loadWasmMsg.wasmMemory = this.#wasmMemory;
    } else {
      const minPages = MemoryLayout.totalPages;
      loadWasmMsg.memoryPages = Math.max(Math.ceil(this.#config.memory.totalMemory / 65536), minPages);
      loadWasmMsg.maxMemoryPages = Math.ceil(this.#config.memory.maxTotalMemory / 65536);
    }

    this.#workletNode.port.postMessage(loadWasmMsg);

    await this.#waitForWorkletInit();
  }

  #createNodeWrapper() {
    const worklet = this.#workletNode;
    return Object.freeze({
      connect: (...args) => worklet.connect(...args),
      disconnect: (...args) => worklet.disconnect(...args),
      get context() { return worklet.context; },
      get numberOfOutputs() { return worklet.numberOfOutputs; },
      get numberOfInputs() { return worklet.numberOfInputs; },
      get channelCount() { return worklet.channelCount; },
      get input() { return worklet; },
    });
  }

  async #initializeOSC() {
    const mode = this.#config.mode;
    const bc = this.#metricsReader.bufferConstants;
    const arenaBase = this.#metricsReader.arenaBase;
    const sharedBuffer = this.#metricsReader.sharedBuffer;

    const transportConfig = {
      workerBaseURL: this.#config.workerBaseURL,
      snapshotIntervalMs: this.#config.snapshotIntervalMs,
      getAudioContextTime: () => this.#audioContext?.currentTime ?? 0,
    };

    if (mode === 'sab') {
      // A host that drains the egress itself says so with a port: the pump worker is not spawned, and that
      // endpoint speaks its protocol instead (lib/osc_in_pump.js runs the same reader wherever it is wanted).
      if (this.#config.oscInEndpoint) transportConfig.oscInEndpoint = this.#config.oscInEndpoint;
      transportConfig.sharedBuffer = sharedBuffer;
      transportConfig.arenaBase = arenaBase;
      transportConfig.bufferConstants = bc;

      // Initialize node ID counter in shared memory.
      // Starts at 1000: 0 is the root group and
      // 1–999 are left free for the client to assign by hand.
      if (bc?.NODE_ID_COUNTER_START !== undefined) {
        const counterBase = arenaBase + bc.NODE_ID_COUNTER_START;
        const counterView = new Int32Array(sharedBuffer, counterBase, 1);
        Atomics.store(counterView, 0, 1000);
      }
    } else {
      this.#nodeIdCounter = 1000;
      transportConfig.nodeIdSource = (rangeSize) => {
        const from = this.#nodeIdCounter;
        this.#nodeIdCounter += rangeSize;
        return { from, to: from + rangeSize };
      };

      // PM mode: provision the AudioWorklet with its own node ID range
      // for the C++ UUID rewriter (same protocol as OscChannel workers)
      const workletNodeIdRangeSize = 10000;
      const workletRange = transportConfig.nodeIdSource(workletNodeIdRangeSize);
      const nodeIdChannel = new MessageChannel();
      const nodeIdSource = transportConfig.nodeIdSource;
      nodeIdChannel.port1.onmessage = (e) => {
        if (e.data.type === 'requestNodeIdRange') {
          const r = nodeIdSource(workletNodeIdRangeSize);
          nodeIdChannel.port1.postMessage({ type: 'nodeIdRange', from: r.from, to: r.to });
        }
      };
      this.#workletNode.port.postMessage(
        { type: 'nodeIdRange', from: workletRange.from, to: workletRange.to },
        [nodeIdChannel.port2]
      );
    }

    this.#osc = createTransport(mode, transportConfig);

    this.#osc.onReply((oscData, sequence, timestamp) => {
      // A verb the worklet forwarded to the host is the front's to answer,
      // not the client's to hear: it never sent one of those inbound.
      if (this.#front && this.#front.take(oscData)) return;
      this.#deliverInbound(oscData, sequence, timestamp);
    });

    // Debug arrives as /clockwork/debug on the OSC-in path above.

    this.#osc.onError((error, workerName) => {
      console.error(`[Clockwork] ${workerName} error:`, error);
      this.#eventEmitter.emit('error', new Error(`${workerName}: ${error}`));
    });

    this.#osc.onOscLog((entries) => {
      for (const entry of entries) {
        const scheduledTime = oscFast.getBundleTimeTag(entry.oscData) || null;
        this.#eventEmitter.emit('out:osc', {
          oscData: entry.oscData,
          sourceId: entry.sourceId,
          sequence: entry.sequence,
          timestamp: entry.timestamp,
          scheduledTime,
        });

        const needsDecode = this.#eventEmitter.hasListeners('out') ||
          this.#eventEmitter.hasListeners('out:text') ||
          this.#eventEmitter.hasListeners('out:html') ||
          this.#config.debug || this.#config.debugOscOut;
        if (needsDecode) {
          try {
            const msg = oscFast.decodePacket(entry.oscData);
            this.#eventEmitter.emit('out', msg);

            if (this.#eventEmitter.hasListeners('out:text') || this.#config.debug || this.#config.debugOscOut) {
              const maxLen = this.#config.activityEvent.oscOutMaxLineLength ?? this.#config.activityEvent.maxLineLength;
              const text = formatOscText(msg, maxLen);
              this.#eventEmitter.emit('out:text', { text, sequence: entry.sequence, timestamp: entry.timestamp, scheduledTime });
            }

            if (this.#eventEmitter.hasListeners('out:html')) {
              const html = formatBundleHtml(msg, entry.sequence, entry.timestamp, this.#clock?.now() ?? 0, entry.sourceId);
              this.#eventEmitter.emit('out:html', { html, sequence: entry.sequence, timestamp: entry.timestamp });
            }
          } catch (e) { /* skip decoded events on decode failure */ }
        }
      }
    });

    if (this.#config.debug || this.#config.debugOscIn) {
      this.on('in:text', ({ text }) => console.log(`[← OSC] ${text}`));
    }
    if (this.#config.debug || this.#config.debugOscOut) {
      this.on('out:text', ({ text }) => console.log(`[OSC →] ${text}`));
    }
    if (this.#config.debug || this.#config.debugEngine) {
      this.on('debug', (msg) => console.log(`[synth] ${msg.text}`));
    }

    if (mode === 'sab') {
      await this.#osc.initialize();
    } else {
      await this.#osc.initialize(this.#workletNode.port);

      // PM mode: pass bufferConstants to transport for decoder worker
      this.#osc.setBufferConstants(bc);

      if (this.#earlyDebugMessages?.length > 0) {
        for (const data of this.#earlyDebugMessages) {
          this.#osc.handleDebugRaw(data);
        }
      }
      // Optional-chain #osc: a debugRawBatch queued from the old worklet can
      // be dispatched during reload()/teardown after #osc has been nulled.
      this.#debugRawHandler = (data) => this.#osc?.handleDebugRaw(data);
      this.#earlyDebugMessages = [];
    }

    // Create main-thread OscChannel for sendOSC()
    // Main thread uses sourceId 0, workers get 1+
    this.#oscChannel = this.#osc.createOscChannel({ sourceId: 0 });
  }

  /*
   * The host's front (js/lib/host_front.js). Always present once the
   * transport is: the worklet forwards every /clockwork/ verb its audio
   * thread does not answer, so SOMETHING on this side has to be the far end
   * that answers or refuses. With `midi` / `gamepad` enabled, that is the
   * managers; without, every such verb is refused by name.
   */
  async #initializeFront() {
    this.#front?.dispose();
    this.#front = new HostFront({
      midi: this.#config.midi,
      gamepad: this.#config.gamepad,
      wasmBaseURL: this.#config.wasmBaseURL,
      deliver: (bytes) => this.#deliverInbound(bytes, -1, performance.now()),
      // What a refusal is stamped with (docs/RESTARTS.md): the guest instance's
      // generation at that moment, which only the page knows where to read.
      generation: () => this.#instanceGeneration(),
      // An event goes INTO the engine, as a native subsystem's would: the
      // transport exists by now, and the client need not be 'initialized'
      // for a keyboard to be heard during boot.
      ingest: (bytes) => this.#sendPreparedOSC(this.#toUint8Array(bytes)),
      // A subsystem that cannot come up is not a failed boot: the engine
      // runs without it, the reason is on the console and the 'error'
      // event, and `midiError` / `gamepadError` keeps it.
      onUnavailable: (name, error) => {
        console.warn(`[Clockwork] ${name} unavailable, booting without it:`, error);
        this.#eventEmitter.emit('error', new Error(`${name} unavailable: ${error?.message ?? error}`));
      },
    });
    await this.#front.init();
  }

  /*
   * One inbound frame for the client: an engine reply or push off the
   * egress, or a reply or push the front made on the engine's behalf — the
   * same path, the same events, so a listener cannot tell which side
   * answered. `sequence` is the egress frame's, or -1 for the front's.
   */
  #deliverInbound(oscData, sequence, timestamp) {
    const scheduledTime = oscFast.getBundleTimeTag(oscData) || null;
    this.#eventEmitter.emit('in:osc', { oscData, sequence, timestamp, scheduledTime });

    try {
      const msg = oscFast.decodePacket(oscData);

      const address = msg[0];
      const args = msg.slice(1);
      if (address === clockworkSys("debug")) {
        // Debug log lines ride the egress as /clockwork/debug — surface them on
        // the 'debug' event, not the regular OSC-in stream.
        const eventMaxLen = this.#config.activityEvent.engineMaxLineLength ?? this.#config.activityEvent.maxLineLength;
        let text = args[0] ?? '';
        if (eventMaxLen > 0 && text.length > eventMaxLen) text = text.slice(0, eventMaxLen) + '...';
        this.#eventEmitter.emit('debug', { text, sequence, timestamp });
        return;
      } else if (address === clockworkSys("synced") && args.length > 0) {
        const syncId = args[0];
        if (this.#syncListeners?.has(syncId)) {
          this.#syncListeners.get(syncId)(msg);
        }
      }

      this.#eventEmitter.emit('in', msg);

      if (this.#eventEmitter.hasListeners('in:text') || this.#config.debug || this.#config.debugOscIn) {
        const maxLen = this.#config.activityEvent.oscInMaxLineLength ?? this.#config.activityEvent.maxLineLength;
        const argsStr = args.map(a => formatOscArg(a, maxLen)).join(', ') || '';
        const text = `${address}${argsStr ? ' ' + argsStr : ''}`;
        this.#eventEmitter.emit('in:text', { text, sequence, timestamp });
      }

      if (this.#eventEmitter.hasListeners('in:html')) {
        const html = formatOscLineHtml(msg, sequence, timestamp, this.#clock?.now() ?? 0);
        this.#eventEmitter.emit('in:html', { html, sequence, timestamp });
      }
    } catch (e) {
      console.error('[Clockwork] Failed to decode OSC message:', e);
    }
  }

  async #finishInitialization({ announce = true } = {}) {
    this.#initialized = true;
    this.#initializing = false;
    this.bootStats.initDuration = performance.now() - this.bootStats.initStartTime;

    if (announce) {
      // Up means its clock can be read too: a page that reads clock.now() the moment init() returns gets the
      // engine's time, not 0 (postMessage mode hears it down the main channel's port a few blocks in). A context
      // not yet running (autoplay) has no blocks to wait for.
      if (this.#audioContext?.state === 'running') await this.#clockReadable(250);
      this.#setEngineState('running', 'boot');
      await this.#announceReady();
    }

    // TODO(v1): Consider whether to keep this dev console helper.
    // It auto-registers instances to window.__clockwork__ for quick debugging (ss.metrics(), ss.tree(), etc.)
    // Unusual pattern - most libs expect devs to do `window.sonic = sonic` themselves.
    // Useful but the `instances` array for multiple engines is over-engineered.
    if (__DEV__ && typeof window !== 'undefined') {
      if (!window.__clockwork__) {
        const ss = window.__clockwork__ = { instances: [] };
        Object.defineProperties(ss, {
          primary: { get: () => ss.instances[0] },
          layout: { get: () => ss.primary?.bufferConstants },
        });
        ss.metrics = () => ss.primary?.getMetrics();
        ss.window = () => ss.primary?.readWindow();
        ss.snapshot = () => ss.primary?.getSnapshot();
      }
      if (!window.__clockwork__.instances.includes(this)) window.__clockwork__.instances.push(this);   // once: a reload is the same instance
    }
  }

  #waitForWorkletInit() {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error("AudioWorklet initialization timeout"));
      }, WORKLET_INIT_TIMEOUT_MS);

      const messageHandler = async (event) => {
        if (event.data.type === "error") {
          clearTimeout(timeout);
          this.#workletNode.port.removeEventListener("message", messageHandler);
          { const e = new Error(event.data.error || "AudioWorklet error"); if (event.data.stack) e.stack = event.data.stack; reject(e); }
          return;
        }

        if (event.data.type === "initialized") {
          clearTimeout(timeout);
          this.#workletNode.port.removeEventListener("message", messageHandler);

          if (event.data.success) {
           try {
            const arenaBase = event.data.arenaBase ?? 0;
            const bufferConstants = event.data.bufferConstants;
            this.#version = event.data.version ?? null;
            // The generation the worklet read off the arena once the instance was up: the
            // page's word for it where it has no shared view of the arena (postMessage).
            this.#generation = event.data.generation ?? 0;
            const sharedBuffer = this.#config.mode === 'sab' ? this.#wasmMemory.buffer : null;

            this.#metricsReader.initSharedViews(sharedBuffer, arenaBase, bufferConstants);

            // How many mirror entries a guest will use is a number only the guest knows
            // the name of. Clockwork publishes the capacity; the guest decides whether it
            // is enough.

            // Initialize NTP timing
            this.#clock = new ClockworkClock({
              mode: this.#config.mode,
              audioContext: this.#audioContext,
              workletPort: this.#workletNode.port,
            });
            this.#clock.initSharedViews(sharedBuffer, arenaBase, bufferConstants);
            // The engine's time is read where the engine publishes it (its sample clock), never computed here
            this.#clock.setNowSource(() => this.#oscChannel?.now() ?? 0);

            // Initialize audio capture (SAB mode only)
            if (this.#config.mode === 'sab') {
              this.#audioCapture.update(sharedBuffer, arenaBase, bufferConstants);
            }

            // PostMessage mode: set initial snapshot
            if (this.#config.mode === 'postMessage' && event.data.initialSnapshot) {
              this.#metricsReader.updateSnapshot(event.data.initialSnapshot);
            }

            resolve();
           } catch (error) {
            // This handler is async and its timeout is already cleared: a throw here (the clock waiting on a
            // context that never started) was an unhandled rejection, and init() never settled at all.
            reject(new Error(`the audio clock did not start (audio context ${this.#audioContext?.state ?? 'gone'}): ${error?.message ?? error}`));
           }
          } else {
            { const e = new Error(event.data.error || "AudioWorklet initialization failed"); if (event.data.stack) e.stack = event.data.stack; reject(e); }
          }
        }
      };

      this.#workletNode.port.addEventListener("message", messageHandler);
      this.#workletNode.port.start();
    });
  }


  #setupMessageHandlers() {
    this.#workletNode.port.addEventListener('message', (event) => {
      const { data } = event;

      switch (data.type) {
        case "error":
          console.error("[Worklet] Error:", data.error);
          // the worklet's stack travels with it: a trap inside the engine (a wasm "memory access out of bounds") is
          // otherwise a message with no place
          { const e = new Error(data.error); if (data.stack) e.stack = data.stack; this.#eventEmitter.emit('error', e); }
          break;

        case "snapshot":
          if (data.buffer) {
            this.#metricsReader.updateSnapshot(data.buffer);
            this.#snapshotsSent = data.snapshotsSent;
          }
          break;

        case "debugRawBatch":
          if (this.#debugRawHandler) {
            this.#debugRawHandler(data);
          } else if (this.#earlyDebugMessages) {
            this.#earlyDebugMessages.push(data);
          }
          break;

        // Note: oscLog is handled directly by the PM transport's #handleWorkletMessage
        // and by the SAB transport's osc_out_log_sab_worker — no forwarding needed here.
      }
    });
  }

  // ============================================================================
  // PRIVATE: METRICS
  // ============================================================================

  /**
   * Extra metrics context from the product built on clockwork.
   *
   * A client holds state clockwork cannot see — how many samples are
   * loaded, how often its own pool has grown — and the metrics object is
   * where a user looks for it. Overriding this is the supported way to get it
   * there; the alternative is a parallel metrics path beside clockwork's,
   * reported separately and never lining up with it.
   *
   * Return whatever the reader understands. Anything it does not recognise is
   * ignored rather than surfaced, so an unknown key is inert, not an error.
   *
   * @returns {object} merged over clockwork's own context
   */
  clientMetrics() { return {}; }

  /**
   * Encode the guest's config block, or null when it has none.
   *
   * Clockwork reserves a region for it and copies the bytes in; it does not
   * know or care what they mean. Clockwork's own geometry travels as arguments
   * to clockwork_init rather than through this block, so a product's encoder is
   * free to lay it out however its guest wants.
   *
   * @param {{mode: string, guestMemoryOffset: number}} ctx  what only
   *        clockwork knows and the encoder may need
   * @returns {ArrayBuffer|ArrayBufferView|null}
   */
  encodeGuestConfig(ctx) { return null; }

  /**
   * Re-send whatever the product had in the engine, after a reload.
   *
   * A reload tears the engine down and builds it again, so everything the
   * engine held is gone, and clockwork has no idea what any of it was.
   * Override this to put it back — definitions, samples, anything.
   *
   * This is the ONLY restore path — there is no second mechanism for any one
   * category of state.
   *
   * Called before the barrier that waits on all of it, so a product does not
   * need its own sync.
   */
  async restoreClientState() {}

  /*
   * The declared guest metrics, merged into the schema clockwork reports so
   * a caller sees one list rather than clockwork's plus a product's.
   */
  getMetricsSchema() {
    return Clockwork.mergeGuestMetrics(this.#guestMetrics, this.#guestMetricsPanels);
  }

  /**
   * Clockwork's schema with one guest's declarations folded in.
   *
   * Static, because a product overriding the static `getMetricsSchema()` needs
   * the same merge before any instance exists — a caller inspecting what a
   * product reports should not have to boot one to find out.
   */
  static mergeGuestMetrics(declared = {}, panels = []) {
    const metrics = { ...METRICS_SCHEMA.metrics };
    for (const [name, def] of Object.entries(declared || {})) {
      metrics[name] = { ...def, offset: GUEST_METRICS_BASE + def.slot };
    }
    const layout = {
      ...METRICS_SCHEMA.layout,
      panels: [...(METRICS_SCHEMA.layout?.panels || []), ...(panels || [])],
    };
    return { ...METRICS_SCHEMA, metrics, layout };
  }

  #metricsContext() {
    return {
      // Only what the guest declared gets through; the rest has no slot.
      guestMetrics: this.clientMetrics(),
      transportMetrics: this.#osc?.getMetrics(),
      clockOffsetMs: this.#clock?.getClockOffset() ?? 0,
      audioContextState: this.#audioContext?.state || "unknown",
      audioHealthPct: this.#audioHealthMonitor?.update() ?? 100,
      playbackStats: this.#capabilities.playbackStats ? this.#audioContext?.playbackStats : null,
    };
  }

  #gatherMetrics() {
    return this.#metricsReader.gatherMetrics(this.#metricsContext());
  }

  #updateMergedArray() {
    this.#metricsReader.updateMergedArray(this.#metricsContext());
  }

  // ============================================================================
  // PRIVATE: UTILITIES
  // ============================================================================

  #readProcessCount() {
    if (this.#config.mode === 'sab') {
      const view = this.#metricsReader.getMetricsView();
      return view ? view[0] : null;
    }
    const buffer = this.#metricsReader.getSnapshotBuffer();
    if (!buffer) return null;
    return new Uint32Array(buffer, 0, 1)[0];
  }

  #ensureInitialized(actionDescription = "perform this operation") {
    if (!this.#initialized) {
      throw new Error(`Clockwork not initialized. Call init() before attempting to ${actionDescription}.`);
    }
  }


  #toUint8Array(data) {
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    throw new Error("oscData must be ArrayBuffer or Uint8Array");
  }

  #sendPreparedOSC(preparedData) {
    // A message larger than the IN ring can never be delivered — fail loudly
    // rather than dropping it silently in the ring writer.
    const bc = this.#metricsReader?.bufferConstants;
    const maxSize = bc?.IN_RING_SIZE;
    if (maxSize && preparedData.length > maxSize - 16 /* Message header */) {
      throw new Error(
        `OSC message too large to send (${preparedData.length} > ${maxSize - 16} bytes)`
      );
    }

    // Dumb send: frame the bytes onto the IN ring (SAB) or postMessage them (PM).
    // The audio thread classifies + schedules (OscIngress + Scheduler).
    // A SAB write that loses the lock race / hits a full ring is dropped and
    // counted as ringBufferDirectWriteFails (no fallback) — not silent.
    //
    // A message for the guest while there is no guest is refused at the
    // boundary, and the client hears the refusal the way it hears every
    // other: /clockwork/error with the address and the reason, on the same
    // path as the engine's replies (docs/RESTARTS.md). The word is
    // "wait for /clockwork/setup", so a listener re-sends then.
    if (!this.#oscChannel.send(preparedData)
        && this.#oscChannel.lastRefusal === REASON_NO_INSTANCE) {
      this.#deliverInbound(
        oscFast.copyEncoded(oscFast.encodeMessage(clockworkSys("error"),
                                                  [oscAddress(preparedData), REASON_NO_INSTANCE,
                                                   { type: "int", value: this.#instanceGeneration() }])),
        -1, performance.now());
    }
  }

      }

export const osc = Clockwork.osc;
