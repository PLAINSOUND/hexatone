# SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
# Copyright (c) 2025-2026 Sam Aaron
#
# clockwork — everything around a realtime audio engine, without the DSP.
#
# Everything on the DSP's side of the boundary is out of scope: no synthesis,
# no graph, no definition formats.
#
# VST3 and CLAP appear here, but as a HOST — clockwork loads and runs other
# people's plugins (plugins/, src/plugin_*). Being a plugin is a different
# thing and is not here. What is left is clockwork — rings, lanes, scheduler tags,
# shared memory, ClockworkClock, the comms client library, the JUCE audio
# backend, MIDI, gamepad — plus one DSP, chosen by CLOCKWORK_DSP, that
# supplies the seven symbols src/dsp_api.h declares.
#
# See docs/BOUNDARY.md.
cmake_minimum_required(VERSION 3.24)

# ─── Which Clockwork ─────────────────────────────────────────────────────────
# Clockwork has no version number (src/clockwork_config.h): a build says which
# Clockwork it is by the commit it was built from, as git names it in this
# repository, "-dirty" when the tree had changes. Not a git checkout (a source
# archive): "unknown". CLOCKWORK_COMMIT set by the caller wins.
project(Clockwork LANGUAGES C CXX)

# Apple's address wait (os_sync_wait_on_address, src/workers/wait_word.cpp)
# is public from macOS 14.4 and iOS 17.4: the floor for every Apple build.
if(APPLE AND CMAKE_OSX_DEPLOYMENT_TARGET)
    if(CMAKE_SYSTEM_NAME STREQUAL "iOS" AND CMAKE_OSX_DEPLOYMENT_TARGET VERSION_LESS 17.4)
        message(FATAL_ERROR "Clockwork needs iOS 17.4 or later (CMAKE_OSX_DEPLOYMENT_TARGET is ${CMAKE_OSX_DEPLOYMENT_TARGET})")
    elseif(NOT CMAKE_SYSTEM_NAME STREQUAL "iOS" AND CMAKE_OSX_DEPLOYMENT_TARGET VERSION_LESS 14.4)
        message(FATAL_ERROR "Clockwork needs macOS 14.4 or later (CMAKE_OSX_DEPLOYMENT_TARGET is ${CMAKE_OSX_DEPLOYMENT_TARGET})")
    endif()
endif()
if(NOT DEFINED CLOCKWORK_COMMIT)
    set(CLOCKWORK_COMMIT "unknown")
    find_package(Git QUIET)
    if(GIT_FOUND)
        execute_process(COMMAND "${GIT_EXECUTABLE}" -C "${CMAKE_CURRENT_SOURCE_DIR}" describe --always --dirty --abbrev=12 --match=NeVeRmAtCh
                        OUTPUT_VARIABLE _cw_commit OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_QUIET RESULT_VARIABLE _cw_git)
        if(_cw_git EQUAL 0 AND _cw_commit)
            set(CLOCKWORK_COMMIT "${_cw_commit}")
        endif()
    endif()
endif()
# its first eight hex digits as a number, where only a number fits (0: unknown)
set(CLOCKWORK_COMMIT_WORD 0)
if(CLOCKWORK_COMMIT MATCHES "^([0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f])")
    math(EXPR CLOCKWORK_COMMIT_WORD "0x${CMAKE_MATCH_1}" OUTPUT_FORMAT DECIMAL)
endif()
message(STATUS "Clockwork ${CLOCKWORK_COMMIT}")
if(APPLE)
    enable_language(OBJCXX)
endif()

# C++20: std::atomic::wait() / notify_all() are used throughout the workers.
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Every thread is a std::jthread with a std::stop_token, and that is the one
# C++20 library feature a current-looking toolchain can still lack: libc++
# kept <stop_token> behind -fexperimental-library until libc++ 20, so Apple
# clang up to Xcode 16.4 fails on the first jthread with a page of errors
# from deep inside a header. Say it once, here, in plain words instead.
include(CheckCXXSourceCompiles)
check_cxx_source_compiles("
#include <stop_token>
#include <thread>
int main() {
    std::jthread t([](const std::stop_token& st) { while (!st.stop_requested()) {} });
    t.request_stop();
    return 0;
}
" CLOCKWORK_HAS_STD_JTHREAD)
if(NOT CLOCKWORK_HAS_STD_JTHREAD)
    message(FATAL_ERROR
        "Clockwork needs std::jthread and std::stop_token (C++20). This standard "
        "library does not provide them: libc++ 20 or later (Xcode 26.6 or later on "
        "macOS), libstdc++ 10 or later, or MSVC 2019 16.10 or later.")
endif()

# ─── The web target ──────────────────────────────────────────────────────────
# `emcmake cmake -B build/web` builds this same tree for the AudioWorklet:
# the same C++ core, the same Rust subsystems, the same DSP boundary, from the
# same lists. What changes is which subsystems are present — a worklet has no
# device, no MIDI port, no socket, no plugin host and no process of its own —
# and those are decided here, before their options are declared, so a web
# configure cannot ask for what a worklet cannot have. scripts/build-web.sh
# wraps this and adds the JavaScript bundle; a product's own build (SuperSonic)
# points CLOCKWORK_DSP at its guest and names the module.
if(EMSCRIPTEN)
    foreach(_off CLOCKWORK_DEVICE CLOCKWORK_MIDI CLOCKWORK_GAMEPAD CLOCKWORK_OSC
                 CLOCKWORK_PLUGINS CLOCKWORK_LINK CLOCKWORK_LINK_AUDIO CLOCKWORK_NIF
                 CLOCKWORK_STANDALONE BUILD_TESTS CLOCKWORK_ASIO)
        set(${_off} OFF CACHE BOOL "off for the web target" FORCE)
    endforeach()
endif()

# ─── Options ─────────────────────────────────────────────────────────────────
# What this binary calls itself: the banner, every log line, the name given to
# hosted plugins, the shared-memory segment, the headless device. An EMBEDDER
# sets this; a standalone clockwork build keeps its own name. See src/clockwork_product.h.
set(CLOCKWORK_PRODUCT_NAME "clockwork" CACHE STRING
    "Product name used in banners, logs and OS-visible names")

# The product's own header — its boot banner lives there, being art rather
# than a word. Empty keeps clockwork's own. See src/clockwork_product.h.
set(CLOCKWORK_PRODUCT_HEADER "" CACHE FILEPATH
    "Header defining CLOCKWORK_PRODUCT_BANNER for this product")

# Shown beside the product name in Windows' version resource — which is what
# UAC and the microphone/permission dialogs display. An embedder sets both.
set(CLOCKWORK_COMPANY_NAME "${CLOCKWORK_PRODUCT_NAME}" CACHE STRING
    "Company name in the Windows version resource")

# The version stamped into the Windows resource and said under the boot
# banner: the PRODUCT's, which an embedder sets. Clockwork has none of its own;
# left empty, the banner says the commit and the Windows resource 0.0.0.0.
# See src/clockwork_product.h.
set(CLOCKWORK_PRODUCT_VERSION "" CACHE STRING
    "Version stamped into OS-visible metadata and the boot banner")

option(BUILD_TESTS "Build the native Catch2 test suite" OFF)
option(CLOCKWORK_PLUGIN_MODULES "Build Clockwork for plugin binaries (position-independent, so a plugin's shared module can take it in) and the test that loads two in one process" ${BUILD_TESTS})

# The scheduler host and clockwork's own test suite exist to prove clockwork
# works on its own. A project that EMBEDS clockwork wants the library and not
# those: its own host is the point, and building ours would give it a second
# main() and a second DSP. Defaults to on when clockwork is the top-level
# project and off when it is a subdirectory, which is the right answer in
# both cases without anyone setting anything.
option(CLOCKWORK_STANDALONE
    "Build the scheduler host and clockwork's own tests"
    ${PROJECT_IS_TOP_LEVEL})

# The DSP. A directory under dsp/ holding a CMakeLists.txt that defines a
# target of the same name, implementing dsp_api.h. The default `dummy` makes a
# noise and exists only so this repository can build and test itself with no
# real DSP present.
set(CLOCKWORK_DSP "dummy" CACHE STRING
    "Which DSP to link (implements src/dsp_api.h)")

# Where that DSP's CMakeLists.txt lives. Empty means dsp/<CLOCKWORK_DSP>
# inside this repository, which is what a standalone build wants.
#
# A CONSUMER SETS THIS. Clockwork is a substrate: the project embedding it
# owns the DSP, and its engine has no business living inside clockwork's
# checkout — that would make clockwork un-updatable without carrying somebody
# else's engine along with it. Point this at a directory anywhere and it is
# added as a subdirectory with its own binary dir.
set(CLOCKWORK_DSP_DIR "" CACHE PATH
    "Directory holding the DSP's CMakeLists.txt (empty = dsp/<CLOCKWORK_DSP> in-tree)")

# ── Rust subsystems ──────────────────────────────────────────────────────────
# ── The native audio device layer ────────────────────────────────────────────
#
# OFF builds clockwork WITHOUT smoothie/JUCE: no device enumeration, no device
# callback, no recovery, no recording. What is left is the substrate — the
# lanes ABI, the clock, the rings, the scheduler, ports, sinks, MIDI, gamepad,
# OSC and the DSP boundary — for a host that owns its own audio callback and
# never opens a device.
#
# That is every embedded target, the AudioWorklet, and a plugin, where the DAW
# owns the device and a second device layer is at best dead weight. The
# coupling is confined to src/native/, so this is a source-list decision rather
# than an #ifdef through the tree.
#
# It also removes clockwork's only JUCE dependency, and with it the ISC/AGPL
# question smoothie exists to answer.
option(CLOCKWORK_WERROR  "Compiler warnings in Clockwork's own targets are errors (CI sets it)" OFF)
# A sanitizer for the whole tree: "address,undefined" or "thread". One knob,
# applied to every language and the link, because a flag handed to CMAKE_C_FLAGS
# and CMAKE_CXX_FLAGS alone misses the Objective-C++ that smoothie's JUCE
# compiles as on macOS — and a thread stop whose atomics are not instrumented
# reads to ThreadSanitizer as no synchronisation at all, so it reports every
# thread stop as a race.
set(CLOCKWORK_SANITIZE "" CACHE STRING "Sanitizer(s) to build the whole tree with: address,undefined or thread (empty for none)")
if(CLOCKWORK_SANITIZE)
    add_compile_options(-fsanitize=${CLOCKWORK_SANITIZE} -fno-omit-frame-pointer)
    add_link_options(-fsanitize=${CLOCKWORK_SANITIZE})
    message(STATUS "Clockwork sanitizer: ${CLOCKWORK_SANITIZE} (C, C++, Objective-C++ and the link)")
endif()
option(CLOCKWORK_DEVICE  "Build the native audio device layer (smoothie/JUCE)" ON)

option(CLOCKWORK_MIDI    "Integrate the Rust/midir MIDI subsystem"        ON)
option(CLOCKWORK_GAMEPAD "Integrate the Rust/gilrs gamepad subsystem"     ON)
option(CLOCKWORK_OSC     "Integrate the Rust/std::net OSC subsystem"      ON)

# ── Who builds the Rust half ─────────────────────────────────────────────────
# ON: cargo builds the Rust subsystems into one umbrella staticlib here, and
# every binary this tree links gets it. OFF: the embedder is a RUST program
# (rust/clockwork-sys) that takes the subsystem crates as dependencies of its
# own — one std, rustc's own link line — and this tree builds the C++ alone.
# The targets that need the umbrella are refused below rather than left to
# fail at link.
option(CLOCKWORK_RUST "Build the Rust subsystems' umbrella staticlib with cargo (OFF: a Rust embedder supplies them as crates)" ON)

# ── The timed-event store ────────────────────────────────────────────────────
# OFF removes clockwork's timed queue entirely — the Rust crate is not
# compiled and no store, slot pool or data pool is carried. What is lost with
# it: /clockwork-sys/schedule, /clockwork-sys/sched/flush, timed MIDI clock out and timed
# OSC forwarding. Everything timed, in other words, except what a DSP schedules
# for itself; immediate messages are unaffected and a timed message still
# reaches the DSP at once, carrying its original timetag, for the DSP to decide
# what to do with.
#
# DEFAULT ON, and the default is not a matter of taste. The two real consumers
# sit on opposite sides of it: a guest scheduled by message uses the store, a self-scheduling guest
# does not (its VM parks programs rather than messages). The failures are
# asymmetric — such a guest
# build that forgets to turn this off carries a store it never fills, which is
# waste and nothing worse; a message-scheduled build that forgets to turn it on loses
# timed delivery. Waste is the better failure, so the default absorbs it. Do
# not "tidy" it to OFF.
#
# This is a compile-time switch and DspInfo::holds_schedule is a runtime one,
# and they are not redundant: see src/scheduler/engine_schedule.h, which states
# how the two compose.
option(CLOCKWORK_SCHEDULER "Build clockwork's timed-event store (/clockwork-sys/schedule, /clockwork-sys/sched/flush, timed MIDI out, timed OSC forwarding). OFF forwards every message immediately, carrying its timetag." ON)

# The CLIENT half of the verb surface (docs/SURFACE.md): /clockwork/midi/out/*,
# /clockwork/midi/clock/beat and /clockwork/osc/send — the verbs that exist
# because something outside clockwork drives it one event at a time. A guest
# that is in charge of itself reaches a wire through clockwork_sink_send and
# never sends them, so a build shaped for such a guest turns this OFF and the
# verbs are not compiled: a client that sends one is refused by name, with
# the reason. The transport half — ports, devices, the clock, subscriptions —
# stays in every build, because owning the hardware is what clockwork is for.
# The timed store is the same split, already made: CLOCKWORK_SCHEDULER.
option(CLOCKWORK_CLIENT_VERBS "Answer the client half of the verb surface (/clockwork/midi/out/*, /clockwork/midi/clock/beat, /clockwork/osc/send). OFF refuses them by name; see docs/SURFACE.md" ON)

# ── Ableton Link: OFF by default, and buildable when you turn it on ──────────
#
# Link is GPL-2.0-or-later, and so is the receive-side renderer that carries
# its audio (src/native/vendor/LinkAudioInputRenderer.hpp, adapted from
# Ableton's own example and vendored here under its original notice). Taken
# under GPLv3, both combine with an AGPL binary. A build under the commercial
# licence cannot take them that way and needs Ableton's own terms. See LICENSE.
option(CLOCKWORK_LINK "Integrate Ableton Link, tempo and audio (GPL-2.0-or-later; fetches the library)" OFF)
option(CLOCKWORK_LINK_AUDIO "Link peer audio in and publish out (needs CLOCKWORK_LINK)" OFF)

# ─── BEAM NIF: clockwork as an Erlang/Elixir native library ────────────────
#
# src/nif/ is one of the reference hosts lanes.h names — a host that drives the
# engine through the ABI and contains no DSP knowledge, which is how "the boundary
# is host-agnostic" gets to be a checkable claim rather than an assertion.
#
# The OTP headers are vendored (external/erlang_headers, Apache-2.0, (c)
# Ericsson) so building the NIF needs no Erlang installation — only running its
# tests does. erl_int_sizes_config.h is generated for the target because the
# sizes it records are the compiler's, not the header author's.
option(CLOCKWORK_NIF "Build the BEAM NIF shared library" OFF)
option(CLOCKWORK_NIF_FRONT "A product adds its own clockwork_nif_make_front to clockwork_nif (src/nif/clockwork_nif_front.h); off, the NIF has no front" OFF)

# Windows-only; a no-op elsewhere. The Steinberg ASIO SDK is dual-licensed,
# Steinberg-proprietary OR GPLv3. external/ASIOSDK2.3.4 is the SDK's source,
# taken under GPLv3, without the logo artwork and PDFs that no compiler opens.
# A build under the commercial licence cannot take it that way and needs
# Steinberg's own agreement. See LICENSE.
option(CLOCKWORK_ASIO "Compile JUCE's ASIO backend on Windows (Steinberg SDK, taken under GPLv3)" OFF)

# ── Audio files ──────────────────────────────────────────────────────────────
# There is no option here, and that is the point. Reading and writing audio
# files is src/clockwork_audio_file.h: the decoders are the Rust crate
# clockwork-audio-decode (symphonia, MPL-2.0, in the umbrella staticlib) and
# the writers and FLAC encoder are this repository's own. No package to find,
# nothing fetched at configure time, and the same formats on every platform
# including WebAssembly — what a build reads is a property of the source
# rather than of the machine it was configured on.
option(CLOCKWORK_CARGO_OFFLINE  "Build the Rust subsystems with --offline (requires pre-vendored crates)" OFF)
# libsamplerate is vendored unmodified (src/vendor/libsamplerate, 0.2.2, its
# medium sinc converter: see CLOCKWORK.md there) for the Link Audio input
# renderer. A distro build can link the packaged one instead — Debian's
# libsamplerate0-dev, pkg-config samplerate — and the copy is not compiled.
option(CLOCKWORK_SYSTEM_SAMPLERATE "Use the system libsamplerate (pkg-config: samplerate) instead of the vendored copy" OFF)

# ── Plugin hosting ───────────────────────────────────────────────────────────
# Clockwork as a HOST of plugins rather than as one — see src/plugin_host.h
# and docs/TRACKS.md. One directory under plugins/ per format, each
# holding its adapter's build and a trivial in-tree test plugin.
#
# Defaults ON, unlike every other fetching option here, because it costs
# nothing to say yes to: CLAP is MIT and header-only, so there is no library to
# build and no licence question to answer. Native only by construction — WASM
# cannot load a native plugin, which is why hosting can never be part of
# clockwork's core contract.
#
# Each format looks for installed SDK headers first (CLAP_INCLUDE_DIR,
# VST3_PLUGINTERFACES_INCLUDE_DIR, or the usual include paths) and fetches the
# pinned copy only when there are none, so a distro build with no network can
# still say yes.
option(CLOCKWORK_PLUGINS "Host CLAP and VST3 plugins (system SDK headers if installed, else fetched)" ON)

# What the plugin-bridge process is called on disk and in the process list.
# Plugins run in this separate process (plugin_bridge.h), so it is the name a
# user sees when one misbehaves; an embedder gives it a product-facing one.
# The engine finds it by this name beside its own executable.
set(CLOCKWORK_PLUGIN_BRIDGE_NAME "clockwork-plugin-bridge" CACHE STRING
    "File name of the plugin-bridge executable, built beside the host binary")
# Where an INSTALLED engine finds the bridge when it is not beside the
# executable. The engine looks for CLOCKWORK_PLUGIN_BRIDGE_NAME as a sibling
# of its own binary first (that is how a build tree and an app bundle are laid
# out), then in this directory. A distribution that keeps helper programs out
# of the user's PATH installs the bridge here — Debian's /usr/libexec/<pkg>,
# say — and sets this to match. Empty means "beside the executable only".
set(CLOCKWORK_PLUGIN_BRIDGE_DIR "" CACHE PATH
    "Directory the engine also searches for the plugin bridge (an installed layout)")

# The bridge's identity to macOS. On macOS the bridge is built as an app
# bundle, <name>.app, because a bare executable has no bundle identifier and
# anything that picks an application by one — OBS's application capture, a
# ScreenCaptureKit filter, TCC — then cannot pick the bridge at all. An
# Info.plist embedded in the executable's __info_plist section is not enough:
# LaunchServices reports a bundle identifier only for a bundle on disk. An
# embedder sets this beside the name.
set(CLOCKWORK_PLUGIN_BRIDGE_BUNDLE_ID "org.clockwork.plugin-bridge" CACHE STRING
    "Bundle identifier of the plugin-bridge app bundle (macOS)")

# ─── Release debug symbols ───────────────────────────────────────────────────
if(MSVC)
    add_compile_options("$<$<CONFIG:Release>:/Z7>")
    add_link_options("$<$<CONFIG:Release>:/DEBUG;/OPT:REF;/OPT:ICF>")
else()
    add_compile_options("$<$<CONFIG:Release>:-g>")
endif()

# ─── IEEE single precision where float evaluates wider ───────────────────────
# 32-bit x86 defaults to -mfpmath=387, so float expressions evaluate in 80-bit
# x87 registers and round to 32 bits only when the compiler happens to spill —
# making the same arithmetic give different answers at different block sizes.
# The target is identified by FLT_EVAL_METHOD, the standard's own signal, not
# by processor name (the 32-bit build runs in a linux/386 container on an
# x86_64 kernel, so CMAKE_SYSTEM_PROCESSOR reads x86_64 while cc is i686).
if(NOT MSVC)
    include(CheckCXXSourceCompiles)
    check_cxx_source_compiles("
#include <cfloat>
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD == 0
#error float expressions already evaluate as float
#endif
int main() { return 0; }
" CLOCKWORK_FLOAT_EVALUATES_WIDER)
    if(CLOCKWORK_FLOAT_EVALUATES_WIDER)
        include(CheckCXXCompilerFlag)
        check_cxx_compiler_flag("-fexcess-precision=standard" CLOCKWORK_HAS_EXCESS_PRECISION)
        if(CLOCKWORK_HAS_EXCESS_PRECISION)
            set(CLOCKWORK_FLOAT_FLAGS -fexcess-precision=standard)
        else()
            set(CLOCKWORK_FLOAT_FLAGS -ffloat-store)
        endif()
        # For this tree, here; for whoever links clockwork, as a PUBLIC option
        # on the library targets below. An embedder's host and tests make the
        # same exactness claims against the same arithmetic, and
        # add_compile_options stops at this directory: without the PUBLIC
        # option an embedder's i386 targets compile wide and fail on values
        # that print identically on both sides of the ==.
        add_compile_options(${CLOCKWORK_FLOAT_FLAGS})
    endif()
endif()

include(FetchContent)
# FetchContent deps are private build details: keep them out of the install
# manifest. The keyword reached FetchContent_Declare in CMake 3.28.
set(_ss_fc_exclude "")
if(CMAKE_VERSION VERSION_GREATER_EQUAL 3.28)
    set(_ss_fc_exclude EXCLUDE_FROM_ALL)
endif()

# ─── Position-independent code, for the NIF ──────────────────────────────────
# A NIF is a shared object the BEAM dlopens, and on Linux a shared object
# cannot swallow a static archive built without -fPIC. The audio path makes it
# strict rather than advisable: `t_on_audio_thread` is a thread-local and its
# TLS relocation (R_X86_64_TPOFF32) has no non-PIC form in a .so at all, so
# the link fails outright instead of degrading.
#
# Here, not beside the NIF target below: this variable initialises a target's
# POSITION_INDEPENDENT_CODE as the target is created, so setting it after
# add_library(clockwork) reaches nothing already defined. macOS's relocation
# model is indifferent, so only a Linux nif build fails without it.
if(CLOCKWORK_NIF OR CLOCKWORK_PLUGIN_MODULES)
    set(CMAKE_POSITION_INDEPENDENT_CODE ON)
endif()

# ─── Smoothie: the audio device layer ───────────────────────────────────
# The vendored ISC fork of the four permissive JUCE 7.0.12 modules. JUCE >= 8
# is AGPL; vendoring also removes any way for a distro build to bind a system
# JUCE 8+ by accident. See smoothie/README.md.
# ── What the device layer is required for ────────────────────────────────────
# Refused rather than worked around: each of these IS a device host, so a build
# that asks for one without a device layer is asking for something that cannot
# link. Saying so here beats an undefined symbol several minutes later.
if(NOT CLOCKWORK_DEVICE)
    foreach(_needs_device CLOCKWORK_NIF CLOCKWORK_PLUGINS)
        if(${_needs_device})
            message(FATAL_ERROR
                "${_needs_device}=ON needs CLOCKWORK_DEVICE=ON: it drives an audio "
                "device (or, for CLOCKWORK_PLUGINS, the track lanes that feed one). "
                "Build the substrate with -D${_needs_device}=OFF, or keep the "
                "device layer.")
        endif()
    endforeach()
endif()

if(CLOCKWORK_DEVICE)
    add_subdirectory(smoothie)
endif()

# ─── Ableton Link (opt-in, GPL) ──────────────────────────────────────────────
if(CLOCKWORK_LINK)
    # The pin, the patches and the Ableton::Link target, shared with the fuzz
    # build (test/fuzz) so they are stated once.
    include(${CMAKE_CURRENT_LIST_DIR}/external/fetch-link.cmake)
    clockwork_fetch_link()
else()
    message(STATUS "Ableton Link disabled — ClockworkClock uses its local-state backing")
endif()

# ─── Paths ───────────────────────────────────────────────────────────────────
# CURRENT, not CMAKE_SOURCE_DIR. When clockwork is embedded as a
# subdirectory, CMAKE_SOURCE_DIR is the EMBEDDER's root and every path built
# from it points into the wrong repository.
set(CLOCKWORK_SRC "${CMAKE_CURRENT_SOURCE_DIR}/src")
set(NATIVE_SRC  "${CMAKE_CURRENT_SOURCE_DIR}/src/native")
set(WORKERS_SRC "${CMAKE_CURRENT_SOURCE_DIR}/src/workers")
set(CLOCKWORK_RUST_DIR "${CMAKE_CURRENT_SOURCE_DIR}/rust")

# ─── Include directories + compile definitions ───────────────────────────────
#
# Both lists are CACHE INTERNAL because they are part of clockwork's contract with an
# embedder — see "The compile profile" below — and a consumer may be a sibling
# directory rather than a child, which PARENT_SCOPE does not reach.
#
# libsamplerate's header is on it with Link: the Link Audio renderer includes
# it, and LinkAudioBridge.h, which an embedder includes, includes the renderer.
set(CLOCKWORK_SAMPLERATE_INCLUDE_DIR)
if(CLOCKWORK_LINK AND NOT CLOCKWORK_SYSTEM_SAMPLERATE)
    set(CLOCKWORK_SAMPLERATE_INCLUDE_DIR ${CLOCKWORK_SRC}/vendor/libsamplerate/include)
endif()
set(CLOCKWORK_INCLUDE_DIRS
    ${NATIVE_SRC}/NativeShim   # first: shims emscripten/ on native builds
    ${NATIVE_SRC}
    ${WORKERS_SRC}
    ${CLOCKWORK_SRC}
    ${CMAKE_CURRENT_SOURCE_DIR}
    ${CLOCKWORK_SRC}/vendor/oscpack
    ${CLOCKWORK_SAMPLERATE_INCLUDE_DIR}
    CACHE INTERNAL "Include directories clockwork's sources need")

# Event-sink size classes, "<cell bytes>:<cells>,..." per kind. Empty means
# memory_profile.h's default for the selected device profile.
set(CLOCKWORK_OSC_SINK_CLASSES "" CACHE STRING
    "Outbound OSC sink classes, \"<cell bytes>:<cells>,...\" (empty = memory_profile.h)")
set(CLOCKWORK_MIDI_SINK_CLASSES "" CACHE STRING
    "MIDI sink classes, \"<cell bytes>:<cells>,...\" (empty = memory_profile.h)")
set(CLOCKWORK_SINK_CLASS_DEFS "")
if(CLOCKWORK_OSC_SINK_CLASSES)
    list(APPEND CLOCKWORK_SINK_CLASS_DEFS "CLOCKWORK_OSC_SINK_CLASSES=\"${CLOCKWORK_OSC_SINK_CLASSES}\"")
endif()
if(CLOCKWORK_MIDI_SINK_CLASSES)
    list(APPEND CLOCKWORK_SINK_CLASS_DEFS "CLOCKWORK_MIDI_SINK_CLASSES=\"${CLOCKWORK_MIDI_SINK_CLASSES}\"")
endif()

# ── The timed-event store's size ─────────────────────────────────────────────
# Pending events and the payload pool they carry. The native defaults are the
# process's; a worklet's live in a static arena inside the wasm module's own
# gap before the guest region, so a web build sizes them for that. A product
# sets its own (SuperSonic: 2048 slots, 512 KB). Whether a late event plays
# is the host's to say at run time (clockwork_set_timed_event_late_limit_ms).
if(EMSCRIPTEN)
    set(CLOCKWORK_SCHEDULER_SLOT_COUNT 8192 CACHE STRING "Timed events the scheduler can hold")
    set(CLOCKWORK_SCHEDULER_DATA_POOL_SIZE 4194304 CACHE STRING "Bytes of queued OSC payload the scheduler can hold")
    set(CLOCKWORK_IN_RING_SIZE 1048576 CACHE STRING "The OSC IN ring, bytes")
else()
    set(CLOCKWORK_SCHEDULER_SLOT_COUNT 512 CACHE STRING "Timed events the scheduler can hold")
    set(CLOCKWORK_SCHEDULER_DATA_POOL_SIZE 524288 CACHE STRING "Bytes of queued OSC payload the scheduler can hold")
endif()

# ── What the web module is compiled with, beyond the shared definitions ──────
# Build-time and runtime memory come from ONE file: js/memory_layout.js is
# what the worklet allocates against, and reading it here is what stops the
# module and its heap disagreeing about how big the heap is.
set(CLOCKWORK_WEB_COMPILE_DEFS "")
if(EMSCRIPTEN)
    find_program(NODE_EXECUTABLE NAMES node nodejs)
    if(NOT NODE_EXECUTABLE AND DEFINED ENV{EMSDK})
        file(GLOB _emsdk_node "$ENV{EMSDK}/node/*/bin/node")
        if(_emsdk_node)
            list(GET _emsdk_node 0 NODE_EXECUTABLE)
        endif()
    endif()
    if(NOT NODE_EXECUTABLE)
        message(FATAL_ERROR "node is needed to read js/memory_layout.js for the web build")
    endif()
    foreach(_which initial max arena)
        execute_process(COMMAND ${NODE_EXECUTABLE} "${CMAKE_CURRENT_SOURCE_DIR}/scripts/get_memory_config.js" ${_which}
                        OUTPUT_VARIABLE _mem_${_which} OUTPUT_STRIP_TRAILING_WHITESPACE
                        RESULT_VARIABLE _mem_rc)
        if(NOT _mem_rc EQUAL 0)
            message(FATAL_ERROR "scripts/get_memory_config.js ${_which} failed")
        endif()
    endforeach()
    set(CLOCKWORK_WEB_INITIAL_MEMORY ${_mem_initial})
    set(CLOCKWORK_WEB_MAX_MEMORY     ${_mem_max})
    set(CLOCKWORK_WEB_MEM_ARENA_SIZE ${_mem_arena})
    math(EXPR _mb_initial "${_mem_initial} / 1048576")
    math(EXPR _mb_max     "${_mem_max} / 1048576")
    math(EXPR _mb_arena   "${_mem_arena} / 1048576")
    message(STATUS "web memory: ${_mb_initial}MB initial, ${_mb_max}MB ceiling, ${_mb_arena}MB arena")
    # Stand between the program and its allocator (src/guest_malloc.h):
    # wasm-ld routes every malloc, calloc, realloc and free through
    # clockwork's wrappers, which count the ones made inside a guest entry
    # point. Costs a compare per call; changes what no allocation does.
    option(CLOCKWORK_WEB_COUNT_GUEST_MALLOC "Count the guest's mallocs (-Wl,--wrap=malloc)" ON)
    set(CLOCKWORK_WEB_COMPILE_DEFS
        CLOCKWORK_WORKLET_CLOCK=1
        CLOCKWORK_COUNT_GUEST_MALLOC=$<IF:$<BOOL:${CLOCKWORK_WEB_COUNT_GUEST_MALLOC}>,1,0>
        CLOCKWORK_AUDIO_NO_STDIO=1
        CLOCKWORK_IN_RING_SIZE=${CLOCKWORK_IN_RING_SIZE}
        CLOCKWORK_MEM_ARENA_SIZE=${CLOCKWORK_WEB_MEM_ARENA_SIZE}u)
    # Every translation unit of the module — clockwork's, the DSP's, the C
    # under both — shares one heap with JavaScript and one set of codegen
    # flags. Directory-wide, so the DSP added below gets them too.
    add_compile_options(
        -pthread -msimd128 -fwasm-exceptions
        -fno-math-errno -fsigned-zeros -fno-associative-math
        -Wno-nontrivial-memcall -Wno-extern-c-compat
        $<$<CONFIG:Release>:-O3>
        $<$<CONFIG:Release>:-flto>)
    add_link_options(-pthread -fwasm-exceptions $<$<CONFIG:Release>:-O3> $<$<CONFIG:Release>:-flto>)
endif()

set(CLOCKWORK_COMPILE_DEFS
    CLOCKWORK_PRODUCT_NAME="${CLOCKWORK_PRODUCT_NAME}"
    $<$<BOOL:${CLOCKWORK_PRODUCT_VERSION}>:CLOCKWORK_PRODUCT_VERSION="${CLOCKWORK_PRODUCT_VERSION}">
    CLOCKWORK_COMMIT="${CLOCKWORK_COMMIT}"
    CLOCKWORK_COMMIT_WORD=${CLOCKWORK_COMMIT_WORD}u
    $<$<BOOL:${CLOCKWORK_PRODUCT_HEADER}>:CLOCKWORK_PRODUCT_HEADER="${CLOCKWORK_PRODUCT_HEADER}">
    NDEBUG=1
    NOMINMAX=1
    $<$<PLATFORM_ID:Windows>:WIN32_LEAN_AND_MEAN=1>
    # The Windows version clockwork targets. Stated, because otherwise a
    # dependency states it: asio — vendored inside Ableton Link, and reached
    # from HeadlessDriver.cpp once CLOCKWORK_LINK_AUDIO is on — defines
    # _WIN32_WINNT as Windows 7 when nothing else has. Windows 7 hides the
    # high-resolution waitable timer that driver asks for, so a Windows Link
    # Audio build fails.
    $<$<PLATFORM_ID:Windows>:_WIN32_WINNT=0x0A00>

    # The audio path is compiled in. This flag does not mean "the DSP itself":
    # it gates clockwork's engine lifecycle, per-block render and audio route
    # — all of which clockwork owns and drives through dsp_api.h. What
    # actually makes sound behind that call is the DSP's, and is not in this
    # repository either way.
    CLOCKWORK_SYNTH=1

    # Whether the native device layer is present. Published because a consumer
    # has to know: without it there is no ClockworkEngine to construct and no
    # device to open, and the host owns its own audio callback.
    CLOCKWORK_DEVICE=$<IF:$<BOOL:${CLOCKWORK_DEVICE}>,1,0>

    # Clockwork's timed queue: present, or not built at all. Every site that
    # parks, fires, flushes or counts a scheduled event is behind this.
    CLOCKWORK_SCHEDULER=$<IF:$<BOOL:${CLOCKWORK_SCHEDULER}>,1,0>

    # The client half of the verb surface: answered, or refused by name. The
    # list itself is clockwork_sys_is_client_verb() in src/clockwork_sys.h.
    CLOCKWORK_CLIENT_VERBS=$<IF:$<BOOL:${CLOCKWORK_CLIENT_VERBS}>,1,0>

    SCHEDULER_DATA_POOL_SIZE=${CLOCKWORK_SCHEDULER_DATA_POOL_SIZE}
    SCHEDULER_SLOT_COUNT=${CLOCKWORK_SCHEDULER_SLOT_COUNT}
    # What the web module is compiled with beyond the shared definitions
    # (empty natively): the worklet clock, no stdio, its rings and arena.
    ${CLOCKWORK_WEB_COMPILE_DEFS}

    # The sink size classes, when a build overrides memory_profile.h's.
    ${CLOCKWORK_SINK_CLASS_DEFS}

    # Per-slot shm_audio_buffer ring duration, in seconds. Every TU that
    # includes shm_audio_buffer.hpp must agree, hence a global rather than a
    # per-target definition; test builds carry more so capture assertions have
    # samples to work with.
    CLOCKWORK_SCOPE_SECONDS=$<IF:$<BOOL:${BUILD_TESTS}>,10,1>
    CACHE INTERNAL "Compile definitions a header-only consumer must match")

# ─── Host sources ────────────────────────────────────────────────────────────
# The core: the ingress/egress lanes, the block driver, the heap, the taps
# planes and the region arithmetic.
# CACHE INTERNAL, like the include directories and compile definitions above:
# a freestanding or embedded target compiles clockwork with its OWN defines — no
# device layer, no JUCE, a different memory profile — so a prebuilt libtau.a is
# no use to it and it needs the sources, and it is a parent project, which a
# plain variable set here never reaches.
set(CLOCKWORK_CORE_SOURCES
    ${CLOCKWORK_SRC}/audio_processor.cpp
    # The client boundary (src/clockwork_client.h). In the core library rather
    # than beside a consumer: the engine's own transports call it to deliver a
    # remote peer's traffic, so it is not optional and there is no second copy.
    ${CLOCKWORK_SRC}/clockwork_client.cpp
    ${CLOCKWORK_SRC}/clockwork_asset_pool.cpp
    # An engine in your process (src/clockwork_embed.h): attach and render
    # here; the device boot is in the device layer below.
    ${CLOCKWORK_SRC}/embed/clockwork_embed.cpp
    ${CLOCKWORK_SRC}/lanes/lanes.cpp
    # A core's C++ state (src/core_state.h): what one engine holds.
    ${CLOCKWORK_SRC}/core_state.cpp
    # A word a thread blocks on until it changes, with a deadline: every wait
    # for another thread's work (src/workers/wait_word.h).
    ${WORKERS_SRC}/wait_word.cpp
    # A name for each long-lived thread, as debuggers and profilers show it.
    ${WORKERS_SRC}/thread_name.cpp
    # What the guest takes from malloc, counted (src/guest_malloc.h). The
    # wrappers inside it link only where the link can wrap (the web).
    ${CLOCKWORK_SRC}/guest_malloc.cpp
    # The arena the guest may not touch, poisoned while it runs: AddressSanitizer
    # builds, armed by a single-threaded harness (src/guest_fence.h).
    ${CLOCKWORK_SRC}/guest_fence.cpp
    ${CLOCKWORK_SRC}/mem_region.cpp
    ${CLOCKWORK_SRC}/engine_support.cpp
    # MIDI clock out is ClockworkClock's: 24 ticks a beat, each carrying its own
    # time to its sink. Nothing to do with the timed queue, so not gated on it.
    ${CLOCKWORK_SRC}/clock/MidiClockOut.cpp
    CACHE INTERNAL "Clockwork's device-independent sources, for freestanding/embedded builds")

# The audio backend and its control surfaces.
# What a host needs whether or not it owns a device: the egress dispatcher and
# the ring reader. Neither mentions JUCE or ClockworkEngine.
set(CLOCKWORK_NATIVE_SOURCES
    ${NATIVE_SRC}/OscEgress.cpp
    ${WORKERS_SRC}/RingReader.cpp
    # A core's memory straight from the system, zeroed by giving pages back
    # (src/os_pages.h).
    ${CLOCKWORK_SRC}/os_pages.cpp)
if(EMSCRIPTEN)
    # A worklet has no egress thread and no ring reader of its own: the
    # JavaScript workers are those. The lanes' asset pool and the embed API
    # are client-side C for a native host.
    set(CLOCKWORK_NATIVE_SOURCES)
    list(REMOVE_ITEM CLOCKWORK_CORE_SOURCES
        ${CLOCKWORK_SRC}/clockwork_asset_pool.cpp
        ${CLOCKWORK_SRC}/embed/clockwork_embed.cpp)
endif()

# The device layer: everything that opens, drives, watches, recovers or records
# an audio device. All of it needs smoothie, and none of it means anything to a
# host that was handed a callback. See CLOCKWORK_DEVICE.
if(CLOCKWORK_DEVICE)
    list(APPEND CLOCKWORK_NATIVE_SOURCES
        ${NATIVE_SRC}/HeadlessDriver.cpp
        ${NATIVE_SRC}/ClockworkProcessor.cpp
        ${NATIVE_SRC}/RealtimeThread.cpp
        ${NATIVE_SRC}/EngineControl.cpp
        ${NATIVE_SRC}/ClockworkEngine.cpp
        ${NATIVE_SRC}/ClockworkEmbedDevice.cpp
        ${NATIVE_SRC}/DevicePolicy.cpp
        ${NATIVE_SRC}/AsioDriverCheck.cpp
        ${NATIVE_SRC}/DeviceLaneApartment.cpp
        ${NATIVE_SRC}/AudioRecovery.cpp)
endif()
if(APPLE)
    list(APPEND CLOCKWORK_NATIVE_SOURCES ${NATIVE_SRC}/MicPermission.mm)
endif()
if(APPLE AND NOT CMAKE_SYSTEM_NAME STREQUAL "iOS")
    # Dispatches AppKit input to any window this process owns. Belongs to
    # clockwork rather than to the plugin library: it is about this process
    # having windows at all, not about what is drawn in them. macOS only:
    # iOS has no AppKit, and a UIKit app's events are UIApplicationMain's.
    list(APPEND CLOCKWORK_NATIVE_SOURCES ${NATIVE_SRC}/CocoaEventPump.mm)
endif()

# ClockworkClock is the one composition root on every native cell: the audio-thread
# time source (WallClock + IIR) through TimeSource, the MIDI follower-timeline
# registry through MidiTimelines, and — only when Link is on — the Link session.
# The audio half of Link is the engine's LinkAudioHost beside the clock, over
# the Link-Audio bus bridge. With Link off, LinkSession.h supplies the
# session-of-one and LinkAudioBridge.h the no-op bridge, both header-inline, so
# those two TUs are dropped rather than compiled empty.
set(CLOCKWORK_CLOCK_SOURCES
    ${CLOCKWORK_SRC}/clock/ClockworkClock.cpp
    ${CLOCKWORK_SRC}/clock/EngineClock.cpp
    ${CLOCKWORK_SRC}/clock/ClockworkClockNative.cpp
    ${CLOCKWORK_SRC}/clock/TimeSource.cpp
    ${CLOCKWORK_SRC}/clock/MidiTimelines.cpp)
if(NOT EMSCRIPTEN)
    list(APPEND CLOCKWORK_CLOCK_SOURCES ${NATIVE_SRC}/LinkAudioHost.cpp)
endif()
if(CLOCKWORK_LINK)
    list(APPEND CLOCKWORK_CLOCK_SOURCES
        ${CLOCKWORK_SRC}/clock/LinkSession.cpp
        ${NATIVE_SRC}/LinkAudioBridge.cpp)
endif()

# libsamplerate (BSD-2-Clause, src/vendor/libsamplerate), which the Link Audio
# renderer reads a peer's stream through: the medium sinc converter alone, and
# no config.h (see CLOCKWORK.md there).
set(CLOCKWORK_SAMPLERATE_SOURCES)
if(CLOCKWORK_LINK AND CLOCKWORK_SYSTEM_SAMPLERATE)
    find_package(PkgConfig REQUIRED)
    pkg_check_modules(SAMPLERATE REQUIRED IMPORTED_TARGET samplerate)
    message(STATUS "clockwork: system libsamplerate ${SAMPLERATE_VERSION} (CLOCKWORK_SYSTEM_SAMPLERATE)")
elseif(CLOCKWORK_LINK)
    set(CLOCKWORK_SAMPLERATE_SOURCES
        ${CLOCKWORK_SRC}/vendor/libsamplerate/src/samplerate.c
        ${CLOCKWORK_SRC}/vendor/libsamplerate/src/src_sinc.c
        ${CLOCKWORK_SRC}/vendor/libsamplerate/src/src_linear.c
        ${CLOCKWORK_SRC}/vendor/libsamplerate/src/src_zoh.c)
    set_source_files_properties(${CLOCKWORK_SAMPLERATE_SOURCES} PROPERTIES
        COMPILE_DEFINITIONS "ENABLE_SINC_MEDIUM_CONVERTER;HAVE_STDBOOL_H;PACKAGE=\"libsamplerate\";VERSION=\"0.2.2\"")
endif()

# Audio file reading and writing (src/clockwork_audio_file.h). The decoders
# are Rust (rust/clockwork-audio-decode, in the umbrella staticlib); the file
# reading, the writers and the FLAC encoder are here.
set(CLOCKWORK_AUDIO_FILE_SOURCES
    ${CLOCKWORK_SRC}/clockwork_audio_file.cpp
    ${CLOCKWORK_SRC}/flac_encoder.cpp)

# oscpack (MIT, Ross Bencina) — src/vendor/oscpack.
set(OSCPACK_SOURCES
    ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscTypes.cpp
    ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscOutboundPacketStream.cpp
    ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscReceivedElements.cpp)

add_library(clockwork STATIC
    ${CLOCKWORK_CORE_SOURCES}
    ${CLOCKWORK_NATIVE_SOURCES}
    ${CLOCKWORK_CLOCK_SOURCES}
    ${CLOCKWORK_AUDIO_FILE_SOURCES}
    ${CLOCKWORK_SAMPLERATE_SOURCES}
    ${OSCPACK_SOURCES})

target_include_directories(clockwork PUBLIC ${CLOCKWORK_INCLUDE_DIRS})
if(CLOCKWORK_FLOAT_FLAGS)
    target_compile_options(clockwork PUBLIC ${CLOCKWORK_FLOAT_FLAGS})
endif()
if(CLOCKWORK_LINK AND CLOCKWORK_SYSTEM_SAMPLERATE)
    target_link_libraries(clockwork PUBLIC PkgConfig::SAMPLERATE)
endif()
target_compile_definitions(clockwork PUBLIC ${CLOCKWORK_COMPILE_DEFS})

# ─── The compile profile, as part of clockwork's interface ─────────────────────────
#
# Anything that addresses shm regions by compile-time constant must be built
# with the SAME profile as clockwork, or server_shm's layout guard rejects it at
# attach. Linking clockwork carries that automatically — but a consumer that is
# header-only BY DESIGN (an out-of-process peer, a layout dumper) never links
# it and cannot inherit PUBLIC defs. That is why CLOCKWORK_COMPILE_DEFS above is a
# CACHE INTERNAL variable and not a local list: it is part of clockwork's contract,
# beside CLOCKWORK_DSP and CLOCKWORK_RUST_WORKSPACE, and a consumer may be a sibling
# directory rather than a child, which PARENT_SCOPE does not reach.
#
# Exported under one name because CMake expands an unset variable to nothing
# without complaint: a consumer that guessed the list wrong would build with
# no profile at all and every layout constant at its default.

# C++20 as a USAGE REQUIREMENT, not just a directory variable. CMAKE_CXX_STANDARD
# above applies to this directory and stops at the submodule boundary, so an
# embedder's own targets would otherwise compile as C++17 and fail on what
# clockwork's headers use (std::atomic::notify_all, for one). Anything linking
# clockwork gets the standard with it.
target_compile_features(clockwork PUBLIC cxx_std_20)

if(CLOCKWORK_DEVICE)
    target_link_libraries(clockwork PUBLIC smoothie)
endif()

if(WIN32 AND CLOCKWORK_ASIO)
    # JUCE's juce_ASIO_windows.cpp includes the SDK headers when JUCE_ASIO=1.
    # ASIOSDK_DIR points at another copy's common/ directory; default is the
    # vendored one.
    if(NOT ASIOSDK_DIR)
        set(ASIOSDK_DIR "${CMAKE_CURRENT_SOURCE_DIR}/external/ASIOSDK2.3.4/common")
    endif()
    target_compile_definitions(smoothie PUBLIC JUCE_ASIO=1)
    target_include_directories(smoothie PUBLIC "${ASIOSDK_DIR}")
    message(STATUS "ASIO enabled (JUCE_ASIO=1, Steinberg SDK under GPLv3, ${ASIOSDK_DIR})")
endif()

# A shared module exports the entry points named and nothing else: everything
# else is hidden by the compiler and, for what the static libraries bring, by
# the linker. A host's dynamic linker can then bind nothing of the host's to
# this module's symbols, nor this module's calls to the host's: BEAM exports
# abs_1, floor_1 and more, the names of scsynth's unary operators, and a NIF
# exporting those too had the engine call BEAM's (supersonic #8).
# scripts/check-exports.sh holds a built module to this.
function(clockwork_exports_only target)
    cmake_parse_arguments(EO "" "" "ENTRY" ${ARGN})
    if(NOT EO_ENTRY)
        message(FATAL_ERROR "clockwork_exports_only(${target}) names no ENTRY")
    endif()
    set_target_properties(${target} PROPERTIES
        C_VISIBILITY_PRESET hidden
        CXX_VISIBILITY_PRESET hidden
        VISIBILITY_INLINES_HIDDEN ON)
    set(_list ${CMAKE_CURRENT_BINARY_DIR}/${target}-exports)
    if(APPLE)
        # Mach-O names carry a leading underscore.
        list(TRANSFORM EO_ENTRY PREPEND "_" OUTPUT_VARIABLE _names)
        string(JOIN "\n" _text ${_names})
        file(WRITE ${_list}.txt "${_text}\n")
        target_link_options(${target} PRIVATE "LINKER:-exported_symbols_list,${_list}.txt")
    elseif(WIN32)
        # A DLL exports what is marked for export; the .def names exactly
        # the entry points.
        string(JOIN "\n    " _text ${EO_ENTRY})
        file(WRITE ${_list}.def "EXPORTS\n    ${_text}\n")
        target_sources(${target} PRIVATE ${_list}.def)
    else()
        string(JOIN "; " _text ${EO_ENTRY})
        file(WRITE ${_list}.map "{\n  global: ${_text};\n  local: *;\n};\n")
        target_link_options(${target} PRIVATE
            "LINKER:--version-script=${_list}.map"
            "LINKER:--exclude-libs,ALL")
    endif()
endfunction()

if(CLOCKWORK_NIF)
    # (CMAKE_POSITION_INDEPENDENT_CODE is set far above, before the first
    # add_library — see there for why it cannot live here.)

    set(_clockwork_erl_headers ${CMAKE_CURRENT_SOURCE_DIR}/external/erlang_headers)
    include(CheckTypeSize)
    check_type_size("char"      SIZEOF_CHAR      BUILTIN_TYPES_ONLY LANGUAGE C)
    check_type_size("short"     SIZEOF_SHORT     BUILTIN_TYPES_ONLY LANGUAGE C)
    check_type_size("int"       SIZEOF_INT       BUILTIN_TYPES_ONLY LANGUAGE C)
    check_type_size("long"      SIZEOF_LONG      BUILTIN_TYPES_ONLY LANGUAGE C)
    check_type_size("long long" SIZEOF_LONG_LONG BUILTIN_TYPES_ONLY LANGUAGE C)
    configure_file(
        ${_clockwork_erl_headers}/erl_int_sizes_config.h.in
        ${CMAKE_CURRENT_BINARY_DIR}/erlang_generated/erl_int_sizes_config.h)

    add_library(clockwork_nif SHARED ${NATIVE_SRC}/../nif/clockwork_nif.cpp)
    if(NOT CLOCKWORK_NIF_FRONT)
        target_sources(clockwork_nif PRIVATE ${NATIVE_SRC}/../nif/clockwork_nif_no_front.cpp)
    endif()
    set_target_properties(clockwork_nif PROPERTIES
        PREFIX ""
        # clockwork.erl resolves the library by this name; see load_nif there.
        OUTPUT_NAME "clockwork"
        # ...but ONLY the runtime artefact. On Windows a SHARED target also
        # emits an import library, and OUTPUT_NAME would name that clockwork.lib
        # too — the exact path the static `clockwork` target already writes.
        # link.exe refuses that outright: "LNK1149: output filename matches
        # input filename". The .dll does not collide (it is redirected to the
        # build root below); the .lib would. Unix has no import library, so
        # this is inert there.
        ARCHIVE_OUTPUT_NAME "clockwork_nif"
        # The build root on every platform and configuration, not Release/ or
        # Debug/, so erlang:load_nif finds it at one path.
        LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}"
        RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}"
        LIBRARY_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}"
        RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}"
        LIBRARY_OUTPUT_DIRECTORY_DEBUG "${CMAKE_BINARY_DIR}"
        RUNTIME_OUTPUT_DIRECTORY_DEBUG "${CMAKE_BINARY_DIR}")
    target_include_directories(clockwork_nif PRIVATE
        ${CMAKE_CURRENT_BINARY_DIR}/erlang_generated
        ${_clockwork_erl_headers}
        ${NATIVE_SRC}/../nif)
    target_link_libraries(clockwork_nif PRIVATE
        clockwork_comms
        clockwork_bundle)
    # ERL_NIF_INIT defines nif_init, the one symbol erlang:load_nif looks up.
    clockwork_exports_only(clockwork_nif ENTRY nif_init)

    if(APPLE)
        # load_nif wants .so on every Unix, not .dylib; and the BEAM's own
        # symbols are resolved at dlopen time, not at link time.
        set_target_properties(clockwork_nif PROPERTIES
            SUFFIX ".so"
            LINK_FLAGS "-undefined dynamic_lookup")
    elseif(UNIX)
        set_target_properties(clockwork_nif PROPERTIES SUFFIX ".so")
    endif()
    message(STATUS "BEAM NIF: enabled (clockwork.so)")
endif()

if(CLOCKWORK_LINK)
    target_link_libraries(clockwork PUBLIC Ableton::Link)
    target_compile_definitions(clockwork PUBLIC CLOCKWORK_LINK=1)
    # The audio half is opt-in on top. Tempo, transport and peers work with
    # CLOCKWORK_LINK alone.
    if(CLOCKWORK_LINK_AUDIO)
        target_compile_definitions(clockwork PUBLIC CLOCKWORK_WITH_LINK_AUDIO=1)
    endif()
    if(WIN32)
        # Link's Windows ThreadPriority uses the Multimedia Class Scheduler.
        target_link_libraries(clockwork PUBLIC avrt)
    endif()
endif()

if(WIN32)
    # Synchronization: WaitOnAddress, the address wait under wait_word.cpp.
    target_link_libraries(clockwork PUBLIC Ws2_32 winmm ole32 Synchronization)
elseif(APPLE AND CMAKE_SYSTEM_NAME STREQUAL "iOS")
    # iOS's AudioUnit.framework is headers only: the calls are AudioToolbox's.
    target_link_libraries(clockwork PUBLIC
        "-framework CoreAudio" "-framework AudioToolbox" "-framework Foundation"
        "-framework CoreFoundation" "-framework AVFoundation")
elseif(APPLE)
    target_link_libraries(clockwork PUBLIC
        "-framework CoreAudio" "-framework AudioUnit" "-framework Foundation"
        "-framework CoreFoundation" "-framework AVFoundation")
elseif(UNIX)
    find_package(Threads REQUIRED)
    target_link_libraries(clockwork PUBLIC Threads::Threads rt ${CMAKE_DL_LIBS})
endif()

# The vendored libraries are system headers to this build: they warn as their
# authors left them and the analyzer leaves them be — they are not ours to fix.
target_include_directories(clockwork SYSTEM PRIVATE ${CLOCKWORK_SRC}/vendor)

if(MSVC)
    target_compile_options(clockwork PRIVATE
        /W1 /wd4244 /wd4267 /wd4305 /wd4800 /wd4996 /permissive-)
else()
    target_compile_options(clockwork PRIVATE
        -Wno-deprecated-declarations -Wno-unused-parameter
        -fno-math-errno -fsigned-zeros)
endif()

# ─── Rust subsystems ─────────────────────────────────────────────────────────
# MIDI, gamepad and OSC networking are Rust, folded by cargo into the single
# `clockwork-native` umbrella staticlib (a binary may link exactly one Rust
# staticlib — each carries its own copy of std). The C++ boundaries are
# src/native/{MidiControl,GamepadControl,OscControl}.cpp against the headers in
# each crate's cpp/ directory.
# A build that rebuilds std (-Z build-std) needs a nightly toolchain with the
# std sources: the web, whose std must carry atomics, and a sanitizer, whose
# std must be instrumented. The pin is a preference: a box with a floating
# `nightly` that has rust-src still builds, with a note. A toolchain that
# merely RESOLVES is not one that works — `rustup which` will install a bare
# dated toolchain — so only one that is listed AND carries the std sources is
# taken. Sets CARGO_EXECUTABLE and CLOCKWORK_RUSTC_EXECUTABLE for the caller;
# `why` names the build in the refusal, and any further arguments are lines
# of advice after it.
set(CLOCKWORK_RUST_NIGHTLY "nightly-2026-07-02" CACHE STRING
    "The nightly toolchain for a build that rebuilds std (the web, a sanitizer)")
function(clockwork_nightly_cargo why)
    find_program(RUSTUP_EXECUTABLE rustup REQUIRED)
    execute_process(COMMAND ${RUSTUP_EXECUTABLE} toolchain list
                    OUTPUT_VARIABLE _toolchains OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_QUIET)
    foreach(_tc IN ITEMS ${CLOCKWORK_RUST_NIGHTLY} nightly)
        if(NOT _toolchains MATCHES "(^|\n)${_tc}")
            continue()
        endif()
        execute_process(COMMAND ${RUSTUP_EXECUTABLE} which --toolchain ${_tc} rustc
                        OUTPUT_VARIABLE _rustc OUTPUT_STRIP_TRAILING_WHITESPACE RESULT_VARIABLE _rc ERROR_QUIET)
        if(NOT _rc EQUAL 0)
            continue()
        endif()
        get_filename_component(_rust_bin "${_rustc}" DIRECTORY)
        if(NOT EXISTS "${_rust_bin}/../lib/rustlib/src/rust/library/Cargo.lock")
            continue()
        endif()
        set(CARGO_EXECUTABLE "${_rust_bin}/cargo" PARENT_SCOPE)
        set(CLOCKWORK_RUSTC_EXECUTABLE "${_rustc}" PARENT_SCOPE)
        if(NOT _tc STREQUAL CLOCKWORK_RUST_NIGHTLY)
            message(STATUS "rust: ${CLOCKWORK_RUST_NIGHTLY} not installed, using ${_tc}")
        else()
            message(STATUS "rust: ${_tc}")
        endif()
        return()
    endforeach()
    string(JOIN "\n  " _advice "  rustup toolchain install ${CLOCKWORK_RUST_NIGHTLY} --component rust-src" ${ARGN})
    message(FATAL_ERROR
        "a nightly Rust toolchain with rust-src is required for ${why}:\n${_advice}")
endfunction()

if(CLOCKWORK_RUST AND EMSCRIPTEN)
    # The worklet shares its heap with JavaScript, so std must be rebuilt with
    # atomics and bulk memory.
    clockwork_nightly_cargo("the web build"
        "rustup target add wasm32-unknown-emscripten --toolchain ${CLOCKWORK_RUST_NIGHTLY}")
    target_compile_definitions(clockwork PRIVATE CLOCKWORK_RUST_LOG=1)
elseif(CLOCKWORK_RUST AND CMAKE_SYSTEM_NAME STREQUAL "iOS")
    # iOS is a cross build: rustc needs the target's std, which only a rustup
    # toolchain carries (a Homebrew rust has the host's alone and is often
    # first on PATH). So the toolchain is rustup's, named, and its rustc is
    # pinned through RUSTC below: a toolchain's cargo run by path, not through
    # the rustup proxy, would otherwise take whichever rustc PATH finds first.
    # The device and the simulator are different targets to rustc — the same
    # arm64, a different platform in every object's load commands.
    if(CMAKE_OSX_SYSROOT MATCHES "[Ss]imulator")
        if(CMAKE_OSX_ARCHITECTURES STREQUAL "x86_64")
            set(CLOCKWORK_RUST_TRIPLE x86_64-apple-ios)
        else()
            set(CLOCKWORK_RUST_TRIPLE aarch64-apple-ios-sim)
        endif()
    else()
        set(CLOCKWORK_RUST_TRIPLE aarch64-apple-ios)
    endif()
    if(CMAKE_OSX_ARCHITECTURES MATCHES ";")
        message(FATAL_ERROR "iOS: one architecture per build (CMAKE_OSX_ARCHITECTURES is ${CMAKE_OSX_ARCHITECTURES}); "
                            "a universal simulator archive is lipo's job, after")
    endif()
    set(CLOCKWORK_RUST_IOS_TOOLCHAIN "stable" CACHE STRING
        "The rustup toolchain that builds the Rust subsystems for iOS")
    find_program(RUSTUP_EXECUTABLE rustup REQUIRED)
    execute_process(COMMAND ${RUSTUP_EXECUTABLE} which --toolchain ${CLOCKWORK_RUST_IOS_TOOLCHAIN} rustc
                    OUTPUT_VARIABLE _rustc OUTPUT_STRIP_TRAILING_WHITESPACE RESULT_VARIABLE _rc ERROR_QUIET)
    if(_rc EQUAL 0)
        get_filename_component(_rust_bin "${_rustc}" DIRECTORY)
    endif()
    if(NOT _rc EQUAL 0 OR NOT EXISTS "${_rust_bin}/../lib/rustlib/${CLOCKWORK_RUST_TRIPLE}")
        message(FATAL_ERROR
            "iOS needs the ${CLOCKWORK_RUST_TRIPLE} std in the rustup toolchain '${CLOCKWORK_RUST_IOS_TOOLCHAIN}':\n"
            "  rustup target add ${CLOCKWORK_RUST_TRIPLE} --toolchain ${CLOCKWORK_RUST_IOS_TOOLCHAIN}")
    endif()
    set(CARGO_EXECUTABLE "${_rust_bin}/cargo")
    set(CLOCKWORK_RUSTC_EXECUTABLE "${_rustc}")
    message(STATUS "rust: ${CLOCKWORK_RUST_IOS_TOOLCHAIN} for ${CLOCKWORK_RUST_TRIPLE}")
    target_compile_definitions(clockwork PRIVATE CLOCKWORK_RUST_LOG=1)
elseif(CLOCKWORK_RUST)
    if(CLOCKWORK_SANITIZE MATCHES "thread")
        # ThreadSanitizer judges only what was built with it. The Rust
        # subsystems hold the core's gate and its wait words, so an ordering
        # they give two C++ threads reads as a race unless they are
        # instrumented too (-Zsanitizer, nightly only), on a std rebuilt the
        # same way.
        clockwork_nightly_cargo("ThreadSanitizer (the Rust subsystems and std are instrumented too)")
        execute_process(COMMAND ${CLOCKWORK_RUSTC_EXECUTABLE} -vV
                        OUTPUT_VARIABLE _rustc_v OUTPUT_STRIP_TRAILING_WHITESPACE)
        string(REGEX MATCH "host: ([^\n]+)" _ "${_rustc_v}")
        set(CLOCKWORK_RUST_TRIPLE ${CMAKE_MATCH_1})
        set(CLOCKWORK_RUST_SANITIZE thread)
    else()
        find_program(CARGO_EXECUTABLE cargo REQUIRED)
    endif()
    # The umbrella carries clockwork-log, so the engine can route the Rust
    # subsystems' lines onto its debug ring (ClockworkEngine::init). An
    # embedder that supplies the crates itself installs a sink from Rust.
    target_compile_definitions(clockwork PRIVATE CLOCKWORK_RUST_LOG=1)
else()
    # A binary linked here would need the umbrella; with CLOCKWORK_RUST=OFF
    # only the embedder's own cargo build supplies the Rust half, and only
    # to its own binary. Refused here, as the device layer's dependants are.
    foreach(_needs_rust CLOCKWORK_STANDALONE BUILD_TESTS CLOCKWORK_PLUGINS CLOCKWORK_NIF)
        if(${_needs_rust})
            message(FATAL_ERROR
                "${_needs_rust}=ON needs CLOCKWORK_RUST=ON: it links a binary in this "
                "tree, and a binary needs the Rust subsystems. Build the library alone "
                "with -D${_needs_rust}=OFF, or let this tree build the umbrella.")
        endif()
    endforeach()
endif()
if(CMAKE_BUILD_TYPE STREQUAL "Debug")
    set(CLOCKWORK_RUST_PROFILE debug)
    set(CLOCKWORK_RUST_CARGO_FLAGS)
else()
    set(CLOCKWORK_RUST_PROFILE release)
    set(CLOCKWORK_RUST_CARGO_FLAGS --release)
endif()
if(CLOCKWORK_CARGO_OFFLINE)
    list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --offline)
endif()
# --locked always: rust/Cargo.lock is committed and is the dependency set that
# was tested. A Cargo.toml edit that would change it fails here instead of
# rewriting the lockfile as a side effect of a C++ build, and a distro build
# gets the reproducibility it requires without asking for it.
list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --locked)

set(CLOCKWORK_RUST_FEATURES)
if(CLOCKWORK_MIDI)
    list(APPEND CLOCKWORK_RUST_FEATURES midi)
    # Windows takes midir's WinRT backend (full-length device names) plus the
    # WinRT DeviceWatcher for hot-swap; both live behind the `winrt` feature.
    if(WIN32)
        list(APPEND CLOCKWORK_RUST_FEATURES winrt)
    endif()
endif()
if(CLOCKWORK_GAMEPAD)
    list(APPEND CLOCKWORK_RUST_FEATURES gamepad)
endif()
if(CLOCKWORK_OSC)
    # `comms` carries the command-transport crate for the comms client library
    # (clockwork_comms below); the engine itself uses none of it.
    list(APPEND CLOCKWORK_RUST_FEATURES osc comms)
endif()
if(CLOCKWORK_SCHEDULER)
    list(APPEND CLOCKWORK_RUST_FEATURES schedule)
endif()
list(JOIN CLOCKWORK_RUST_FEATURES "," CLOCKWORK_RUST_FEATURES_ARG)
list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --no-default-features)
if(CLOCKWORK_RUST_FEATURES_ARG)
    list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --features ${CLOCKWORK_RUST_FEATURES_ARG})
endif()

# ── Which Rust staticlib ─────────────────────────────────────────────────────
#
# Exactly ONE Rust staticlib may be linked into a binary: each bundles its own
# copy of std, and two collide at link time. clockwork-native is the umbrella
# clockwork uses when it is the whole program.
#
# An embedder with Rust of its own therefore CANNOT link clockwork-native as well —
# it must build a single umbrella that depends on both clockwork's crates and
# its own, and point these three at it. This is why clockwork-native is "the umbrella
# clockwork uses standalone" rather than "the umbrella".
#
# The contract for a replacement, and the only thing clockwork assumes about
# it: it must accept the same feature names clockwork passes below (midi,
# gamepad, osc, schedule), forwarding each to the corresponding clockwork crate.
# Nothing here knows or cares what else it contains.
set(CLOCKWORK_RUST_WORKSPACE "${CLOCKWORK_RUST_DIR}" CACHE PATH
    "Cargo workspace holding the Rust umbrella to build")
set(CLOCKWORK_RUST_PACKAGE "clockwork-native" CACHE STRING
    "Cargo package name of the Rust umbrella")
set(CLOCKWORK_RUST_LIB_NAME "clockwork_native" CACHE STRING
    "Basename of the staticlib that package produces")

if(EMSCRIPTEN)
    set(CLOCKWORK_RUST_TARGET_DIR ${CLOCKWORK_RUST_WORKSPACE}/target/wasm32-unknown-emscripten/${CLOCKWORK_RUST_PROFILE})
    set(CLOCKWORK_RUST_CARGO_ENV ${CMAKE_COMMAND} -E env
        "RUSTFLAGS=-C target-feature=+atomics,+bulk-memory,+mutable-globals"
        "RUSTC=${CLOCKWORK_RUSTC_EXECUTABLE}")
    list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --target wasm32-unknown-emscripten -Z build-std=std,panic_abort)
elseif(CMAKE_SYSTEM_NAME STREQUAL "iOS")
    set(CLOCKWORK_RUST_TARGET_DIR ${CLOCKWORK_RUST_WORKSPACE}/target/${CLOCKWORK_RUST_TRIPLE}/${CLOCKWORK_RUST_PROFILE})
    # The floor, for the same reason as macOS's below; iOS reads its own
    # variable.
    set(CLOCKWORK_RUST_CARGO_ENV ${CMAKE_COMMAND} -E env
        "RUSTC=${CLOCKWORK_RUSTC_EXECUTABLE}"
        "IPHONEOS_DEPLOYMENT_TARGET=${CMAKE_OSX_DEPLOYMENT_TARGET}")
    list(APPEND CLOCKWORK_RUST_CARGO_FLAGS --target ${CLOCKWORK_RUST_TRIPLE})
else()
    set(CLOCKWORK_RUST_CARGO_ENV ${CMAKE_COMMAND} -E env)
    # The flags that pick the target, shared with the bridge's own build
    # below: none for a plain host build, which cargo places under target/
    # directly; the host triple and a rebuilt std for a sanitizer, which
    # cargo places under target/<triple>/ as it does any explicit target.
    set(CLOCKWORK_RUST_TARGET_FLAGS)
    if(CLOCKWORK_RUST_SANITIZE)
        set(CLOCKWORK_RUST_TARGET_DIR ${CLOCKWORK_RUST_WORKSPACE}/target/${CLOCKWORK_RUST_TRIPLE}/${CLOCKWORK_RUST_PROFILE})
        list(APPEND CLOCKWORK_RUST_CARGO_ENV
            "RUSTFLAGS=-Zsanitizer=${CLOCKWORK_RUST_SANITIZE}"
            "RUSTC=${CLOCKWORK_RUSTC_EXECUTABLE}")
        set(CLOCKWORK_RUST_TARGET_FLAGS --target ${CLOCKWORK_RUST_TRIPLE} -Z build-std)
    else()
        set(CLOCKWORK_RUST_TARGET_DIR ${CLOCKWORK_RUST_WORKSPACE}/target/${CLOCKWORK_RUST_PROFILE})
    endif()
    list(APPEND CLOCKWORK_RUST_CARGO_FLAGS ${CLOCKWORK_RUST_TARGET_FLAGS})
    if(APPLE AND CMAKE_OSX_DEPLOYMENT_TARGET)
        # rustc reads the deployment floor from the environment, as clang does
        # from the flag: without it the crates' objects carry the SDK's version,
        # and every link into a binary with a lower floor warns that the
        # archive "was built for newer macOS". This covers clockwork's own
        # crates; the standard library's objects are the toolchain's (a
        # Homebrew rust is built on the host's SDK and still warns for std —
        # a rustup toolchain's prebuilt std does not).
        list(APPEND CLOCKWORK_RUST_CARGO_ENV
            "MACOSX_DEPLOYMENT_TARGET=${CMAKE_OSX_DEPLOYMENT_TARGET}")
    endif()
endif()
set(CLOCKWORK_RUST_LIB
    ${CLOCKWORK_RUST_TARGET_DIR}/${CMAKE_STATIC_LIBRARY_PREFIX}${CLOCKWORK_RUST_LIB_NAME}${CMAKE_STATIC_LIBRARY_SUFFIX})

# cargo tracks incremental freshness itself, so run it every build.
if(CLOCKWORK_RUST)
    add_custom_target(clockwork_rust ALL
        BYPRODUCTS ${CLOCKWORK_RUST_LIB}
        COMMAND ${CLOCKWORK_RUST_CARGO_ENV} ${CARGO_EXECUTABLE} build ${CLOCKWORK_RUST_CARGO_FLAGS} -p ${CLOCKWORK_RUST_PACKAGE}
        WORKING_DIRECTORY ${CLOCKWORK_RUST_WORKSPACE}
        COMMENT "Building Rust subsystems (cargo: ${CLOCKWORK_RUST_PACKAGE})"
        VERBATIM)
    add_dependencies(clockwork clockwork_rust)
endif()

# The Rust archive and the C++ host reference each other — Rust's tap plane
# calls back into the C++ shm base, the C++ control surfaces call into Rust —
# and one left-to-right link pass cannot resolve that. State the cycle as a
# target dependency so CMake repeats the archives.
add_library(clockwork_rust_lib STATIC IMPORTED)
set_target_properties(clockwork_rust_lib PROPERTIES IMPORTED_LOCATION ${CLOCKWORK_RUST_LIB})
target_link_libraries(clockwork_rust_lib INTERFACE clockwork)
target_link_libraries(clockwork PUBLIC clockwork_rust_lib)

if(WIN32)
    # Rust std (windows-msvc) pulls these in; authoritative list from
    # `rustc --print native-static-libs`.
    target_link_libraries(clockwork PUBLIC ntdll userenv dbghelp)
endif()

# Per-subsystem boundaries + the OS libraries each Rust backend needs at final link
# (Rust staticlibs do not carry their link deps).
if(CLOCKWORK_MIDI)
    target_sources(clockwork PRIVATE ${NATIVE_SRC}/MidiControl.cpp)
    target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-midi/cpp)
    target_compile_definitions(clockwork PUBLIC CLOCKWORK_MIDI=1)
    if(APPLE)
        target_link_libraries(clockwork PUBLIC "-framework CoreMIDI")
    elseif(WIN32)
        target_link_libraries(clockwork PUBLIC ole32 oleaut32 runtimeobject)
    elseif(UNIX)
        target_link_libraries(clockwork PUBLIC asound)
    endif()
endif()
if(CLOCKWORK_GAMEPAD)
    target_sources(clockwork PRIVATE ${NATIVE_SRC}/GamepadControl.cpp)
    target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-gamepad/cpp)
    target_compile_definitions(clockwork PUBLIC CLOCKWORK_GAMEPAD=1)
    if(APPLE)
        # gilrs cannot see Apple-driven pads; src/gc.rs uses GameController.
        target_link_libraries(clockwork PUBLIC "-framework GameController" objc)
    elseif(UNIX AND NOT WIN32)
        target_link_libraries(clockwork PUBLIC udev)   # gilrs evdev hotplug
    endif()
endif()
if(CLOCKWORK_OSC)
    target_sources(clockwork PRIVATE ${NATIVE_SRC}/OscControl.cpp)
    target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-osc-net/cpp)
    target_compile_definitions(clockwork PUBLIC CLOCKWORK_OSC=1)
endif()

# The port substrate has no option and no boundary file. src/clockwork_ports.h
# is the contract and part of clockwork; audio_processor.cpp calls
# clockwork_port_read/clockwork_port_write directly, so there is
# nothing to switch off — with no port bound the two calls scan an empty table
# and return. Only the DISK endpoints' header needs an include path, because it
# ships with the crate that implements it, the way every other Rust subsystem's
# does.
target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-ports-disk/cpp)
target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-taps/cpp)
target_include_directories(clockwork PRIVATE ${CLOCKWORK_RUST_DIR}/clockwork-audio-decode/cpp)

# The timed-event store has no option and no boundary file either, for the same
# reason: src/scheduler/Scheduler.h and src/scheduler/schedule_parse.h are the
# contract and they live with clockwork, and what is behind them
# (rust/clockwork-schedule) is reached by those headers directly. Only the C
# ABI header needs an include path.
# Unconditional, and not an oversight: the crate's `parse` half is compiled in
# both configurations (a timestamped bundle is the DSP's, so a build with no
# store still has to read its timetag), and one header declares both halves.
# With the store off its store functions are simply not in the archive, and
# every C++ site that would call one is gated — so a mistake there is a link
# error, which is the failure you want.
target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-schedule/cpp)
# The clock's value type and follower registry (src/clock/Timeline.h and
# MidiTimelines.h are thin C++ over it).
target_include_directories(clockwork PUBLIC ${CLOCKWORK_RUST_DIR}/clockwork-clock/cpp)

# ─── Plugin hosting adapters ─────────────────────────────────────────────────
# Each format's directory adds its adapter to clockwork and builds its own
# test plugin. They are added here, after clockwork exists, so each one keeps
# its own sources, its own SDK fetch and its own flags in its own file.
if(CLOCKWORK_PLUGINS AND NOT EMSCRIPTEN)
    add_subdirectory(plugins/clap)
    add_subdirectory(plugins/vst3)
endif()

# ─── The DSP ─────────────────────────────────────────────────────────────────
# Everything above is clockwork. Everything the DSP owns is behind
# src/dsp_api.h — the entry points docs/BOUNDARY.md lists — and arrives as one
# more static library named by CLOCKWORK_DSP. The header is the list; nothing
# else restates its length.
if(CLOCKWORK_DSP_DIR)
    get_filename_component(CLOCKWORK_DSP_SRC_DIR "${CLOCKWORK_DSP_DIR}"
                           ABSOLUTE BASE_DIR "${CMAKE_BINARY_DIR}")
else()
    set(CLOCKWORK_DSP_SRC_DIR "${CMAKE_CURRENT_SOURCE_DIR}/dsp/${CLOCKWORK_DSP}")
endif()
if(NOT EXISTS "${CLOCKWORK_DSP_SRC_DIR}/CMakeLists.txt")
    message(FATAL_ERROR
        "CLOCKWORK_DSP=${CLOCKWORK_DSP}: no CMakeLists.txt at ${CLOCKWORK_DSP_SRC_DIR}. "
        "A DSP is a directory defining a target of its own name that implements "
        "src/dsp_api.h; set CLOCKWORK_DSP_DIR to point at one outside this tree.")
endif()
# The explicit binary dir is required, not stylistic: add_subdirectory refuses
# a source directory outside the current tree without one.
add_subdirectory("${CLOCKWORK_DSP_SRC_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/dsp-${CLOCKWORK_DSP}")
if(NOT TARGET ${CLOCKWORK_DSP})
    message(FATAL_ERROR "dsp/${CLOCKWORK_DSP} defined no target named ${CLOCKWORK_DSP}")
endif()
message(STATUS "DSP: ${CLOCKWORK_DSP}")

# Clockwork and the DSP call each other in both directions by construction —
# clockwork runs blocks and hands over OSC, the DSP answers through
# DspHost::emit_osc and DspHost::log. Link them as a group so a single pass is
# not asked to resolve a cycle. `out`: the link line for clockwork with the
# DSP target `dsp`.
function(clockwork_lib_group out dsp)
    if(APPLE OR MSVC OR EMSCRIPTEN)
        set(${out} clockwork ${dsp} ${CLOCKWORK_RUST_LIB} PARENT_SCOPE)
    else()
        # $<TARGET_FILE:clockwork>, not the target NAME: CMake reorders a
        # named target by its own dependency rules and can hoist it out of
        # the group, leaving the DSP inside unable to reach back for the
        # clockwork symbols it calls. A file path stays where it is put.
        # BOTH forms of clockwork, deliberately. The target carries the
        # usage requirements — include directories and compile definitions —
        # which a bare file path does not; $<TARGET_FILE:> pins the archive
        # INSIDE the group, which a target name does not. Without the file,
        # the DSP cannot reach back for the symbols it calls; without the
        # target, nothing that links this can find a header. The archive
        # appearing twice on the line costs nothing.
        set(${out}
            clockwork
            -Wl,--start-group
            $<TARGET_FILE:clockwork> $<TARGET_FILE:${dsp}> ${CLOCKWORK_RUST_LIB}
            -Wl,--end-group
            PARENT_SCOPE)
    endif()
endfunction()
clockwork_lib_group(CLOCKWORK_LIB_GROUP ${CLOCKWORK_DSP})

# What an EMBEDDER links. CLOCKWORK_LIB_GROUP above is a plain variable in
# this directory's scope, so it is empty in a parent project: a consumer
# using it would get clockwork with no DSP in the link line and undefined
# dsp_* references. An INTERFACE target carries the same flags across the
# directory boundary, including the --start-group/--end-group pair
# the clockwork/DSP call cycle needs.
#
# Link this, and only this:  target_link_libraries(you PRIVATE clockwork_bundle)
#
# A build that cannot use the library at all — freestanding or embedded — takes
# CLOCKWORK_CORE_SOURCES and CLOCKWORK_INCLUDE_DIRS instead; see where they are set.

add_library(clockwork_bundle INTERFACE)
target_link_libraries(clockwork_bundle INTERFACE ${CLOCKWORK_LIB_GROUP})
# The group names the DSP by FILE so it stays inside --start-group, and a file
# path creates no dependency edge, so without this a consumer linking the
# bundle gets "No rule to make target" for the DSP's archive unless the guest
# happens to build first.
add_dependencies(clockwork_bundle ${CLOCKWORK_DSP})
if(CLOCKWORK_RUST)
    add_dependencies(clockwork_bundle clockwork_rust)
endif()

# A plugin binary built on Clockwork (src/clockwork_plugin.h, docs/ENGINES.md
# 3.7): a shared module a host loads, perhaps beside another plugin with a
# Clockwork of its own, so it exports the entry points named and nothing
# else (clockwork_exports_only): no host's dynamic linker can then bind
# another module's calls to this module's Clockwork, or this module's to
# another's. The entry points are marked CLOCKWORK_PLUGIN_ENTRY.
#
#   clockwork_plugin_module(my_plugin ENTRY clap_entry)
function(clockwork_plugin_module target)
    cmake_parse_arguments(PM "" "" "ENTRY" ${ARGN})
    if(NOT PM_ENTRY)
        message(FATAL_ERROR "clockwork_plugin_module(${target}) names no ENTRY")
    endif()
    target_link_libraries(${target} PRIVATE clockwork_bundle)
    target_include_directories(${target} PRIVATE ${CLOCKWORK_INCLUDE_DIRS})
    clockwork_exports_only(${target} ENTRY ${PM_ENTRY})
endfunction()

# ─── The web module ──────────────────────────────────────────────────────────
# One STANDALONE_WASM module with imported shared memory — the worklet
# supplies the memory, so JavaScript and clockwork address one heap — and no
# JavaScript of its own: js/workers/clockwork_audio_worklet.js loads it.
if(EMSCRIPTEN)
    set(CLOCKWORK_WEB_MODULE_NAME "clockwork" CACHE STRING
        "Basename of the wasm module (a product names its own: SuperSonic's is clockwork-scsynth)")
    set(CLOCKWORK_WEB_DIST_DIR "${CMAKE_CURRENT_SOURCE_DIR}/dist/wasm" CACHE PATH
        "Where the module is written")
    set(CLOCKWORK_WEB_STACK_SIZE 1048576 CACHE STRING "The wasm stack, bytes")
    # The linker's map beside the module (<name>.map): where it placed every
    # symbol. scripts/static-map.mjs reduces it to <name>.symbols.json, which
    # the dev tools read to name static memory. Build metadata, not shipped.
    option(CLOCKWORK_WEB_LINK_MAP "Write the linker's map beside the web module" ON)
    set(CLOCKWORK_WEB_ASSERTIONS 0 CACHE STRING "emscripten -sASSERTIONS")
    set(CLOCKWORK_WEB_SAFE_HEAP 0 CACHE STRING "emscripten -sSAFE_HEAP")
    option(CLOCKWORK_WEB_KEEP_NAMES "Keep function names in the module (--profiling-funcs)" OFF)
    # The audio file codecs (the Rust decoders, the FLAC encoder) are a
    # native concern: on the web, samples arrive already decoded through the
    # browser's own decoder and nothing records to a file. Opt in for a
    # client that decodes in the module.
    option(CLOCKWORK_WEB_AUDIO_FILES "Export the audio file codecs to the web client" OFF)
    # A product may export more of its own (CLOCKWORK_WEB_EXTRA_EXPORTS).
    set(CLOCKWORK_WEB_EXTRA_EXPORTS "" CACHE STRING "Extra exported functions, ';'-separated, with their leading underscore")

    # Every worklet entry point. A name missing here is dead-stripped and the
    # worklet fails at run time, not at build time — so this list has to be
    # right, and it is clockwork's to keep: the worklet is clockwork's.
    set(CLOCKWORK_WEB_EXPORTS
        ___wasm_call_ctors _clockwork_memory_claim _clockwork_core_new _clockwork_core_held _clockwork_init _clockwork_boot_error _clockwork_malloc_mark_boot _get_arena_base _clockwork_product_version
        _clockwork_tick _clockwork_audio_out _clockwork_audio_in _clockwork_block_size
        _clockwork_log _clockwork_log_va _clockwork_log_raw
        _clear_scheduler _clockwork_host_forward _clockwork_host_forwards
        _clockwork_ingress_mark_stale _clockwork_audio_back _clockwork_audio_starts _clockwork_set_timed_event_late_limit_ms _clockwork_carry_generation _clockwork_close
        _clockwork_worklet_alloc _clockwork_worklet_free
        _clockwork_client_abi_version _clockwork_client_status_text
        _clockwork_client_open_memory
        _clockwork_client_close _clockwork_client_info
        _clockwork_client_send _clockwork_client_send_begin
        _clockwork_client_send_commit _clockwork_client_send_abort
        _clockwork_client_poll _clockwork_client_count_undelivered _clockwork_client_region
        _clockwork_client_metrics _clockwork_client_clock _clockwork_client_beat_at
        _clockwork_client_tap_sizeof _clockwork_client_tap_open
        _clockwork_client_tap_open_in _clockwork_client_tap_close
        _clockwork_client_tap_poll _clockwork_client_tap_missed
        _clockwork_client_audio_tap_open _clockwork_client_audio_tap_valid
        _clockwork_client_audio_tap_activations
        _clockwork_client_audio_tap_audible_end _clockwork_client_audio_tap_read
        _clockwork_client_copy_bytes _clockwork_client_copy)
    if(CLOCKWORK_WEB_AUDIO_FILES)
        list(APPEND CLOCKWORK_WEB_EXPORTS
            _clockwork_audio_probe_memory _clockwork_audio_decode_memory
            _clockwork_audio_free _clockwork_audio_duration
            _clockwork_audio_can_write _clockwork_audio_writer_open_memory
            _clockwork_audio_writer_write _clockwork_audio_writer_frames
            _clockwork_audio_writer_close)
    endif()
    if(CLOCKWORK_WEB_EXTRA_EXPORTS)
        list(APPEND CLOCKWORK_WEB_EXPORTS ${CLOCKWORK_WEB_EXTRA_EXPORTS})
    endif()
    list(JOIN CLOCKWORK_WEB_EXPORTS "\",\"" _exports_joined)
    set(_exports_file "${CMAKE_CURRENT_BINARY_DIR}/clockwork_web_exports.json")
    file(WRITE "${_exports_file}" "[\"${_exports_joined}\"]\n")

    add_executable(clockwork_web ${CLOCKWORK_SRC}/web_module.cpp)
    set_target_properties(clockwork_web PROPERTIES
        OUTPUT_NAME "${CLOCKWORK_WEB_MODULE_NAME}"
        SUFFIX ".wasm"
        RUNTIME_OUTPUT_DIRECTORY "${CLOCKWORK_WEB_DIST_DIR}")
    target_link_libraries(clockwork_web PRIVATE clockwork_bundle)
    target_link_options(clockwork_web PRIVATE
        -sSTANDALONE_WASM
        -sNO_FILESYSTEM=1
        -sENVIRONMENT=worker
        -sALLOW_MEMORY_GROWTH=1
        -sINITIAL_MEMORY=${CLOCKWORK_WEB_INITIAL_MEMORY}
        -sMAXIMUM_MEMORY=${CLOCKWORK_WEB_MAX_MEMORY}
        -sSTACK_SIZE=${CLOCKWORK_WEB_STACK_SIZE}
        "-sEXPORTED_FUNCTIONS=@${_exports_file}"
        --no-entry
        -Wl,--import-memory,--shared-memory,--allow-multiple-definition
        -sASSERTIONS=${CLOCKWORK_WEB_ASSERTIONS}
        -sSAFE_HEAP=${CLOCKWORK_WEB_SAFE_HEAP}
        $<$<BOOL:${CLOCKWORK_WEB_KEEP_NAMES}>:--profiling-funcs>
        $<$<BOOL:${CLOCKWORK_WEB_LINK_MAP}>:-Wl,--Map=${CLOCKWORK_WEB_DIST_DIR}/${CLOCKWORK_WEB_MODULE_NAME}.map>
        # src/guest_malloc.cpp: the program's allocator calls go through
        # clockwork, which counts the guest's. Allocations are untouched.
        $<$<BOOL:${CLOCKWORK_WEB_COUNT_GUEST_MALLOC}>:-Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc,--wrap=free>
        -sERROR_ON_UNDEFINED_SYMBOLS=1)
    message(STATUS "web module: ${CLOCKWORK_WEB_DIST_DIR}/${CLOCKWORK_WEB_MODULE_NAME}.wasm")
endif()

# ── Windows version resource ─────────────────────────────────────────────────
# src/native/clockwork_version.rc.in is configured here and attached to
# clockwork_bundle as an INTERFACE source so an EMBEDDER's executable gets it
# without knowing it exists — the same reason the link group is a target
# rather than a variable. Without it a Windows build carries no version
# information: Explorer and every UAC and device-permission dialog show a
# bare filename.
if(WIN32)
    # Windows wants the version as four comma-separated fields.
    # Windows wants numbers: a product's version, or none (0.0.0.0) standalone
    set(_cw_rc_version "0.0.0")
    if(CLOCKWORK_PRODUCT_VERSION MATCHES "^[0-9]+(\\.[0-9]+)*$")
        set(_cw_rc_version "${CLOCKWORK_PRODUCT_VERSION}")
    endif()
    string(REPLACE "." ";" CLOCKWORK_VERSION_PARTS "${_cw_rc_version}")
    list(LENGTH CLOCKWORK_VERSION_PARTS CLOCKWORK_VERSION_N)
    while(CLOCKWORK_VERSION_N LESS 4)
        list(APPEND CLOCKWORK_VERSION_PARTS 0)
        list(LENGTH CLOCKWORK_VERSION_PARTS CLOCKWORK_VERSION_N)
    endwhile()
    list(JOIN CLOCKWORK_VERSION_PARTS "," CLOCKWORK_RC_VERSION_COMMAS)
    set(PROJECT_VERSION "${_cw_rc_version}")

    # The product's icon, for the window class and the taskbar: resource id
    # 1 when the embedder names an .ico (CLOCKWORK_PRODUCT_ICON), nothing
    # otherwise — the rc is fine with an empty line there.
    set(CLOCKWORK_PRODUCT_ICON "" CACHE FILEPATH "An .ico this product's binaries carry as resource 1 (Windows)")
    set(CLOCKWORK_RC_ICON "")
    if(CLOCKWORK_PRODUCT_ICON AND EXISTS "${CLOCKWORK_PRODUCT_ICON}")
        file(TO_CMAKE_PATH "${CLOCKWORK_PRODUCT_ICON}" _clockwork_icon)
        set(CLOCKWORK_RC_ICON "1 ICON \"${_clockwork_icon}\"")
    endif()
    set(CLOCKWORK_VERSION_RC "${CMAKE_CURRENT_BINARY_DIR}/clockwork_version.rc")
    configure_file("${NATIVE_SRC}/clockwork_version.rc.in" "${CLOCKWORK_VERSION_RC}" @ONLY)
    target_sources(clockwork_bundle INTERFACE "${CLOCKWORK_VERSION_RC}")
endif()

# There is no reference host: an engine is a library with no process shape
# of its own. The process around it — the command line, the sockets, the run
# loop — is the client's (clockwork-supersonic/host/ is one), composed from
# the comms client library below.

# ─── The standalone SCHEDULER host ───────────────────────────────────────────
# A different program from the one above: an OSC/MIDI event scheduler with no
# synthesis engine, driving the timed store off the wall clock. Built with the
# standalone tree so it keeps compiling against the boundary.
#
# Needs the timed store, because scheduling is the entire program: with
# CLOCKWORK_SCHEDULER=OFF there is nothing for it to be.
if(CLOCKWORK_STANDALONE AND CLOCKWORK_SCHEDULER)
    add_executable(clockwork-scheduler-host ${CLOCKWORK_SRC}/host/main.cpp)
    add_dependencies(clockwork-scheduler-host ${CLOCKWORK_DSP})
    # Its control port is the comms library's TCP server (clockwork_comms_abi.h).
    target_include_directories(clockwork-scheduler-host PRIVATE ${CLOCKWORK_SRC}/comms)
    target_link_libraries(clockwork-scheduler-host PRIVATE ${CLOCKWORK_LIB_GROUP})
endif()

# ─── The comms client library ────────────────────────────────────────────────
# The command transports (src/comms/clockwork_comms.h). NOT part of the engine:
# an engine has no sockets, and a host that wants some links this and stands
# them behind the engine's one reply door. SuperSonic's host and the NIF both
# do; an in-process embedder need not. Its Rust half is
# the clockwork-comms crate, carried in the native umbrella under the `comms`
# feature so the symbols are there for whoever links this.
# A worklet has no sockets and no host process to stand them in, so the web
# target builds none of this.
if(NOT EMSCRIPTEN)
add_library(clockwork_comms STATIC
    ${CLOCKWORK_SRC}/comms/StreamOscTransport.cpp
    ${CLOCKWORK_SRC}/comms/ShmTransport.cpp)
if(CLOCKWORK_FLOAT_FLAGS)
    target_compile_options(clockwork_comms PUBLIC ${CLOCKWORK_FLOAT_FLAGS})
endif()
target_include_directories(clockwork_comms PUBLIC ${CLOCKWORK_SRC}/comms)
target_link_libraries(clockwork_comms PUBLIC clockwork)
set_target_properties(clockwork_comms PROPERTIES POSITION_INDEPENDENT_CODE ON)
# The old name, for consumers pinned to it; retire once they say clockwork_comms.
add_library(clockwork_transports ALIAS clockwork_comms)
endif()

# ─── The plugin-host dispatcher ──────────────────────────────────────────────
# The adapters themselves were added further up, where clockwork is built.
# This is the boundary on top of them: one library holding the public C symbols.
if(CLOCKWORK_PLUGINS)
    # plugin_host.cpp is the ONE definition of plugin_host.h's C symbols; the
    # adapters export namespaced entry points instead, because two adapters
    # both defining plugin_scan is a duplicate symbol at link.
    if(NOT TARGET clockwork_plugin_host)
        add_library(clockwork_plugin_host STATIC ${CLOCKWORK_SRC}/plugin_host.cpp)
        target_include_directories(clockwork_plugin_host PUBLIC ${CLOCKWORK_SRC})
        set_target_properties(clockwork_plugin_host PROPERTIES POSITION_INDEPENDENT_CODE ON)
    endif()
    # Tracks: the consumer that gives a hosted plugin a place in the audio
    # path. Built with the host rather than into clockwork, so a build
    # without plugin support has neither and the audio path's hook stays null.
    target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/plugin_track.cpp)
    # Anything linking the host learns it is there, so a host's main can install
    # the tracks under a define that is actually set somewhere.
    target_compile_definitions(clockwork_plugin_host PUBLIC CLOCKWORK_HAS_PLUGIN_TRACKS=1)
    # Discovery: finding plugins on disk, so a host does not ship with paths
    # compiled into it. Built here rather than into clockwork for the same
    # reason as the tracks — a build without plugin support has neither.
    target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/plugin_discovery.cpp)
    # The editor window: the engine's own, so the editor belongs to the instance
    # that makes sound rather than to a second copy loaded to draw with. macOS
    # relies on the Cocoa run loop the bridge already pumps; Windows on the
    # message pump it already runs (PluginBridgeMain.cpp, pumpEvents), which
    # is why neither needs a thread of its own. Linux has no loop to lean on
    # and a stub answers "no window" honestly.
    if(APPLE)
        target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/native/PluginEditorWindow.mm)
        target_link_libraries(clockwork_plugin_host PRIVATE "-framework Cocoa")
    elseif(WIN32)
        # Compiled by CI, not yet run on Windows: see the file's header.
        target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/native/PluginEditorWindowWin.cpp)
        # user32 for the window itself. PRIVATE on a static library still
        # reaches whoever links it, so the bridge and the tests get it too.
        target_link_libraries(clockwork_plugin_host PRIVATE user32)
    else()
        target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/plugin_editor_window_stub.cpp)
    endif()
    if(TARGET clockwork_plugin_vst3)
        target_link_libraries(clockwork_plugin_host PUBLIC clockwork_plugin_vst3)
    endif()
    if(TARGET clockwork_plugin_clap)
        target_link_libraries(clockwork_plugin_host PUBLIC clockwork_plugin_clap)
    endif()

    # The verbs: the /clockwork-sys/track/* surface, decoded where the plugins are.
    # Part of the host library because both the bridge and a test that hosts
    # in-process want them, and neither wants the other's main().
    target_sources(clockwork_plugin_host PRIVATE ${CLOCKWORK_SRC}/plugin_bridge_verbs.cpp)
    # The verbs speak OSC (clockwork_sys.h, oscpack) and clockwork_product.h: clockwork's
    # headers, not its library.
    target_include_directories(clockwork_plugin_host PRIVATE ${CLOCKWORK_INCLUDE_DIRS})
    target_compile_definitions(clockwork_plugin_host PRIVATE CLOCKWORK_PRODUCT_NAME="${CLOCKWORK_PRODUCT_NAME}")

    # ── The bridge ──────────────────────────────────────────────────────────
    # THE ENGINE NEVER LINKS THE PLUGIN HOST. Plugins run in this separate
    # process, which shares a memory segment with the engine (plugin_bridge.h)
    # and is reached through a pair of ports like any other outboard audio.
    # A plugin that crashes takes the bridge down and the engine notices, so
    # the audio keeps going; a plugin's editor window belongs to the bridge's
    # own run loop. clockwork gets only TrackControl — the proxy that owns
    # the segment, spawns the bridge and relays OSC across — and the define
    # that lets a host's main and ClockworkEngine wire it in.
    #
    # The binary sits beside the host binary under a product-facing name
    # (CLOCKWORK_PLUGIN_BRIDGE_NAME), because it is what a user sees in Activity
    # Monitor when a plugin misbehaves, and what an entitlement is granted to.
    target_sources(clockwork PRIVATE ${NATIVE_SRC}/TrackControl.cpp)
    target_compile_definitions(clockwork PUBLIC
        CLOCKWORK_HAS_PLUGIN_TRACKS=1
        CLOCKWORK_PLUGIN_BRIDGE_NAME="${CLOCKWORK_PLUGIN_BRIDGE_NAME}")
    if(CLOCKWORK_PLUGIN_BRIDGE_DIR)
        target_compile_definitions(clockwork PUBLIC
            CLOCKWORK_PLUGIN_BRIDGE_DIR="${CLOCKWORK_PLUGIN_BRIDGE_DIR}")
    endif()

    if(NOT EMSCRIPTEN)
        # The bridge's own Rust staticlib: only the port substrate. It cannot
        # share clockwork-native, whose archive is bound to clockwork by the link
        # cycle above, and it wants none of the engine's subsystems anyway.
        # The profile and offline flags, not the feature list: the bridge's
        # crate has no subsystems to switch on.
        set(CLOCKWORK_BRIDGE_CARGO_FLAGS)
        if(NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
            list(APPEND CLOCKWORK_BRIDGE_CARGO_FLAGS --release)
        endif()
        if(CLOCKWORK_CARGO_OFFLINE)
            list(APPEND CLOCKWORK_BRIDGE_CARGO_FLAGS --offline)
        endif()
        list(APPEND CLOCKWORK_BRIDGE_CARGO_FLAGS --locked ${CLOCKWORK_RUST_TARGET_FLAGS})
        # Built from Clockwork's workspace whoever is embedding: the bridge
        # is clockwork's binary, and an embedder's umbrella has nothing it
        # needs.
        set(CLOCKWORK_BRIDGE_RUST_LIB
            ${CLOCKWORK_RUST_TARGET_DIR}/${CMAKE_STATIC_LIBRARY_PREFIX}clockwork_bridge_native${CMAKE_STATIC_LIBRARY_SUFFIX})
        add_custom_target(clockwork_bridge_rust ALL
            BYPRODUCTS ${CLOCKWORK_BRIDGE_RUST_LIB}
            COMMAND ${CLOCKWORK_RUST_CARGO_ENV} ${CARGO_EXECUTABLE} build ${CLOCKWORK_BRIDGE_CARGO_FLAGS} -p clockwork-bridge-native
            WORKING_DIRECTORY ${CLOCKWORK_RUST_DIR}
            COMMENT "Building Rust port substrate for the plugin bridge (cargo: clockwork-bridge-native)"
            VERBATIM)
        add_library(clockwork_bridge_rust_lib STATIC IMPORTED)
        set_target_properties(clockwork_bridge_rust_lib PROPERTIES IMPORTED_LOCATION ${CLOCKWORK_BRIDGE_RUST_LIB})

        # The wait word is compiled in: the bridge links the plugin host
        # library, which waits on one, and not the core that holds it.
        add_executable(clockwork_plugin_bridge
            ${NATIVE_SRC}/PluginBridgeMain.cpp
            ${NATIVE_SRC}/RealtimeThread.cpp
            ${WORKERS_SRC}/wait_word.cpp
            ${OSCPACK_SOURCES})
        if(APPLE)
            target_sources(clockwork_plugin_bridge PRIVATE ${NATIVE_SRC}/CocoaEventPump.mm)
        elseif(WIN32)
            # Its own version and icon: the editor windows it opens carry
            # this binary's, and consent prompts name it.
            target_sources(clockwork_plugin_bridge PRIVATE "${CLOCKWORK_VERSION_RC}")
        endif()
        add_dependencies(clockwork_plugin_bridge clockwork_bridge_rust)
        target_include_directories(clockwork_plugin_bridge PRIVATE ${CLOCKWORK_INCLUDE_DIRS})
        target_compile_definitions(clockwork_plugin_bridge PRIVATE
            CLOCKWORK_PRODUCT_NAME="${CLOCKWORK_PRODUCT_NAME}"
            CLOCKWORK_HAS_PLUGIN_TRACKS=1)
        target_link_libraries(clockwork_plugin_bridge PRIVATE clockwork_plugin_host clockwork_bridge_rust_lib)
        if(APPLE)
            target_link_libraries(clockwork_plugin_bridge PRIVATE
                "-framework Cocoa" "-framework CoreFoundation")
            # An app bundle, <CLOCKWORK_PLUGIN_BRIDGE_NAME>.app beside the host
            # binary, so the process has a bundle identifier (see
            # CLOCKWORK_PLUGIN_BRIDGE_BUNDLE_ID). The engine looks inside it:
            # TrackControl::findBridge. LSUIElement keeps it out of the Dock.
            set_target_properties(clockwork_plugin_bridge PROPERTIES
                MACOSX_BUNDLE TRUE
                MACOSX_BUNDLE_INFO_PLIST "${NATIVE_SRC}/bridge_info.plist.in")
        elseif(WIN32)
            target_link_libraries(clockwork_plugin_bridge PRIVATE ntdll userenv dbghelp ws2_32 Synchronization)
        else()
            target_link_libraries(clockwork_plugin_bridge PRIVATE pthread ${CMAKE_DL_LIBS})
        endif()
        set_target_properties(clockwork_plugin_bridge PROPERTIES
            OUTPUT_NAME "${CLOCKWORK_PLUGIN_BRIDGE_NAME}"
            RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}")
        if(APPLE)
            # The linker signs the executable ad hoc, but a bundle is signed as
            # a bundle — its Info.plist sealed with it — or `codesign --verify`
            # on the .app says "code has no resources but signature indicates
            # they must be present", and a host that copies the bundle into its
            # own and verifies (macdeployqt does) reports an error. An ad-hoc
            # bundle signature here; a release re-signs with its identity.
            add_custom_command(TARGET clockwork_plugin_bridge POST_BUILD
                COMMAND codesign --force --sign - "$<TARGET_BUNDLE_DIR:clockwork_plugin_bridge>"
                COMMENT "Signing the plugin bridge bundle (ad hoc)"
                VERBATIM)
        endif()
        # Anything that builds the host binary gets the bridge beside it.
    endif()
endif()

# ─── Tests ───────────────────────────────────────────────────────────────────
# Clockwork's own suite, and only when clockwork is what is being built.
# An embedder turning BUILD_TESTS on means ITS tests, not ours.
if(BUILD_TESTS AND CLOCKWORK_STANDALONE)
    enable_testing()
    add_subdirectory(test)
endif()

# ─── Warnings as errors, for Clockwork's own targets ─────────────────────────
# CI configures with CLOCKWORK_WERROR=ON: a warning in our sources fails the
# build there, where a count of them would otherwise drift unread. Only our
# targets — the fetched dependencies warn as they will, and are not ours to
# fix — and not MSVC, whose /W1 is a different conversation.
if(CLOCKWORK_WERROR AND NOT MSVC)
    foreach(_t clockwork clockwork_comms)
        if(TARGET ${_t})
            target_compile_options(${_t} PRIVATE -Werror)
        endif()
    endforeach()
    # The vendored sources compiled into the library (oscpack, libsamplerate)
    # warn as their authors left them: theirs to fix, not ours to fail on.
    set_source_files_properties(
        ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscTypes.cpp
        ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscOutboundPacketStream.cpp
        ${CLOCKWORK_SRC}/vendor/oscpack/osc/OscReceivedElements.cpp
        ${CLOCKWORK_SAMPLERATE_SOURCES}
        PROPERTIES COMPILE_OPTIONS -Wno-error)
endif()
