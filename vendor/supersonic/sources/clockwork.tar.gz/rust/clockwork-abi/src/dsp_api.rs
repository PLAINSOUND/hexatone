// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2026 Sam Aaron
//! `src/dsp_api.h` — the guest boundary. The host fills [`DspConfig`] and
//! [`DspHost`] and calls the entry points a guest exports; the guest answers
//! [`DspInfo`] from `dsp_describe`. See the header for every contract; this
//! file is its shape, field for field, and `tests/layout.rs` holds it to that.

use core::ffi::{c_char, c_int, c_void};

use crate::sink::{ClockworkSink, ClockworkSinkKind};
use crate::timetag::ClockworkTimetag;
use crate::params::ClockworkParamEntry;

/// The guest's instance: opaque to the host, `struct Dsp` in C.
#[repr(C)]
pub struct Dsp {
    _opaque: [u8; 0],
}

/// `ClockworkClockState` (clockwork_clock_state.h): read whole with
/// [`crate::clock::read`], never field by field. Where the platform has no
/// 64-bit atomics it stays opaque, as the guest there has no Rust reader.
#[cfg(target_has_atomic = "64")]
pub use crate::clock::ClockworkClockState;
#[cfg(not(target_has_atomic = "64"))]
#[repr(C)]
pub struct ClockworkClockState {
    _opaque: [u8; 0],
}

/// `ClockworkChannelMapState` (shared_memory.h). Opaque here.
#[repr(C)]
pub struct ClockworkChannelMapState {
    _opaque: [u8; 0],
}

/// `DspFpEnv`: the floating-point environment of the thread `dsp_process`
/// runs on, as the host declared it.
pub const DSP_FP_ENV_UNKNOWN: i32 = 0;
pub const DSP_FP_ENV_DENORMALS_HONOURED: i32 = 1;
pub const DSP_FP_ENV_FLUSH_TO_ZERO: i32 = 2;

/// What the host hands `dsp_new`.
#[repr(C)]
pub struct DspConfig {
    pub sample_rate: f64,
    /// Frames per `dsp_process` call.
    pub block_size: u32,
    pub max_input_channels: u32,
    pub max_output_channels: u32,
    /// May be NULL.
    pub clock: *const ClockworkClockState,
    /// May be NULL when the host reserved no arena.
    pub channel_map: *const ClockworkChannelMapState,
    /// The guest's shared-memory window; NULL/0 if none.
    pub shm_window: *mut c_void,
    pub shm_window_bytes: u32,
    pub persistent: *mut c_void,
    pub persistent_bytes: u32,
    /// The guest's working memory: the fast tier, sized to its want.
    pub memory: *mut c_void,
    pub memory_bytes: u32,
    /// The bulk tier; NULL/0 on a single-region host.
    pub memory_bulk: *mut c_void,
    pub memory_bulk_bytes: u32,
    /// Bulk in: the client writes, the guest only reads.
    pub assets: *const c_void,
    pub assets_bytes: u32,
    /// Bulk out: the guest writes, the client reads.
    pub returns: *mut c_void,
    pub returns_bytes: u32,
    /// Opaque to clockwork; the host's and the guest's private matter.
    pub guest_config: *const c_void,
    pub guest_config_bytes: u32,
    /// A `DSP_FP_ENV_*` value.
    pub fp_env: i32,
}

/// A DSP's hold on a tap slot (`DspHost::tap_open`): four words, the
/// shape the tap substrate spells out (rust/clockwork-taps). Opaque to a
/// DSP apart from two reads: `slot` is non-NULL while the handle owns a slot,
/// and `channels` is how many that slot carries, as the host clamped it. The
/// other two are unused and 0.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct DspTapHandle {
    pub slot: *mut c_void,
    pub data: *mut f32,
    pub channels: u32,
    pub max_frames: u32,
}

/// What a guest may call back into. Every pointer may be NULL and must be
/// checked: a host that offers no sinks leaves `open_sink` NULL. `Copy`,
/// because a guest keeps its own copy: the host's pointer is only promised
/// for the duration of `dsp_new`.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct DspHost {
    pub ctx: *mut c_void,
    /// Reply to `token`, or notify listeners with token 0. Non-zero if queued.
    pub emit_osc:
        Option<unsafe extern "C" fn(ctx: *mut c_void, token: u32, bytes: *const u8, len: u32) -> c_int>,
    pub log: Option<unsafe extern "C" fn(ctx: *mut c_void, level: c_int, text: *const c_char)>,
    /// Control thread only.
    pub open_sink: Option<
        unsafe extern "C" fn(
            ctx: *mut c_void,
            kind: ClockworkSinkKind,
            target: *const c_char,
            capacity: u32,
        ) -> ClockworkSink,
    >,
    /// Audio thread callable. `when` is an OSC timetag, or
    /// [`ClockworkTimetag::IMMEDIATELY`].
    pub send_sink: Option<
        unsafe extern "C" fn(
            ctx: *mut c_void,
            sink: ClockworkSink,
            bytes: *const u8,
            len: u32,
            when: ClockworkTimetag,
        ) -> c_int,
    >,
    /// Give back bytes taken through `alloc_bytes`. Any thread.
    pub free_bytes: Option<unsafe extern "C" fn(ctx: *mut c_void, ptr: *mut c_void)>,
    /// The guest is done with an asset `dsp_asset` handed it.
    pub asset_release: Option<unsafe extern "C" fn(ctx: *mut c_void, id: u32) -> c_int>,
    /// Bytes from the guest's bulk memory (`DspConfig::memory_bulk`), the span clockwork runs its allocator
    /// over; given back through `free_bytes`. Audio thread callable; lock-free, and NULL rather than blocking.
    /// A Rust guest need not call it: its `Box` and `Vec` land in the same span by themselves while one of its
    /// entry points is open (clockwork's global allocator routes them there).
    pub alloc_bytes: Option<unsafe extern "C" fn(ctx: *mut c_void, bytes: usize) -> *mut c_void>,
    /// Claim tap slot `index` to publish `channels` channels into. Non-zero on success.
    pub tap_open:
        Option<unsafe extern "C" fn(ctx: *mut c_void, index: u32, channels: u32, hnd: *mut DspTapHandle) -> c_int>,
    /// Append a block to a claimed tap. Audio thread callable; never allocates.
    pub tap_write: Option<
        unsafe extern "C" fn(
            ctx: *mut c_void,
            hnd: *mut DspTapHandle,
            channels: *const *const f32,
            n_channels: u32,
            frames: u32,
        ),
    >,
    /// Give the slot back.
    pub tap_close: Option<unsafe extern "C" fn(ctx: *mut c_void, hnd: *mut DspTapHandle)>,
    /// Drops the bundles clockwork holds for this DSP ahead of their time
    /// (a DSP's own "clear the schedule" verb). Callable from `dsp_process`.
    pub flush_schedule: Option<unsafe extern "C" fn(ctx: *mut c_void)>,
    pub param_define: Option<
        unsafe extern "C" fn(
            ctx: *mut c_void, entries: *const ClockworkParamEntry, count: u32,
            text: *const u8, text_bytes: u32, slots: *mut u32,
        ) -> i32,
    >,
    pub param_value: Option<unsafe extern "C" fn(ctx: *mut c_void, slot: u32) -> f32>,
    pub param_set: Option<unsafe extern "C" fn(ctx: *mut c_void, slot: u32, value: f32) -> c_int>,
}

/// What `dsp_describe` answers. Static: describable before any instance.
#[repr(C)]
pub struct DspInfo {
    pub name: *const c_char,
    pub version: *const c_char,
    /// Non-zero: the guest holds its own schedule and wants every message the
    /// moment it arrives, carrying its timetag.
    pub holds_schedule: i32,
    /// Bytes wanted from the fast tier; 0 means no claim.
    pub memory_bytes_wanted: u32,
    /// Bytes wanted from the bulk tier; 0 means no claim.
    pub memory_bulk_bytes_wanted: u32,
    /// Non-zero: the host's inbound events (`/clockwork/midi/in/…`,
    /// `/clockwork/gamepad/in/…`, the ports and devices pushes) are handed
    /// to `dsp_osc` as they arrive, each with its arrival timetag as a
    /// trailing `t` argument when the host knows it.
    pub wants_events: i32,
    /// What the window is: a magic naming the guest's window format and the
    /// version of that format, copied into the arena table's window entry
    /// when the guest binds. 0 and 0: undeclared.
    pub window_magic: u32,
    pub window_version: u32,
    /// What device change the instance takes live (`DSP_SURVIVES_*`): such a
    /// change is a hot restart, the instance told through `dsp_reconfigure`
    /// and keeping what it holds. 0: survives nothing; every such change is
    /// cold (clockwork's docs/RESTARTS.md).
    pub survives: u32,
    /// How many instances one process may hold, one per core at most; a
    /// build past the count is refused with the reason. 0, as a zeroed
    /// `DspInfo` leaves it, is one. [`DSP_INSTANCES_ANY`] is any number, and
    /// a promise that the guest keeps no process-wide mutable state.
    pub instances: u32,
}

/// `DspInfo::instances`: any number in one process.
pub const DSP_INSTANCES_ANY: u32 = u32::MAX;

/// `DspInfo::survives`: a different sample rate.
pub const DSP_SURVIVES_RATE_CHANGE: u32 = 1 << 0;
/// `DspInfo::survives`: different channel ceilings.
pub const DSP_SURVIVES_CHANNEL_CHANGE: u32 = 1 << 1;

// SAFETY: a DspInfo is immutable static data — string pointers into
// statics — which is the only way a guest ever builds one.
unsafe impl Sync for DspInfo {}

/// `CLOCKWORK_ASSET_*`: what an asset's bytes are.
pub const CLOCKWORK_ASSET_RAW: u32 = 0;
pub const CLOCKWORK_ASSET_AUDIO_F32: u32 = 1;

/// One asset the client staged in the assets area and committed, handed to
/// `dsp_asset` on the audio thread. The bytes stay valid until the guest
/// calls `DspHost::asset_release(id)`.
#[repr(C)]
pub struct ClockworkAsset {
    /// `sizeof(ClockworkAsset)`, for the guest to check.
    pub struct_bytes: u32,
    pub id: u32,
    /// A `CLOCKWORK_ASSET_*` value.
    pub kind: u32,
    /// Who committed it; opaque to the guest.
    pub token: u32,
    pub bytes: *const c_void,
    pub byte_count: u32,
    /// `AUDIO_F32` only, else 0.
    pub channels: u32,
    pub frames: u32,
    pub sample_rate: f32,
}

// ── The entry points a guest exports ─────────────────────────────────────────
//
// Declared as function TYPES rather than functions: a guest defines them with
// `#[no_mangle] pub unsafe extern "C" fn dsp_new(...)` and can assert its
// definition against these to be sure of the signature:
//
//     const _: clockwork_abi::dsp_api::DspNewFn = dsp_new;

pub type DspDescribeFn = unsafe extern "C" fn() -> *const DspInfo;
/// The refusal buffer the host passes `dsp_new` is at least this long.
pub const DSP_REFUSAL_BYTES: u32 = 512;
pub type DspNewFn =
    unsafe extern "C" fn(config: *const DspConfig, host: *const DspHost, err: *mut c_char, err_bytes: u32) -> *mut Dsp;
pub type DspFreeFn = unsafe extern "C" fn(dsp: *mut Dsp);
pub type DspProcessFn = unsafe extern "C" fn(
    dsp: *mut Dsp,
    inputs: *const *const f32,
    n_in: u32,
    outputs: *const *mut f32,
    n_out: u32,
    frames: u32,
    block_time: ClockworkTimetag,
);
pub type DspOscFn = unsafe extern "C" fn(
    dsp: *mut Dsp,
    bytes: *const u8,
    len: u32,
    when: ClockworkTimetag,
    token: u32,
    block_time: ClockworkTimetag,
);
/// Return 0 to take the asset, non-zero to refuse it.
pub type DspAssetFn = unsafe extern "C" fn(dsp: *mut Dsp, asset: *const ClockworkAsset) -> c_int;
