// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2026 Sam Aaron
//! `src/clockwork_client.h` — the client boundary: a handle over an engine's
//! memory, wherever that memory is (another process's segment, this address
//! space, a wasm heap), and the calls a client makes through it. The header
//! is the contract; this is its shape.

use core::ffi::{c_char, c_int, c_void};

pub const CLOCKWORK_CLIENT_ABI_VERSION: u32 = 1;

/// `ClockworkStatus`. A newtype, not an enum: a status the header does not
/// list must be a value here, not undefined behaviour.
#[repr(transparent)]
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct ClockworkStatus(pub c_int);

impl ClockworkStatus {
    pub const OK: ClockworkStatus = ClockworkStatus(0);
    pub const E_ARG: ClockworkStatus = ClockworkStatus(1);
    pub const E_VERSION: ClockworkStatus = ClockworkStatus(2);
    pub const E_NOT_FOUND: ClockworkStatus = ClockworkStatus(3);
    pub const E_PERM: ClockworkStatus = ClockworkStatus(4);
    pub const E_ABSENT: ClockworkStatus = ClockworkStatus(5);
    pub const E_FULL: ClockworkStatus = ClockworkStatus(6);
    pub const E_TOO_BIG: ClockworkStatus = ClockworkStatus(7);
    pub const E_CLOSED: ClockworkStatus = ClockworkStatus(8);
    pub const E_NOMEM: ClockworkStatus = ClockworkStatus(9);
    pub const E_NO_INSTANCE: ClockworkStatus = ClockworkStatus(10);
    pub const E_BUSY: ClockworkStatus = ClockworkStatus(11);
    pub const E_TIMEOUT: ClockworkStatus = ClockworkStatus(12);

    pub fn is_ok(self) -> bool { self == Self::OK }
}

/// The handle. Opaque; `ClockworkClient` in C.
#[repr(C)]
pub struct ClockworkClient {
    _opaque: [u8; 0],
}

/// A tap on a ring: a reader with a cursor of its own that consumes nothing.
#[repr(C)]
pub struct ClockworkClientTap {
    _opaque: [u8; 0],
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkClientInfo {
    pub struct_bytes: u32,
    pub abi_version: u32,
    pub engine_version: u32,
    /// `CLOCKWORK_FEATURE_*` bits.
    pub features: u32,
    pub sample_rate: f64,
    pub block_frames: u32,
    pub input_channels: u32,
    pub output_channels: u32,
    /// How many bytes the ring this handle sends into holds; 0 for a reader.
    pub send_ring_bytes: u32,
    /// The largest single message that ring always takes (half of it, less a frame's header); 0 for a reader.
    pub max_message_bytes: u32,
}

pub const CLOCKWORK_FEATURE_TAPS: u32 = 1 << 0;
pub const CLOCKWORK_FEATURE_SCOPE: u32 = 1 << 1;
pub const CLOCKWORK_FEATURE_BULK: u32 = 1 << 2;
pub const CLOCKWORK_FEATURE_WINDOW: u32 = 1 << 3;
pub const CLOCKWORK_FEATURE_SCHEDULER: u32 = 1 << 4;

/// `clockwork_client_wait` with no deadline.
pub const CLOCKWORK_WAIT_FOREVER: u32 = 0xFFFF_FFFF;

/// One frame off the egress, as `clockwork_client_poll` hands it over. The
/// bytes are the ring's and are valid until the next poll.
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ClockworkClientMessage {
    pub bytes: *const u8,
    pub length: u32,
    /// The token the request it answers carried; 0 for one nobody asked for.
    pub token: u32,
    pub sequence: u32,
}

/// `ClockworkRegionId`. A newtype, as [`ClockworkStatus`] is.
#[repr(transparent)]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct ClockworkRegionId(pub c_int);

impl ClockworkRegionId {
    pub const METRICS: ClockworkRegionId = ClockworkRegionId(1);
    pub const WINDOW: ClockworkRegionId = ClockworkRegionId(2);
    pub const ASSETS: ClockworkRegionId = ClockworkRegionId(3);
    pub const RETURNS: ClockworkRegionId = ClockworkRegionId(4);
    pub const TAPS: ClockworkRegionId = ClockworkRegionId(5);
    pub const SCOPE: ClockworkRegionId = ClockworkRegionId(6);
    pub const INGRESS: ClockworkRegionId = ClockworkRegionId(7);
    pub const EGRESS: ClockworkRegionId = ClockworkRegionId(8);
    pub const NATIVE_STATS: ClockworkRegionId = ClockworkRegionId(9);
    pub const PARAMS: ClockworkRegionId = ClockworkRegionId(10);
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ClockworkRegion {
    pub base: *mut c_void,
    pub bytes: u32,
    pub writable: c_int,
}

/// The scope's shape, from the engine's table: slot `i` lies `slot_bytes * i`
/// from the scope region's base, a header of `header_bytes` and a ring of
/// `frames` frames of up to `channels` channels.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkScopeShape {
    pub struct_bytes: u32,
    pub slot_count: u32,
    pub slot_bytes: u32,
    pub header_bytes: u32,
    pub frames: u32,
    pub channels: u32,
}

/// Copies, for a reader that cannot map the engine's memory (clockwork_client.h, "Copies").
pub const CLOCKWORK_COPY_MAGIC: u32 = 0x5950_4F43;
pub const CLOCKWORK_COPY_VERSION: u32 = 1;
/// The arena's header and tables.
pub const CLOCKWORK_COPY_ARENA: u32 = 1 << 0;
/// The metrics, the guest's window and the metrics history, back to back.
pub const CLOCKWORK_COPY_METRICS: u32 = 1 << 1;
/// The parameter table's region, whole or with its generation word odd.
pub const CLOCKWORK_COPY_PARAMS: u32 = 1 << 2;
/// A want's source: a tap slot.
pub const CLOCKWORK_COPY_TAP: u32 = 1;
/// A want's source: the device's scope ([`crate::arena::CLOCKWORK_TAP_OUT`] / [`crate::arena::CLOCKWORK_TAP_IN`]).
pub const CLOCKWORK_COPY_SCOPE: u32 = 2;

/// A window to copy: the newest `frames` frames of `slot` of `source`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkCopyWant {
    pub source: u32,
    pub slot: u32,
    pub frames: u32,
}

/// The front of a copy.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkCopyHeader {
    pub magic: u32,
    pub version: u32,
    pub bytes: u32,
    pub generation: u32,
    pub arena_bytes: u32,
    pub metrics_bytes: u32,
    pub windows: u32,
    pub params_bytes: u32,
}

/// The front of a window in a copy; `frames * channels` floats follow.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkCopyWindow {
    pub source: u32,
    pub slot: u32,
    pub channels: u32,
    pub frames: u32,
    pub activations: u32,
    pub _reserved: u32,
    pub write_position: u64,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkClientClock {
    pub struct_bytes: u32,
    pub bpm: f64,
    pub beat_origin_ntp: f64,
    pub is_playing_at_ntp: f64,
    pub is_playing: i32,
    pub flags: u32,
    pub meter_num: i32,
    pub meter_den: i32,
}

/// Which frame is heard at which NTP instant, as one snapshot. Fill
/// `struct_bytes` with `size_of::<Self>()`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ClockworkClientSampleClock {
    pub struct_bytes: u32,
    pub sample_rate: u32,
    pub engine_frames: u64,
    pub dac_ntp: f64,
    pub output_latency_frames: u32,
}

/// A tap slot reader. Fill `struct_bytes` with `size_of::<Self>()` and
/// `slot`; `clockwork_client_audio_tap_open` fills the rest.
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ClockworkAudioTapReader {
    pub struct_bytes: u32,
    pub slot: u32,
    pub _internal: *mut c_void,
    pub _ring_frames: u32,
}

impl ClockworkAudioTapReader {
    /// A reader for `slot`, ready to hand to `clockwork_client_audio_tap_open`.
    pub const fn for_slot(slot: u32) -> ClockworkAudioTapReader {
        ClockworkAudioTapReader {
            struct_bytes: core::mem::size_of::<ClockworkAudioTapReader>() as u32,
            slot,
            _internal: core::ptr::null_mut(),
            _ring_frames: 0,
        }
    }
}

extern "C" {
    pub fn clockwork_client_abi_version() -> u32;
    pub fn clockwork_client_status_text(s: ClockworkStatus) -> *const c_char;

    pub fn clockwork_client_open_shm(endpoint: *const c_char, secret: *const u8, out_status: *mut ClockworkStatus) -> *mut ClockworkClient;
    pub fn clockwork_client_default_endpoint(port: u32, buf: *mut c_char, cap: u32) -> u32;
    pub fn clockwork_client_open_shm_handle(native_handle: isize, out_status: *mut ClockworkStatus) -> *mut ClockworkClient;
    pub fn clockwork_client_open_shm_peer(endpoint: *const c_char, secret: *const u8, out_status: *mut ClockworkStatus) -> *mut ClockworkClient;
    pub fn clockwork_client_open_shm_peer_handles(reader_handle: isize, command_handle: isize, wake_event: isize, out_status: *mut ClockworkStatus) -> *mut ClockworkClient;
    pub fn clockwork_client_open_memory(base: *mut c_void, bytes: u32, out_status: *mut ClockworkStatus) -> *mut ClockworkClient;
    pub fn clockwork_client_core(c: *const ClockworkClient) -> *mut crate::lanes::ClockworkCore;
    pub fn clockwork_client_close(c: *mut ClockworkClient);

    pub fn clockwork_client_info(c: *mut ClockworkClient, out: *mut ClockworkClientInfo) -> ClockworkStatus;

    pub fn clockwork_client_send(c: *mut ClockworkClient, osc: *const u8, bytes: u32, token: u32) -> ClockworkStatus;
    pub fn clockwork_client_send_begin(c: *mut ClockworkClient, max_bytes: u32, out_status: *mut ClockworkStatus) -> *mut u8;
    pub fn clockwork_client_send_commit(c: *mut ClockworkClient, bytes: u32, token: u32) -> ClockworkStatus;
    pub fn clockwork_client_send_abort(c: *mut ClockworkClient);
    pub fn clockwork_client_poll(c: *mut ClockworkClient, out: *mut ClockworkClientMessage, max: u32) -> u32;
    pub fn clockwork_client_count_undelivered(c: *mut ClockworkClient, n: u32);
    pub fn clockwork_client_wait(c: *mut ClockworkClient, seen: *mut u32, timeout_ms: u32) -> ClockworkStatus;
    pub fn clockwork_client_wake(c: *mut ClockworkClient);

    pub fn clockwork_client_tap_sizeof() -> usize;
    pub fn clockwork_client_tap_open(c: *mut ClockworkClient, ring: u32, out_status: *mut ClockworkStatus) -> *mut ClockworkClientTap;
    pub fn clockwork_client_tap_open_in(
        storage: *mut c_void,
        storage_bytes: usize,
        c: *mut ClockworkClient,
        ring: u32,
        out_status: *mut ClockworkStatus,
    ) -> *mut ClockworkClientTap;
    pub fn clockwork_client_tap_close(t: *mut ClockworkClientTap);
    pub fn clockwork_client_tap_poll(t: *mut ClockworkClientTap, out: *mut ClockworkClientMessage, max: u32) -> u32;
    pub fn clockwork_client_tap_missed(t: *const ClockworkClientTap) -> u64;

    pub fn clockwork_client_region(c: *mut ClockworkClient, id: ClockworkRegionId, out: *mut ClockworkRegion) -> ClockworkStatus;
    pub fn clockwork_client_metrics(c: *mut ClockworkClient, out: *mut u32, max: u32) -> u32;
    pub fn clockwork_client_clock(c: *mut ClockworkClient, out: *mut ClockworkClientClock) -> ClockworkStatus;
    pub fn clockwork_client_beat_at(clock: *const ClockworkClientClock, ntp_seconds: f64) -> f64;
    pub fn clockwork_client_sample_clock(c: *mut ClockworkClient, out: *mut ClockworkClientSampleClock) -> ClockworkStatus;
    pub fn clockwork_client_ntp_at_frame(clock: *const ClockworkClientSampleClock, frame: u64) -> f64;

    pub fn clockwork_client_audio_tap_open(c: *mut ClockworkClient, slot: u32, out: *mut ClockworkAudioTapReader) -> ClockworkStatus;
    pub fn clockwork_client_audio_tap_valid(r: *const ClockworkAudioTapReader) -> c_int;
    pub fn clockwork_client_audio_tap_activations(r: *const ClockworkAudioTapReader) -> u32;
    pub fn clockwork_client_audio_tap_audible_end(c: *mut ClockworkClient, r: *const ClockworkAudioTapReader) -> u64;
    pub fn clockwork_client_audio_tap_read(
        c: *mut ClockworkClient,
        r: *const ClockworkAudioTapReader,
        end: u64,
        frames: u32,
        out: *mut f32,
        out_channels: *mut u32,
    ) -> u32;
    /// The device's scope slots: [`crate::arena::CLOCKWORK_TAP_OUT`] /
    /// [`crate::arena::CLOCKWORK_TAP_IN`].
    pub fn clockwork_client_scope_read(
        c: *mut ClockworkClient,
        slot: u32,
        frames: u32,
        out: *mut f32,
        out_floats: u32,
        out_channels: *mut u32,
    ) -> u32;
    pub fn clockwork_client_scope_shape(c: *mut ClockworkClient, out: *mut ClockworkScopeShape) -> ClockworkStatus;
    pub fn clockwork_client_copy_bytes(c: *mut ClockworkClient, parts: u32, wants: *const ClockworkCopyWant, count: u32) -> u32;
    pub fn clockwork_client_copy(
        c: *mut ClockworkClient,
        parts: u32,
        wants: *const ClockworkCopyWant,
        count: u32,
        out: *mut c_void,
        bytes: u32,
    ) -> u32;
}

