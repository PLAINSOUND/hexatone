// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2026 Sam Aaron
//! The declarations against the headers. A C probe (tests/probe.c) is
//! compiled against src/*.h by the system C compiler and prints every
//! struct's size and every field's offset; each line is compared with the
//! Rust side. A header that moves without this crate moving with it fails
//! here, on the host, before any guest reads a field through the wrong
//! pointer on the audio thread.
//!
//! Host only: it needs a C compiler on PATH (`cc`, or `$CC`). Skipped with a
//! message, not passed, when there is none.

use std::mem::{offset_of, size_of};
use std::path::PathBuf;
use std::process::Command;

use clockwork_abi::client::*;
use clockwork_abi::dsp_api::*;
use clockwork_abi::sink::*;
use clockwork_abi::lanes;
use clockwork_abi::arena::*;
use clockwork_abi::embed::*;
use clockwork_abi::profile::*;
use clockwork_abi::timetag::*;
use clockwork_abi::params::*;

macro_rules! expect {
    ($m:ident, $T:ty { $($f:ident),* $(,)? }) => {{
        $m.push((format!("size {}", stringify!($T)), size_of::<$T>()));
        $( $m.push((format!("field {} {}", stringify!($T), stringify!($f)), offset_of!($T, $f))); )*
    }};
}

#[test]
fn every_struct_is_the_header_s_size_and_every_field_is_at_the_header_s_offset() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let src = root.join("../../src");
    let probe = root.join("tests/probe.c");
    let out = std::env::temp_dir().join(format!("clockwork-abi-probe-{}", std::process::id()));
    let cc = std::env::var("CC").unwrap_or_else(|_| "cc".into());
    let compiled = Command::new(&cc)
        .arg("-std=c11").arg("-I").arg(&src).arg("-o").arg(&out).arg(&probe)
        .status();
    let Ok(status) = compiled else {
        eprintln!("no C compiler ({cc}) on PATH — the layout probe did not run");
        return;
    };
    assert!(status.success(), "the probe did not compile against the headers");
    let output = Command::new(&out).output().expect("run the probe");
    let _ = std::fs::remove_file(&out);
    let text = String::from_utf8(output.stdout).unwrap();

    let mut mine: Vec<(String, usize)> = Vec::new();
    expect!(mine, DspConfig {
        sample_rate, block_size, max_input_channels, max_output_channels, clock, channel_map,
        shm_window, shm_window_bytes, persistent, persistent_bytes, memory, memory_bytes,
        memory_bulk, memory_bulk_bytes, assets, assets_bytes, returns, returns_bytes,
        guest_config, guest_config_bytes, fp_env,
    });
    expect!(mine, DspHost { ctx, emit_osc, log, open_sink, send_sink, free_bytes, asset_release,
        alloc_bytes, tap_open, tap_write, tap_close, flush_schedule, param_define, param_value, param_set });
    {
        use lanes::ClockworkBlockTime;
        expect!(mine, ClockworkBlockTime {
            struct_bytes, output_latency_frames, audio_frames, wall_ntp, monotonic_secs, link_host_micros,
            block_ntp, block_host_micros,
        });
    }
    expect!(mine, ClockworkParamEntry { live, id, kind, unit, flags, group, min, max, def, definer, name, taper, role, text, text_bytes, reserved });
    expect!(mine, ClockworkParamsHeader { magic, version, capacity, count, generation, values_offset, entries_offset, entry_bytes, text_offset, text_capacity, text_used, reserved });
    expect!(mine, DspTapHandle { slot, data, channels, max_frames });
    expect!(mine, DspInfo {
        name, version, holds_schedule, memory_bytes_wanted, memory_bulk_bytes_wanted, wants_events,
        window_magic, window_version, survives, instances,
    });
    expect!(mine, ClockworkAsset {
        struct_bytes, id, kind, token, bytes, byte_count, channels, frames, sample_rate,
    });
    expect!(mine, ClockworkClientInfo {
        struct_bytes, abi_version, engine_version, features, sample_rate, block_frames,
        input_channels, output_channels, send_ring_bytes, max_message_bytes,
    });
    expect!(mine, ClockworkClientMessage { bytes, length, token, sequence });
    expect!(mine, ClockworkRegion { base, bytes, writable });
    expect!(mine, ClockworkScopeShape { struct_bytes, slot_count, slot_bytes, header_bytes, frames, channels });
    expect!(mine, ClockworkCopyWant { source, slot, frames });
    expect!(mine, ClockworkCopyHeader { magic, version, bytes, generation, arena_bytes, metrics_bytes, windows, params_bytes });
    expect!(mine, ClockworkCopyWindow { source, slot, channels, frames, activations, _reserved, write_position });
    expect!(mine, ClockworkClientClock {
        struct_bytes, bpm, beat_origin_ntp, is_playing_at_ntp, is_playing, flags, meter_num, meter_den,
    });
    expect!(mine, ClockworkClientSampleClock {
        struct_bytes, sample_rate, engine_frames, dac_ntp, output_latency_frames,
    });
    expect!(mine, ClockworkAudioTapReader { struct_bytes, slot, _internal, _ring_frames });
    expect!(mine, ClockworkTimetag { ntp });
    expect!(mine, ClockworkSinkStats { sent, dropped, late, scheduled, cancelled });
    expect!(mine, ClockworkStatus {});
    expect!(mine, ClockworkRegionId {});
    expect!(mine, ClockworkSinkKind {});
    expect!(mine, ClockworkSink {});
    expect!(mine, ClockworkEmbedConfig {
        struct_bytes, sample_rate, block_size, input_channels, output_channels, max_render_frames,
        app_name, device, profile, flags, driver, assets_bytes, returns_bytes, guest_config,
        time_origin_ntp,
    });
    expect!(mine, ClockworkProfile {
        struct_bytes, in_ring_bytes, rt_out_ring_bytes, nrt_out_ring_bytes, scope_frames, scope_channels,
        tap_slots, track_tap_slots, tap_ring_frames, window_bytes, persist_bytes,
    });
    expect!(mine, ClockworkEmbedDevice {
        struct_bytes, driver, device, sample_rate, buffer_frames, block_frames,
        input_channels, output_channels, output_latency_frames, input_latency_frames,
    });
    expect!(mine, ClockworkArenaAreaEntry { area, space, base_lo, base_hi, bytes_lo, bytes_hi });
    expect!(mine, ClockworkArenaEntry { id, offset, bytes, owner, audience, cadence, tier, lifetime, geom });
    expect!(mine, ClockworkArenaHeader {
        magic, version, header_bytes, instance_id, arena_bytes, clockwork_bytes, guest_offset,
        guest_bytes, area_count, area_bytes, entry_count, entry_bytes, state, generation, reserved,
        areas, entries,
    });
    let consts: [(&str, i64); 35] = [
        ("CLOCKWORK_E_NO_INSTANCE", ClockworkStatus::E_NO_INSTANCE.0 as i64),
        ("CLOCKWORK_E_TIMEOUT", ClockworkStatus::E_TIMEOUT.0 as i64),
        ("CLOCKWORK_WAIT_FOREVER", CLOCKWORK_WAIT_FOREVER as i64),
        ("CLOCKWORK_AUDIENCE_PUBLIC", ClockworkArenaAudience::PUBLIC.0 as i64),
        ("CLOCKWORK_AUDIENCE_TRANSPORT", ClockworkArenaAudience::TRANSPORT.0 as i64),
        ("CLOCKWORK_AREA_GUEST_PRIVATE", ClockworkArenaArea::GUEST_PRIVATE.0 as i64),
        ("CLOCKWORK_AREA_GUEST_MEMORY_BULK", ClockworkArenaArea::GUEST_MEMORY_BULK.0 as i64),
        ("CLOCKWORK_SPACE_PROCESS", ClockworkArenaSpace::PROCESS.0 as i64),
        ("CLOCKWORK_CADENCE_BOOT", ClockworkArenaCadence::BOOT.0 as i64),
        ("CLOCKWORK_TIER_BULK", ClockworkArenaTier::BULK.0 as i64),
        ("CLOCKWORK_LIFETIME_REBUILD", ClockworkArenaLifetime::REBUILD.0 as i64),
        ("CLOCKWORK_ARENA_MAX_AREAS", CLOCKWORK_ARENA_MAX_AREAS as i64),
        ("CLOCKWORK_ARENA_GEOM_WORDS", CLOCKWORK_ARENA_GEOM_WORDS as i64),
        ("CLOCKWORK_GEOM_WINDOW_VERSION", geom::WINDOW_VERSION as i64),
        ("CLOCKWORK_E_NOMEM", ClockworkStatus::E_NOMEM.0 as i64),
        ("CLOCKWORK_REGION_EGRESS", ClockworkRegionId::EGRESS.0 as i64),
        ("CLOCKWORK_REGION_NATIVE_STATS", ClockworkRegionId::NATIVE_STATS.0 as i64),
        ("CLOCKWORK_REGION_PARAMS", ClockworkRegionId::PARAMS.0 as i64),
        ("kClockworkSinkOsc", ClockworkSinkKind::OSC.0 as i64),
        ("CLOCKWORK_FEATURE_SCHEDULER", CLOCKWORK_FEATURE_SCHEDULER as i64),
        ("CLOCKWORK_WANTS_OSC", lanes::CLOCKWORK_WANTS_OSC as i64),
        ("CLOCKWORK_ASSET_AUDIO_F32", CLOCKWORK_ASSET_AUDIO_F32 as i64),
        ("DSP_FP_ENV_FLUSH_TO_ZERO", DSP_FP_ENV_FLUSH_TO_ZERO as i64),
        ("CLOCKWORK_CLIENT_ABI_VERSION", CLOCKWORK_CLIENT_ABI_VERSION as i64),
        ("CLOCKWORK_RESERVED_LANES_MAX", lanes::CLOCKWORK_RESERVED_LANES_MAX as i64),
        ("CLOCKWORK_ARENA_MAGIC", CLOCKWORK_ARENA_MAGIC as i64),
        ("CLOCKWORK_ARENA_VERSION", CLOCKWORK_ARENA_VERSION as i64),
        ("CLOCKWORK_ARENA_HEADER_BYTES", CLOCKWORK_ARENA_HEADER_BYTES as i64),
        ("CLOCKWORK_ARENA_MAX_ENTRIES", CLOCKWORK_ARENA_MAX_ENTRIES as i64),
        ("CLOCKWORK_TAP_SLOTS_MAX", CLOCKWORK_TAP_SLOTS_MAX as i64),
        ("CLOCKWORK_ARENA_CLOCKWORK_TAPS", ClockworkArenaRegion::CLOCKWORK_TAPS.0 as i64),
        ("CLOCKWORK_OWNER_HOST", ClockworkArenaOwner::HOST.0 as i64),
        ("CLOCKWORK_ARENA_GUEST_PERSIST", ClockworkArenaRegion::GUEST_PERSIST.0 as i64),
        ("CLOCKWORK_GEOM_TAP_TRACK_FIRST", geom::TAP_TRACK_FIRST as i64),
        ("CLOCKWORK_TAP_IN", CLOCKWORK_TAP_IN as i64),
    ];

    // Every line the probe printed must match, and every expectation must
    // have been printed: a field missing from either side is a failure.
    let mut seen = 0;
    for line in text.lines() {
        let parts: Vec<&str> = line.split(' ').collect();
        match parts.as_slice() {
            ["const", name, value] => {
                let (_, mine) = consts.iter().find(|(n, _)| n == name)
                    .unwrap_or_else(|| panic!("the probe printed a constant this crate does not declare: {name}"));
                assert_eq!(*mine, value.parse::<i64>().unwrap(), "{name}");
                seen += 1;
            }
            _ => {
                let key = parts[..parts.len() - 1].join(" ");
                let value: usize = parts[parts.len() - 1].parse().unwrap();
                let (_, mine) = mine.iter().find(|(k, _)| *k == key)
                    .unwrap_or_else(|| panic!("the header has something this crate does not declare: {key}"));
                assert_eq!(*mine, value, "{key}: Rust says {mine}, the header says {value}");
                seen += 1;
            }
        }
    }
    assert_eq!(seen, mine.len() + consts.len(),
        "this crate declares something the probe did not print — add it to tests/probe.c");
}
