// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2026 Sam Aaron
//
// GENERATED FILE — DO NOT EDIT.
// Source of truth: js/lib/metrics_schema.js
// Regenerate with:  npm run gen:metrics-header
// test/metrics_schema.test.mjs fails when this file is out of step with the
// schema, as it does for the C++ twin, src/metrics_schema.h.
//
//! The metrics schema, by name.
//!
//! The engine's counters are a flat `u32` array a client reads as a block
//! ([`crate::Metrics`]); the device layer's own account of its callback is a
//! second, smaller one ([`crate::NativeStats`]). This module says what each
//! word means — the key, unit and description every GUI shows, the same words
//! the web component and a Qt panel use — and gives each table an enum so a
//! reading is asked for as `Metric::AudioSampleRate` rather than as word 42.
//!
//! Offsets are not dense: the schema numbers context metrics the web host
//! merges in after the engine's, and a native engine reports fewer words than
//! the highest offset here. `Metrics::get` answers `None` for a word the
//! engine did not report.

/// One performance metric: `offset` indexes the metrics `u32` array.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FieldInfo {
    pub offset: u32,
    /// The schema key: the stable identifier, shared with the web UI.
    pub key: &'static str,
    /// The unit of measurement; empty for a state.
    pub unit: &'static str,
    pub description: &'static str,
}

/// One native stat: `index` is the `u32` slot within the NATIVE_STATS region.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct NativeStatInfo {
    pub index: u32,
    pub key: &'static str,
    pub unit: &'static str,
    pub description: &'static str,
}

/// A row combining several metrics in one reading ("current | peak", ...).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CompositeInfo {
    pub key: &'static str,
    pub description: &'static str,
}

/// The named bits of each flags metric: `flags::<key>::<NAME>` is the bit
/// that name has in the metric's word.
pub mod flags {
    pub mod engine_subsystems {
        pub const MIDI: u32 = 1 << 0;
        pub const GAMEPAD: u32 = 1 << 1;
        pub const OSC: u32 = 1 << 2;
        pub const LINK: u32 = 1 << 3;
        pub const LINK_AUDIO: u32 = 1 << 4;
        pub const SCHEDULER: u32 = 1 << 5;
    }
}

/// Every performance metric, in offset order.
pub const FIELDS: &[FieldInfo] = &[
    FieldInfo { offset: 0, key: "engineProcessCount", unit: "count", description: "Audio process() calls" },
    FieldInfo { offset: 1, key: "engineMessagesProcessed", unit: "count", description: "Messages drained from the IN ring and dispatched" },
    FieldInfo { offset: 2, key: "engineMessagesDropped", unit: "count", description: "Messages refused on the way in: the IN ring full, or a message too big for it" },
    FieldInfo { offset: 3, key: "engineSchedulerDepth", unit: "count", description: "Current scheduler queue depth" },
    FieldInfo { offset: 4, key: "engineSchedulerPeakDepth", unit: "count", description: "Peak scheduler queue depth (high water mark)" },
    FieldInfo { offset: 5, key: "engineSchedulerDropped", unit: "count", description: "Events dropped because the scheduler queue overflowed" },
    FieldInfo { offset: 6, key: "engineSequenceGaps", unit: "count", description: "Messages lost in transit from host to Clockwork" },
    FieldInfo { offset: 7, key: "engineWasmErrors", unit: "count", description: "WASM execution errors in audio worklet" },
    FieldInfo { offset: 8, key: "engineSchedulerLates", unit: "count", description: "Bundles executed after their scheduled time" },
    FieldInfo { offset: 9, key: "oscOutMessagesSent", unit: "count", description: "OSC messages sent from host to Clockwork" },
    FieldInfo { offset: 10, key: "oscOutBytesSent", unit: "bytes", description: "Total bytes sent from host to Clockwork" },
    FieldInfo { offset: 11, key: "oscInMessagesReceived", unit: "count", description: "OSC replies received from Clockwork" },
    FieldInfo { offset: 12, key: "oscInBytesReceived", unit: "bytes", description: "Total bytes received from Clockwork" },
    FieldInfo { offset: 13, key: "oscInMessagesDropped", unit: "count", description: "Replies lost in transit from Clockwork to host" },
    FieldInfo { offset: 14, key: "oscInCorrupted", unit: "count", description: "Corrupted messages detected in the ring buffer" },
    FieldInfo { offset: 15, key: "debugMessagesReceived", unit: "count", description: "Debug messages from Clockwork" },
    FieldInfo { offset: 16, key: "debugBytesReceived", unit: "bytes", description: "Debug bytes received" },
    FieldInfo { offset: 17, key: "inBufferUsedBytes", unit: "bytes", description: "Bytes used in IN ring buffer" },
    FieldInfo { offset: 18, key: "outBufferUsedBytes", unit: "bytes", description: "Bytes used in OUT ring buffer" },
    FieldInfo { offset: 19, key: "nrtOutBufferUsedBytes", unit: "bytes", description: "Bytes used in NRT-out ring buffer" },
    FieldInfo { offset: 20, key: "inBufferPeakBytes", unit: "bytes", description: "Peak bytes used in IN ring buffer" },
    FieldInfo { offset: 21, key: "outBufferPeakBytes", unit: "bytes", description: "Peak bytes used in OUT ring buffer" },
    FieldInfo { offset: 22, key: "nrtOutBufferPeakBytes", unit: "bytes", description: "Peak bytes used in NRT-out ring buffer" },
    FieldInfo { offset: 23, key: "engineSchedulerMaxLateMs", unit: "ms", description: "Maximum lateness observed in the scheduler (ms)" },
    FieldInfo { offset: 24, key: "engineSchedulerLastLateMs", unit: "ms", description: "Most recent late magnitude in the scheduler (ms)" },
    FieldInfo { offset: 25, key: "engineSchedulerLastLateTick", unit: "count", description: "Process count when the last scheduler late occurred" },
    FieldInfo { offset: 26, key: "ringBufferDirectWriteFails", unit: "count", description: "SAB mode only: direct IN-ring writes that lost the lock race or hit a full ring and were dropped (no fallback)" },
    FieldInfo { offset: 27, key: "linkPeers", unit: "count", description: "Connected Ableton Link peers on the network" },
    FieldInfo { offset: 28, key: "linkTempoMbpm", unit: "milliBpm", description: "Shared Link session tempo" },
    FieldInfo { offset: 29, key: "linkBeatCenti", unit: "centi", description: "Current Link beat position" },
    FieldInfo { offset: 30, key: "linkPhaseCenti", unit: "centi", description: "Phase within the Link quantum" },
    FieldInfo { offset: 31, key: "linkPlaying", unit: "bool", description: "Link transport playing (0/1)" },
    FieldInfo { offset: 32, key: "linkAudioInChannels", unit: "count", description: "Active received Link Audio channels" },
    FieldInfo { offset: 33, key: "linkAudioStreamRate", unit: "Hz", description: "Received Link Audio stream sample rate" },
    FieldInfo { offset: 34, key: "linkAudioUnderruns", unit: "count", description: "Link Audio input frames that arrived too late to play, every input together" },
    FieldInfo { offset: 35, key: "linkAudioBufferedMs", unit: "ms", description: "Received Link Audio held ahead of playback, the most of any input (ms)" },
    FieldInfo { offset: 36, key: "linkAudioDriftPpm", unit: "ppm", description: "Read-rate deviation from the sender's clock (parts per million)" },
    FieldInfo { offset: 37, key: "linkAudioPublish", unit: "bool", description: "Link Audio publishing enabled (0/1)" },
    FieldInfo { offset: 38, key: "linkAudioSinks", unit: "count", description: "Active Link Audio output sinks" },
    FieldInfo { offset: 39, key: "clockworkCommit", unit: "commit", description: "Which Clockwork: the commit it was built from (its first 8 hex digits; 0 when unknown)" },
    FieldInfo { offset: 40, key: "engineSchedulerCapacity", unit: "count", description: "Timed events the scheduler can hold (0 in a build with none)" },
    FieldInfo { offset: 41, key: "engineSchedulerPoolBytes", unit: "bytes", description: "Bytes of timed messages the scheduler can hold (0 in a build with none)" },
    FieldInfo { offset: 42, key: "audioSampleRate", unit: "Hz", description: "Output sample rate" },
    FieldInfo { offset: 43, key: "audioBlockSize", unit: "count", description: "Audio block size in frames per callback" },
    FieldInfo { offset: 44, key: "audioOutputChannels", unit: "count", description: "Output bus channels" },
    FieldInfo { offset: 45, key: "audioInputChannels", unit: "count", description: "Input bus channels" },
    FieldInfo { offset: 46, key: "clockTempoMbpm", unit: "milliBpm", description: "Tempo of the engine's internal ClockworkClock" },
    FieldInfo { offset: 47, key: "clockBeatCenti", unit: "centi", description: "Current ClockworkClock beat position" },
    FieldInfo { offset: 48, key: "clockPhaseCenti", unit: "centi", description: "Phase within the quantum" },
    FieldInfo { offset: 49, key: "clockPlaying", unit: "bool", description: "Transport playing (0/1)" },
    FieldInfo { offset: 50, key: "clockDriftUs", unit: "us", description: "The difference between the audio clock and the wall clock (µs, signed), smoothed; a jump means the audio clock was re-anchored" },
    FieldInfo { offset: 51, key: "clockOffsetMs", unit: "ms", description: "Clock offset for multi-system sync" },
    FieldInfo { offset: 52, key: "audioContextState", unit: "", description: "AudioContext state" },
    FieldInfo { offset: 53, key: "guestPoolUsedBytes", unit: "bytes", description: "Bytes in use in the guest's pool now: what it has allocated from its bulk memory (payloads as carved)" },
    FieldInfo { offset: 54, key: "guestPoolPeakBytes", unit: "bytes", description: "The most bytes ever in use in the guest's pool" },
    FieldInfo { offset: 55, key: "egressFramesRefused", unit: "count", description: "Replies, broadcasts and log lines an egress ring refused, for want of room or for their size: what the clients never got. 0 in a healthy engine" },
    FieldInfo { offset: 56, key: "rustHeapUsedBytes", unit: "bytes", description: "Bytes in use in the rust heap now (the RT router's block)" },
    FieldInfo { offset: 57, key: "rustHeapFallbacks", unit: "count", description: "Rust allocations inside the engine that fell back to the system allocator because the rust heap was full" },
    FieldInfo { offset: 58, key: "guestMallocBytes", unit: "bytes", description: "Bytes the guest holds from malloc: taken inside its entry points with malloc or new and not freed" },
    FieldInfo { offset: 59, key: "guestMallocsProcessing", unit: "count", description: "malloc, calloc or realloc calls the guest made while processing (inside dsp_process, dsp_osc or dsp_asset) since boot; 0 for a guest that allocates only through clockwork" },
    FieldInfo { offset: 60, key: "mallocsAfterBoot", unit: "count", description: "malloc, calloc or realloc calls anywhere in the engine's program since the engine was ready; the memory model says 0" },
    FieldInfo { offset: 61, key: "mallocBytesAfterBoot", unit: "bytes", description: "Bytes taken from malloc since the engine was ready and still held" },
    FieldInfo { offset: 62, key: "egressFramesUndelivered", unit: "count", description: "Replies and broadcasts the transport could not deliver: a client gone, a datagram the socket refused, a peer whose reply ring was full. 0 in a healthy engine" },
    FieldInfo { offset: 63, key: "clockAnchors", unit: "count", description: "Times the audio clock was re-anchored since boot" },
    FieldInfo { offset: 64, key: "engineSchedulerLateDropped", unit: "count", description: "Timed events dropped for coming due later than the host allows (schedulerLateLimitMs); 0 unless a host set a limit" },
    FieldInfo { offset: 65, key: "cuesDropped", unit: "count", description: "Cues the cue port's rate limit dropped: a sender over its rate, or the port over its own. 0 unless someone floods it" },
    FieldInfo { offset: 66, key: "deviceMissedCycles", unit: "count", description: "Cycles the audio driver says the device missed since the engine started (macOS's overload notices, ALSA's xruns): audio that never reached the device. 0 where the driver can't say" },
    FieldInfo { offset: 67, key: "deviceClockJumps", unit: "count", description: "Times the device's own sample clock moved by other than the frames played: audio the device skipped or replayed" },
    FieldInfo { offset: 68, key: "deviceClockJumpFrames", unit: "frames", description: "Frames the device's sample clock skipped over in those jumps" },
    FieldInfo { offset: 69, key: "silentCallbacks", unit: "count", description: "Audio callbacks played as silence for want of a block, once the engine had rendered its first: a control call holding the engine, or no block ready" },
    FieldInfo { offset: 70, key: "callbackGapRecentUs", unit: "us", description: "Longest time between the starts of two audio callbacks, this minute and the last" },
    FieldInfo { offset: 71, key: "callbackGapMaxUs", unit: "us", description: "Longest time between the starts of two audio callbacks since the engine started" },
    FieldInfo { offset: 72, key: "paramsLive", unit: "count", description: "Entries in the parameter table" },
    FieldInfo { offset: 73, key: "paramsGeneration", unit: "count", description: "Times the set of parameters changed" },
    FieldInfo { offset: 74, key: "paramMoves", unit: "count", description: "Times a parameter's value moved" },
    FieldInfo { offset: 75, key: "paramsRefused", unit: "count", description: "Parameter defines and sets refused" },
    FieldInfo { offset: 76, key: "engineSubsystems", unit: "", description: "Subsystems the engine has, one bit each" },
    FieldInfo { offset: 80, key: "inBufferCapacity", unit: "bytes", description: "IN ring buffer capacity" },
    FieldInfo { offset: 81, key: "outBufferCapacity", unit: "bytes", description: "OUT ring buffer capacity" },
    FieldInfo { offset: 82, key: "nrtOutBufferCapacity", unit: "bytes", description: "NRT-out ring buffer capacity" },
    FieldInfo { offset: 83, key: "mode", unit: "", description: "Transport mode" },
    FieldInfo { offset: 84, key: "glitchCount", unit: "count", description: "Chrome only: audio underrun/glitch events" },
    FieldInfo { offset: 85, key: "glitchDurationMs", unit: "ms", description: "Chrome only: total silence from audio underruns" },
    FieldInfo { offset: 86, key: "averageLatencyUs", unit: "us", description: "Chrome only: average audio output latency" },
    FieldInfo { offset: 87, key: "maxLatencyUs", unit: "us", description: "Chrome only: maximum audio output latency" },
    FieldInfo { offset: 88, key: "audioHealthPct", unit: "%", description: "Cross-browser: fraction of expected audio frames delivered (100% = no issues)" },
    FieldInfo { offset: 89, key: "totalFramesDurationMs", unit: "ms", description: "Chrome only: total audio rendered duration" },
    FieldInfo { offset: 90, key: "hasPlaybackStats", unit: "bool", description: "1 if Chrome playbackStats API is available, 0 otherwise" },
];

/// Every native stat, in index order.
pub const NATIVE_STATS: &[NativeStatInfo] = &[
    NativeStatInfo { index: 0, key: "cpuAvgCenti", unit: "centi", description: "Average DSP load: how much of each audio callback's time budget the render consumed, smoothed over the last ~10 callbacks. 100% means rendering ate the whole real-time deadline" },
    NativeStatInfo { index: 1, key: "cpuPeakCenti", unit: "centi", description: "Peak DSP load: spikes show immediately, then decay ~5% per callback so they fade instead of pinning forever. Sustained values near 100% risk audible glitches" },
    NativeStatInfo { index: 2, key: "cbOverruns", unit: "count", description: "Audio callbacks that overran their time budget" },
    NativeStatInfo { index: 3, key: "nrtMaxPassUs", unit: "us", description: "Longest the control thread has spent handling one batch of commands since boot" },
    NativeStatInfo { index: 4, key: "nrtInFlightUs", unit: "us", description: "How long the control thread has been stuck in the command it is handling right now. Anything but 0 means later commands, and every reply behind them, are waiting" },
    NativeStatInfo { index: 5, key: "nrtRecentWorstUs", unit: "us", description: "Longest the control thread has spent handling one batch of commands in the last minute (unlike the since-boot worst, this decays back to quiet)" },
];

/// The composite rows.
pub const COMPOSITES: &[CompositeInfo] = &[
    CompositeInfo { key: "schedulerQueueCurrentPeak", description: "Current | peak scheduler queue depth" },
    CompositeInfo { key: "schedulerLateWorstLast", description: "Worst | most recent late bundle execution (ms)" },
    CompositeInfo { key: "debugCountBytes", description: "Debug messages from Clockwork (count and bytes)" },
    CompositeInfo { key: "oscSentCountBytes", description: "Messages | bytes sent from host to Clockwork" },
    CompositeInfo { key: "oscRecvCountBytes", description: "Messages | bytes received back from Clockwork" },
    CompositeInfo { key: "inRingUsedPeak", description: "Used / peak bytes in the IN ring buffer (host to Clockwork)" },
    CompositeInfo { key: "outRingUsedPeak", description: "Used / peak bytes in the OUT ring buffer (Clockwork replies to host)" },
    CompositeInfo { key: "nrtRingUsedPeak", description: "Used / peak bytes in the NRT-out ring buffer (replies, notifications, debug)" },
    CompositeInfo { key: "linkAudioChannelsRate", description: "Received Link Audio channels and their sample rate" },
    CompositeInfo { key: "linkAudioPublishSinks", description: "Link Audio publishing state (1 = on) | active output sinks" },
    CompositeInfo { key: "busChannelsOutIn", description: "Output | input audio bus channels" },
    CompositeInfo { key: "nrtWorstRecentBoot", description: "Worst control pass in the last minute | since boot (ms)" },
    CompositeInfo { key: "deviceClockJumpsFrames", description: "Times the device's sample clock moved by other than the frames played | the frames it skipped over" },
    CompositeInfo { key: "callbackGapRecentBoot", description: "Longest time between the starts of two audio callbacks, lately | since the engine started (ms)" },
];

/// The performance metrics by name. `m as u32` is the offset.
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Metric {
    EngineProcessCount = 0,
    EngineMessagesProcessed = 1,
    EngineMessagesDropped = 2,
    EngineSchedulerDepth = 3,
    EngineSchedulerPeakDepth = 4,
    EngineSchedulerDropped = 5,
    EngineSequenceGaps = 6,
    EngineWasmErrors = 7,
    EngineSchedulerLates = 8,
    OscOutMessagesSent = 9,
    OscOutBytesSent = 10,
    OscInMessagesReceived = 11,
    OscInBytesReceived = 12,
    OscInMessagesDropped = 13,
    OscInCorrupted = 14,
    DebugMessagesReceived = 15,
    DebugBytesReceived = 16,
    InBufferUsedBytes = 17,
    OutBufferUsedBytes = 18,
    NrtOutBufferUsedBytes = 19,
    InBufferPeakBytes = 20,
    OutBufferPeakBytes = 21,
    NrtOutBufferPeakBytes = 22,
    EngineSchedulerMaxLateMs = 23,
    EngineSchedulerLastLateMs = 24,
    EngineSchedulerLastLateTick = 25,
    RingBufferDirectWriteFails = 26,
    LinkPeers = 27,
    LinkTempoMbpm = 28,
    LinkBeatCenti = 29,
    LinkPhaseCenti = 30,
    LinkPlaying = 31,
    LinkAudioInChannels = 32,
    LinkAudioStreamRate = 33,
    LinkAudioUnderruns = 34,
    LinkAudioBufferedMs = 35,
    LinkAudioDriftPpm = 36,
    LinkAudioPublish = 37,
    LinkAudioSinks = 38,
    ClockworkCommit = 39,
    EngineSchedulerCapacity = 40,
    EngineSchedulerPoolBytes = 41,
    AudioSampleRate = 42,
    AudioBlockSize = 43,
    AudioOutputChannels = 44,
    AudioInputChannels = 45,
    ClockTempoMbpm = 46,
    ClockBeatCenti = 47,
    ClockPhaseCenti = 48,
    ClockPlaying = 49,
    ClockDriftUs = 50,
    ClockOffsetMs = 51,
    AudioContextState = 52,
    GuestPoolUsedBytes = 53,
    GuestPoolPeakBytes = 54,
    EgressFramesRefused = 55,
    RustHeapUsedBytes = 56,
    RustHeapFallbacks = 57,
    GuestMallocBytes = 58,
    GuestMallocsProcessing = 59,
    MallocsAfterBoot = 60,
    MallocBytesAfterBoot = 61,
    EgressFramesUndelivered = 62,
    ClockAnchors = 63,
    EngineSchedulerLateDropped = 64,
    CuesDropped = 65,
    DeviceMissedCycles = 66,
    DeviceClockJumps = 67,
    DeviceClockJumpFrames = 68,
    SilentCallbacks = 69,
    CallbackGapRecentUs = 70,
    CallbackGapMaxUs = 71,
    ParamsLive = 72,
    ParamsGeneration = 73,
    ParamMoves = 74,
    ParamsRefused = 75,
    EngineSubsystems = 76,
    InBufferCapacity = 80,
    OutBufferCapacity = 81,
    NrtOutBufferCapacity = 82,
    Mode = 83,
    GlitchCount = 84,
    GlitchDurationMs = 85,
    AverageLatencyUs = 86,
    MaxLatencyUs = 87,
    AudioHealthPct = 88,
    TotalFramesDurationMs = 89,
    HasPlaybackStats = 90,
}

impl Metric {
    /// Every metric, in offset order.
    pub const ALL: &'static [Metric] = &[Metric::EngineProcessCount, Metric::EngineMessagesProcessed, Metric::EngineMessagesDropped, Metric::EngineSchedulerDepth, Metric::EngineSchedulerPeakDepth, Metric::EngineSchedulerDropped, Metric::EngineSequenceGaps, Metric::EngineWasmErrors, Metric::EngineSchedulerLates, Metric::OscOutMessagesSent, Metric::OscOutBytesSent, Metric::OscInMessagesReceived, Metric::OscInBytesReceived, Metric::OscInMessagesDropped, Metric::OscInCorrupted, Metric::DebugMessagesReceived, Metric::DebugBytesReceived, Metric::InBufferUsedBytes, Metric::OutBufferUsedBytes, Metric::NrtOutBufferUsedBytes, Metric::InBufferPeakBytes, Metric::OutBufferPeakBytes, Metric::NrtOutBufferPeakBytes, Metric::EngineSchedulerMaxLateMs, Metric::EngineSchedulerLastLateMs, Metric::EngineSchedulerLastLateTick, Metric::RingBufferDirectWriteFails, Metric::LinkPeers, Metric::LinkTempoMbpm, Metric::LinkBeatCenti, Metric::LinkPhaseCenti, Metric::LinkPlaying, Metric::LinkAudioInChannels, Metric::LinkAudioStreamRate, Metric::LinkAudioUnderruns, Metric::LinkAudioBufferedMs, Metric::LinkAudioDriftPpm, Metric::LinkAudioPublish, Metric::LinkAudioSinks, Metric::ClockworkCommit, Metric::EngineSchedulerCapacity, Metric::EngineSchedulerPoolBytes, Metric::AudioSampleRate, Metric::AudioBlockSize, Metric::AudioOutputChannels, Metric::AudioInputChannels, Metric::ClockTempoMbpm, Metric::ClockBeatCenti, Metric::ClockPhaseCenti, Metric::ClockPlaying, Metric::ClockDriftUs, Metric::ClockOffsetMs, Metric::AudioContextState, Metric::GuestPoolUsedBytes, Metric::GuestPoolPeakBytes, Metric::EgressFramesRefused, Metric::RustHeapUsedBytes, Metric::RustHeapFallbacks, Metric::GuestMallocBytes, Metric::GuestMallocsProcessing, Metric::MallocsAfterBoot, Metric::MallocBytesAfterBoot, Metric::EgressFramesUndelivered, Metric::ClockAnchors, Metric::EngineSchedulerLateDropped, Metric::CuesDropped, Metric::DeviceMissedCycles, Metric::DeviceClockJumps, Metric::DeviceClockJumpFrames, Metric::SilentCallbacks, Metric::CallbackGapRecentUs, Metric::CallbackGapMaxUs, Metric::ParamsLive, Metric::ParamsGeneration, Metric::ParamMoves, Metric::ParamsRefused, Metric::EngineSubsystems, Metric::InBufferCapacity, Metric::OutBufferCapacity, Metric::NrtOutBufferCapacity, Metric::Mode, Metric::GlitchCount, Metric::GlitchDurationMs, Metric::AverageLatencyUs, Metric::MaxLatencyUs, Metric::AudioHealthPct, Metric::TotalFramesDurationMs, Metric::HasPlaybackStats];

    /// The word this metric is, in the metrics array.
    pub const fn offset(self) -> u32 {
        self as u32
    }

    /// Key, unit and description.
    pub const fn info(self) -> &'static FieldInfo {
        match self {
            Metric::EngineProcessCount => &FIELDS[0],
            Metric::EngineMessagesProcessed => &FIELDS[1],
            Metric::EngineMessagesDropped => &FIELDS[2],
            Metric::EngineSchedulerDepth => &FIELDS[3],
            Metric::EngineSchedulerPeakDepth => &FIELDS[4],
            Metric::EngineSchedulerDropped => &FIELDS[5],
            Metric::EngineSequenceGaps => &FIELDS[6],
            Metric::EngineWasmErrors => &FIELDS[7],
            Metric::EngineSchedulerLates => &FIELDS[8],
            Metric::OscOutMessagesSent => &FIELDS[9],
            Metric::OscOutBytesSent => &FIELDS[10],
            Metric::OscInMessagesReceived => &FIELDS[11],
            Metric::OscInBytesReceived => &FIELDS[12],
            Metric::OscInMessagesDropped => &FIELDS[13],
            Metric::OscInCorrupted => &FIELDS[14],
            Metric::DebugMessagesReceived => &FIELDS[15],
            Metric::DebugBytesReceived => &FIELDS[16],
            Metric::InBufferUsedBytes => &FIELDS[17],
            Metric::OutBufferUsedBytes => &FIELDS[18],
            Metric::NrtOutBufferUsedBytes => &FIELDS[19],
            Metric::InBufferPeakBytes => &FIELDS[20],
            Metric::OutBufferPeakBytes => &FIELDS[21],
            Metric::NrtOutBufferPeakBytes => &FIELDS[22],
            Metric::EngineSchedulerMaxLateMs => &FIELDS[23],
            Metric::EngineSchedulerLastLateMs => &FIELDS[24],
            Metric::EngineSchedulerLastLateTick => &FIELDS[25],
            Metric::RingBufferDirectWriteFails => &FIELDS[26],
            Metric::LinkPeers => &FIELDS[27],
            Metric::LinkTempoMbpm => &FIELDS[28],
            Metric::LinkBeatCenti => &FIELDS[29],
            Metric::LinkPhaseCenti => &FIELDS[30],
            Metric::LinkPlaying => &FIELDS[31],
            Metric::LinkAudioInChannels => &FIELDS[32],
            Metric::LinkAudioStreamRate => &FIELDS[33],
            Metric::LinkAudioUnderruns => &FIELDS[34],
            Metric::LinkAudioBufferedMs => &FIELDS[35],
            Metric::LinkAudioDriftPpm => &FIELDS[36],
            Metric::LinkAudioPublish => &FIELDS[37],
            Metric::LinkAudioSinks => &FIELDS[38],
            Metric::ClockworkCommit => &FIELDS[39],
            Metric::EngineSchedulerCapacity => &FIELDS[40],
            Metric::EngineSchedulerPoolBytes => &FIELDS[41],
            Metric::AudioSampleRate => &FIELDS[42],
            Metric::AudioBlockSize => &FIELDS[43],
            Metric::AudioOutputChannels => &FIELDS[44],
            Metric::AudioInputChannels => &FIELDS[45],
            Metric::ClockTempoMbpm => &FIELDS[46],
            Metric::ClockBeatCenti => &FIELDS[47],
            Metric::ClockPhaseCenti => &FIELDS[48],
            Metric::ClockPlaying => &FIELDS[49],
            Metric::ClockDriftUs => &FIELDS[50],
            Metric::ClockOffsetMs => &FIELDS[51],
            Metric::AudioContextState => &FIELDS[52],
            Metric::GuestPoolUsedBytes => &FIELDS[53],
            Metric::GuestPoolPeakBytes => &FIELDS[54],
            Metric::EgressFramesRefused => &FIELDS[55],
            Metric::RustHeapUsedBytes => &FIELDS[56],
            Metric::RustHeapFallbacks => &FIELDS[57],
            Metric::GuestMallocBytes => &FIELDS[58],
            Metric::GuestMallocsProcessing => &FIELDS[59],
            Metric::MallocsAfterBoot => &FIELDS[60],
            Metric::MallocBytesAfterBoot => &FIELDS[61],
            Metric::EgressFramesUndelivered => &FIELDS[62],
            Metric::ClockAnchors => &FIELDS[63],
            Metric::EngineSchedulerLateDropped => &FIELDS[64],
            Metric::CuesDropped => &FIELDS[65],
            Metric::DeviceMissedCycles => &FIELDS[66],
            Metric::DeviceClockJumps => &FIELDS[67],
            Metric::DeviceClockJumpFrames => &FIELDS[68],
            Metric::SilentCallbacks => &FIELDS[69],
            Metric::CallbackGapRecentUs => &FIELDS[70],
            Metric::CallbackGapMaxUs => &FIELDS[71],
            Metric::ParamsLive => &FIELDS[72],
            Metric::ParamsGeneration => &FIELDS[73],
            Metric::ParamMoves => &FIELDS[74],
            Metric::ParamsRefused => &FIELDS[75],
            Metric::EngineSubsystems => &FIELDS[76],
            Metric::InBufferCapacity => &FIELDS[77],
            Metric::OutBufferCapacity => &FIELDS[78],
            Metric::NrtOutBufferCapacity => &FIELDS[79],
            Metric::Mode => &FIELDS[80],
            Metric::GlitchCount => &FIELDS[81],
            Metric::GlitchDurationMs => &FIELDS[82],
            Metric::AverageLatencyUs => &FIELDS[83],
            Metric::MaxLatencyUs => &FIELDS[84],
            Metric::AudioHealthPct => &FIELDS[85],
            Metric::TotalFramesDurationMs => &FIELDS[86],
            Metric::HasPlaybackStats => &FIELDS[87],
        }
    }

    /// The schema key.
    pub const fn key(self) -> &'static str {
        self.info().key
    }
}

/// The native stats by name. `s as u32` is the slot.
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum NativeStat {
    CpuAvgCenti = 0,
    CpuPeakCenti = 1,
    CbOverruns = 2,
    NrtMaxPassUs = 3,
    NrtInFlightUs = 4,
    NrtRecentWorstUs = 5,
}

impl NativeStat {
    /// Every native stat, in index order.
    pub const ALL: &'static [NativeStat] = &[NativeStat::CpuAvgCenti, NativeStat::CpuPeakCenti, NativeStat::CbOverruns, NativeStat::NrtMaxPassUs, NativeStat::NrtInFlightUs, NativeStat::NrtRecentWorstUs];

    /// The slot this stat is, in the NATIVE_STATS region.
    pub const fn index(self) -> u32 {
        self as u32
    }

    /// Key, unit and description.
    pub const fn info(self) -> &'static NativeStatInfo {
        match self {
            NativeStat::CpuAvgCenti => &NATIVE_STATS[0],
            NativeStat::CpuPeakCenti => &NATIVE_STATS[1],
            NativeStat::CbOverruns => &NATIVE_STATS[2],
            NativeStat::NrtMaxPassUs => &NATIVE_STATS[3],
            NativeStat::NrtInFlightUs => &NATIVE_STATS[4],
            NativeStat::NrtRecentWorstUs => &NATIVE_STATS[5],
        }
    }

    /// The schema key.
    pub const fn key(self) -> &'static str {
        self.info().key
    }
}
