// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Clockwork-Commercial
// Copyright (c) 2025-2026 Sam Aaron
//! Disk endpoints for the port substrate.
//!
//! Two of them, in opposite directions: a worker that streams a WAV file into
//! a source port, and one that drains a sink port to a WAV file. Between them
//! they are the sample streamed from disk in `docs/PORTS.md` and the
//! recording path.
//!
//! # Why a separate crate
//!
//! `clockwork-ports` must mention no endpoint at all, and the cheapest way to
//! guarantee that is a dependency edge that only runs one way. This crate
//! depends on the substrate; the substrate cannot depend on this one without
//! a cycle cargo would refuse. The rule is therefore checked by the build
//! rather than by review.
//!
//! The same shape is what a Link endpoint would take: a crate that owns a
//! `LinkAudioBridge` handle, produces peer audio into a source port and
//! consumes aux output from a sink port, and touches nothing in the substrate.

pub mod ffi;
pub mod pace;
pub mod sink;
pub mod source;
pub mod wav;

/// The port a worker runs on: the table it is in, its handle there, and
/// its channel count as the worker found it at open.
pub(crate) struct Feed<'a> {
    pub ports: &'a clockwork_ports::registry::Ports,
    pub port: u32,
    pub channels: usize,
}
